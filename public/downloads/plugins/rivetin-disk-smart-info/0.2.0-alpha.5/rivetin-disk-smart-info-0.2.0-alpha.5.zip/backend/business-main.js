// A2 dynamic business-backend entrypoint: mTLS invoke on 9443 + local health on
// 18081. The runtime ConfigMap contract (§3.2) does not carry methods; the method
// table comes from the installed package's metadata.backend declaration.
import { readFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { createBusinessBackend } from './business-runtime.js';
import { loadTowerApi } from './tower-api.js';

const contractPath = '/run/rivetin/runtime/backend-contract.json';
const contractFields = new Set(['schemaVersion', 'workloadId', 'capability', 'interfaceVersion', 'frameworkOrigin',
  'frameworkPin', 'dataStoreId', 'limits']);
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const pin = /^[a-f0-9]{64}$/;
const logUnconfigured = () => console.log(JSON.stringify({ time: new Date().toISOString(), level: 'WARN',
  component: 'rivetin-disk-smart-info', event: 'cloudtower_unconfigured' }));

/**
 * Validate the A2 §3.2 backend-contract.json (no methods) and overlay the
 * installed package's declared method/needs table for runtime dispatch.
 */
export function validateBackendContract(contract, metadata) {
  const backend = metadata?.backend;
  if (!contract || typeof contract !== 'object' || Array.isArray(contract) ||
      Object.keys(contract).some(key => !contractFields.has(key)) ||
      contract.schemaVersion !== 1 || contract.workloadId !== metadata?.id ||
      typeof contract.capability !== 'string' || contract.capability !== backend?.capability ||
      contract.interfaceVersion !== backend?.interfaceVersion ||
      typeof contract.frameworkOrigin !== 'string' || !/^https:\/\/[^\s]+$/.test(contract.frameworkOrigin) ||
      typeof contract.frameworkPin !== 'string' || !pin.test(contract.frameworkPin) ||
      typeof contract.dataStoreId !== 'string' || !uuid.test(contract.dataStoreId) ||
      !contract.limits || typeof contract.limits !== 'object' || Array.isArray(contract.limits) ||
      !Number.isSafeInteger(contract.limits.requestBytes) || contract.limits.requestBytes < 1 ||
      !Number.isSafeInteger(contract.limits.responseBytes) || contract.limits.responseBytes < 1) {
    throw new Error('SMART_BACKEND_CONTRACT_INVALID');
  }
  if (!backend || !backend.methods || typeof backend.methods !== 'object' || Array.isArray(backend.methods) ||
      !Object.keys(backend.methods).length) throw new Error('SMART_BACKEND_DECLARATION_INVALID');
  return { ...contract, methods: { ...backend.methods }, ...(backend.needs ? { needs: backend.needs } : {}) };
}

export async function startBusinessBackend(metadata) {
  const contract = JSON.parse(await readFile(contractPath, 'utf8'));
  const runtimeContract = validateBackendContract(contract, metadata);
  const identityValue = /^[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,61}[A-Za-z0-9])?$/;
  if (!identityValue.test(process.env.RIVETIN_INSTANCE_ID || '') || !uuid.test(process.env.RIVETIN_POD_UID || '') ||
      !/^[1-9][0-9]*$/.test(process.env.RIVETIN_GENERATION || '') || !Number.isSafeInteger(Number(process.env.RIVETIN_GENERATION))) {
    throw new Error('SMART_IDENTITY_INVALID');
  }
  if (typeof process.getuid === 'function' && process.getuid() === 0) throw new Error('SMART_NON_ROOT_REQUIRED');
  const tls = { ca: await readFile('/run/rivetin/tls/ca.crt'), cert: await readFile('/run/rivetin/tls/tls.crt'),
    key: await readFile('/run/rivetin/tls/tls.key') };
  const identity = { transportVersion: 1, instanceId: process.env.RIVETIN_INSTANCE_ID, generation: Number(process.env.RIVETIN_GENERATION) };
  const tower = await loadTowerApi();
  if (tower === null) logUnconfigured();
  const runtime = await createBusinessBackend({ directory: process.env.RIVETIN_DATA || '/data', contract: runtimeContract,
    tls, identity, request: tower?.request });
  const log = (level, event, state) => console.log(JSON.stringify({ time: new Date().toISOString(), level,
    component: metadata.id, version: metadata.version, event, state }));
  let lastReady = null;
  const checkReady = async () => {
    const ready = await runtime.ready();
    if (ready !== lastReady) { lastReady = ready; log('INFO', 'state_changed', ready ? 'ready' : 'not_ready'); }
    return ready;
  };
  await new Promise((resolve, reject) => { runtime.server.once('error', reject); runtime.server.listen(9443, '0.0.0.0', resolve); });
  const health = createServer(async (request, response) => {
    if (request.method !== 'GET' || !['/live', '/ready'].includes(request.url)) return response.writeHead(404).end();
    const ready = request.url === '/live' || await checkReady();
    response.writeHead(ready ? 200 : 503, { 'content-type': 'text/plain', 'cache-control': 'no-store' }).end(ready ? 'ok\n' : 'unavailable\n');
  });
  await new Promise((resolve, reject) => { health.once('error', reject); health.listen(18081, '127.0.0.1', resolve); });
  runtime.start();
  let stopping = false;
  const shutdown = async () => {
    if (stopping) return;
    stopping = true;
    const timer = setTimeout(() => process.exit(1), 20000);
    await new Promise(resolve => health.close(resolve));
    await runtime.stop();
    clearTimeout(timer);
    log('INFO', 'stopped', 'stopped');
  };
  process.once('SIGTERM', () => void shutdown());
  process.once('SIGINT', () => void shutdown());
  return { runtime, health };
}
