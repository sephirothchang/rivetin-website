// A2 dynamic business backend runtime: read-only identity/history plus the SMART
// collection and batch orchestration absorbed into the Pod.
import { randomUUID } from 'node:crypto';
import { createBackendServer, createPeerClient } from './server/workload-http.js';
import { createPermitMonitor } from './server/workload-permit.js';
import { createReadOnlyProvider } from './read-only.js';
import { createTowerDiskReaders } from './tower-inventory.js';
import { createSshChannelAdapter } from './ssh-channel.js';
import { createSmartCollection } from './server/smart-collection.js';
import { createSmartBatch } from './server/smart-batch.js';

const actorOk = actor => actor && typeof actor.id === 'string' && ['tower', 'cli', 'demo'].includes(actor.source);
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const exact = (value, keys) => object(value) && Object.keys(value).sort().join() === [...keys].sort().join();
const failure = (code, status = 503) => Object.assign(new Error(code), { status });

/** Pure dispatcher/authorizer used by the runtime and unit tests. */
export function createBusinessHandlers({ contract, directory, request, call }) {
  if (!object(contract) || typeof contract.capability !== 'string' || !object(contract.methods)) throw new Error('SMART_CONTRACT_INVALID');
  const inventory = request ? createTowerDiskReaders({ request }) : {
    async readDisk() { throw failure('SMART_TOWER_UNCONFIGURED'); },
    async readDiskInventory() { throw failure('SMART_TOWER_UNCONFIGURED'); },
  };
  const ssh = call ? createSshChannelAdapter({ call }) : null;
  const readOnly = createReadOnlyProvider(directory, { ...inventory, ssh });
  const broker = ssh ? {
    selectSmartTarget: (pluginId, target, actor) => ssh.selectSmartTarget({ pluginId, ...target }, actor),
    snapshotSmartSelections: (pluginId, actor) => ssh.snapshotSmartSelections({ pluginId }, actor),
    runTarget: (selection, actor, options) => ssh.runTarget({ selection }, actor, options),
  } : null;
  const collection = broker ? createSmartCollection(directory, { provider: readOnly, broker }) : null;
  const batch = collection ? createSmartBatch(directory, { provider: readOnly, broker, collection }) : null;
  let recovered = false;
  const recover = async () => {
    if (recovered) return;
    await Promise.all([collection?.recoverNow?.(), batch?.recoverNow?.()]);
    recovered = true;
  };
  const capability = contract.capability;
  const methods = contract.methods;
  const handlers = {
    readInventory: (input, actor) => readOnly.readInventory({ diskId: input.diskId, actor }),
    resolveDisk: (input, actor) => readOnly.resolveDisk({ diskId: input.diskId, actor }),
    readLatest: (input, actor) => readOnly.readLatest({ identity: input.identity, actor }),
    readHistory: (input, actor) => readOnly.readHistory({ identity: input.identity, limit: input.limit, cursor: input.cursor, actor }),
    bindings: (input, actor) => readOnly.bindings({ actor }),
    bind: () => { throw failure('SMART_COLLECTION_UNAVAILABLE'); },
    unbind: () => { throw failure('SMART_COLLECTION_UNAVAILABLE'); },
    async collect(input, actor, value) {
      if (!collection) throw failure('SMART_COLLECTION_UNAVAILABLE');
      await recover();
      return collection.submit({ pluginId: 'rivetin-disk-smart-info', diskId: input.identity.diskId,
        generation: input.identity.generation, actor, requestId: input.requestId });
    },
    async collection(input, actor, value) {
      if (!collection) throw failure('SMART_COLLECTION_UNAVAILABLE');
      await recover();
      const operationId = value?.operationId ?? input.operationId;
      if (!operationId) throw failure('SMART_COLLECTION_REQUEST_INVALID', 400);
      return collection.get({ pluginId: 'rivetin-disk-smart-info', diskId: input.identity.diskId,
        generation: input.identity.generation, actor, operationId });
    },
    async collectAll(input, actor) {
      if (!batch) throw failure('SMART_COLLECTION_UNAVAILABLE');
      await recover();
      return batch.submit({ pluginId: 'rivetin-disk-smart-info', actor, requestId: input.requestId });
    },
    async collectionAll(input, actor, value) {
      if (!batch) throw failure('SMART_COLLECTION_UNAVAILABLE');
      await recover();
      const operationId = value?.operationId ?? input.operationId;
      if (!operationId) throw failure('SMART_COLLECTION_REQUEST_INVALID', 400);
      return batch.get({ pluginId: 'rivetin-disk-smart-info', actor, operationId });
    },
  };
  function handler(method) {
    const prefix = capability.split('.')[0] + '.';
    if (typeof method !== 'string' || !method.startsWith(prefix)) return null;
    return handlers[method.slice(prefix.length)] ?? null;
  }
  function validInput(method, input) {
    if (method.endsWith('readInventory') || method.endsWith('resolveDisk')) return exact(input, ['schemaVersion', 'diskId']);
    if (method.endsWith('readLatest')) return exact(input, ['schemaVersion', 'identity']);
    if (method.endsWith('readHistory')) return exact(input, ['schemaVersion', 'identity', 'limit', 'cursor']) ||
      exact(input, ['schemaVersion', 'identity', 'limit']) || exact(input, ['schemaVersion', 'identity']);
    if (method.endsWith('collect')) return exact(input, ['schemaVersion', 'identity', 'requestId']);
    if (method.endsWith('collection')) return exact(input, ['schemaVersion', 'identity']);
    if (method.endsWith('collectAll')) return exact(input, ['schemaVersion', 'requestId']);
    if (method.endsWith('collectionAll')) return exact(input, ['schemaVersion']);
    if (method.endsWith('bindings')) return exact(input, ['schemaVersion']);
    return true;
  }
  return {
    capability, methods, ssh, collection, batch,
    authorize(value, permits) {
      return Boolean(permits?.current()) && object(value) && value.capability === capability &&
        value.interfaceVersion === contract.interfaceVersion && Object.hasOwn(methods, value.method) &&
        methods[value.method] === value.kind && actorOk(value.caller) && value.caller.role === 'ROOT' &&
        value.caller.admin === true && value.caller.pluginId === null && value.credentialLeaseId === null;
    },
    async execute(value, { signal } = {}) {
      const run = handler(value?.method);
      if (!run) throw failure('SMART_REQUEST_INVALID', 400);
      if (!validInput(value.method, value.input)) throw failure('SMART_REQUEST_INVALID', 400);
      if (signal?.aborted) throw failure('SMART_EXECUTION_CANCELLED', 409);
      const input = value.input?.identity ? { ...value.input, identity: { ...value.input.identity, path: value.input.identity.path ?? '' } } : value.input;
      return run(input, value.caller, value);
    },
  };
}

export async function createBusinessBackend({ directory, contract, tls, identity, permits, framework, request, call, permitFactory = createPermitMonitor, serverFactory = createBackendServer }) {
  if (!object(contract)) throw new Error('SMART_CONTRACT_INVALID');
  const peer = framework ?? createPeerClient({ origin: contract.frameworkOrigin, tls, serverPin: contract.frameworkPin });
  let paused = false;
  // onPause closes admission after a permit failure; onGrant re-opens it once the
  // framework admits this Pod again. Without the grant reset, one transient 403
  // during a framework restart would leave the business backend not_ready until
  // the Pod process itself was restarted.
  const monitor = permits ?? permitFactory({ renew: () => peer.permit(identity),
    onPause: async () => { paused = true; }, onGrant: () => { paused = false; } });
  const callNeeds = typeof call === 'function' ? call : async (capability, method, input, actor, { operationId, signal } = {}) => {
    const kind = method === 'runTarget' ? 'submit' : 'read';
    const requestId = randomUUID(), operation = operationId ?? (kind === 'submit' ? randomUUID() : null);
    return peer.call({ transportVersion: 1, instanceId: identity.instanceId, generation: identity.generation,
      requestId, operationId: operation, capability, interfaceVersion: 1, method, kind, input }, monitor.current(), { signal });
  };
  const handlers = createBusinessHandlers({ contract, directory, request, call: callNeeds });
  const ready = async () => !paused && Boolean(monitor.current());
  const server = serverFactory({ tls, frameworkPin: contract.frameworkPin, identity, permits: monitor, framework: peer,
    execute: (value, options) => handlers.execute(value, options), authorize: value => handlers.authorize(value, monitor), ready });
  return { server, handlers, ready, start: () => monitor.start(),
    async stop() { paused = true; await monitor.stop(); await new Promise(resolve => server.close(resolve)); } };
}
