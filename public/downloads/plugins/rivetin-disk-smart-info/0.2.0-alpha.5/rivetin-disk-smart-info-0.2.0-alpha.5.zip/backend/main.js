import { createServer } from 'node:http';
import { access, readFile } from 'node:fs/promises';
import { createSmartRuntime } from './runtime.js';
import { startBusinessBackend } from './business-main.js';

const backendContract = '/run/rivetin/runtime/backend-contract.json';

async function main() {
  const metadata = JSON.parse(await readFile(new URL('../metadata', import.meta.url), 'utf8'));
  if (metadata.id !== 'rivetin-disk-smart-info' || typeof metadata.version !== 'string') throw new Error('SMART_METADATA_INVALID');
  let business = false;
  try { await access(backendContract); business = true; }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  if (business) return await startBusinessBackend(metadata);
  const config = JSON.parse(await readFile('/run/rivetin/runtime/smart.json', 'utf8'));
  if (!config || Object.keys(config).sort().join(',') !== 'frameworkOrigin,frameworkPin') throw new Error('SMART_CONFIG_INVALID');
  if (typeof process.getuid === 'function' && process.getuid() === 0) throw new Error('SMART_NON_ROOT_REQUIRED');
  const generation = process.env.RIVETIN_GENERATION;
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const installation = /^[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,61}[A-Za-z0-9])?$/;
  if (!installation.test(process.env.RIVETIN_INSTANCE_ID || '') || ![process.env.RIVETIN_WORKLOAD_ID, process.env.RIVETIN_POD_UID].every(value => uuid.test(value || '')) || !/^[1-9][0-9]*$/.test(generation || '') || !Number.isSafeInteger(Number(generation))) throw new Error('SMART_IDENTITY_INVALID');
  const tls = { ca: await readFile('/run/rivetin/tls/ca.crt'), cert: await readFile('/run/rivetin/tls/tls.crt'), key: await readFile('/run/rivetin/tls/tls.key') };
  const identity = { transportVersion: 1, instanceId: process.env.RIVETIN_WORKLOAD_ID, generation: Number(generation) };
  const runtime = await createSmartRuntime({ directory: '/data', tls, identity, ...config });
  const log = (level, event, state) => console.log(JSON.stringify({ time: new Date().toISOString(), level, component: metadata.id, version: metadata.version, event, state }));
  let lastReady = null;
  const checkReady = async () => {
    const ready = await runtime.ready();
    if (ready !== lastReady) { lastReady = ready; log('INFO', 'state_changed', ready ? 'ready' : 'not_ready'); }
    return ready;
  };
  await new Promise((resolve, reject) => { runtime.server.once('error', reject); runtime.server.listen(9443, '0.0.0.0', resolve); });
  const health = createServer(async (request, response) => {
    if (request.method !== 'GET' || !['/live', '/ready'].includes(request.url)) return response.writeHead(404).end();
    const ready = request.url === '/live' || await checkReady();
    response.writeHead(ready ? 200 : 503, { 'content-type': 'text/plain', 'cache-control': 'no-store' }).end(ready ? 'ok\n' : 'unavailable\n');
  });
  await new Promise((resolve, reject) => { health.once('error', reject); health.listen(18081, '127.0.0.1', resolve); });
  runtime.start();
  log('INFO', 'started', 'starting');
  const statusTimer = setInterval(() => { void checkReady().then(ready => log('INFO', 'status', ready ? 'ready' : 'not_ready')); }, 30000);
  statusTimer.unref();
  let stopping = false;
  const shutdown = async () => {
    if (stopping) return;
    stopping = true;
    clearInterval(statusTimer);
    const timer = setTimeout(() => process.exit(1), 20000);
    await new Promise(resolve => health.close(resolve));
    await runtime.stop();
    clearTimeout(timer);
    log('INFO', 'stopped', 'stopped');
  };
  process.once('SIGTERM', () => void shutdown());
  process.once('SIGINT', () => void shutdown());
}

main().catch(error => { process.stderr.write('SMART_RUNTIME_START_FAILED ' + (error?.message || '') + '\n'); process.exitCode = 1; });
