// Read-only SMART surface implemented inside the Pod.
//
// It owns the physical-disk identity key and history directory under /data. The
// binding/collection orchestration is intentionally not part of this slice: bind,
// unbind and mutation methods are deferred to the collection migration and return
// an explicit unavailable code here.
import path from 'node:path';
import { readFile } from 'node:fs/promises';
import { createHash, createHmac, randomBytes } from 'node:crypto';
import { createSmartHistory, validateHistorySmart } from './server/smart-history.js';
import { atomic } from './server/storage.js';

const pluginId = 'rivetin-disk-smart-info';
const identifier = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(value);
const hex = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = (value, max) => typeof value === 'string' && value.length > 0 && value.length <= max && !/[\x00-\x1f\x7f]/.test(value);
const actorOk = actor => object(actor) && text(actor.id, 128) && ['tower', 'cli', 'demo'].includes(actor.source);
const source = 'host-smartctl';
const failure = (code, status = 503) => Object.assign(new Error(code), { status });
const exact = (value, keys) => object(value) && Object.keys(value).sort().join() === [...keys].sort().join();

export function validateIdentity(value) {
  if (!object(value) || !identifier(value.diskId) || !identifier(value.hostId) || !hex(value.generation) ||
      value.deviceId !== value.generation || value.path !== '' || typeof value.model !== 'string' || value.model.length > 512) {
    throw failure('SMART_IDENTITY_INVALID', 400);
  }
  return { diskId: value.diskId, hostId: value.hostId, generation: value.generation, deviceId: value.deviceId, path: '', model: value.model };
}

export function createReadOnlyProvider(directory, { readDisk, readDiskInventory = readDisk, history = createSmartHistory(directory), ssh, now = Date.now } = {}) {
  if (typeof readDisk !== 'function' || typeof readDiskInventory !== 'function' ||
      !history || !['latest', 'page'].every(name => typeof history[name] === 'function')) throw new Error('SMART_PROVIDER_REQUIRED');
  const root = path.join(path.resolve(directory), 'smart-provider');
  const keyFile = path.join(root, 'key.json');
  async function key(create = true) {
    try {
      const value = JSON.parse(await readFile(keyFile, 'utf8'));
      if (!exact(value, ['version', 'key']) || value.version !== 1 || !hex(value.key)) throw failure('SMART_PROVIDER_CORRUPT');
      return Buffer.from(value.key, 'hex');
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      if (!create) return null;
      const value = { version: 1, key: randomBytes(32).toString('hex') };
      await atomic(keyFile, value);
      return Buffer.from(value.key, 'hex');
    }
  }
  const hmac = (secret, purpose, value) => createHmac('sha256', secret).update(purpose + '\0' + JSON.stringify(value)).digest('hex');
  const generationFor = (secret, tower) => hmac(secret, 'physical-disk-generation-v1',
    { diskId: tower.id, hostId: tower.hostId, serial: tower.serial });
  const generation = generationFor;
  const snapshot = (record, identity) => record === null ? { schemaVersion: 1, source, identity, status: 'unavailable',
    code: 'SMART_NO_SAMPLE', collectedAt: null } : { schemaVersion: 1, source, identity, status: record.status,
    collectedAt: record.collectedAt, ...(record.status === 'ok' ? { smart: record.smart } : { code: record.code }),
    ...(record.gapCode ? { gapCode: record.gapCode } : {}) };
  const historyRead = async task => {
    try { return await task(); } catch (error) {
      if (/^SMART_HISTORY_CURSOR_(?:INVALID|EXPIRED)$/.test(error.message)) throw failure(error.message, 400);
      if (error.message === 'SMART_HISTORY_CURSOR_STALE') throw failure(error.message, 409);
      if (error.message === 'SMART_HISTORY_PAGE_LIMIT_INVALID') throw failure(error.message, 400);
      throw failure('SMART_HISTORY_UNAVAILABLE');
    }
  };
  const scope = identity => ({ pluginId, diskId: identity.diskId, hostId: identity.hostId, generation: identity.generation });
  return Object.freeze({
    async readInventory({ diskId, actor } = {}) {
      if (!identifier(diskId)) throw failure('SMART_DISK_REQUEST_INVALID', 400);
      if (!actorOk(actor)) throw failure('AUTHENTICATION_REQUIRED', 401);
      const tower = await readDiskInventory({ diskId, actor });
      if (!tower || tower.id !== diskId) throw failure('SMART_DISK_RESPONSE_INVALID');
      return { schemaVersion: 1, disk: { diskId: tower.id, model: tower.model } };
    },
    async resolveDisk({ diskId, actor } = {}) {
      if (!identifier(diskId)) throw failure('SMART_DISK_REQUEST_INVALID', 400);
      if (!actorOk(actor)) throw failure('AUTHENTICATION_REQUIRED', 401);
      const tower = await readDisk({ diskId, actor });
      if (!tower || tower.id !== diskId) throw failure('SMART_DISK_RESPONSE_INVALID');
      return { diskId: tower.id, hostId: tower.hostId, generation: generation(await key(), tower),
        deviceId: generation(await key(), tower), path: '', model: tower.model };
    },
    async readLatest({ identity, actor } = {}) {
      if (!actorOk(actor)) throw failure('AUTHENTICATION_REQUIRED', 401);
      const value = validateIdentity(identity);
      const result = await historyRead(() => history.latest(scope(value)));
      return snapshot(result.record, value);
    },
    async readHistory({ identity, limit = 30, cursor = null, actor } = {}) {
      if (!actorOk(actor)) throw failure('AUTHENTICATION_REQUIRED', 401);
      const value = validateIdentity(identity);
      if (!Number.isInteger(limit) || limit < 1 || limit > 30 || cursor !== null && (typeof cursor !== 'string' || cursor.length > 4096)) {
        throw failure('SMART_HISTORY_REQUEST_INVALID', 400);
      }
      const result = await historyRead(() => history.page({ ...scope(value), limit, ...(cursor === null ? {} : { cursor }) }));
      return { schemaVersion: 1, source, identity: value, items: result.items.map(record => snapshot(record, value)),
        nextCursor: result.nextCursor, snapshotAt: result.snapshotAt };
    },
    async collectionTarget({ pluginId, diskId, generation, actor } = {}) {
      if (!actorOk(actor) || actor.admin !== true) throw failure('ADMIN_REQUIRED', 403);
      if (!text(pluginId, 100) || !identifier(diskId) || !hex(generation)) throw failure('SMART_COLLECTION_REQUEST_INVALID', 400);
      const tower = await readDisk({ diskId, actor });
      if (!tower || tower.id !== diskId) throw failure('SMART_DISK_RESPONSE_INVALID');
      const secret = await key(), actual = generationFor(secret, tower);
      if (actual !== generation) throw failure('SMART_GENERATION_CHANGED', 409);
      return { profileHostId: tower.hostId, deviceId: tower.id, generation, bindingToken: generation };
    },
    async collectionCandidates({ pluginId, actor } = {}) {
      if (!actorOk(actor) || actor.admin !== true) throw failure('ADMIN_REQUIRED', 403);
      if (!ssh || typeof ssh.snapshotSmartSelections !== 'function') throw failure('SMART_COLLECTION_UNAVAILABLE');
      const snapshot = await ssh.snapshotSmartSelections({ pluginId }, actor);
      if (!snapshot || !Array.isArray(snapshot.items)) throw failure('SMART_COLLECTION_UNAVAILABLE');
      const seen = new Set(), secret = await key(), items = [];
      for (const selection of snapshot.items.slice(0, 101)) {
        if (!selection || !identifier(selection.hostId) || !identifier(selection.deviceId) || seen.has(selection.deviceId)) throw failure('SMART_COLLECTION_CANDIDATES_INVALID', 400);
        seen.add(selection.deviceId);
        const tower = await readDisk({ diskId: selection.deviceId, actor });
        if (!tower || tower.id !== selection.deviceId || tower.hostId !== selection.hostId) throw failure('SMART_BINDING_CHANGED', 409);
        const generation = generationFor(secret, tower);
        items.push({ diskId: tower.id, generation, profileHostId: tower.hostId, deviceId: tower.id, bindingToken: generation });
        if (items.length > 100) throw failure('SMART_BATCH_TARGET_LIMIT', 409);
      }
      return { items };
    },
    async recordSample({ input, target, sample, operationId } = {}) {
      if (!input || !identifier(input.diskId) || !target || !hex(target.generation) || typeof operationId !== 'string') throw failure('SMART_COLLECTION_FAILED');
      if (!sample || typeof sample !== 'object' || !sample.smart) throw failure('SMART_OUTPUT_INVALID');
      let smart;
      try { smart = validateHistorySmart(sample.smart); } catch { throw failure('SMART_OUTPUT_INVALID'); }
      await history.append({ pluginId, diskId: input.diskId, hostId: target.profileHostId, generation: target.generation,
        operation: 'disk.smart.read', operationId, collectedAt: new Date(now()).toISOString(), status: 'ok', smart });
      return { ok: true };
    },
    async bindings({ actor } = {}) {
      if (!actorOk(actor) || actor.admin !== true) throw failure('ADMIN_REQUIRED', 403);
      return { items: [] };
    },
    async bind() { throw failure('SMART_COLLECTION_UNAVAILABLE'); },
    async unbind() { throw failure('SMART_COLLECTION_UNAVAILABLE'); },
  });
}
