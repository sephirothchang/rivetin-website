import { randomUUID } from 'node:crypto';
import { createBackendServer, createPeerClient } from './server/workload-http.js';
import { createPermitMonitor } from './server/workload-permit.js';
import { createSingleDisk } from './single-disk.js';

const methods = { collectOne: 'submit', operation: 'observe', readLatest: 'read', readHistory: 'read' };
const exact = (value, keys) => value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).sort().join(',') === [...keys].sort().join(',');
const validIdentity = value => exact(value, ['diskId', 'hostId', 'generation', 'deviceId', 'path', 'model']) &&
  /^[A-Za-z0-9_-]{1,128}$/.test(value.diskId) && /^[A-Za-z0-9_-]{1,128}$/.test(value.hostId) &&
  /^[a-f0-9]{64}$/.test(value.generation) && value.deviceId === value.generation && value.path === '' && typeof value.model === 'string' && value.model.length <= 160;

export async function createSmartRuntime({ directory, tls, frameworkOrigin, frameworkPin, identity }) {
  const framework = createPeerClient({ origin: frameworkOrigin, tls, serverPin: frameworkPin });
  let paused = false;
  const permits = createPermitMonitor({ renew: () => framework.permit(identity), onPause: async () => { paused = true; await service.stop(); } });
  async function call(method, kind, input, operationId = null, options = {}) {
    const token = permits.current();
    if (!token) throw new Error('SMART_FRAMEWORK_UNAVAILABLE');
    return framework.call({ ...identity, requestId: randomUUID(), operationId, capability: 'framework.smart-context',
      interfaceVersion: 1, method, kind, input }, token, options);
  }
  const context = {
    validateCollection: (input, options) => call('validateCollection', 'read', input, null, options),
    sampleOne: (input, operationId, options) => call('sampleOne', 'submit', input, operationId, options),
    observeSample: (input, operationId, options) => call('observeSample', 'observe', input, operationId, options),
    authorizePublish: (input, options) => call('authorizePublish', 'read', input, null, options),
  };
  const service = createSingleDisk(directory, context);
  let recovered;
  async function authorize(value) {
    return Boolean(permits.current()) && value.capability === 'disk.smart' && value.interfaceVersion === 1 && methods[value.method] === value.kind &&
      value.caller?.source === 'tower' && value.caller.role === 'ROOT' && value.caller.admin === true && value.caller.pluginId === null &&
      value.credentialLeaseId === null;
  }
  async function execute(value, { signal }) {
    if (!await ready()) throw new Error('SMART_RUNTIME_UNAVAILABLE');
    if (value.method === 'collectOne') return service.collectOne(value.input, { operationId: value.operationId, parentRequestId: value.requestId, actor: value.caller, signal });
    if (value.method === 'operation' && exact(value.input, [])) return service.operation(value.operationId, value.caller);
    if (value.method === 'readLatest' && exact(value.input, ['schemaVersion', 'identity']) && value.input.schemaVersion === 1 && validIdentity(value.input.identity)) return service.readLatest(value.input.identity);
    if (value.method === 'readHistory' && value.input?.schemaVersion === 1 && validIdentity(value.input.identity) && Object.keys(value.input).every(key => ['schemaVersion', 'identity', 'limit', 'cursor'].includes(key))) return service.readHistory(value.input.identity, value.input);
    throw new Error('SMART_REQUEST_INVALID');
  }
  const ready = async () => {
    if (paused || !permits.current()) return false;
    if (!recovered) recovered = service.recover();
    try { await recovered; } catch { return false; }
    return !paused && Boolean(permits.current());
  };
  const server = createBackendServer({ tls, frameworkPin, identity, permits, framework, execute, authorize, ready });
  return { server, ready, start: () => permits.start(), async stop() { paused = true; await permits.stop(); await service.stop(); await new Promise(resolve => server.close(resolve)); } };
}
