import { randomUUID } from 'node:crypto';
import { constants } from 'node:fs';
import { lstat, open } from 'node:fs/promises';
import path from 'node:path';
import { atomic, storage } from './storage.js';

const schema = 'rivetin.fw-backup-fence.v1';
const controllerEpoch = randomUUID();
const identifier = /^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/;
const sha256 = /^[a-f0-9]{64}$/;
const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const error = (code, status = 409) => Object.assign(new Error(code), { status });
const fields = (value, names) => value && typeof value === 'object' && !Array.isArray(value) &&
  Object.keys(value).length === names.length && names.every(name => Object.hasOwn(value, name));
const bindingFields = ['installationId', 'fwPodUID', 'operationId', 'scopeSHA256'];

export function createBackupFence(directory, domains, pause = async () => () => {}) {
  const domainNames = [...new Set(domains.map(domain => domain.name))];
  const supportedDomains = ['smart-history', 'smart', 'resource-actions', 'ssh-vault', 'runtime-metadata', 'framework-core'];
  const root = path.resolve(directory);
  const insideDomains = task => domains.reduceRight((next, domain) => async () => {
    const relative = path.relative(root, domain.lock.root);
    if (path.isAbsolute(relative) || relative.split(path.sep).includes('..')) throw error('FW_BACKUP_FENCE_INVALID', 503);
    let folder = root;
    for (const part of ['', ...relative.split(path.sep).filter(Boolean)]) {
      folder = path.join(folder, part);
      const info = await lstat(folder).catch(failure => { if (failure.code !== 'ENOENT') throw failure; });
      if (!info) break;
      if (!info.isDirectory()) throw error('FW_BACKUP_FENCE_INVALID', 503);
    }
    return domain.lock.locked(next);
  }, task)();
  // Keep the r1 control path so an earlier durable SMART fence still closes admission.
  const file = path.join(path.resolve(directory), '.smart-history-backup-fence.json');
  function validBinding(value) {
    return bindingFields.slice(0, 3).every(key => typeof value[key] === 'string' && identifier.test(value[key])) &&
      typeof value.scopeSHA256 === 'string' && sha256.test(value.scopeSHA256);
  }
  async function read() {
    let handle;
    try {
      handle = await open(file, constants.O_RDONLY | (constants.O_NOFOLLOW || 0) | (constants.O_NONBLOCK || 0));
      const info = await handle.stat();
      if (!info.isFile() || info.nlink !== 1 || info.size > 2048) throw error('FW_BACKUP_FENCE_INVALID', 503);
      const buffer = Buffer.alloc(2049);
      const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
      if (bytesRead !== info.size) throw error('FW_BACKUP_FENCE_INVALID', 503);
      const record = JSON.parse(buffer.subarray(0, bytesRead));
      const keys = [...bindingFields, 'schema', 'generation', 'controllerEpoch', 'phase'];
      if (!fields(record, keys) && !fields(record, [...keys, 'domains'])) throw error('FW_BACKUP_FENCE_INVALID', 503);
      const recorded = record.domains === undefined ? ['smart-history'] : record.domains;
      if (!Array.isArray(recorded) || !recorded.length || recorded.length !== new Set(recorded).size ||
          recorded.some(domain => !supportedDomains.includes(domain)) ||
          record.schema !== schema || !validBinding(record) || !uuid.test(record.generation) ||
          !uuid.test(record.controllerEpoch) || !['frozen', 'released'].includes(record.phase)) {
        throw error('FW_BACKUP_FENCE_INVALID', 503);
      }
      return { ...record, domains: recorded };
    } catch (failure) {
      if (!handle && failure.code === 'ENOENT') return null;
      throw error('FW_BACKUP_FENCE_INVALID', 503);
    } finally { await handle?.close(); }
  }
  function view(record) {
    const { controllerEpoch: owner, domains: covered, ...result } = record;
    const phase = record.phase === 'frozen' && owner !== controllerEpoch ? 'stale' : record.phase;
    return { ...result, phase, coveredDomains: phase === 'frozen' ? covered : [],
      fullConfigProtected: false, observedAt: new Date().toISOString() };
  }
  function assertBound(record, binding) {
    if (bindingFields.some(key => binding[key] !== record[key])) throw error('FW_BACKUP_FENCE_CONFLICT');
  }
  return {
    async held(domain) {
      const record = await read();
      return record?.phase === 'frozen' && (record.domains.includes(domain) ||
        domain === 'smart-history' && record.domains.includes('smart'));
    },
    async assertWritable(domain) {
      if (await this.held(domain)) throw error('FW_BACKUP_FENCE_HELD', 503);
    },
    async begin(binding, previousGeneration) {
      if (!fields(binding, bindingFields) || !validBinding(binding)) throw error('FW_BACKUP_FENCE_REQUEST_INVALID', 400);
      if (previousGeneration !== undefined && (typeof previousGeneration !== 'string' || !uuid.test(previousGeneration))) {
        throw error('FW_BACKUP_FENCE_REQUEST_INVALID', 400);
      }
      const resume = await pause();
      try { return await insideDomains(async () => {
        const current = await read();
        if (current?.operationId === binding.operationId || current?.phase === 'frozen') {
          assertBound(current, binding);
          return view(current);
        }
        if (current?.generation !== previousGeneration) throw error('FW_BACKUP_FENCE_CONFLICT');
        for (const domain of domains) await domain.prepare();
        const record = { ...binding, schema, generation: randomUUID(), controllerEpoch, phase: 'frozen', domains: domainNames };
        await atomic(file, record);
        return view(record);
      }); } finally { resume(); }
    },
    async status(binding) {
      return insideDomains(async () => {
        const current = await read();
        if (!current || binding.operationId && current.operationId !== binding.operationId) throw error('FW_BACKUP_FENCE_NOT_FOUND', 404);
        if (current.installationId !== binding.installationId || current.fwPodUID !== binding.fwPodUID) {
          throw error('FW_BACKUP_FENCE_CONFLICT');
        }
        return view(current);
      });
    },
    async release(binding, generation) {
      if (!fields(binding, bindingFields) || !validBinding(binding) || typeof generation !== 'string' || !uuid.test(generation)) {
        throw error('FW_BACKUP_FENCE_REQUEST_INVALID', 400);
      }
      return insideDomains(async () => {
        const current = await read();
        if (!current || current.generation !== generation) throw error('FW_BACKUP_FENCE_CONFLICT');
        assertBound(current, binding);
        const released = { ...current, phase: 'released' };
        if (current.phase !== released.phase) await atomic(file, released);
        return view(released);
      });
    },
  };
}

export function guardedBackupDomain(directory, name, subdirectory, prepare = async () => {}) {
  const lock = storage(path.join(path.resolve(directory), subdirectory));
  const guard = createBackupFence(directory, []);
  return { ...lock, name, lock, prepare, locked: task => lock.locked(async () => {
    await guard.assertWritable(name);
    return task();
  }) };
}

export function createBackupAdmission(directory) {
  const guard = createBackupFence(directory, []);
  let paused = false, active = 0, drained;
  return {
    async run(task) {
      if (paused) throw error('FW_BACKUP_FENCE_HELD', 503);
      active++;
      try {
        await guard.assertWritable('framework-core');
        return await task();
      } finally {
        if (--active === 0) drained?.();
      }
    },
    async pause() {
      if (paused) throw error('FW_BACKUP_FENCE_BUSY', 409);
      paused = true;
      const resume = () => { paused = false; };
      if (!active) return resume;
      let timer;
      try {
        await Promise.race([
          new Promise(resolve => { drained = resolve; }),
          new Promise((_, reject) => { timer = setTimeout(() => reject(error('FW_BACKUP_FENCE_BUSY', 409)), 3000); }),
        ]);
        return resume;
      } catch (failure) { resume(); throw failure; }
      finally { clearTimeout(timer); drained = undefined; }
    },
  };
}
