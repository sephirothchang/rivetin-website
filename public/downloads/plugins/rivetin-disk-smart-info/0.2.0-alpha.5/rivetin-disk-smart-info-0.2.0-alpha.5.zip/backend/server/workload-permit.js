import { performance } from 'node:perf_hooks';
import { fields } from '../shared/provider-connections.js';
import { permitMs, pollMs, wireVersion, WorkloadError } from './workload-protocol.js';

// The receiver's clock is monotonic. A delayed grant never extends the
// authority past the original request's TTL, and pause discards in-flight grants.
export function createPermitMonitor({ renew, onPause = () => {}, onGrant = () => {}, clock = () => performance.now() }) {
  let drainState = 'unknown', previouslyPermitted = false;
  let permit, expiration = 0, revision = 0, failures = 0, successes = 0;
  let recovering = false, paused = false, pending, timer, expiryTimer, draining = Promise.resolve();
  function suspend() {
    const wasActive = Boolean(permit);
    clearTimeout(expiryTimer);
    permit = undefined;
    expiration = 0;
    recovering = true;
    successes = 0;
    revision++;
    if (wasActive) {
      drainState = 'pending';
      draining = draining.then(onPause).then(() => { drainState = 'completed'; }, error => { drainState = 'unknown'; throw error; });
      // A failed drain leaves this process paused until operator recovery.
      draining.catch(() => { paused = true; });
    }
    return draining;
  }
  function current() {
    if (permit && clock() >= expiration) suspend();
    return permit || null;
  }
  async function poll() {
    if (pending) return pending;
    pending = (async () => {
      current();
      const requested = clock(), prior = revision;
      try {
        const value = fields(await renew(), ['transportVersion', 'permit', 'ttlMs']);
        if (value.transportVersion !== wireVersion || typeof value.permit !== 'string' ||
          !/^[a-f0-9]{64}$/.test(value.permit) || !Number.isSafeInteger(value.ttlMs) ||
          value.ttlMs < 1 || value.ttlMs > permitMs || requested + value.ttlMs <= clock()) {
          throw new WorkloadError('WORKLOAD_PERMIT_INVALID', 503);
        }
        onGrant();
        await draining;
        if (revision !== prior || paused) return;
        failures = 0;
        successes++;
        if (recovering && successes < 2) return;
        recovering = false;
        permit = value.permit;
        previouslyPermitted = true;
        drainState = 'pending';
        expiration = requested + value.ttlMs;
        clearTimeout(expiryTimer);
        expiryTimer = setTimeout(current, Math.max(1, Math.ceil(expiration - clock())));
        expiryTimer.unref();
      } catch (error) {
        if (revision !== prior || paused) return;
        successes = 0;
        if (error.status === 403 || ++failures >= 3) suspend();
      }
    })();
    try { await pending; } finally { pending = undefined; }
  }
  return {
    current,
    pauseStatus() {
      const active = Boolean(current());
      return { admissionClosed: !active, permitExpired: previouslyPermitted && !active, drain: drainState };
    },
    poll,
    pause: suspend,
    start() {
      if (paused || timer) return;
      void poll();
      timer = setInterval(poll, pollMs);
      timer.unref();
    },
    async stop() {
      paused = true;
      clearInterval(timer);
      await suspend();
    },
  };
}
