import { bounded, fields, integer, object, parseConnectionJson, text, uuid } from '../shared/provider-connections.js';
import { validId } from '../shared/identity.js';

export const wireVersion = 1;
export const prefix = '/internal/rivetin/v1';
export const pollMs = 30_000;
export const permitMs = 90_000;
export const requestLimit = 96 * 1024;
export const responseLimit = 4 * 1024 * 1024;
export const standardExchangeMs = 20_000;
export const maximumExchangeMs = 305_000;
const envelopeKeys = ['transportVersion', 'instanceId', 'generation', 'requestId', 'operationId',
  'capability', 'interfaceVersion', 'method', 'kind', 'input'];
const namePattern = /^[a-z][a-zA-Z0-9_.-]{0,95}$/;
const operationPattern = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;

export class WorkloadError extends Error {
  constructor(code, status = 403, outcome = 'not-accepted') {
    super(code);
    this.code = code;
    this.status = status;
    this.outcome = outcome;
  }
}
const invalid = () => new WorkloadError('WORKLOAD_SCHEMA_INVALID', 400);
export function validName(value) {
  if (typeof value !== 'string' || !namePattern.test(value)) throw invalid();
  return value;
}
export function operationId(value) {
  if (typeof value !== 'string' || !operationPattern.test(value)) throw invalid();
  return value;
}
export function identity(value) {
  if (value.transportVersion !== wireVersion) throw invalid();
  uuid(value.instanceId);
  integer(value.generation, 1);
  return value;
}
export function permitRequest(value) {
  return identity(fields(value, ['transportVersion', 'instanceId', 'generation']));
}
export function callerIdentity(value) {
  fields(value, ['id', 'name', 'source', 'role', 'admin', 'pluginId']);
  for (const field of ['id', 'name', 'source']) text(value[field]);
  if (typeof value.admin !== 'boolean' || (value.pluginId !== null && !validId(value.pluginId))) throw invalid();
  if (value.source === 'tower') text(value.role, 32);
  else if (value.role !== null) throw invalid();
  return value;
}
export function validateCall(value, forwarded = false) {
  identity(fields(value, forwarded ? [...envelopeKeys, 'caller', 'credentialLeaseId'] : envelopeKeys));
  uuid(value.requestId);
  if (value.kind === 'read') {
    if (value.operationId !== null) throw invalid();
  } else {
    if (!['submit', 'observe'].includes(value.kind)) throw invalid();
    operationId(value.operationId);
  }
  validName(value.capability);
  validName(value.method);
  integer(value.interfaceVersion, 1);
  if (!object(value.input)) throw invalid();
  if (forwarded) {
    callerIdentity(value.caller);
    if (value.credentialLeaseId !== null) {
      if (value.kind === 'observe') throw invalid();
      uuid(value.credentialLeaseId);
    }
  }
  return value;
}
export function credentialRequest(value) {
  identity(fields(value, ['transportVersion', 'instanceId', 'generation', 'requestId', 'operationId', 'credentialLeaseId']));
  uuid(value.requestId);
  if (value.operationId !== null) operationId(value.operationId);
  uuid(value.credentialLeaseId);
  return value;
}
export function parseWire(bytes, limit = requestLimit) {
  try {
    return parseConnectionJson(new TextDecoder('utf-8', { fatal: true }).decode(bytes), limit);
  } catch {
    throw invalid();
  }
}
export function encodeWire(value, limit = requestLimit) {
  return JSON.stringify(bounded(value, limit));
}
export function safeError(error, kind) {
  if (error instanceof WorkloadError || (error && /^[A-Z][A-Z0-9_]{1,99}$/.test(error.code || '') &&
    ['unknown', 'not-accepted'].includes(error.outcome))) {
    return { code: error.code, outcome: error.outcome };
  }
  const message = error?.message;
  const code = typeof message === 'string' &&
    /^(?:(?:SMART|SSH|CONNECTION|VC)_[A-Z0-9_]{1,90}|ADMIN_REQUIRED|AUTHENTICATION_REQUIRED)$/.test(message)
    ? message : 'WORKLOAD_UNAVAILABLE';
  return { code, outcome: kind === 'submit' ? 'unknown' : 'not-accepted' };
}
export function callReply(call, body) {
  return { transportVersion: wireVersion, requestId: call.requestId, operationId: call.operationId, ...body };
}
export function readReply(value, call) {
  const common = ['transportVersion', 'requestId', 'operationId', 'ok'];
  fields(value, [...common, value?.ok === true ? 'result' : 'error']);
  if (value.transportVersion !== wireVersion || value.requestId !== call.requestId ||
    value.operationId !== call.operationId || typeof value.ok !== 'boolean') throw invalid();
  if (!value.ok) {
    const error = fields(value.error, ['code', 'outcome']);
    if (!/^[A-Z][A-Z0-9_]{1,99}$/.test(error.code) || !['unknown', 'not-accepted'].includes(error.outcome)) throw invalid();
  }
  return value;
}
