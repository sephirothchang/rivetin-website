export const idPattern = /^rivetin-[a-z0-9]+(?:-[a-z0-9]+)*$/;
export const validId = value => typeof value === 'string' && value.length <= 100 && idPattern.test(value);
export const LCM_COMPONENT_ID = 'rivetin-framework-lcm';
export function assertPluginId(value) {
  if (value === LCM_COMPONENT_ID) throw Object.assign(new Error('BUILTIN_COMPONENT_MANAGED_SEPARATELY'), { status: 409 });
  return assertId(value);
}
export function assertId(value) {
  if (!validId(value)) throw new Error('INVALID_PLUGIN_ID');
  return value;
}
