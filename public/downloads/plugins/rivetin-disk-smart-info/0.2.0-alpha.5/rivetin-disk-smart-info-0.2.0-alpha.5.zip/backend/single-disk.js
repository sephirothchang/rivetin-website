import path from 'node:path';
import { lstat, readFile } from 'node:fs/promises';
import { atomic, storage } from './server/storage.js';
import { createSmartHistory, validateHistorySmart } from './server/smart-history.js';

const pluginId = 'rivetin-disk-smart-info';
const uuid = value => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(value);
const hex = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const exact = (value, keys) => value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).sort().join(',') === [...keys].sort().join(',');
const invalid = () => { throw new Error('SMART_REQUEST_INVALID'); };
const response = row => ({ schemaVersion: 1, operationId: row.operationId, status: row.status, ...(row.code ? { code: row.code } : {}) });

// Context methods are authenticated framework calls, supplied by the runtime adapter.
export function createSingleDisk(directory, context) {
  if (!context || !['validateCollection', 'sampleOne', 'observeSample', 'authorizePublish'].every(key => typeof context[key] === 'function')) invalid();
  const root = path.resolve(directory);
  const lock = storage(path.join(root, 'smart-receipts'));
  const file = path.join(lock.root, 'operations.json');
  const history = createSmartHistory(root);
  const pending = new Set();
  const controllers = new Map();
  let stopping = false;
  async function load() {
    try {
      const info = await lstat(file);
      if (!info.isFile() || info.isSymbolicLink() || info.size > 8 * 1024 * 1024) invalid();
      const value = JSON.parse(await readFile(file, 'utf8'));
      if (!value || value.version !== 1 || !value.items || typeof value.items !== 'object' || Array.isArray(value.items) || Object.keys(value.items).length > 10000) invalid();
      return value;
    } catch (error) {
      if (error.code === 'ENOENT') return { version: 1, items: {} };
      throw error;
    }
  }
  async function update(id, change) {
    return lock.locked(async () => {
      const state = await load();
      const row = state.items[id];
      if (!row) throw new Error('SMART_COLLECTION_NOT_FOUND');
      await change(row);
      await atomic(file, state);
      return response(row);
    });
  }
  async function recover() {
    await lock.locked(async () => {
      const state = await load();
      let changed = false;
      for (const row of Object.values(state.items)) {
        if (row.status === 'running') { row.status = 'unknown'; row.code = 'SMART_COLLECTION_INTERRUPTED'; changed = true; }
      }
      if (changed) await atomic(file, state);
    });
  }
  async function execute(row, signal) {
    const controller = new AbortController();
    controllers.set(row.operationId, controller);
    const abort = () => controller.abort();
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) abort();
    try {
      const validation = await context.validateCollection({ parentRequestId: row.parentRequestId, operationId: row.operationId }, { signal: controller.signal });
      if (validation?.operationId !== row.operationId || validation.identity?.diskId !== row.diskId || validation.identity?.generation !== row.generation) invalid();
      let result;
      try {
        result = await context.sampleOne({ parentRequestId: row.parentRequestId }, row.operationId, { timeoutMs: 50000, signal: controller.signal });
      } catch (error) {
        if (error.outcome !== 'unknown' || controller.signal.aborted) throw error;
        result = await context.observeSample({ parentRequestId: row.parentRequestId }, row.operationId, { signal: controller.signal });
      }
      if (result?.operationId !== row.operationId || result.state !== 'sample_ready' || !exact(result.sample, ['sampleId', 'finishedAt', 'smart']) || !uuid(result.sample.sampleId)) invalid();
      const smart = validateHistorySmart(result.sample.smart);
      const identity = validation.identity;
      const record = { pluginId, diskId: row.diskId, hostId: identity.hostId, generation: row.generation,
        operation: 'disk.smart.read', operationId: row.operationId, collectedAt: result.sample.finishedAt, status: 'ok', smart };
      const publication = await history.append(record, { beforeCommit: async () => {
        if (stopping || controller.signal.aborted) throw new Error('SMART_COLLECTION_INTERRUPTED');
        const permit = await context.authorizePublish({ parentRequestId: row.parentRequestId, operationId: row.operationId, sampleId: result.sample.sampleId }, { signal: controller.signal });
        const expires = Date.parse(permit?.expiresAt);
        if (stopping || controller.signal.aborted || permit?.operationId !== row.operationId || permit?.sampleId !== result.sample.sampleId || permit.authorized !== true || !Number.isFinite(expires) || expires <= Date.now() || expires > Date.now() + 5000) throw new Error('SMART_PUBLISH_UNAUTHORIZED');
      } });
      if (publication.record?.operationId !== row.operationId || publication.record?.status !== 'ok') throw new Error('SMART_COLLECTION_FAILED');
      await update(row.operationId, current => { if (current.status === 'running' && !stopping) { current.sampleId = result.sample.sampleId; current.status = 'succeeded'; } });
    } catch {
      await update(row.operationId, current => { if (current.status === 'running') { current.status = 'unknown'; current.code = 'SMART_COLLECTION_INTERRUPTED'; } });
    } finally { signal?.removeEventListener('abort', abort); controllers.delete(row.operationId); }
  }
  return {
    recover,
    async collectOne(input, envelope) {
      if (!exact(input, ['schemaVersion', 'pluginId', 'diskId', 'generation', 'bindingToken']) || input.schemaVersion !== 1 || input.pluginId !== pluginId || typeof input.diskId !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(input.diskId) || !hex(input.generation) || !hex(input.bindingToken) || !uuid(envelope?.operationId) || !uuid(envelope?.parentRequestId) || typeof envelope?.actor?.id !== 'string' || typeof envelope.actor.source !== 'string') invalid();
      const row = { ...input, operationId: envelope.operationId, parentRequestId: envelope.parentRequestId, actor: { id: envelope.actor.id, source: envelope.actor.source }, status: 'running' };
      await lock.locked(async () => {
        const state = await load();
        if (state.items[row.operationId]) throw new Error('SMART_COLLECTION_REQUEST_CONFLICT');
        if (Object.keys(state.items).length >= 10000) throw new Error('SMART_COLLECTION_CAPACITY_EXCEEDED');
        state.items[row.operationId] = row;
        if (Buffer.byteLength(JSON.stringify(state)) > 8 * 1024 * 1024) throw new Error('SMART_COLLECTION_CAPACITY_EXCEEDED');
        await atomic(file, state);
      });
      const task = execute(row, envelope.signal);
      pending.add(task);
      task.then(() => pending.delete(task), () => pending.delete(task));
      return response(row);
    },
    async operation(operationId, actor) {
      if (!uuid(operationId)) invalid();
      return lock.locked(async () => {
        const row = (await load()).items[operationId];
        if (!row || row.actor.id !== actor?.id || row.actor.source !== actor?.source) throw new Error('SMART_COLLECTION_NOT_FOUND');
        return response(row);
      });
    },
    async readLatest(identity) {
      const { record } = await history.latest({ pluginId, diskId: identity.diskId, hostId: identity.hostId, generation: identity.generation });
      return snapshot(record, identity);
    },
    async readHistory(identity, options = {}) {
      const result = await history.page({ pluginId, diskId: identity.diskId, hostId: identity.hostId, generation: identity.generation,
        ...(options.limit === undefined ? {} : { limit: options.limit }), ...(options.cursor == null ? {} : { cursor: options.cursor }) });
      return { schemaVersion: 1, source: 'host-smartctl', identity, items: result.items.map(item => snapshot(item, identity)), nextCursor: result.nextCursor, snapshotAt: result.snapshotAt };
    },
    async stop() { stopping = true; for (const controller of controllers.values()) controller.abort(); await Promise.allSettled([...pending]); },
    async drain() { await Promise.allSettled([...pending]); },
  };
}

function snapshot(record, identity) {
  if (!record) return { schemaVersion: 1, source: 'host-smartctl', identity, status: 'unavailable', code: 'SMART_NO_SAMPLE', collectedAt: null };
  return { schemaVersion: 1, source: 'host-smartctl', identity, status: record.status, collectedAt: record.collectedAt,
    ...(record.status === 'ok' ? { smart: record.smart } : { code: record.code }), ...(record.gapCode ? { gapCode: record.gapCode } : {}) };
}
