// A2 needs adapter for the SSH channel methods SMART is allowed to call.
// Authorization/approval/scope/audit stay in the framework SSH workload; this
// module only shapes requests and returns the framework's bounded results.
const text = (value, max) => typeof value === 'string' && value.length > 0 && value.length <= max;

export function createSshChannelAdapter({ call } = {}) {
  if (typeof call !== 'function') throw new Error('SMART_SSH_CALL_REQUIRED');
  const invoke = (method, input, actor, options = {}) =>
    call('ssh.channel', method, input, actor, { ...options });
  return Object.freeze({
    async selectSmartTarget({ pluginId, hostId, deviceId } = {}, actor, options) {
      if (!text(pluginId, 100) || !text(hostId, 128) || !text(deviceId, 128)) throw Object.assign(new Error('SMART_SSH_TARGET_INVALID'), { status: 400 });
      return invoke('selectSmartTarget', { pluginId, hostId, deviceId }, actor, options);
    },
    async snapshotSmartSelections({ pluginId } = {}, actor, options) {
      if (!text(pluginId, 100)) throw Object.assign(new Error('SMART_SSH_TARGET_INVALID'), { status: 400 });
      return invoke('snapshotSmartSelections', { pluginId }, actor, options);
    },
    async runTarget({ selection } = {}, actor, { operationId, signal } = {}) {
      if (!selection || typeof selection !== 'object') throw Object.assign(new Error('SMART_SSH_TARGET_INVALID'), { status: 400 });
      return invoke('runTarget', { selection }, actor, { operationId, signal });
    },
  });
}
