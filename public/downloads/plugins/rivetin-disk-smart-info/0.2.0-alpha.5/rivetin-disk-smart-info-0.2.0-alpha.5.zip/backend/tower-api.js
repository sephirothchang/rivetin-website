// Real CloudTower transport for the SMART business backend. Credentials come only
// from the A2 Secret mount: url/username/password required, ca/insecureTls optional.
// Fetch is injected for tests; the Node https transport never logs credentials,
// tokens or response bodies.
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import https from 'node:https';

const required = (value, max) => typeof value === 'string' && value.length > 0 && Buffer.byteLength(value) <= max;
const origin = value => {
  try { const url = new URL(value); return url.protocol === 'https:' && url.origin === value.replace(/\/$/, '') ? value.replace(/\/$/, '') : null; }
  catch { return null; }
};

export function createHttpsTransport({ url, ca, insecureTls = false } = {}) {
  const base = origin(url);
  if (!base) throw new Error('SMART_TOWER_CONFIG_INVALID');
  const options = { ...(ca ? { ca } : {}), ...(insecureTls ? { rejectUnauthorized: false } : {}) };
  function request({ method, path: route, body, token, signal }) {
    return new Promise((resolve, reject) => {
      const target = new URL(base + route);
      const payload = body === undefined ? undefined : JSON.stringify(body);
      const req = https.request(target, { ...options, method, agent: false, minVersion: 'TLSv1.2', timeout: 15000,
        headers: { accept: 'application/json', ...(payload ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(payload) } : {}),
          ...(token ? { authorization: token } : {}) } }, response => {
        const chunks = [];
        response.on('data', chunk => { chunks.push(chunk); if (Buffer.concat(chunks).length > 4 * 1024 * 1024) req.destroy(new Error('SMART_TOWER_RESPONSE_INVALID')); });
        response.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          if (response.statusCode < 200 || response.statusCode >= 300) return reject(Object.assign(new Error('SMART_TOWER_UNAVAILABLE'), { statusCode: response.statusCode }));
          try { resolve(text ? JSON.parse(text) : null); } catch { reject(new Error('SMART_TOWER_RESPONSE_INVALID')); }
        });
      });
      req.on('timeout', () => req.destroy(Object.assign(new Error('SMART_TOWER_UNAVAILABLE'), { code: 'ETIMEDOUT' })));
      req.on('error', failed => reject(failed.code === 'DEPTH_ZERO_SELF_SIGNED_CERT' || failed.code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE' || failed.code === 'SELF_SIGNED_CERT_IN_CHAIN'
        ? new Error('SMART_TOWER_TLS_UNTRUSTED') : new Error('SMART_TOWER_UNAVAILABLE')));
      signal?.addEventListener('abort', () => req.destroy(Object.assign(new Error('SMART_TOWER_UNAVAILABLE'), { code: 'ABORT_ERR' })), { once: true });
      if (payload) req.write(payload);
      req.end();
    });
  }
  return { request };
}

export async function loadTowerApi({ directory = '/run/rivetin/cloudtower', transportFactory = createHttpsTransport, transport } = {}) {
  const readOptional = async name => { try { return (await readFile(path.join(directory, name), 'utf8')).trim(); } catch (error) { if (error.code === 'ENOENT') return null; throw error; } };
  const [url, username, password, ca, insecure] = await Promise.all(['url', 'username', 'password', 'ca', 'insecureTls'].map(readOptional));
  if (!url && !username && !password && !ca && !insecure) return null;
  if (!required(url, 4096) || !required(username, 4096) || !required(password, 4096) || (insecure !== null && !['true', 'false'].includes(insecure))) {
    throw new Error('SMART_TOWER_CONFIG_INVALID');
  }
  const insecureTls = insecure === 'true';
  return createTowerRequest({ transport: transport ?? transportFactory({ url, ca, insecureTls }), username, password });
}

export function createTowerRequest({ transport, username, password } = {}) {
  if (!transport || typeof transport.request !== 'function' || !required(username, 4096) || !required(password, 4096)) throw new Error('SMART_TOWER_CONFIG_INVALID');
  let token = null, login = null;
  async function tokenValue() {
    if (token) return token;
    if (!login) login = (async () => {
      const body = await transport.request({ method: 'POST', path: '/v2/api/login', body: { username, password, source: 'LOCAL' } });
      const value = body?.data?.token ?? body?.token;
      if (!required(value, 4096)) throw new Error('SMART_TOWER_UNAVAILABLE');
      return value;
    })().finally(() => { login = null; });
    token = await login; return token;
  }
  return {
    async request(route, body, actor, { signal } = {}) {
      const bearer = await tokenValue();
      const response = await transport.request({ method: 'POST', path: route, body, token: bearer, signal });
      return response?.data ?? response;
    },
  };
}
