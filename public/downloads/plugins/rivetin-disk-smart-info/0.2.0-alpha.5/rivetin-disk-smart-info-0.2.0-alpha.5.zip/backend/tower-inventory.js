// Tower disk projections for the SMART Pod. The request transport is injected so
// the A2 tower.api credential adapter (or a unit-test fake) supplies authenticated
// CloudTower access; this module never handles credentials or logs responses.
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const identifier = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(value);
const text = (value, max) => typeof value === 'string' && value.length > 0 && value.length <= max && !/[\x00-\x1f\x7f]/.test(value);
const devicePath = value => typeof value === 'string' && /^\/dev\/[A-Za-z0-9._/-]{1,200}$/.test(value);

export function createTowerDiskReaders({ request } = {}) {
  if (typeof request !== 'function') throw new Error('SMART_TOWER_UNAVAILABLE');
  async function disks(diskId, actor, signal) {
    const rows = await request('/v2/api/get-disks', { where: { id: diskId }, first: 2, skip: 0, orderBy: 'id_ASC' }, actor, { signal });
    if (!Array.isArray(rows) || rows.length > 1) throw new Error('SMART_TOWER_RESPONSE_INVALID');
    return rows[0] ?? null;
  }
  return {
    async readDisk({ diskId, actor, signal } = {}) {
      if (!identifier(diskId)) throw new Error('SMART_DISK_REQUEST_INVALID');
      const disk = await disks(diskId, actor, signal);
      if (!disk) throw Object.assign(new Error('SMART_DISK_NOT_FOUND'), { status: 404 });
      if (!object(disk.host) || !identifier(disk.host.id) || !text(disk.serial, 256) || !devicePath(disk.path) ||
          !text(disk.model, 512)) throw new Error('SMART_DISK_RESPONSE_INVALID');
      return { id: disk.id, hostId: disk.host.id, serial: disk.serial, path: disk.path, model: disk.model };
    },
    async readDiskInventory({ diskId, actor, signal } = {}) {
      if (!identifier(diskId)) throw new Error('SMART_DISK_REQUEST_INVALID');
      const disk = await disks(diskId, actor, signal);
      if (!disk) throw Object.assign(new Error('SMART_DISK_NOT_FOUND'), { status: 404 });
      if (!text(disk.model, 512)) throw new Error('SMART_DISK_RESPONSE_INVALID');
      return { id: disk.id, model: disk.model };
    },
  };
}
