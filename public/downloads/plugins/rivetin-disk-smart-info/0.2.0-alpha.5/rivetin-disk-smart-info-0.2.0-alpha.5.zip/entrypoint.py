"""Start the SMART backend from the common Runtime working directory."""
import os
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
os.chdir(root)
command = ['node', str(root / 'backend' / 'main.js')]
if os.name == 'nt':
    raise SystemExit(subprocess.call(command))
os.execvp(command[0], command)
