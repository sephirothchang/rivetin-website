/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// external "node:fs/promises"
const promises_namespaceObject = require("node:fs/promises");
;// external "node:path"
const external_node_path_namespaceObject = require("node:path");
;// external "node:crypto"
const external_node_crypto_namespaceObject = require("node:crypto");
;// ../../framework/shared/network-topology.js
const TOPOLOGY_LIMITS = Object.freeze({ clusters: 200, hosts: 128, switches: 128, networks: 512, nics: 1024, vmGroups: 512, peers: 256 });
const fail = () => { throw new Error('TOPOLOGY_RESPONSE_INVALID'); };
const exact = (value, keys) => { if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).sort().join() !== keys.split(' ').sort().join()) fail(); };
const topologyId = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(value);
const network_topology_text = value => typeof value === 'string' && value.length > 0 && value.length <= 256 && !/[\x00-\x1f\x7f]/.test(value);
const array = (value, limit) => Array.isArray(value) && value.length <= limit;
const optional = value => value === null || network_topology_text(value);
const integer = (value, max) => value === null || Number.isSafeInteger(value) && value >= 0 && value <= max;
const time = value => typeof value === 'string' && /T.*(?:Z|[+-]\d{2}:\d{2})$/.test(value) && Number.isFinite(Date.parse(value)) && Date.parse(value) <= Date.now() + 5000;
function unique(values) { if (new Set(values).size !== values.length) fail(); }
function validateTopologyClusters(value) {
  exact(value, 'schemaVersion source complete observedAt clusters');
  if (value?.schemaVersion !== 1 || value.source !== 'cloudtower' || value.complete !== true || !time(value.observedAt) || !array(value.clusters, TOPOLOGY_LIMITS.clusters) || value.clusters.some(row => !topologyId(row?.id) || !network_topology_text(row.name))) fail();
  for (const row of value.clusters) exact(row, 'id name');
  unique(value.clusters.map(row => row.id)); return structuredClone(value);
}
function validateTopologySnapshot(value, clusterId) {
  exact(value, 'schemaVersion source cluster revision observedAt complete hosts switches nics vmGroups peers'); exact(value.cluster, 'id name');
  if (!topologyId(clusterId) || value?.schemaVersion !== 1 || value.source !== 'cloudtower' || value.cluster?.id !== clusterId || !network_topology_text(value.cluster.name) || !/^[a-f0-9]{64}$/.test(value.revision || '') || !time(value.observedAt) || typeof value.complete !== 'boolean') fail();
  for (const key of ['hosts', 'switches', 'nics', 'vmGroups', 'peers']) if (!array(value[key], TOPOLOGY_LIMITS[key])) fail();
  if ([...value.hosts, ...value.peers].some(row => !topologyId(row?.id) || !network_topology_text(row.name))) fail();
  for (const row of [...value.hosts, ...value.peers]) exact(row, 'id name');
  const networks = [];
  for (const row of value.switches) {
    exact(row, 'id name mtu purpose networks');
    if (!topologyId(row?.id) || !network_topology_text(row.name) || !integer(row.mtu, 65535) || !optional(row.purpose) || !array(row.networks, TOPOLOGY_LIMITS.networks)) fail();
    for (const net of row.networks) { exact(net, 'id name vlan purpose'); if (!topologyId(net?.id) || !network_topology_text(net.name) || !integer(net.vlan, 4094) || !optional(net.purpose)) fail(); networks.push(net); }
  }
  if (networks.length > TOPOLOGY_LIMITS.networks) fail();
  const hosts = new Set(value.hosts.map(row => row.id)), switches = new Set(value.switches.map(row => row.id)), peers = new Set(value.peers.map(row => row.id)), nets = new Set(networks.map(row => row.id));
  for (const row of value.nics) if (!topologyId(row?.id) || !network_topology_text(row.name) || !hosts.has(row.hostId) || row.switchId !== null && !switches.has(row.switchId) || !['up', 'down', 'unknown'].includes(row.link) || !integer(row.speedMbps, 10000000) || !optional(row.bond) || !optional(row.bondMode) || row.peerId !== null && !peers.has(row.peerId) || !optional(row.peerPort)) fail();
  for (const row of value.nics) exact(row, 'id name hostId switchId link speedMbps bond bondMode peerId peerPort');
  for (const row of value.vmGroups) { exact(row, 'networkId count'); if (!nets.has(row?.networkId) || !integer(row.count, 1000000)) fail(); }
  for (const list of [value.hosts, value.switches, value.nics, value.peers, networks]) unique(list.map(row => row.id));
  unique(value.vmGroups.map(row => row.networkId)); return structuredClone(value);
}

;// ../../framework/shared/network-transactions.js


const NETWORK_TRANSACTION_MINIMUM = '0.2.7';
const NETWORK_TRANSACTION_PLUGIN = 'rivetin-network-topology';
const NETWORK_TRANSACTION_PERMISSION = 'network.topology.write';
const NETWORK_TRANSACTION_LIMITS = Object.freeze({ planMs: 60000, confirmMs: 90000, dispatchMarginMs: 15000, nics: 128, pending: 8, commands: 64, terminal: 1000, recordBytes: 262144, journalBytes: 67108864 });
const NETWORK_TRANSACTION_PHASES = Object.freeze(['queued', 'preparing', 'applying', 'awaiting-confirmation', 'rollback-requested', 'rolling-back', 'confirmed', 'rolled-back', 'expired-unapplied', 'failed-unapplied', 'rejected', 'apply-unknown', 'rollback-unknown', 'conflict', 'manual-intervention']);
const NETWORK_TRANSACTION_TERMINAL = Object.freeze(['confirmed', 'rolled-back', 'expired-unapplied', 'failed-unapplied', 'rejected']);
const NETWORK_TRANSACTION_CAPABILITY_REASONS = Object.freeze(['NETWORK_INDEPENDENT_IDENTITY_REQUIRED', 'NETWORK_INDEPENDENT_WORKER_REQUIRED', 'NETWORK_STORAGE_UNVERIFIED', 'NETWORK_REVERSIBILITY_UNVERIFIED', 'NETWORK_CONCURRENCY_UNVERIFIED', 'NETWORK_DEPENDENCIES_UNVERIFIED', 'NETWORK_IDENTITY_VERSION_MISMATCH', 'NETWORK_TARGET_NOT_ALLOWED', 'NETWORK_CLOCK_UNSAFE', 'NETWORK_STORE_UNCERTAIN', 'NETWORK_READINESS_STALE']);
const transactionUuid = value => typeof value === 'string' && /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(value);
const transactionHash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
function transactionError(code, status = 400) { return Object.assign(new Error(code), { code, status }); }
const network_transactions_fail = () => { throw transactionError('NETWORK_TRANSACTION_INVALID'); };
function transactionExact(value, fields) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).sort().join() !== fields.split(' ').sort().join()) network_transactions_fail();
}
function transactionRequest(kind, input) {
  const fields = { capabilities: 'pluginId clusterId', plan: 'pluginId clusterId expectedReadRevision intent', apply: 'pluginId planId planHash requestId ack', confirm: 'pluginId planHash requestId', rollback: 'pluginId planHash requestId' }[kind];
  if (!fields) network_transactions_fail(); transactionExact(input, fields);
  if (input.pluginId !== NETWORK_TRANSACTION_PLUGIN) network_transactions_fail();
  if (['capabilities', 'plan'].includes(kind) && !topologyId(input.clusterId)) network_transactions_fail();
  if (kind === 'plan') {
    if (!transactionHash(input.expectedReadRevision)) network_transactions_fail();
    transactionExact(input.intent, 'intentId operation vdsId nicIds');
    if (!transactionUuid(input.intent.intentId) || input.intent.operation !== 'vds-nic-set-replace' || !topologyId(input.intent.vdsId) || !Array.isArray(input.intent.nicIds) || input.intent.nicIds.length > NETWORK_TRANSACTION_LIMITS.nics || input.intent.nicIds.some(id => !topologyId(id)) || new Set(input.intent.nicIds).size !== input.intent.nicIds.length) network_transactions_fail();
  }
  if (['apply', 'confirm', 'rollback'].includes(kind) && (!transactionUuid(input.requestId) || !transactionHash(input.planHash))) network_transactions_fail();
  if (kind === 'apply' && (!transactionUuid(input.planId) || input.ack !== true)) network_transactions_fail();
  return structuredClone(input);
}
function supportsNetworkTransactions(manifest) {
  const version = manifest?.compatibility?.frameworkMinVersion;
  if (manifest?.compatibility?.schemaVersion !== 2 || !/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(version || '') || !manifest.permissions?.includes(NETWORK_TRANSACTION_PERMISSION)) return false;
  const [major, minor, patch] = version.split('.').map(Number);
  return major > 0 || minor > 2 || minor === 2 && patch >= 7;
}

const network_transactions_time = value => typeof value === 'string' && /T.*Z$/.test(value) && Number.isFinite(Date.parse(value));
const optionalTime = value => value === null || network_transactions_time(value);
const optionalId = value => value === null || topologyId(value);
const code = value => value === null || typeof value === 'string' && /^[A-Z][A-Z0-9_]{0,99}$/.test(value);
function validateTransactionResponse(kind, value, expected = {}) {
  const invalid = () => { throw transactionError('NETWORK_TRANSACTION_RESPONSE_INVALID'); };
  const envelope = 'schemaVersion pluginId clusterId serverTime';
  const fields = {
    capabilities: `${envelope} capabilities`, plan: `${envelope} planId planHash sourceRevision expiresAt operation intentId canonicalDiff affectedIds capabilities`,
    status: `${envelope} transactionId requestId planId planHash intentId acceptedAt deadline phase stateVersion stateUpdatedAt lastVerifiedAt sourceObservedAt pendingCommand steps remainingEffects`,
    list: `${envelope} items nextCursor`,
  }[kind];
  try { transactionExact(value, fields || ''); } catch { invalid(); }
  if (value.schemaVersion !== 1 || value.pluginId !== NETWORK_TRANSACTION_PLUGIN || !topologyId(value.clusterId) || !network_transactions_time(value.serverTime)) invalid();
  for (const key of ['pluginId', 'clusterId', 'transactionId', 'requestId', 'planId', 'planHash', 'intentId']) if (expected[key] !== undefined && value[key] !== expected[key]) invalid();
  if (kind === 'capabilities' || kind === 'plan') {
    const c = value.capabilities;
    try { transactionExact(c, 'identityReady workerReady storageReady clockSafe operation'); transactionExact(c.operation, 'supported applyAllowed reasonCodes verifiedAt limits'); } catch { invalid(); }
    if (['identityReady', 'workerReady', 'storageReady', 'clockSafe'].some(key => typeof c[key] !== 'boolean') || typeof c.operation.supported !== 'boolean' || typeof c.operation.applyAllowed !== 'boolean' || !Array.isArray(c.operation.reasonCodes) || c.operation.reasonCodes.length > 20 || c.operation.reasonCodes.some(x => !NETWORK_TRANSACTION_CAPABILITY_REASONS.includes(x)) || !optionalTime(c.operation.verifiedAt) || JSON.stringify(c.operation.limits) !== JSON.stringify(NETWORK_TRANSACTION_LIMITS)) invalid();
    if (c.operation.applyAllowed && (!c.operation.supported || c.operation.reasonCodes.length || ['identityReady', 'workerReady', 'storageReady', 'clockSafe'].some(key => c[key] !== true))) invalid();
  }
  if (kind === 'plan') {
    try { transactionExact(value.canonicalDiff, 'vdsId beforeNicIds afterNicIds'); } catch { invalid(); }
    if (!transactionUuid(value.planId) || !transactionHash(value.planHash) || !transactionHash(value.sourceRevision) || !network_transactions_time(value.expiresAt) || !transactionUuid(value.intentId) || value.operation !== 'vds-nic-set-replace' || !topologyId(value.canonicalDiff.vdsId)) invalid();
    for (const rows of [value.affectedIds, value.canonicalDiff.beforeNicIds, value.canonicalDiff.afterNicIds]) if (!Array.isArray(rows) || rows.length > 257 || rows.some(x => !topologyId(x)) || new Set(rows).size !== rows.length) invalid();
  }
  if (kind === 'list') {
    if (!Array.isArray(value.items) || value.items.length > 50 || value.nextCursor !== null && (typeof value.nextCursor !== 'string' || value.nextCursor.length > 1024)) invalid();
    for (const item of value.items) validateTransactionResponse('status', item, { pluginId: value.pluginId, clusterId: value.clusterId });
  }
  if (kind === 'status') {
    if (![value.transactionId, value.requestId, value.planId, value.intentId].every(transactionUuid) || !transactionHash(value.planHash) || ![value.acceptedAt, value.deadline, value.stateUpdatedAt].every(network_transactions_time) || !optionalTime(value.lastVerifiedAt) || !optionalTime(value.sourceObservedAt) || !NETWORK_TRANSACTION_PHASES.includes(value.phase) || !Number.isSafeInteger(value.stateVersion) || value.stateVersion < 1) invalid();
    if (value.pendingCommand !== null) { try { transactionExact(value.pendingCommand, 'kind requestId acceptedAt'); } catch { invalid(); } if (!['confirm', 'rollback'].includes(value.pendingCommand.kind) || !transactionUuid(value.pendingCommand.requestId) || !network_transactions_time(value.pendingCommand.acceptedAt)) invalid(); }
    if (!Array.isArray(value.steps) || value.steps.length !== 1 || !Array.isArray(value.remainingEffects) || value.remainingEffects.length > 1 || value.remainingEffects.some(x => !code(x) || x === null)) invalid();
    for (const step of value.steps) {
      try { transactionExact(step, 'stepId dependsOn phase forwardTaskId forwardTaskState inverseTaskId inverseTaskState dispatchIntentAt lastTaskObservedAt lastObjectVerifiedAt preimageMatched postimageMatched remainingEffectCode'); } catch { invalid(); }
      if (step.stepId !== 'replace-nics' || !Array.isArray(step.dependsOn) || step.dependsOn.length || !['planned', 'dispatch-intent', 'submitted', 'succeeded', 'failed', 'unknown', 'compensation-intent', 'compensating', 'compensated', 'conflict'].includes(step.phase) || ![step.forwardTaskId, step.inverseTaskId].every(optionalId) || ![step.forwardTaskState, step.inverseTaskState].every(x => x === null || ['pending', 'succeeded', 'failed'].includes(x)) || ![step.dispatchIntentAt, step.lastTaskObservedAt, step.lastObjectVerifiedAt].every(optionalTime) || ![step.preimageMatched, step.postimageMatched].every(x => x === null || typeof x === 'boolean') || !code(step.remainingEffectCode)) invalid();
    }
  }
  return structuredClone(value);
}

;// ../../framework/server/network-transaction-store.js





const NETWORK_COMMAND_HISTORY_LIMIT = 4096;
const NETWORK_CONTROL_HISTORY_LIMIT = 2 * (NETWORK_TRANSACTION_LIMITS.terminal + NETWORK_TRANSACTION_LIMITS.pending);
const NETWORK_RECEIPT_LIMIT = NETWORK_COMMAND_HISTORY_LIMIT + NETWORK_CONTROL_HISTORY_LIMIT;

const transactionDigest = value => (0,external_node_crypto_namespaceObject.createHash)('sha256').update(canonical(value)).digest('hex');
function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}';
  return JSON.stringify(value);
}
function commandPeer(key) {
  if (!Buffer.isBuffer(key) || key.length !== 32) throw transactionError('NETWORK_COMMAND_PEER_REQUIRED', 503);
  key = Buffer.from(key);
  const mac = value => (0,external_node_crypto_namespaceObject.createHmac)('sha256', key).update(canonical(value)).digest('hex');
  return { seal: value => ({ value, signature: mac(value) }), verify(envelope) {
    if (!envelope || Object.keys(envelope).sort().join() !== 'signature,value' || !/^[a-f0-9]{64}$/.test(envelope.signature || '') || !(0,external_node_crypto_namespaceObject.timingSafeEqual)(Buffer.from(envelope.signature), Buffer.from(mac(envelope.value)))) throw transactionError('NETWORK_COMMAND_PEER_INVALID', 403);
    return envelope.value;
  } };
}

// The injected directory sync is for fault testing. Production never substitutes it.
function createTransactionStore(root, { syncDirectory, sameFile = (a, b) => a.ino === b.ino && a.dev === b.dev, sharedFiles = false, fault = async () => {} } = {}) {
  root = external_node_path_namespaceObject.resolve(root); let poisoned = false;
  const location = (area, name) => {
    if (!['commands', 'responses', 'journal', 'locks', 'command-locks'].includes(area) || !/^[a-zA-Z0-9_.-]{1,160}$/.test(name) || name.startsWith('.')) throw transactionError('NETWORK_STORE_PATH_INVALID');
    return external_node_path_namespaceObject.join(root, area, name);
  };
  async function sync(dir) {
    if (syncDirectory) return syncDirectory(dir);
    const handle = await (0,promises_namespaceObject.open)(dir, 'r'); try { await handle.sync(); } finally { await handle.close(); }
  }
  async function plain(file) { const info = await (0,promises_namespaceObject.lstat)(file); if (!info.isFile() || info.isSymbolicLink() || info.nlink !== 1) throw transactionError('NETWORK_STORE_UNSAFE', 503); return info; }
  async function read(area, name, fallback) {
    const file = location(area, name);
    try {
      const info = await plain(file), max = area === 'journal' ? NETWORK_TRANSACTION_LIMITS.journalBytes : NETWORK_TRANSACTION_LIMITS.recordBytes;
      if (info.size > max) throw transactionError('NETWORK_STORE_LIMIT', 503);
      const handle = await (0,promises_namespaceObject.open)(file, 'r');
      try {
        const current = await handle.stat(); if (!sameFile(current, info) || current.size !== info.size || !current.isFile()) throw transactionError('NETWORK_STORE_UNSAFE', 503);
        const buffer = Buffer.alloc(info.size + 1); let offset = 0;
        while (offset <= info.size) { const { bytesRead } = await handle.read(buffer, offset, buffer.length - offset, offset); if (!bytesRead) break; offset += bytesRead; }
        const after = await handle.stat();
        if (offset !== info.size || !sameFile(after, current) || after.size !== current.size || after.mtimeMs !== current.mtimeMs || after.ctimeMs !== current.ctimeMs) throw transactionError('NETWORK_STORE_UNSAFE', 503);
        return JSON.parse(buffer.subarray(0, offset).toString('utf8'));
      } finally { await handle.close(); }
    } catch (error) { if (error.code === 'ENOENT' && fallback !== undefined) return structuredClone(fallback); throw transactionError('NETWORK_STORE_UNAVAILABLE', 503); }
  }
  async function write(area, name, value) {
    if (poisoned) throw transactionError('NETWORK_STORE_UNCERTAIN', 503);
    const file = location(area, name), temp = file + '.' + (0,external_node_crypto_namespaceObject.randomUUID)() + '.tmp', bytes = Buffer.from(JSON.stringify(value) + '\n');
    if (bytes.length > (area === 'journal' ? NETWORK_TRANSACTION_LIMITS.journalBytes : NETWORK_TRANSACTION_LIMITS.recordBytes)) throw transactionError('NETWORK_STORE_LIMIT', 503);
    try {
      const handle = await (0,promises_namespaceObject.open)(temp, 'wx', sharedFiles && ['commands', 'responses', 'journal'].includes(area) ? 0o640 : 0o600);
      try { await handle.writeFile(bytes); await handle.sync(); } finally { await handle.close(); }
      await fault('before-rename', { area, name, value }); await (0,promises_namespaceObject.rename)(temp, file); await sync(external_node_path_namespaceObject.dirname(file)); await fault('after-sync', { area, name, value });
      if (canonical(await read(area, name)) !== canonical(value)) throw transactionError('NETWORK_STORE_UNCERTAIN', 503);
    } catch { poisoned = true; throw transactionError('NETWORK_STORE_UNCERTAIN', 503); }
  }
  async function list(area) {
    const names = await (0,promises_namespaceObject.readdir)(external_node_path_namespaceObject.join(root, area));
    if (names.length > 8192) throw transactionError('NETWORK_STORE_LIMIT', 503);
    if (names.some(x => !/^[a-zA-Z0-9_.-]{1,220}$/.test(x))) throw transactionError('NETWORK_STORE_UNSAFE', 503);
    return names.filter(x => x.endsWith('.json')).sort();
  }
  async function lock(name, fn) {
    const dir = location('command-locks', name); try { await (0,promises_namespaceObject.mkdir)(dir, { mode: 0o700 }); } catch { throw transactionError('NETWORK_STORE_BUSY', 503); }
    try { return await fn(); } finally { await (0,promises_namespaceObject.rmdir)(dir); }
  }
  return { root, read, write, list, lock, get poisoned() { return poisoned; },
    async initialize() {
      await (0,promises_namespaceObject.mkdir)(root, { recursive: true, mode: 0o700 });
      for (const dir of [root, ...['commands', 'responses', 'journal', 'locks', 'command-locks'].map(x => external_node_path_namespaceObject.join(root, x))]) {
        await (0,promises_namespaceObject.mkdir)(dir, { recursive: true, mode: 0o700 }); const info = await (0,promises_namespaceObject.lstat)(dir); if (!info.isDirectory() || info.isSymbolicLink()) throw transactionError('NETWORK_STORE_UNSAFE', 503);
        await sync(dir);
      }
      await sync(root); await sync(external_node_path_namespaceObject.dirname(root));
    },
    async acquireWorker(identity) {
      const file = location('locks', 'worker.json'); let handle;
      try { handle = await (0,promises_namespaceObject.open)(file, 'wx', 0o600); } catch { throw transactionError('NETWORK_WORKER_FENCING_REQUIRED', 503); }
      const nonce = (0,external_node_crypto_namespaceObject.randomUUID)();
      try { await handle.writeFile(JSON.stringify({ ...identity, nonce })); await handle.sync(); await sync(external_node_path_namespaceObject.dirname(file)); }
      catch { await handle.close(); throw transactionError('NETWORK_STORE_UNCERTAIN', 503); }
      let released = false;
      const assertOwned = async () => { if ((await read('locks', 'worker.json')).nonce !== nonce) throw transactionError('NETWORK_WORKER_FENCING_REQUIRED', 503); };
      const release = async () => {
        if (released) return;
        await assertOwned();
        await handle.close(); await (0,promises_namespaceObject.unlink)(file); await sync(external_node_path_namespaceObject.dirname(file)); released = true;
      };
      release.assertOwned = assertOwned; return release;
    },
  };
}

;// external "node:perf_hooks"
const external_node_perf_hooks_namespaceObject = require("node:perf_hooks");
;// external "node:fs"
const external_node_fs_namespaceObject = require("node:fs");
;// ../../framework/server/network-transaction-identity.js
/* unused harmony import specifier */ var network_transaction_identity_open;
/* unused harmony import specifier */ var lstat;
/* unused harmony import specifier */ var constants;
/* unused harmony import specifier */ var path;
/* unused harmony import specifier */ var network_transaction_identity_transactionError;
/* unused harmony import specifier */ var network_transaction_identity_canonical;






function validateNetworkIdentityRef(ref) {
  transactionExact(ref, 'provider version uid filename subjectId target permissionEvidenceHash');
  let target; try { target = new URL(ref.target); } catch { throw transactionError('NETWORK_IDENTITY_INVALID'); }
  if (ref.provider !== 'immutable-secret-subpath' || !/^[A-Za-z0-9_-]{1,128}$/.test(ref.version || '') || !/^[A-Za-z0-9_-]{1,128}$/.test(ref.uid || '') || !/^[A-Za-z0-9_-]{1,128}$/.test(ref.filename || '') || !/^[A-Za-z0-9_-]{1,128}$/.test(ref.subjectId || '') || !transactionHash(ref.permissionEvidenceHash) || target.protocol !== 'https:' || target.username || target.password || target.pathname !== '/' || target.search || target.hash) throw transactionError('NETWORK_IDENTITY_INVALID');
  return structuredClone(ref);
}

// No path is accepted from a command. Old versions remain explicitly configured
// while they own unresolved transactions; a same-named new key is not substituted.
function createNetworkIdentityProvider({ identities, verify, fileSystem = { open: network_transaction_identity_open, lstat } }) {
  if (!Array.isArray(identities) || !identities.length || identities.length > 8 || typeof verify !== 'function') throw network_transaction_identity_transactionError('NETWORK_INDEPENDENT_IDENTITY_REQUIRED', 503);
  for (const item of identities) {
    validateNetworkIdentityRef(item.ref);
    if (!path.isAbsolute(item.file) || path.basename(item.file) !== item.ref.filename || ![0o400, 0o440].includes(item.mode) || !Number.isInteger(item.uid) || !Number.isInteger(item.gid) || !Number.isInteger(item.httpUid) || item.httpUid === 0 || item.httpUid === item.uid || !Array.isArray(item.httpGids) || item.mode === 0o440 && item.httpGids.includes(item.gid)) throw network_transaction_identity_transactionError('NETWORK_IDENTITY_ISOLATION_UNVERIFIED', 503);
  }
  return { async withActor(ref, callback, signal) {
    validateNetworkIdentityRef(ref); const entry = identities.find(item => network_transaction_identity_canonical(item.ref) === network_transaction_identity_canonical(ref));
    if (!entry) throw network_transaction_identity_transactionError('NETWORK_IDENTITY_VERSION_MISMATCH', 503);
    let handle, bytes;
    try {
      let parent = path.dirname(entry.file);
      while (true) {
        const info = await fileSystem.lstat(parent); if (!info.isDirectory() || info.isSymbolicLink() || info.mode & 0o022 || ![0, entry.uid].includes(info.uid)) throw new Error('untrusted parent');
        const next = path.dirname(parent); if (parent === next) break; parent = next;
      }
      const before = await fileSystem.lstat(entry.file); if (!before.isFile() || before.isSymbolicLink()) throw new Error('not regular');
      handle = await fileSystem.open(entry.file, constants.O_RDONLY | (constants.O_NOFOLLOW || 0));
      const info = await handle.stat();
      if (!info.isFile() || info.nlink !== 1 || info.ino !== before.ino || info.dev !== before.dev || info.uid !== entry.uid || info.gid !== entry.gid || (info.mode & 0o777) !== entry.mode || info.size < 1 || info.size > 8192) throw new Error('invalid identity file');
      bytes = Buffer.alloc(info.size + 1); const { bytesRead } = await handle.read(bytes, 0, bytes.length, 0); const after = await handle.stat();
      if (bytesRead !== info.size || after.size !== info.size || after.ino !== info.ino || after.dev !== info.dev || after.mtimeMs !== info.mtimeMs || after.ctimeMs !== info.ctimeMs) throw new Error('identity file changed');
      const key = bytes.subarray(0, bytesRead).toString('utf8'); if (!key || /[\x00-\x20\x7f]/.test(key)) throw new Error('invalid key');
      signal?.throwIfAborted();
      const actor = { id: ref.subjectId, source: 'network-worker', auth: { Authorization: key } };
      const proof = await verify({ actor, identityRef: ref, signal });
      if (proof?.subjectId !== ref.subjectId || proof.target !== ref.target || proof.permissionEvidenceHash !== ref.permissionEvidenceHash) throw new Error('identity proof mismatch');
      return await callback(actor);
    } catch { throw network_transaction_identity_transactionError('NETWORK_INDEPENDENT_IDENTITY_REQUIRED', 503); }
    finally { bytes?.fill(0); await handle?.close(); }
  } };
}

;// ../../framework/server/network-transaction-protection.js




const deny = code => { throw transactionError(code, 422); };
const safe = type => ['VM', 'MIGRATION'].includes(type);
const uniqueIds = (rows, max = 1024) => Array.isArray(rows) && rows.length <= max && rows.every(topologyId) && new Set(rows).size === rows.length;
function protectNicReplacement(raw, input, now) {
  transactionExact(raw, 'complete clusterId readRevision observedAt vdses vlans nics dependencies reversibility concurrency');
  if (!raw || raw.complete !== true || raw.clusterId !== input.clusterId || !transactionHash(raw.readRevision) || !Number.isFinite(Date.parse(raw.observedAt)) || now - Date.parse(raw.observedAt) > 10000 || Date.parse(raw.observedAt) > now + 2000) deny('NETWORK_SOURCE_UNTRUSTED');
  if (!Array.isArray(raw.vdses) || !Array.isArray(raw.vlans) || !Array.isArray(raw.nics) || raw.vdses.length > 128 || raw.vlans.length > 512 || raw.nics.length > 1024 || [raw.vdses, raw.vlans, raw.nics].some(rows => rows.some(x => !topologyId(x?.id)) || new Set(rows.map(x => x.id)).size !== rows.length)) deny('NETWORK_SOURCE_UNTRUSTED');
  const vds = raw.vdses.find(x => x.id === input.intent.vdsId);
  for (const sw of raw.vdses) transactionExact(sw, 'id clusterId internal type nicIds vlanIds asyncTaskId version');
  for (const vlan of raw.vlans) transactionExact(vlan, 'id vdsId type networkIds');
  for (const nic of raw.nics) transactionExact(nic, 'id clusterId hostId physical type vdsIds');
  if (!vds || vds.clusterId !== input.clusterId || vds.internal !== false || !safe(vds.type) || vds.asyncTaskId !== null || !uniqueIds(vds.nicIds, NETWORK_TRANSACTION_LIMITS.nics) || !uniqueIds(vds.vlanIds, 512) || !transactionHash(vds.version)) deny('NETWORK_PROTECTED_RESOURCE');
  if (raw.vlans.some(x => x.vdsId === vds.id && !vds.vlanIds.includes(x.id)) || vds.vlanIds.some(id => { const x = raw.vlans.find(x => x.id === id); return !x || x.vdsId !== vds.id || !safe(x.type) || !uniqueIds(x.networkIds, 512); })) deny('NETWORK_PROTECTED_RESOURCE');
  const nicIds = [...new Set([...vds.nicIds, ...input.intent.nicIds])].sort();
  const dependencies = raw.dependencies;
  transactionExact(dependencies, 'verified workerPathNicIds protectedNicIds evidenceHash');
  transactionExact(raw.reversibility, 'verified evidenceHash'); transactionExact(raw.concurrency, 'verified evidenceHash');
  if (dependencies?.verified !== true || !uniqueIds(dependencies.workerPathNicIds) || !uniqueIds(dependencies.protectedNicIds) || !transactionHash(dependencies.evidenceHash)) deny('NETWORK_DEPENDENCIES_UNVERIFIED');
  for (const id of nicIds) {
    const nic = raw.nics.find(x => x.id === id);
    if (!nic || nic.clusterId !== input.clusterId || nic.physical !== true || !safe(nic.type) || !topologyId(nic.hostId) || !uniqueIds(nic.vdsIds, 128) || nic.vdsIds.some(x => x !== vds.id) || nic.vdsIds.includes(vds.id) !== vds.nicIds.includes(id) || dependencies.workerPathNicIds.includes(id) || dependencies.protectedNicIds.includes(id)) deny('NETWORK_PROTECTED_NIC');
    if (raw.vdses.some(sw => sw.id !== vds.id && (!Array.isArray(sw.nicIds) || sw.nicIds.includes(id)))) deny('NETWORK_PROTECTED_NIC');
  }
  if (raw.reversibility?.verified !== true || !transactionHash(raw.reversibility.evidenceHash)) deny('NETWORK_REVERSIBILITY_UNVERIFIED');
  if (raw.concurrency?.verified !== true || !transactionHash(raw.concurrency.evidenceHash)) deny('NETWORK_CONCURRENCY_UNVERIFIED');
  const before = [...vds.nicIds].sort(), after = [...input.intent.nicIds].sort();
  if (JSON.stringify(before) === JSON.stringify(after)) deny('NETWORK_NO_CHANGE');
  const { nicIds: ignoredNicIds, version: ignoredVersion, ...vdsGuard } = vds;
  const nicGuards = raw.nics.filter(x => nicIds.includes(x.id)).map(({ vdsIds, ...nic }) => nic).sort((a, b) => a.id.localeCompare(b.id));
  const preimage = { vds, vlans: raw.vlans.filter(x => x.vdsId === vds.id), nics: raw.nics.filter(x => nicIds.includes(x.id)), dependencies, reversibility: raw.reversibility, concurrency: raw.concurrency };
  if (Buffer.byteLength(JSON.stringify(preimage)) > NETWORK_TRANSACTION_LIMITS.recordBytes / 2) deny('NETWORK_RECORD_LIMIT');
  return { vdsId: vds.id, beforeNicIds: before, afterNicIds: after, version: vds.version, observedAt: raw.observedAt,
    preimage: structuredClone(preimage), intended: { vdsId: vds.id, nicIds: after }, inverse: { vdsId: vds.id, nicIds: before },
    guardHash: transactionDigest({ vds: vdsGuard, vlans: raw.vlans.filter(x => x.vdsId === vds.id), nics: nicGuards, dependencies, reversibility: raw.reversibility, concurrency: raw.concurrency }),
    evidenceHash: transactionDigest(preimage) };
}

;// ../../framework/server/network-transaction-worker.js








const iso = value => new Date(value).toISOString();
const network_transaction_worker_fail = (code, status = 409) => { throw transactionError(code, status); };
const pending = tx => !NETWORK_TRANSACTION_TERMINAL.includes(tx.phase);
const equalIds = (a, b) => canonical([...a].sort()) === canonical([...b].sort());
const blankStep = () => ({ stepId: 'replace-nics', dependsOn: [], phase: 'planned', forwardTaskId: null, forwardTaskState: null, inverseTaskId: null, inverseTaskState: null, dispatchIntentAt: null, lastTaskObservedAt: null, lastObjectVerifiedAt: null, preimageMatched: null, postimageMatched: null, remainingEffectCode: null });
function transactionView(tx, now) {
  return { schemaVersion: 1, pluginId: NETWORK_TRANSACTION_PLUGIN, clusterId: tx.clusterId, serverTime: iso(now), ...Object.fromEntries(['transactionId', 'requestId', 'planId', 'planHash', 'intentId', 'acceptedAt', 'deadline', 'phase', 'stateVersion', 'stateUpdatedAt', 'lastVerifiedAt', 'sourceObservedAt', 'pendingCommand', 'steps', 'remainingEffects'].map(key => [key, structuredClone(tx[key])])) };
}

function createNetworkTransactionWorker({ store, peer, native, authorize, readiness, identityRef, now = Date.now, monotonic = () => external_node_perf_hooks_namespaceObject.performance.now(), workerIdentity = {} }) {
  let state, release, busy = false, lastWall, lastMono, stopped = false;
  const inFlight = new Set();
  function clock() {
    const wall = now(), mono = monotonic();
    if (!Number.isFinite(wall) || !Number.isFinite(mono) || state && wall < state.maxObservedWall - 2000 || lastWall !== undefined && Math.abs((wall - lastWall) - (mono - lastMono)) > 2000) state.clockUnsafe = true;
    lastWall = wall; lastMono = mono; if (state) state.maxObservedWall = Math.max(state.maxObservedWall, wall); return wall;
  }
  async function save({ admission = false } = {}) {
    if (Object.keys(state.receipts).length > NETWORK_RECEIPT_LIMIT) network_transaction_worker_fail('NETWORK_RECEIPT_CAPACITY', 503);
    state.version++;
    for (const tx of Object.values(state.transactions)) if (Buffer.byteLength(canonical(tx)) > NETWORK_TRANSACTION_LIMITS.recordBytes) network_transaction_worker_fail('NETWORK_JOURNAL_LIMIT', 503);
    const bytes = Buffer.byteLength(JSON.stringify(state)) + 1;
    const controlReserve = NETWORK_TRANSACTION_LIMITS.pending * (NETWORK_TRANSACTION_LIMITS.recordBytes + 2 * 2048) + 4096;
    if (bytes > NETWORK_TRANSACTION_LIMITS.journalBytes - (admission ? controlReserve : 0)) network_transaction_worker_fail(admission ? 'NETWORK_JOURNAL_ADMISSION_CAPACITY' : 'NETWORK_JOURNAL_LIMIT', 503);
    await store.write('journal', 'state.json', state);
  }
  function transition(tx, phase, code = null) {
    if (tx.phase === phase && tx.steps[0].remainingEffectCode === code) return;
    tx.phase = phase; tx.stateVersion++; tx.stateUpdatedAt = iso(clock()); tx.remainingEffects = code ? [code] : []; tx.steps[0].remainingEffectCode = code;
    if (tx.events.length < 128) tx.events.push({ at: tx.stateUpdatedAt, phase, code });
    else { tx.events[127] = { at: tx.stateUpdatedAt, phase, code }; }
  }
  async function ready(clusterId, ref = identityRef) {
    const value = await bounded(signal => readiness({ clusterId, identityRef: ref, signal }));
    const reasons = [];
    for (const [key, reason] of [['identityReady', 'NETWORK_INDEPENDENT_IDENTITY_REQUIRED'], ['workerReady', 'NETWORK_INDEPENDENT_WORKER_REQUIRED'], ['storageReady', 'NETWORK_STORAGE_UNVERIFIED'], ['reversible', 'NETWORK_REVERSIBILITY_UNVERIFIED'], ['concurrencySafe', 'NETWORK_CONCURRENCY_UNVERIFIED'], ['dependenciesVerified', 'NETWORK_DEPENDENCIES_UNVERIFIED']]) if (value?.[key] !== true) reasons.push(reason);
    if (!ref || canonical(value?.identityRef) !== canonical(ref)) reasons.push('NETWORK_IDENTITY_VERSION_MISMATCH');
    if (value?.targetAllowed !== true) reasons.push('NETWORK_TARGET_NOT_ALLOWED');
    if (!Number.isFinite(Date.parse(value?.verifiedAt)) || clock() - Date.parse(value.verifiedAt) > 10000 || Date.parse(value.verifiedAt) > clock() + 2000) reasons.push('NETWORK_READINESS_STALE');
    if (state.clockUnsafe) reasons.push('NETWORK_CLOCK_UNSAFE');
    if (store.poisoned) reasons.push('NETWORK_STORE_UNCERTAIN');
    return { identityReady: value?.identityReady === true, workerReady: value?.workerReady === true, storageReady: value?.storageReady === true && !store.poisoned, clockSafe: !state.clockUnsafe,
      operation: { supported: true, applyAllowed: !reasons.length, reasonCodes: reasons, verifiedAt: value?.verifiedAt || null, limits: NETWORK_TRANSACTION_LIMITS } };
  }
  async function bounded(fn) {
    if (state && !store.poisoned) await store.write('journal', 'heartbeat.json', { schemaVersion: 1, observedAt: iso(clock()), clockSafe: !state.clockUnsafe, workerIdentity });
    const controller = new AbortController(); let timer;
    let promise; try { promise = Promise.resolve(fn(controller.signal)); } catch (error) { promise = Promise.reject(error); }
    inFlight.add(promise); promise.then(() => inFlight.delete(promise), () => inFlight.delete(promise));
    try { return await Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => { controller.abort(); reject(transactionError('NETWORK_NATIVE_TIMEOUT', 503)); }, 4000); })]); }
    finally { clearTimeout(timer); }
  }
  async function authority(command, active = true) {
    const result = await bounded(signal => authorize({ ownerId: command.ownerId, clusterId: command.clusterId, pluginId: NETWORK_TRANSACTION_PLUGIN, manifestHash: command.manifestHash, active, signal }));
    if (result?.authorized !== true || active && (result.active !== true || result.packageId !== command.manifestHash || !supportsNetworkTransactions(result.manifest))) network_transaction_worker_fail('NETWORK_TRANSACTION_PERMISSION_REQUIRED', 403);
  }
  function envelope(clusterId, fields) { return { schemaVersion: 1, pluginId: NETWORK_TRANSACTION_PLUGIN, clusterId, serverTime: iso(clock()), ...fields }; }
  async function observe(tx) {
    const raw = await bounded(signal => native.read({ clusterId: tx.clusterId, vdsId: tx.action.vdsId, identityRef: tx.identityRef, signal }));
    const sw = raw?.vdses?.find(x => x.id === tx.action.vdsId);
    if (!Array.isArray(sw?.nicIds)) network_transaction_worker_fail('NETWORK_SOURCE_UNTRUSTED');
    const pre = equalIds(sw.nicIds, tx.action.beforeNicIds), post = equalIds(sw.nicIds, tx.action.afterNicIds);
    const target = post ? tx.action.beforeNicIds : tx.action.afterNicIds;
    const protectedRead = protectNicReplacement(raw, { clusterId: tx.clusterId, intent: { vdsId: tx.action.vdsId, nicIds: target } }, clock());
    if (protectedRead.guardHash !== tx.action.guardHash) network_transaction_worker_fail('NETWORK_OBJECT_CONFLICT');
    tx.sourceObservedAt = raw.observedAt; tx.lastVerifiedAt = iso(clock());
    const step = tx.steps[0]; step.lastObjectVerifiedAt = tx.lastVerifiedAt; step.preimageMatched = pre; step.postimageMatched = post;
    return { pre, post, version: sw.version };
  }
  async function answer(command, data, status = 200) { await store.write('responses', command.commandId + '.json', { status, data }); }
  async function processCommand(command) {
    transactionExact(command, 'schemaVersion kind commandId ownerId clusterId manifestHash acceptedAt transactionId input');
    if (command?.schemaVersion !== 1 || !transactionUuid(command.commandId) || !['capabilities', 'plan', 'apply', 'confirm', 'rollback'].includes(command.kind) || !/^[A-Za-z0-9_-]{1,128}$/.test(command.ownerId || '') || !transactionHash(command.manifestHash)) network_transaction_worker_fail('NETWORK_COMMAND_INVALID', 403);
    transactionRequest(command.kind, command.input);
    if (!topologyId(command.clusterId) || command.input.clusterId !== undefined && command.input.clusterId !== command.clusterId || !Number.isFinite(Date.parse(command.acceptedAt)) || ['confirm', 'rollback'].includes(command.kind) && !transactionUuid(command.transactionId) || !['confirm', 'rollback'].includes(command.kind) && command.transactionId !== null) network_transaction_worker_fail('NETWORK_COMMAND_INVALID', 403);
    const digest = transactionDigest({ kind: command.kind, input: command.input, transactionId: command.transactionId });
    const key = transactionDigest({ ownerId: command.ownerId, requestId: command.input.requestId || command.commandId });
    if (state.receipts[key]) {
      if (state.receipts[key].digest !== digest) network_transaction_worker_fail('NETWORK_IDEMPOTENCY_MISMATCH');
      const old = state.receipts[key]; return answer(command, old.transactionId ? transactionView(state.transactions[old.transactionId], clock()) : old.data, 200);
    }
    await authority(command, command.kind !== 'rollback'); clock();
    if (command.kind === 'capabilities') return answer(command, envelope(command.clusterId, { capabilities: await ready(command.clusterId) }));
    if (command.kind === 'plan') {
      if (state.clockUnsafe) network_transaction_worker_fail('NETWORK_CLOCK_UNSAFE', 422);
      const capabilities = await ready(command.clusterId);
      if (!capabilities.operation.applyAllowed) network_transaction_worker_fail(capabilities.operation.reasonCodes[0], 422);
      const raw = await bounded(signal => native.read({ clusterId: command.clusterId, vdsId: command.input.intent.vdsId, identityRef, signal }));
      if (raw?.readRevision !== command.input.expectedReadRevision) network_transaction_worker_fail('NETWORK_PREIMAGE_CHANGED');
      const action = protectNicReplacement(raw, command.input, clock());
      const id = (0,external_node_crypto_namespaceObject.randomUUID)(), plan = { planId: id, ownerId: command.ownerId, clusterId: command.clusterId, manifestHash: command.manifestHash, intentId: command.input.intent.intentId, action, sourceRevision: raw.readRevision, expiresAt: iso(clock() + NETWORK_TRANSACTION_LIMITS.planMs), identityRef: structuredClone(identityRef) };
      plan.planHash = transactionDigest(plan);
      state.plans = Object.fromEntries(Object.entries(state.plans).filter(([, x]) => Date.parse(x.expiresAt) > clock()));
      if (Object.keys(state.plans).length >= 128) network_transaction_worker_fail('NETWORK_PLAN_CAPACITY', 503);
      state.plans[id] = plan;
      const data = envelope(command.clusterId, { planId: id, planHash: plan.planHash, sourceRevision: plan.sourceRevision, expiresAt: plan.expiresAt, operation: 'vds-nic-set-replace', intentId: plan.intentId,
        canonicalDiff: { vdsId: action.vdsId, beforeNicIds: action.beforeNicIds, afterNicIds: action.afterNicIds }, affectedIds: [...new Set([action.vdsId, ...action.beforeNicIds, ...action.afterNicIds])].sort(), capabilities });
      state.receipts[key] = { digest, data }; await save({ admission: true }); return answer(command, data);
    }
    if (command.kind === 'apply') {
      const plan = state.plans[command.input.planId];
      if (!plan || plan.ownerId !== command.ownerId || plan.clusterId !== command.clusterId || plan.manifestHash !== command.manifestHash || plan.planHash !== command.input.planHash) network_transaction_worker_fail('NETWORK_PLAN_NOT_FOUND', 404);
      if (clock() >= Date.parse(plan.expiresAt)) network_transaction_worker_fail('NETWORK_PLAN_EXPIRED');
      const capabilities = await ready(plan.clusterId, plan.identityRef); if (!capabilities.operation.applyAllowed) network_transaction_worker_fail(capabilities.operation.reasonCodes[0], 422);
      const all = Object.values(state.transactions), unresolved = all.filter(pending);
      if (unresolved.length >= NETWORK_TRANSACTION_LIMITS.pending || unresolved.some(x => x.clusterId === plan.clusterId) || all.filter(x => !pending(x)).length >= NETWORK_TRANSACTION_LIMITS.terminal) network_transaction_worker_fail('NETWORK_TRANSACTION_CAPACITY', 503);
      const tx = { schemaVersion: 1, transactionId: (0,external_node_crypto_namespaceObject.randomUUID)(), requestId: command.input.requestId, planId: plan.planId, planHash: plan.planHash, intentId: plan.intentId, ownerId: command.ownerId, clusterId: plan.clusterId, manifestHash: plan.manifestHash, acceptedAt: iso(clock()), deadline: iso(clock() + NETWORK_TRANSACTION_LIMITS.confirmMs), phase: 'queued', stateVersion: 1,
        stateUpdatedAt: iso(clock()), maxObservedWall: clock(), lastVerifiedAt: null, sourceObservedAt: plan.action.observedAt, pendingCommand: null, remainingEffects: [], steps: [blankStep()], action: structuredClone(plan.action), identityRef: structuredClone(plan.identityRef), forwardAttempt: null, inverseAttempt: null, rollbackRequested: false, confirmationProof: null, events: [], polls: { errors: 0, nextAt: 0 }, ownerCommand: { ownerId: command.ownerId, clusterId: plan.clusterId, manifestHash: plan.manifestHash } };
      state.transactions[tx.transactionId] = tx; state.receipts[key] = { digest, transactionId: tx.transactionId }; await save({ admission: true }); return answer(command, transactionView(tx, clock()), 202);
    }
    const tx = state.transactions[command.transactionId];
    if (!tx || tx.ownerId !== command.ownerId || tx.clusterId !== command.clusterId || tx.planHash !== command.input.planHash) network_transaction_worker_fail('NETWORK_TRANSACTION_NOT_FOUND', 404);
    if (!pending(tx)) network_transaction_worker_fail('NETWORK_TRANSACTION_TERMINAL');
    if (tx.pendingCommand?.kind === command.kind || command.kind === 'rollback' && tx.rollbackRequested) network_transaction_worker_fail('NETWORK_COMMAND_ALREADY_PENDING');
    if (command.kind === 'confirm' && (tx.phase !== 'awaiting-confirmation' || clock() >= Date.parse(tx.deadline) || state.clockUnsafe || tx.rollbackRequested)) network_transaction_worker_fail('NETWORK_CONFIRM_NOT_ALLOWED');
    tx.pendingCommand = { kind: command.kind, requestId: command.input.requestId, acceptedAt: iso(clock()) };
    if (command.kind === 'rollback') { tx.rollbackRequested = true; transition(tx, 'rollback-requested', tx.steps[0].remainingEffectCode); }
    state.receipts[key] = { digest, transactionId: tx.transactionId }; await save(); return answer(command, transactionView(tx, clock()), 202);
  }
  async function commands({ controlsOnly = false, skipControls = false, limit = 4 } = {}) {
    const names = await store.list('commands'), values = [];
    for (const name of names) {
      const command = peer.verify(await store.read('commands', name));
      if (await store.read('responses', command.commandId + '.json', null)) continue;
      values.push(command);
    }
    values.sort((a, b) => (['rollback', 'confirm'].includes(a.kind) ? 0 : 1) - (['rollback', 'confirm'].includes(b.kind) ? 0 : 1) || a.acceptedAt.localeCompare(b.acceptedAt));
    if (values.length > NETWORK_TRANSACTION_LIMITS.commands + NETWORK_TRANSACTION_LIMITS.pending * 2) network_transaction_worker_fail('NETWORK_COMMAND_CAPACITY', 503);
    for (const command of values.filter(command => controlsOnly ? ['confirm', 'rollback'].includes(command.kind) : skipControls ? !['confirm', 'rollback'].includes(command.kind) : true).slice(0, limit)) {
      const before = { ...state, plans: { ...state.plans }, transactions: { ...state.transactions }, receipts: { ...state.receipts } };
      if (command.transactionId && state.transactions[command.transactionId]) before.transactions[command.transactionId] = structuredClone(state.transactions[command.transactionId]);
      try { await processCommand(command); }
      catch (error) {
        if (store.poisoned) throw error;
        const unsafe = state.clockUnsafe, observed = state.maxObservedWall; state = before; state.clockUnsafe ||= unsafe; state.maxObservedWall = Math.max(observed, state.maxObservedWall);
        const code = /^NETWORK_[A-Z_]+$/.test(error.code || '') ? error.code : 'NETWORK_DEPENDENCY_UNAVAILABLE';
        await answer(command, { schemaVersion: 1, code, serverTime: iso(clock()), retryableRead: true, transactionId: command.transactionId || null, requestId: command.input?.requestId || null }, error.status || 503);
      }
    }
  }
  async function dispatch(tx, inverse, version) {
    const step = tx.steps[0], field = inverse ? 'inverseAttempt' : 'forwardAttempt';
    if (tx[field]) return;
    tx[field] = { attemptId: (0,external_node_crypto_namespaceObject.randomUUID)(), at: iso(clock()), bodyHash: transactionDigest({ vdsId: tx.action.vdsId, nicIds: inverse ? tx.action.beforeNicIds : tx.action.afterNicIds, version }) };
    step.phase = inverse ? 'compensation-intent' : 'dispatch-intent'; if (!inverse) step.dispatchIntentAt = tx[field].at;
    transition(tx, inverse ? 'rolling-back' : 'applying', 'NETWORK_EFFECT_POSSIBLE'); await save();
    // Intent is durable before this last gate. Refusal here must stay uncertain.
    const capabilities = await ready(tx.clusterId, tx.identityRef); clock();
    if (capabilities.operation.reasonCodes.some(code => !inverse || code !== 'NETWORK_CLOCK_UNSAFE') || !inverse && (state.clockUnsafe || clock() >= Date.parse(tx.deadline) - NETWORK_TRANSACTION_LIMITS.dispatchMarginMs || tx.rollbackRequested)) { transition(tx, inverse ? 'rollback-unknown' : 'apply-unknown', 'NETWORK_DISPATCH_NOT_PROVEN'); await save(); return; }
    if (!inverse) {
      await authority(tx.ownerCommand); await commands({ controlsOnly: true, limit: 16 }); clock();
      if (tx.rollbackRequested || clock() >= Date.parse(tx.deadline) - NETWORK_TRANSACTION_LIMITS.dispatchMarginMs || state.clockUnsafe) { transition(tx, 'apply-unknown', 'NETWORK_DISPATCH_NOT_PROVEN'); await save(); return; }
    }
    await release.assertOwned(); clock();
    if (!inverse && (clock() >= Date.parse(tx.deadline) - NETWORK_TRANSACTION_LIMITS.dispatchMarginMs || state.clockUnsafe || tx.rollbackRequested)) { transition(tx, 'apply-unknown', 'NETWORK_DISPATCH_NOT_PROVEN'); await save(); return; }
    let response;
    try { response = await bounded(signal => native.dispatch({ clusterId: tx.clusterId, vdsId: tx.action.vdsId, nicIds: inverse ? tx.action.beforeNicIds : tx.action.afterNicIds, expectedVersion: version, guardHash: tx.action.guardHash, attemptId: tx[field].attemptId, identityRef: tx.identityRef, signal,
      beforeSend: async () => {
        await release.assertOwned(); if (!inverse) { await authority(tx.ownerCommand); await commands({ controlsOnly: true, limit: 16 }); }
        clock(); signal.throwIfAborted();
        if (store.poisoned || !inverse && (state.clockUnsafe || clock() >= Date.parse(tx.deadline) - NETWORK_TRANSACTION_LIMITS.dispatchMarginMs || tx.rollbackRequested)) network_transaction_worker_fail('NETWORK_DISPATCH_NOT_PROVEN');
      } })); }
    catch { step.phase = 'unknown'; transition(tx, inverse ? 'rollback-unknown' : 'apply-unknown', 'NETWORK_NATIVE_OUTCOME_UNKNOWN'); await save(); return; }
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(response?.taskId || '')) { step.phase = 'unknown'; transition(tx, inverse ? 'rollback-unknown' : 'apply-unknown', 'NETWORK_NATIVE_OUTCOME_UNKNOWN'); await save(); return; }
    step[inverse ? 'inverseTaskId' : 'forwardTaskId'] = response.taskId; step[inverse ? 'inverseTaskState' : 'forwardTaskState'] = 'pending'; step.phase = inverse ? 'compensating' : 'submitted'; tx.polls.nextAt = clock() + 1000; await save();
  }
  async function poll(tx, inverse) {
    const step = tx.steps[0], id = step[inverse ? 'inverseTaskId' : 'forwardTaskId'];
    if (!id || tx.polls.errors >= 5 || clock() < tx.polls.nextAt) return false;
    let result;
    try {
      result = await bounded(signal => native.task({ taskId: id, identityRef: tx.identityRef, signal }));
      if (result?.taskId !== id || !['pending', 'succeeded', 'failed'].includes(result.state)) throw new Error('invalid task');
      tx.polls.errors = 0; tx.polls.nextAt = clock() + 1000;
    } catch {
      tx.polls.errors++; tx.polls.nextAt = clock() + Math.min(8000, 1000 * 2 ** (tx.polls.errors - 1));
      if (tx.polls.errors >= 5) { step.phase = 'unknown'; transition(tx, inverse ? 'rollback-unknown' : 'apply-unknown', 'NETWORK_TASK_UNAVAILABLE'); }
      await save(); return false;
    }
    const stateKey = inverse ? 'inverseTaskState' : 'forwardTaskState';
    const changed = step[stateKey] !== result.state; step[stateKey] = result.state; step.lastTaskObservedAt = iso(clock());
    if (result.state === 'pending') { if (changed) await save(); return false; }
    const current = await observe(tx);
    if (inverse) {
      if (result.state === 'succeeded' && current.pre) { step.phase = 'compensated'; tx.pendingCommand = null; transition(tx, 'rolled-back'); }
      else { step.phase = 'conflict'; transition(tx, current.post ? 'rollback-unknown' : 'conflict', 'NETWORK_INVERSE_NOT_VERIFIED'); }
    } else if (result.state === 'succeeded' && current.post) { step.phase = 'succeeded'; transition(tx, tx.rollbackRequested || clock() >= Date.parse(tx.deadline) || state.clockUnsafe ? 'rollback-requested' : 'awaiting-confirmation', 'NETWORK_UNCONFIRMED_CHANGE'); }
    else if (result.state === 'failed' && current.pre) { step.phase = 'failed'; transition(tx, 'failed-unapplied'); }
    else if (current.post) { step.phase = 'succeeded'; tx.rollbackRequested = true; transition(tx, 'rollback-requested', 'NETWORK_PARTIAL_CHANGE'); }
    else { step.phase = 'unknown'; transition(tx, 'apply-unknown', 'NETWORK_NATIVE_POSTIMAGE_MISMATCH'); }
    await save(); return true;
  }
  async function advance(tx) {
    clock(); const expired = clock() >= Date.parse(tx.deadline), step = tx.steps[0];
    if (!pending(tx)) return;
    if (!tx.forwardAttempt) {
      if (expired || tx.rollbackRequested || state.clockUnsafe) { transition(tx, 'expired-unapplied'); tx.pendingCommand = null; await save(); return; }
      if (clock() >= Date.parse(tx.deadline) - NETWORK_TRANSACTION_LIMITS.dispatchMarginMs) return;
      await authority(tx.ownerCommand); const capabilities = await ready(tx.clusterId, tx.identityRef); if (!capabilities.operation.applyAllowed) { transition(tx, 'rejected'); await save(); return; }
      const current = await observe(tx); if (!current.pre) { transition(tx, 'conflict', 'NETWORK_PREIMAGE_CHANGED'); await save(); return; }
      return dispatch(tx, false, current.version);
    }
    if (tx.inverseAttempt) { if (step.inverseTaskId && step.inverseTaskState === 'pending') await poll(tx, true); return; }
    if (step.forwardTaskId && step.forwardTaskState === 'pending') { await poll(tx, false); return; }
    if (step.forwardTaskState !== 'succeeded' && step.phase !== 'succeeded') return;
    if (tx.rollbackRequested || expired || state.clockUnsafe) {
      const capabilities = await ready(tx.clusterId, tx.identityRef);
      if (!capabilities.identityReady || !capabilities.storageReady || !capabilities.workerReady || capabilities.operation.reasonCodes.some(x => x !== 'NETWORK_CLOCK_UNSAFE')) { transition(tx, 'manual-intervention', 'NETWORK_ROLLBACK_IDENTITY_UNAVAILABLE'); await save(); return; }
      const current = await observe(tx);
      if (!current.post) { step.phase = 'conflict'; transition(tx, 'conflict', 'NETWORK_OBJECT_CONFLICT'); await save(); return; }
      tx.polls.errors = 0; return dispatch(tx, true, current.version);
    }
    if (tx.pendingCommand?.kind === 'confirm') {
      await authority(tx.ownerCommand); const current = await observe(tx); clock();
      if (!current.post) { transition(tx, 'conflict', 'NETWORK_OBJECT_CONFLICT'); await save(); return; }
      if (state.clockUnsafe || clock() >= Date.parse(tx.deadline)) return;
      tx.confirmationIntent = { requestId: tx.pendingCommand.requestId, at: iso(clock()), postimageHash: transactionDigest(tx.action.afterNicIds) }; await save();
      // A recovered intent without this completed-sync observation never confirms.
      if (state.clockUnsafe || clock() >= Date.parse(tx.deadline)) { tx.rollbackRequested = true; await save(); return; }
      tx.confirmationProof = { intentHash: transactionDigest(tx.confirmationIntent), durableBefore: iso(clock()) }; tx.pendingCommand = null; transition(tx, 'confirmed'); await save();
    }
  }
  return {
    async start() {
      await store.initialize(); release = await store.acquireWorker(workerIdentity);
      try {
        state = await store.read('journal', 'state.json', { schemaVersion: 1, version: 0, maxObservedWall: 0, clockUnsafe: false, plans: {}, transactions: {}, receipts: {} });
        transactionExact(state, 'schemaVersion version maxObservedWall clockUnsafe plans transactions receipts');
        if (state.schemaVersion !== 1 || !Number.isSafeInteger(state.version) || !Number.isFinite(state.maxObservedWall) || typeof state.clockUnsafe !== 'boolean' || !state.plans || !state.transactions || !state.receipts || Object.keys(state.plans).length > 128 || Object.keys(state.transactions).length > NETWORK_TRANSACTION_LIMITS.terminal + NETWORK_TRANSACTION_LIMITS.pending || Object.keys(state.receipts).length > NETWORK_RECEIPT_LIMIT) network_transaction_worker_fail('NETWORK_JOURNAL_INVALID', 503);
        clock();
        for (const [id, tx] of Object.entries(state.transactions)) {
          if (id !== tx.transactionId || !topologyId(tx.ownerId) || !transactionHash(tx.manifestHash) || !topologyId(tx.action?.vdsId) || ![tx.action?.guardHash, tx.action?.version, tx.action?.evidenceHash].every(transactionHash) || [tx.action?.beforeNicIds, tx.action?.afterNicIds].some(rows => !Array.isArray(rows) || rows.length > NETWORK_TRANSACTION_LIMITS.nics || rows.some(x => !topologyId(x)) || new Set(rows).size !== rows.length)) network_transaction_worker_fail('NETWORK_JOURNAL_INVALID', 503);
          validateNetworkIdentityRef(tx.identityRef); validateTransactionResponse('status', transactionView(tx, clock()));
          if (transactionDigest(tx.action.preimage) !== tx.action.evidenceHash || tx.action.inverse?.vdsId !== tx.action.vdsId || tx.action.intended?.vdsId !== tx.action.vdsId || !equalIds(tx.action.inverse.nicIds, tx.action.beforeNicIds) || !equalIds(tx.action.intended.nicIds, tx.action.afterNicIds)) network_transaction_worker_fail('NETWORK_JOURNAL_INVALID', 503);
          if (tx.forwardAttempt && !tx.steps[0].forwardTaskId && pending(tx)) transition(tx, 'apply-unknown', 'NETWORK_RECOVERED_DISPATCH_UNKNOWN');
          if (tx.inverseAttempt && !tx.steps[0].inverseTaskId && pending(tx)) transition(tx, 'rollback-unknown', 'NETWORK_RECOVERED_DISPATCH_UNKNOWN');
        }
        await save();
      } catch (error) { stopped = true; throw error; }
    },
    async tick() {
      if (!state || stopped || busy || store.poisoned) network_transaction_worker_fail('NETWORK_WORKER_UNAVAILABLE', 503); busy = true;
      try {
        clock(); await commands({ controlsOnly: true, limit: 16 }); const visited = new Set();
        async function advancePending() {
          for (const tx of Object.values(state.transactions).filter(pending).sort((a, b) => a.deadline.localeCompare(b.deadline))) {
            if (inFlight.size) break;
            if (visited.has(tx.transactionId)) continue; visited.add(tx.transactionId);
            try { await advance(tx); }
            catch (error) { if (store.poisoned) throw error; transition(tx, 'manual-intervention', 'NETWORK_RECONCILIATION_REQUIRED'); await save(); }
          }
        }
        await advancePending(); await commands({ skipControls: true, limit: 4 }); await advancePending();
        await store.write('journal', 'heartbeat.json', { schemaVersion: 1, observedAt: iso(clock()), clockSafe: !state.clockUnsafe, workerIdentity });
      } finally { busy = false; }
    },
    async stop() { if (busy || inFlight.size) network_transaction_worker_fail('NETWORK_WORKER_FENCING_REQUIRED', 503); stopped = true; if (release) await release(); },
  };
}

;// ./backend/readback.js





const readback_fail = (code, status) => { throw transactionError(code, status); };
const pluginId = 'rivetin-network-topology';

function createReadback({ store, peer, now = Date.now }) {
  async function state() {
    const journal = await store.read('journal', 'state.json');
    if (journal?.schemaVersion !== 1 || !Number.isSafeInteger(journal.version) || !journal.transactions || !journal.plans) readback_fail('NETWORK_JOURNAL_INVALID', 503);
    return journal;
  }
  function view(tx) { return validateTransactionResponse('status', transactionView(tx, now())); }
  async function pending(journal, ownerId, clusterId = null) {
    const result = [];
    for (const name of await store.list('commands')) {
      if (name.startsWith('control-')) continue;
      const command = peer.verify(await store.read('commands', name));
      if (command.kind !== 'apply' || command.ownerId !== ownerId || (clusterId && command.clusterId !== clusterId)) continue;
      if (Object.values(journal.transactions).some(tx => tx.ownerId === ownerId && tx.clusterId === command.clusterId && tx.requestId === command.input.requestId)) continue;
      const response = await store.read('responses', `${command.commandId}.json`, null);
      if (response && ![200, 202].includes(response.status) && response.data?.transactionId === null) continue;
      result.push(command);
    }
    return result;
  }
  function verify(envelope, kind, fields) {
    const value = peer.verify(envelope);
    transactionExact(value, `schemaVersion kind ownerId requestId issuedAt expiresAt${fields ? ` ${fields}` : ''}`);
    const issued = Date.parse(value.issuedAt), expires = Date.parse(value.expiresAt), current = now();
    if (value.schemaVersion !== 1 || value.kind !== kind || !topologyId(value.ownerId) || !transactionUuid(value.requestId) ||
        !/^\d{4}-\d\d-\d\dT.*Z$/.test(value.issuedAt) || !/^\d{4}-\d\d-\d\dT.*Z$/.test(value.expiresAt) ||
        !Number.isFinite(issued) || !Number.isFinite(expires) || issued > current + 2000 || expires <= current || expires <= issued || expires - issued > 60000) readback_fail('NETWORK_COMMAND_PEER_INVALID', 403);
    return value;
  }
  function own(journal, id, ownerId) {
    const tx = journal.transactions[id];
    if (!tx || tx.ownerId !== ownerId) readback_fail('NETWORK_TRANSACTION_NOT_FOUND', 404);
    return tx;
  }
  return {
    async enqueue(envelope) {
      const command = peer.verify(envelope);
      transactionExact(command, 'schemaVersion kind commandId ownerId clusterId manifestHash acceptedAt transactionId input');
      if (command.schemaVersion !== 1 || !['capabilities', 'plan', 'apply', 'confirm', 'rollback'].includes(command.kind) ||
          !transactionUuid(command.commandId) || !topologyId(command.ownerId) || !topologyId(command.clusterId) ||
          !transactionHash(command.manifestHash) || !Number.isFinite(Date.parse(command.acceptedAt))) readback_fail('NETWORK_TRANSACTION_INVALID', 400);
      transactionRequest(command.kind, command.input);
      const control = ['confirm', 'rollback'].includes(command.kind);
      if ((control && !transactionUuid(command.transactionId)) || (!control && command.transactionId !== null) ||
          (command.input.clusterId !== undefined && command.input.clusterId !== command.clusterId)) readback_fail('NETWORK_TRANSACTION_INVALID', 400);
      const name = control ? `control-${command.transactionId}-${command.kind}.json` : transactionDigest({ ownerId: command.ownerId, requestId: command.input.requestId || command.commandId }) + '.json';
      return store.lock('submission', async () => {
        const previous = await store.read('commands', name, null);
        if (previous) {
          if (canonical(peer.verify(previous)) !== canonical(command)) readback_fail('NETWORK_IDEMPOTENCY_MISMATCH', 409);
          return { durable: true, commandId: command.commandId };
        }
        const journal = await state();
        if (command.kind === 'apply') {
          const plan = journal.plans[command.input.planId];
          if (!plan || plan.ownerId !== command.ownerId || plan.planHash !== command.input.planHash || plan.clusterId !== command.clusterId || plan.manifestHash !== command.manifestHash) readback_fail('NETWORK_PLAN_NOT_FOUND', 404);
        }
        if (control) {
          const tx = own(journal, command.transactionId, command.ownerId);
          if (tx.clusterId !== command.clusterId || tx.manifestHash !== command.manifestHash || tx.planHash !== command.input.planHash || tx.requestId === command.input.requestId) readback_fail('NETWORK_IDEMPOTENCY_MISMATCH', 409);
        } else if ((await pending(journal, command.ownerId, command.clusterId)).length) readback_fail('NETWORK_PENDING_SUBMISSION', 503);
        const names = await store.list('commands');
        if ((!control && names.filter(file => !file.startsWith('control-')).length >= (/* inlined export .NETWORK_COMMAND_HISTORY_LIMIT */4096)) || names.length >= NETWORK_RECEIPT_LIMIT) readback_fail('NETWORK_COMMAND_RETENTION_CAPACITY', 503);
        const waiting = [];
        for (const file of names) {
          const row = peer.verify(await store.read('commands', file));
          if (!(await store.read('responses', `${row.commandId}.json`, null))) waiting.push(row);
        }
        if (control && waiting.some(row => row.kind === command.kind && row.transactionId === command.transactionId)) readback_fail('NETWORK_COMMAND_ALREADY_PENDING', 409);
        if (!control && waiting.filter(row => !['confirm', 'rollback'].includes(row.kind)).length >= NETWORK_TRANSACTION_LIMITS.commands) readback_fail('NETWORK_COMMAND_CAPACITY', 503);
        await store.write('commands', name, envelope);
        return { durable: true, commandId: command.commandId };
      });
    },
    async response(envelope) {
      const q = verify(envelope, 'response', 'commandId clusterId');
      if (!transactionUuid(q.commandId) || !topologyId(q.clusterId)) readback_fail('NETWORK_TRANSACTION_INVALID', 400);
      for (const name of await store.list('commands')) {
        const command = peer.verify(await store.read('commands', name));
        if (command.commandId !== q.commandId || command.ownerId !== q.ownerId || command.clusterId !== q.clusterId) continue;
        const response = await store.read('responses', `${q.commandId}.json`, null);
        if (!response) readback_fail('NETWORK_PENDING_SUBMISSION', 503);
        return response;
      }
      readback_fail('NETWORK_PENDING_SUBMISSION', 503);
    },
    async status(envelope) {
      const q = verify(envelope, 'status', 'transactionId');
      if (!transactionUuid(q.transactionId)) readback_fail('NETWORK_TRANSACTION_INVALID', 400);
      const tx = own(await state(), q.transactionId, q.ownerId);
      return { scope: { clusterId: tx.clusterId, manifestHash: tx.manifestHash }, response: { status: 200, data: view(tx) } };
    },
    async planScope(envelope) {
      const q = verify(envelope, 'plan-scope', 'planId planHash');
      if (!transactionUuid(q.planId) || !transactionHash(q.planHash)) readback_fail('NETWORK_TRANSACTION_INVALID', 400);
      const plan = (await state()).plans[q.planId];
      if (!plan || plan.ownerId !== q.ownerId || plan.planHash !== q.planHash) readback_fail('NETWORK_PLAN_NOT_FOUND', 404);
      return { planId: q.planId, planHash: q.planHash, clusterId: plan.clusterId, manifestHash: plan.manifestHash };
    },
    async list(envelope) {
      const q = verify(envelope, 'list', 'clusterId lookupRequestId cursor limit');
      if (!topologyId(q.clusterId) || (q.lookupRequestId !== null && !transactionUuid(q.lookupRequestId)) ||
          (q.lookupRequestId !== null && q.cursor !== null) || (q.limit !== null && (!Number.isInteger(q.limit) || q.limit < 1 || q.limit > 50))) readback_fail('NETWORK_TRANSACTION_INVALID', 400);
      const limit = q.limit ?? 20;
      return store.lock('submission', async () => {
        const journal = await state();
        if ((await pending(journal, q.ownerId, q.clusterId)).length) readback_fail('NETWORK_PENDING_SUBMISSION', 503);
        let after = '';
        if (q.cursor !== null) {
          let cursor;
          try {
            if (typeof q.cursor !== 'string' || q.cursor.length > 1024 || !/^[A-Za-z0-9_-]+$/.test(q.cursor)) throw new Error();
            cursor = peer.verify(JSON.parse(Buffer.from(q.cursor, 'base64url').toString('utf8')));
          } catch { readback_fail('NETWORK_CURSOR_INVALID', 409); }
          if (cursor.kind !== 'cursor' || cursor.ownerId !== q.ownerId || cursor.clusterId !== q.clusterId || cursor.version !== journal.version || cursor.limit !== limit || cursor.expiresAt < now()) readback_fail('NETWORK_CURSOR_EXPIRED', 409);
          after = cursor.after;
        }
        let rows = Object.values(journal.transactions).filter(tx => tx.ownerId === q.ownerId && tx.clusterId === q.clusterId)
          .sort((a, b) => (a.acceptedAt + a.transactionId).localeCompare(b.acceptedAt + b.transactionId));
        if (q.lookupRequestId !== null) {
          rows = rows.filter(tx => tx.requestId === q.lookupRequestId);
          if (rows.length !== 1) readback_fail('NETWORK_TRANSACTION_NOT_FOUND', 404);
        }
        rows = rows.filter(tx => tx.acceptedAt + tx.transactionId > after);
        const selected = rows.slice(0, q.lookupRequestId !== null ? 1 : limit), last = selected.at(-1);
        const nextCursor = rows.length > selected.length ? Buffer.from(JSON.stringify(peer.seal({ kind: 'cursor', ownerId: q.ownerId, clusterId: q.clusterId, version: journal.version, limit, after: last.acceptedAt + last.transactionId, expiresAt: now() + 60000 }))).toString('base64url') : null;
        return { status: 200, data: { schemaVersion: 1, pluginId, clusterId: q.clusterId, serverTime: new Date(now()).toISOString(), items: selected.map(view), nextCursor } };
      });
    },
    async scopes(envelope) {
      const q = verify(envelope, 'scopes', '');
      return store.lock('submission', async () => {
        const journal = await state(), submissions = await pending(journal, q.ownerId);
        const owned = Object.values(journal.transactions).filter(tx => tx.ownerId === q.ownerId);
        const clusters = [...new Set([...owned, ...submissions].map(tx => tx.clusterId))].sort().map(clusterId => ({
          clusterId,
          pending: submissions.filter(tx => tx.clusterId === clusterId).length + owned.filter(tx => tx.clusterId === clusterId && !['confirmed', 'rolled-back', 'expired-unapplied', 'failed-unapplied', 'rejected'].includes(tx.phase)).length,
        }));
        return { serverTime: new Date(now()).toISOString(), clusters };
      });
    },
  };
}

;// ./backend/service.js




// The framework owns the user-facing API and passes signed commands separately.
function createTopologyTransactionWorker({ root = '/data', key, native, authorize, readiness, identityRef, workerIdentity }) {
  const store = createTransactionStore(root);
  const peer = commandPeer(key);
  const worker = createNetworkTransactionWorker({ store, peer, native, authorize, readiness, identityRef, workerIdentity });
  return { worker, control: createReadback({ store, peer }) };
}

;// external "node:https"
const external_node_https_namespaceObject = require("node:https");
;// ./backend/http.js


const prefix = '/internal/rivetin/v1/network-transactions/';
const methods = { enqueue: 'enqueue', response: 'response', status: 'status', list: 'list', 'plan-scope': 'planScope', scopes: 'scopes' };

function createControlServer({ tls, control }) {
  return (0,external_node_https_namespaceObject.createServer)({ ...tls, requestCert: true, rejectUnauthorized: true }, async (req, res) => {
    const reply = (status, data) => {
      res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
      res.end(JSON.stringify(data));
    };
    try {
      const path = new URL(req.url, 'https://worker.invalid');
      const method = methods[path.pathname.slice(prefix.length)];
      if (!path.pathname.startsWith(prefix) || !method || path.search || req.method !== 'POST') return reply(404, { code: 'NETWORK_TRANSACTION_NOT_FOUND' });
      if (!req.socket.authorized || !/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] || '')) return reply(403, { code: 'NETWORK_COMMAND_PEER_INVALID' });
      const chunks = []; let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 32768) return reply(413, { code: 'NETWORK_TRANSACTION_INVALID' });
        chunks.push(chunk);
      }
      let envelope;
      try { envelope = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
      catch { return reply(400, { code: 'NETWORK_TRANSACTION_INVALID' }); }
      return reply(200, await control[method](envelope));
    } catch (error) {
      const code = typeof error?.code === 'string' && /^NETWORK_[A-Z0-9_]+$/.test(error.code) ? error.code : 'NETWORK_DEPENDENCY_UNAVAILABLE';
      const status = Number.isInteger(error?.status) && error.status >= 400 && error.status <= 599 ? error.status : 503;
      return reply(status, { schemaVersion: 1, code, serverTime: new Date().toISOString(), retryableRead: true, transactionId: null, requestId: null });
    }
  });
}

;// external "node:timers/promises"
const external_node_timers_promises_namespaceObject = require("node:timers/promises");
;// ./backend/runtime.js


async function runWorker({ worker, version, signal, onReady = async () => {}, intervalMs = 1000, log = console.log }) {
  const emit = (level, code) => log(JSON.stringify({
    time: new Date().toISOString(), level, component: 'rivetin-network-topology', version, code,
  }));
  let started = false;
  try {
    emit('info', 'TOPO_WORKER_STARTING');
    await worker.start();
    started = true;
    await onReady();
    emit('info', 'TOPO_WORKER_READY');
    let lastSummary = Date.now();
    while (!signal.aborted) {
      await worker.tick();
      if (Date.now() - lastSummary >= 60000) {
        emit('info', 'TOPO_WORKER_RUNNING');
        lastSummary = Date.now();
      }
      if (!signal.aborted) await (0,external_node_timers_promises_namespaceObject.setTimeout)(intervalMs, undefined, { signal }).catch(error => {
        if (error.name !== 'AbortError') throw error;
      });
    }
    await worker.stop();
    started = false;
    emit('info', 'TOPO_WORKER_STOPPED');
  } catch (error) {
    // Do not release a potentially active worker lock after an uncertain failure.
    const code = typeof error?.code === 'string' && /^NETWORK_[A-Z0-9_]+$/.test(error.code)
      ? error.code : 'TOPO_WORKER_FAILED';
    emit('error', code);
    if (started) emit('error', 'TOPO_WORKER_FENCING_REQUIRED');
    throw error;
  }
}

;// ./backend/main.js





async function main() {
  const metadata = JSON.parse(await (0,promises_namespaceObject.readFile)('metadata', 'utf8'));
  if (metadata.id !== 'rivetin-network-topology' || typeof metadata.version !== 'string') throw new Error('TOPO_METADATA_INVALID');
  const key = await (0,promises_namespaceObject.readFile)('/run/rivetin/topology/peer.key');
  const tls = {
    key: await (0,promises_namespaceObject.readFile)('/run/rivetin/tls/tls.key'),
    cert: await (0,promises_namespaceObject.readFile)('/run/rivetin/tls/tls.crt'),
    ca: await (0,promises_namespaceObject.readFile)('/run/rivetin/tls/ca.crt'),
  };
  // Do not start against an existing journal until its independent identity and
  // recovery adapter are available. Starting could otherwise alter pending work.
  try {
    const journal = JSON.parse(await (0,promises_namespaceObject.readFile)('/data/journal/state.json', 'utf8'));
    if (journal.schemaVersion !== 1 || !journal.transactions || !journal.plans || !journal.receipts ||
        Object.keys(journal.transactions).length || Object.keys(journal.plans).length || Object.keys(journal.receipts).length) {
      throw Object.assign(new Error('TOPO_EXISTING_JOURNAL_REQUIRES_IDENTITY'), { code: 'TOPO_EXISTING_JOURNAL_REQUIRES_IDENTITY' });
    }
    if ((await (0,promises_namespaceObject.readdir)('/data/commands')).length || (await (0,promises_namespaceObject.readdir)('/data/responses')).length) throw Object.assign(new Error('TOPO_EXISTING_JOURNAL_REQUIRES_IDENTITY'), { code: 'TOPO_EXISTING_JOURNAL_REQUIRES_IDENTITY' });
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  const unavailable = async () => { throw Object.assign(new Error('NETWORK_INDEPENDENT_IDENTITY_REQUIRED'), { code: 'NETWORK_INDEPENDENT_IDENTITY_REQUIRED', status: 503 }); };
  const service = createTopologyTransactionWorker({
    root: '/data', key, native: { read: unavailable, dispatch: unavailable, task: unavailable },
    authorize: async () => ({ authorized: false }),
    readiness: async () => ({ identityReady: false, workerReady: true, storageReady: false, verifiedAt: new Date().toISOString() }),
    identityRef: null, workerIdentity: { processId: process.pid, bootNonce: process.env.RIVETIN_WORKER_INSTANCE || 'unassigned', mode: 'independent-process' },
  });
  key.fill(0);
  const server = createControlServer({ tls, control: service.control });
  const controller = new AbortController();
  process.once('SIGTERM', () => controller.abort());
  process.once('SIGINT', () => controller.abort());
  try {
    await runWorker({ worker: service.worker, version: metadata.version, signal: controller.signal,
      onReady: () => new Promise((resolve, reject) => { server.once('error', reject); server.listen(9443, '0.0.0.0', resolve); }) });
  } finally {
    if (server.listening) await new Promise(resolve => server.close(resolve));
  }
}

main().catch(error => {
  const code = typeof error?.code === 'string' && /^(?:NETWORK|TOPO)_[A-Z0-9_]+$/.test(error.code) ? error.code : 'TOPO_BACKEND_START_FAILED';
  console.error(JSON.stringify({ time: new Date().toISOString(), level: 'error', component: 'rivetin-network-topology', code }));
  process.exitCode = 1;
});

/******/ })()
;