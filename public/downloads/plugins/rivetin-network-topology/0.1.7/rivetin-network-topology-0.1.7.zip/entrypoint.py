"""Start the topology backend from the common Runtime entrypoint."""
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    try:
        metadata = json.loads((root / "metadata").read_text(encoding="utf-8"))
        if metadata.get("id") != "rivetin-network-topology" or not isinstance(metadata.get("version"), str):
            raise ValueError("invalid metadata")
        os.chdir(root)
        print(json.dumps({
            "time": datetime.now(timezone.utc).isoformat(),
            "level": "info",
            "component": metadata["id"],
            "version": metadata["version"],
            "event": "TOPO_BACKEND_STARTING",
        }), flush=True)
        os.execvp("node", ["node", str(root / "backend" / "main.cjs")])
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        print("TOPO_BACKEND_START_FAILED", file=sys.stderr, flush=True)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
