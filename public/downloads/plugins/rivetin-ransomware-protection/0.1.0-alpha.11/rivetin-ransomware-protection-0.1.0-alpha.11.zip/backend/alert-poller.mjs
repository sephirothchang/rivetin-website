/**
 * Background CloudTower alert poller + automatic alert snapshot.
 *
 * CloudTower custom alert rules trigger CloudTower alerts. When the real webhook
 * receiver is unavailable (or before a notifier is configured), the plugin polls
 * get-alerts, records normalized events, and pins an alert snapshot for protected
 * VMs exactly once. Duplicate polls never create a second snapshot because the
 * event ledger key is stable.
 */
import { dedupeAlerts, normalizeAlert } from '../src/core/events.js';

const defaultIntervalMs = 60 * 1000;

function errorCode(error) {
  const value = typeof error?.code === 'string' ? error.code : typeof error?.message === 'string' ? error.message : '';
  if (value.startsWith('CLOUDTOWER_') || value.startsWith('LOGIN_') || value === 'RANSOM_CLOUDTOWER_WRITE_FAILED') {
    return value;
  }
  return 'RANSOM_ALERT_POLL_FAILED';
}

function snapshotName(alert, now) {
  const alertId = typeof alert.alertId === 'string' ? alert.alertId.replace(/[^A-Za-z0-9_-]/g, '').slice(0, 12) : 'alert';
  return `rivetin-alert-${now.replace(/[:.]/g, '-')}-${alertId}`.slice(0, 80);
}

export function createAlertPoller({ store, cloudTower, rulesStore, log = () => {}, clock = () => new Date().toISOString(),
  intervalMs = defaultIntervalMs } = {}) {
  let timer = null, stopped = false, running = null;
  const configured = () => cloudTower?.configured === true;
  const getClient = () => (configured() ? cloudTower.client : null);
  function desired() {
    return rulesStore && typeof rulesStore.desired === 'function' ? rulesStore.desired() : null;
  }
  function protectedVm(vmId) {
    const current = desired();
    if (current && Array.isArray(current.vms) && current.vms.some(entry => entry.vmId === vmId)) return true;
    // Backward-compatible fallback for the pre-2B protection projection.
    return Boolean(store && typeof store.findPolicy === 'function' && store.findPolicy(vmId));
  }

  async function pinSnapshot(client, alert) {
    const vmId = alert.vmId;
    const now = clock();
    const name = snapshotName(alert, now);
    const created = await client.createVmSnapshot({ vmId, name });
    let snapshotId = typeof created?.snapshotId === 'string' ? created.snapshotId : null;
    if (!snapshotId) {
      const snapshots = await client.getVmSnapshots(vmId).catch(() => []);
      snapshotId = (Array.isArray(snapshots) ? snapshots : []).find(row => row && row.name === name && typeof row.id === 'string')?.id ?? null;
    }
    if (!snapshotId) throw Object.assign(new Error('RANSOM_CLOUDTOWER_WRITE_FAILED'), { code: 'RANSOM_CLOUDTOWER_WRITE_FAILED' });
    return { snapshotId, vmId, createdAt: clock(), name };
  }

  async function pollOnce() {
    if (running) return running;
    running = (async () => {
      const client = getClient();
      if (!client) return { polledAt: clock(), received: 0, recorded: 0, snapshots: 0, skipped: 'RANSOM_CLOUDTOWER_REQUIRED' };
      let alerts;
      try { alerts = await client.getAlerts({ where: { ended: false }, first: 100 }); }
      catch (error) { log('WARN', 'alert-poll-failed', { code: errorCode(error) }); throw error; }
      const normalized = [];
      for (const row of Array.isArray(alerts) ? alerts : []) {
        try { normalized.push(normalizeAlert({ ...row, source: 'poll' })); }
        catch { /* unnormalizable alerts are skipped, never fabricated */ }
      }
      const deduped = dedupeAlerts(normalized, { windowMinutes: 5 });
      const current = desired();
      let recorded = 0, snapshots = 0;
      for (const alert of deduped) {
        const id = 'auto-poll-' + alert.incidentKey;
        const existing = store.findEvent(id);
        if (existing) continue;
        let snapshot = null, snapshotError = null;
        if (protectedVm(alert.vmId) && current?.enabled !== false) {
          try {
            snapshot = await pinSnapshot(client, alert);
            snapshots += 1;
          } catch (error) { snapshotError = errorCode(error); }
        }
        await store.addEvent({ id, source: 'poll', event: alert, receivedAt: clock(), snapshot, snapshotError });
        recorded += 1;
        log('INFO', 'alert-recorded', { vmId: alert.vmId, alertId: alert.alertId, snapshotId: snapshot?.snapshotId ?? null,
          result: snapshotError ? 'snapshot-failed' : snapshot ? 'snapshot-created' : 'recorded' });
      }
      return { polledAt: clock(), received: Array.isArray(alerts) ? alerts.length : 0, recorded, snapshots };
    })().finally(() => { running = null; });
    return running;
  }

  function schedule(delay = intervalMs) {
    if (stopped) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      pollOnce().catch(() => {}).finally(() => { if (!stopped) schedule(intervalMs); });
    }, Math.max(1000, delay));
    timer.unref?.();
  }

  return Object.freeze({
    pollOnce,
    start({ initialDelayMs = 5000 } = {}) { schedule(initialDelayMs); },
    stop() { stopped = true; if (timer) clearTimeout(timer); timer = null; },
    status: () => ({ running: Boolean(timer), configured: configured(), intervalMs }),
  });
}
