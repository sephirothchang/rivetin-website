/**
 * Deployment-provided CloudTower credential mount (`<pluginId>-cloudtower` Secret).
 *
 * The framework projects the Secret keys to `/run/rivetin/cloudtower/<key>` and is
 * responsible for rejecting unknown keys at install time (`PLUGIN_CREDENTIAL_MOUNT_INVALID`).
 * This parser is the Runtime-side second check: required keys are url/username/password;
 * `ca` (PEM) and `insecureTls` ("true"/"false") are optional. Unknown keys, missing
 * required values, malformed CA material and non-boolean TLS flags are rejected so a
 * malformed Secret can never silently weaken the connection.
 *
 * The parser never logs or returns credential values beyond the parsed object.
 */
import { X509Certificate } from 'node:crypto';
import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';

export const CLOUDTOWER_MOUNT_KEYS = Object.freeze(['url', 'username', 'password', 'ca', 'insecureTls']);
const MAX_CA_BYTES = 65536;
const MAX_VALUE_BYTES = 65536;

export class CredentialMountInvalid extends Error {
  constructor(reason, key) {
    super('PLUGIN_CREDENTIAL_MOUNT_INVALID');
    this.code = 'PLUGIN_CREDENTIAL_MOUNT_INVALID';
    this.reason = reason;
    if (key) this.key = key;
  }
}

const record = value => Boolean(value) && typeof value === 'object' && !Array.isArray(value);

function readText(files, key) {
  const raw = files[key];
  if (raw === undefined) return undefined;
  if (Buffer.isBuffer(raw)) return raw.toString('utf8');
  if (typeof raw === 'string') return raw;
  throw new CredentialMountInvalid('value', key);
}

export function parseCloudTowerMount(files = {}) {  if (!record(files)) throw new CredentialMountInvalid('shape');
  const unknown = Object.keys(files).filter(key => !CLOUDTOWER_MOUNT_KEYS.includes(key)).sort();
  if (unknown.length) throw new CredentialMountInvalid('unknown-key', unknown[0]);
  const url = readText(files, 'url');
  const username = readText(files, 'username');
  const password = readText(files, 'password');
  for (const [key, value] of [['url', url], ['username', username], ['password', password]]) {
    if (typeof value !== 'string' || value.length === 0) throw new CredentialMountInvalid('missing:' + key, key);
  }
  let origin;
  try {
    const parsed = new URL(url.trim());
    if (parsed.protocol !== 'https:' || parsed.origin !== url.trim().replace(/\/+$/, '')) {
      throw new Error('CLOUDTOWER_URL_INVALID');
    }
    origin = parsed.origin;
  } catch {
    throw new CredentialMountInvalid('url', 'url');
  }
  const ca = readText(files, 'ca');
  if (ca !== undefined) {
    if (ca.length === 0 || Buffer.byteLength(ca) > MAX_CA_BYTES || !ca.includes('-----BEGIN CERTIFICATE-----') ||
        !ca.includes('-----END CERTIFICATE-----')) throw new CredentialMountInvalid('ca', 'ca');
    try { new X509Certificate(ca); } catch { throw new CredentialMountInvalid('ca', 'ca'); }
  }
  const insecureText = readText(files, 'insecureTls');
  let insecureTls = false;
  if (insecureText !== undefined) {
    const value = insecureText.trim();
    if (value !== 'true' && value !== 'false') throw new CredentialMountInvalid('insecureTls', 'insecureTls');
    insecureTls = value === 'true';
  }
  return Object.freeze({ origin, username, password, ...(ca === undefined ? {} : { ca }), insecureTls });
}

/**
 * Read the projected Secret directory without treating the Kubernetes volume
 * metadata (`..data`, `..<timestamp>` symlinks/directories) as credential keys.
 */
export async function readCloudTowerMount(directory, { readdir: readdirImpl = readdir, readFile: readFileImpl = readFile } = {}) {
  let names;
  try { names = await readdirImpl(directory); } catch { return null; }
  const files = {};
  for (const name of names) {
    if (name.startsWith('..')) continue;
    if (!name || name.includes('/') || name.includes('\\')) throw new CredentialMountInvalid('key', name);
    let bytes;
    try { bytes = await readFileImpl(path.join(directory, name)); } catch { throw new CredentialMountInvalid('value', name); }
    if (!Buffer.isBuffer(bytes) || bytes.length === 0 || bytes.length > MAX_VALUE_BYTES) throw new CredentialMountInvalid('value', name);
    files[name] = bytes;
  }
  return files;
}
