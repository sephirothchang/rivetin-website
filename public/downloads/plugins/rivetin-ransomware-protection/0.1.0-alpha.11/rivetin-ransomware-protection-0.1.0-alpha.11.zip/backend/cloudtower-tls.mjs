/**
 * TLS-capable fetch for the backend's read-only CloudTower calls.
 *
 * Node's global fetch (undici) cannot be given a private CA without an installed
 * dispatcher; the plugin runtime does not ship `undici` as a dependency. This module
 * therefore implements the minimal fetch surface the core modules use (status/ok/
 * json/text) on top of `node:https`, with:
 *   - `ca` (PEM) for a deployment-provided trust anchor (default behavior);
 *   - explicit `insecureTls` for test environments only (logs a warning at startup;
 *     never enabled by default);
 *   - TLS certificate failures mapped to `RANSOM_CLOUDTOWER_TLS_UNTRUSTED` so the
 *     framework route does not collapse them into a generic unavailability.
 */
import { request as httpsRequest } from 'node:https';

export const TLS_UNTRUSTED = 'RANSOM_CLOUDTOWER_TLS_UNTRUSTED';
const TRUST_ERROR_CODES = new Set([
  'SELF_SIGNED_CERT_IN_CHAIN', 'DEPTH_ZERO_SELF_SIGNED_CERT', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE',
  'UNABLE_TO_GET_ISSUER_CERT_LOCALLY', 'CERT_HAS_EXPIRED', 'CERT_NOT_YET_VALID', 'CERT_UNTRUSTED',
  'CERT_REJECTED', 'CERT_SIGNATURE_FAILURE', 'ERR_TLS_CERT_ALTNAME_INVALID', 'HOSTNAME_MISMATCH',
]);

export class CloudTowerTlsUntrusted extends Error {
  constructor(cause) {
    super(TLS_UNTRUSTED);
    this.code = TLS_UNTRUSTED;
    this.cause = cause;
  }
}

export function isTlsTrustError(error) {
  const code = typeof error?.code === 'string' ? error.code : '';
  return TRUST_ERROR_CODES.has(code) || /CERT|SELF_SIGNED|ALTNAME|ISSUER/i.test(code);
}

function responseOf(response, body) {
  const text = () => body.toString('utf8');
  return {
    ok: response.statusCode >= 200 && response.statusCode < 300,
    status: response.statusCode,
    headers: response.headers,
    text,
    json: async () => JSON.parse(text()),
  };
}

export function createTlsFetch({ ca, insecureTls = false, timeoutMs = 15000, request = httpsRequest } = {}) {
  if (ca !== undefined && typeof ca !== 'string' && !Buffer.isBuffer(ca)) throw new TypeError('CLOUDTOWER_TLS_CA_INVALID');
  if (typeof insecureTls !== 'boolean') throw new TypeError('CLOUDTOWER_TLS_FLAG_INVALID');
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1) throw new TypeError('CLOUDTOWER_TLS_TIMEOUT_INVALID');
  return function fetchImpl(input, init = {}) {
    const target = typeof input === 'string' || input instanceof URL ? new URL(String(input)) : new URL(String(input?.url ?? input));
    if (target.protocol !== 'https:') return Promise.reject(Object.assign(new Error('CLOUDTOWER_HTTPS_REQUIRED'), { code: 'CLOUDTOWER_HTTPS_REQUIRED' }));
    return new Promise((resolve, reject) => {
      const headers = init.headers && typeof init.headers === 'object' ? { ...init.headers } : {};
      const body = init.body === undefined ? undefined : (typeof init.body === 'string' ? init.body : JSON.stringify(init.body));
      if (body !== undefined) headers['content-length'] = Buffer.byteLength(body);
      const req = request({
        hostname: target.hostname, port: target.port || 443, path: target.pathname + target.search,
        method: init.method || 'GET', headers, timeout: timeoutMs,
        rejectUnauthorized: insecureTls !== true, ...(ca === undefined ? {} : { ca }),
      }, response => {
        const chunks = [];
        response.on('data', chunk => chunks.push(chunk));
        response.on('end', () => resolve(responseOf(response, Buffer.concat(chunks))));
        response.on('error', reject);
      });
      req.on('timeout', () => req.destroy(Object.assign(new Error('CLOUDTOWER_TIMEOUT'), { code: 'CLOUDTOWER_TIMEOUT' })));
      req.on('error', error => reject(isTlsTrustError(error) ? new CloudTowerTlsUntrusted(error) : error));
      if (init.signal && typeof init.signal.addEventListener === 'function') {
        if (init.signal.aborted) req.destroy(Object.assign(new Error('CLOUDTOWER_ABORTED'), { code: 'CLOUDTOWER_ABORTED' }));
        else init.signal.addEventListener('abort', () => req.destroy(Object.assign(new Error('CLOUDTOWER_ABORTED'), { code: 'CLOUDTOWER_ABORTED' })), { once: true });
      }
      if (body !== undefined) req.write(body);
      req.end();
    });
  };
}
