/**
 * Durable local state for the business backend.
 *
 * `/data` is the framework-owned Runtime PVC (RWO, preserved across upgrades and
 * uninstalls). `data-schema.json` carries the schema version; `state.json` is the
 * bounded projection the read-only M5 methods serve. Writes are atomic (tmp + rename)
 * with 0600 permissions; malformed files fail closed rather than being rewritten.
 */
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';

export const SCHEMA_VERSION = 1;
const stateName = 'state.json';
const schemaName = 'data-schema.json';
const limits = Object.freeze({ policies: 200, events: 500, deliveries: 200, webhookRecent: 500, operations: 500 });
const maxBytes = 1024 * 1024;

function empty() {
  return { schemaVersion: SCHEMA_VERSION, policies: [], events: [], deliveries: [], webhookRecent: [], operations: [], updatedAt: new Date(0).toISOString() };
}

function object(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function boundedList(value, maximum) {
  return Array.isArray(value) ? value.filter(item => object(item)).slice(-maximum) : [];
}

export class DataSchemaUnsupported extends Error {
  constructor(version) {
    super('RANSOM_DATA_SCHEMA_UNSUPPORTED');
    this.code = 'RANSOM_DATA_SCHEMA_UNSUPPORTED';
    this.version = version;
  }
}

export async function openDataStore(directory, { clock = () => new Date().toISOString() } = {}) {
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const schemaFile = path.join(directory, schemaName);
  const stateFile = path.join(directory, stateName);
  let schema;
  try { schema = JSON.parse(await readFile(schemaFile, 'utf8')); }
  catch (error) {
    if (error.code !== 'ENOENT') throw Object.assign(new Error('RANSOM_STORAGE_UNAVAILABLE'), { code: 'RANSOM_STORAGE_UNAVAILABLE' });
    schema = { schemaVersion: SCHEMA_VERSION };
    await writeFile(schemaFile, JSON.stringify(schema) + '\n', { mode: 0o600, flag: 'wx' }).catch(error => {
      if (error.code !== 'EEXIST') throw error;
    });
  }
  if (!object(schema) || !Number.isSafeInteger(schema.schemaVersion) || schema.schemaVersion < 1) {
    throw Object.assign(new Error('RANSOM_STORAGE_UNAVAILABLE'), { code: 'RANSOM_STORAGE_UNAVAILABLE' });
  }
  if (schema.schemaVersion !== SCHEMA_VERSION) throw new DataSchemaUnsupported(schema.schemaVersion);
  let state;
  try {
    const bytes = await readFile(stateFile);
    if (bytes.length > maxBytes) throw new Error('RANSOM_STORAGE_UNAVAILABLE');
    state = JSON.parse(bytes.toString('utf8'));
  } catch (error) {
    if (error.code === 'ENOENT') state = empty();
    else throw Object.assign(new Error('RANSOM_STORAGE_UNAVAILABLE'), { code: 'RANSOM_STORAGE_UNAVAILABLE' });
  }
  if (!object(state) || state.schemaVersion !== SCHEMA_VERSION) {
    throw Object.assign(new Error('RANSOM_STORAGE_UNAVAILABLE'), { code: 'RANSOM_STORAGE_UNAVAILABLE' });
  }
  const current = {
    schemaVersion: SCHEMA_VERSION,
    policies: boundedList(state.policies, limits.policies),
    events: boundedList(state.events, limits.events),
    deliveries: boundedList(state.deliveries, limits.deliveries),
    webhookRecent: boundedList(state.webhookRecent, limits.webhookRecent),
    operations: boundedList(state.operations, limits.operations),
    updatedAt: typeof state.updatedAt === 'string' ? state.updatedAt : clock(),
  };
  async function save() {
    current.updatedAt = clock();
    const temporary = stateFile + '.tmp';
    await writeFile(temporary, JSON.stringify(current) + '\n', { mode: 0o600 });
    await rename(temporary, stateFile);
  }
  return {
    directory,
    schemaVersion: SCHEMA_VERSION,
    policies: () => current.policies.map(row => structuredClone(row)),
    events: () => current.events.map(row => structuredClone(row)),
    deliveries: () => current.deliveries.map(row => structuredClone(row)),
    addEvent(row) { current.events.push(structuredClone(row)); current.events = current.events.slice(-limits.events); return save(); },
    addPolicy(row) { current.policies.push(structuredClone(row)); current.policies = current.policies.slice(-limits.policies); return save(); },
    findPolicy(vmId) { return current.policies.find(row => row.vmId === vmId) ?? null; },
    syncPolicies(rows) { current.policies = rows.slice(0, limits.policies).map(row => structuredClone(row)); return save(); },
    findOperation(id) { return current.operations.find(row => row.operationId === id) ?? null; },
    beginOperation(row) { current.operations.push(structuredClone(row)); current.operations = current.operations.slice(-limits.operations); return save(); },
    finishOperation(id, patch) {
      const row = current.operations.find(item => item.operationId === id);
      if (row) Object.assign(row, structuredClone(patch));
      return save();
    },
    findEvent(id) { return current.events.find(row => row.id === id) ?? null; },
    findDelivery(id) { return current.deliveries.find(row => row.id === id) ?? null; },
    findWebhook(bodySha256) { return current.webhookRecent.find(row => row.sha256 === bodySha256) ?? null; },
    rememberWebhook(row) {
      current.webhookRecent.push(structuredClone(row));
      current.webhookRecent = current.webhookRecent.slice(-limits.webhookRecent);
      return save();
    },
    counts() {
      return { policies: current.policies.length, events: current.events.length, deliveries: current.deliveries.length };
    },
  };
}
