/**
 * Business backend declaration of this plugin.
 *
 * This is the Runtime-side copy of `rivetin.json.backend`. The standard ZIP metadata
 * (and therefore the framework's dynamic registry) is generated from `rivetin.json`,
 * while the Pod payload cannot carry `rivetin.json`; a backend test asserts both stay
 * identical. Never widen this map without updating `rivetin.json` in the same change.
 */
export const CAPABILITY = 'ransomware.protection';
export const INTERFACE_VERSION = 1;
export const METHODS = Object.freeze({
  'ransomware.status': 'read',
  'ransomware.inventory.vms': 'read',
  'ransomware.protection.list': 'read',
  'ransomware.protection.sync': 'submit',
  'ransomware.rules.status': 'read',
  'ransomware.rules.reconcile': 'submit',
  'ransomware.protection.register': 'submit',
  'ransomware.protection.remove': 'submit',
  'ransomware.events.list': 'read',
  'ransomware.events.read': 'read',
  'ransomware.events.snapshot': 'submit',
  'ransomware.events.rebuild': 'submit',
  'ransomware.events.scan': 'submit',
  'ransomware.events.deliver': 'submit',
  'ransomware.events.close': 'submit',
  'ransomware.alerts.poll': 'read',
  'ransomware.webhook.event': 'submit',
  'ransomware.delivery.read': 'read',
});
export const WEBHOOK = Object.freeze({ method: 'ransomware.webhook.event', channels: Object.freeze(['cloudtower']) });

export function ownsMethod(method, kind) {
  return typeof method === 'string' && Object.hasOwn(METHODS, method) && METHODS[method] === kind;
}
