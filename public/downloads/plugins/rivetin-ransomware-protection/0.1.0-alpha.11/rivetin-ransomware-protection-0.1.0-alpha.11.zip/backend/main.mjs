#!/usr/bin/env node
/**
 * Ransomware protection business backend Runtime entry (workload-backend-v1).
 *
 * Started by the package root `entrypoint.py` from the standard ZIP payload. The
 * framework projects `/run/rivetin/runtime/backend-contract.json`, mounts the mTLS
 * material at `/run/rivetin/tls`, and injects the workload identity via env. This
 * process serves:
 *   - inner mTLS HTTPS 0.0.0.0:9443  /internal/rivetin/v1/{health,permit,pause,invoke}
 *   - local probes      127.0.0.1:18081 /live, /ready
 *   - wipes its permit through the framework `/permit` endpoint and serves the 14
 *     declared methods from the local `/data` projection.
 *
 * Read-only M5 scope: CloudTower reads (get-alerts) are used when the deployment
 * provided the optional `<pluginId>-cloudtower` Secret; CloudTower writes, webhook
 * signing secrets and any real-environment action are deployment/authorization
 * gated (missing optional material is reported, never fatal).
 */
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { createBackendServer, createPeerClient } from '../runtime-support/server/workload-http.js';
import { createLocalProbeServer } from '../runtime-support/server/workload-local-health.js';
import { createPermitMonitor } from '../runtime-support/server/workload-permit.js';
import { wireVersion, WorkloadError } from '../runtime-support/server/workload-protocol.js';
import { createCloudTowerClient } from '../src/core/cloudtower.js';
import { createSessionTransport } from '../src/core/auth.js';
import { CLOUDTOWER_DIRECTORY, WEBHOOK_DIRECTORY, dataDirectory, loadBackendContract, loadTlsMaterial, runtimeIdentity } from './runtime-contract.mjs';
import { parseCloudTowerMount, readCloudTowerMount } from './cloudtower-mount.mjs';
import { createTlsFetch } from './cloudtower-tls.mjs';
import { DataSchemaUnsupported, openDataStore } from './data-store.mjs';
import { openRulesStore } from './rules-store.mjs';
import { createReconciler } from './reconciler.mjs';
import { createAlertPoller } from './alert-poller.mjs';
import { ownsMethod } from './declaration.mjs';
import { createMethodHandlers } from './methods.mjs';

const component = 'rivetin-ransomware-protection';
const workloadPort = 9443;
const probePort = 18081;
const startedAt = new Date().toISOString();
let version = null;
let stage = 'configuration';

function log(level, event, fields = {}) {
  const stream = level === 'INFO' ? process.stdout : process.stderr;
  stream.write(JSON.stringify({ time: new Date().toISOString(), level, component, version, event, ...fields }) + '\n');
}

function errorCode(error, fallback) {
  const code = typeof error?.code === 'string' ? error.code : typeof error?.message === 'string' ? error.message : '';
  return /^RANSOM_[A-Z0-9_]{1,90}$/.test(code) ? code : fallback;
}

async function packageVersion() {
  try {
    const metadata = JSON.parse(await readFile(new URL('../metadata', import.meta.url), 'utf8'));
    return typeof metadata.version === 'string' ? metadata.version : null;
  } catch { return null; }
}

async function readOptional(file, maximum = 65536) {
  try {
    const bytes = await readFile(file);
    return bytes.length > 0 && bytes.length <= maximum ? bytes : null;
  } catch { return null; }
}

async function loadCloudTower(directory = CLOUDTOWER_DIRECTORY) {
  let files;
  try { files = await readCloudTowerMount(directory); }
  catch (error) { return { configured: false, client: null, invalid: error?.code || 'credential-mount', reason: error?.reason, key: error?.key }; }
  if (files === null || Object.keys(files).length === 0) return { configured: false, client: null };
  let material;
  try { material = parseCloudTowerMount(files); }
  catch (error) {
    return { configured: false, client: null, invalid: error?.code || 'credential-mount', reason: error?.reason, key: error?.key };
  }
  try {
    // CA material is the default trust path. `insecureTls` is an explicit
    // test-environment-only opt-out; it is parsed as a literal flag and logged
    // at startup, and it is never enabled by default.
    const tlsFetch = createTlsFetch({ ca: material.ca, insecureTls: material.insecureTls });
    const session = createSessionTransport({ baseUrl: material.origin,
      credentials: { username: material.username, password: material.password, source: 'LOCAL' }, fetch: tlsFetch });
    return { configured: true, client: createCloudTowerClient({ transport: session.transport }), insecureTls: material.insecureTls };
  } catch { return { configured: false, client: null, invalid: 'transport' }; }
}

async function loadWebhookKey(directory = WEBHOOK_DIRECTORY) {
  const bytes = await readOptional(path.join(directory, 'signing.key'), 4096);
  return bytes && bytes.length >= 32 ? bytes : null;
}

async function main() {
  version = await packageVersion();
  stage = 'contract';
  const contract = await loadBackendContract();
  const identity = runtimeIdentity();
  const tls = await loadTlsMaterial();
  const directory = dataDirectory();
  stage = 'data';
  let store, unsupportedSchema = null;
  try { store = await openDataStore(directory); }
  catch (error) {
    if (error instanceof DataSchemaUnsupported) {
      unsupportedSchema = error.version;
      store = { schemaVersion: error.version, policies: () => [], events: () => [], deliveries: () => [],
        counts: () => ({ policies: 0, events: 0, deliveries: 0 }), findEvent: () => null, findDelivery: () => null,
        findWebhook: () => null, addEvent: async () => {}, rememberWebhook: async () => {}, addPolicy: async () => {} };
      log('WARN', 'data-schema-unsupported', { schemaVersion: error.version });
    } else throw error;
  }
  stage = 'desired';
  const rulesStore = await openRulesStore(directory);
  if (rulesStore.quarantined.length > 0) log('WARN', 'rules-ledger-quarantined', { files: rulesStore.quarantined });
  stage = 'credentials';
  const cloudTower = await loadCloudTower();
  if (cloudTower.invalid) log('WARN', 'cloudtower-credentials-invalid', { reason: cloudTower.invalid,
    ...(cloudTower.reason ? { shape: cloudTower.reason } : {}), ...(cloudTower.key ? { key: cloudTower.key } : {}) });
  if (cloudTower.configured && cloudTower.insecureTls) log('WARN', 'cloudtower-insecure-tls-enabled', {
    risk: 'TLS certificate verification disabled for the CloudTower read connection (test-environment only)' });
  const webhookKey = await loadWebhookKey();
  stage = 'reconciler';
  const reconciler = createReconciler({ rulesStore, cloudTower, log,
    clientFactory: () => (cloudTower.configured === true ? cloudTower.client : null) });
  const alertPoller = createAlertPoller({ store, cloudTower, rulesStore, log });
  stage = 'handlers';
  const handlers = createMethodHandlers({ store, identity: { ...identity, workloadId: contract.workloadId }, contract,
    cloudTower, webhookKey, version, startedAt, log, reconciler, alertPoller });
  stage = 'permit';
  const client = createPeerClient({ origin: contract.frameworkOrigin, tls, serverPin: contract.frameworkPin });
  const permits = createPermitMonitor({
    renew: () => client.permit({ transportVersion: wireVersion, instanceId: identity.instanceId, generation: identity.generation }),
    onGrant: () => log('INFO', 'permit-granted'),
    onPause: () => log('INFO', 'permit-paused'),
  });
  const execute = async value => {
    if (unsupportedSchema !== null && value.method !== 'ransomware.status') {
      throw new WorkloadError('RANSOM_DATA_SCHEMA_UNSUPPORTED', 409);
    }
    return handlers.execute(value);
  };
  const businessReady = async () => unsupportedSchema === null;
  stage = 'listener';
  const server = createBackendServer({
    tls, frameworkPin: contract.frameworkPin,
    identity: { transportVersion: wireVersion, instanceId: identity.instanceId, generation: identity.generation },
    permits, execute, ready: businessReady,
    authorize: value => value.capability === contract.capability &&
      value.interfaceVersion === contract.interfaceVersion && ownsMethod(value.method, value.kind),
  });
  const probes = createLocalProbeServer({ ready: async () => unsupportedSchema === null && Boolean(permits.current()) });
  let stopping;
  const stop = () => stopping ??= (async () => {
    permits.stop().catch(() => {});
    reconciler.stop();
    alertPoller.stop();
    await Promise.all([
      new Promise(resolve => server.close(() => resolve())),
      new Promise(resolve => probes.close(() => resolve())),
    ]);
    log('INFO', 'stopped');
  })();
  process.once('SIGTERM', () => { stop().then(() => { process.exitCode = 0; }, () => { process.exitCode = 1; }); });
  process.once('SIGINT', () => { stop().then(() => { process.exitCode = 0; }, () => { process.exitCode = 1; }); });
  await Promise.all([
    new Promise((resolve, reject) => { server.once('error', reject); server.listen(workloadPort, '0.0.0.0', () => { server.removeListener('error', reject); resolve(); }); }),
    new Promise((resolve, reject) => { probes.once('error', reject); probes.listen(probePort, '127.0.0.1', () => { probes.removeListener('error', reject); resolve(); }); }),
  ]);
  permits.start();
  reconciler.start();
  alertPoller.start();
  log('INFO', 'running', { stage: 'running', workloadPort, probePort, cloudTowerConfigured: cloudTower.configured,
    rulesStore: rulesStore.paths, reconciler: true, alertPoller: true,
    cloudTowerInsecureTls: cloudTower.insecureTls === true, webhookConfigured: webhookKey !== null, dataSchemaUnsupported: unsupportedSchema });
}

main().catch(error => {
  log('ERROR', 'startup-failed', { stage, errorCode: errorCode(error, 'RANSOM_RUNTIME_START_FAILED') });
  process.exitCode = 1;
});
