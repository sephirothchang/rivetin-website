/**
 * Method dispatch for the ransomware protection business backend.
 *
 * Methods and kinds are fixed by `backend/declaration.mjs` (source mirror of
 * `rivetin.json.backend`). Read methods serve the persisted `/data` projection and
 * the optional CloudTower read API; submit methods that would mutate CloudTower are
 * explicitly not implemented in this read-only M5 candidate and return a stable
 * `RANSOM_SUBMIT_NOT_IMPLEMENTED` instead of pretending success.
 *
 * Webhook events are verified (HMAC-SHA256 over the raw body with the deployment
 * provided signing key), deduplicated and recorded; a missing signing key yields
 * `denied` so an unverified route can never be treated as accepted.
 */
import { createHmac, timingSafeEqual } from 'node:crypto';
import { WorkloadError } from '../runtime-support/server/workload-protocol.js';
import { METHODS, WEBHOOK, ownsMethod } from './declaration.mjs';
import { dedupeAlerts, normalizeAlert } from '../src/core/events.js';

const text = (value, maximum = 256) => typeof value === 'string' && value.length > 0 && value.length <= maximum;
const object = value => Boolean(value) && typeof value === 'object' && !Array.isArray(value);
const signaturePattern = /^sha256=([a-f0-9]{64})$/;
const webhookDedupeMs = 10 * 60 * 1000;

function inputOf(input) {
  if (!object(input)) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
  return input;
}

function cloudTowerFailure(error) {
  const code = typeof error?.code === 'string' ? error.code
    : typeof error?.message === 'string' ? error.message : '';
  // Keep certificate trust failures distinguishable from a generic CloudTower
  // outage so operators can add the deployment CA (or explicitly enable the
  // test-only insecure flag) instead of retrying blindly.
  if (code === 'RANSOM_CLOUDTOWER_TLS_UNTRUSTED' || /CERT|SELF_SIGNED|ALTNAME|ISSUER/i.test(code)) {
    return new WorkloadError('RANSOM_CLOUDTOWER_TLS_UNTRUSTED', 503);
  }
  return new WorkloadError('RANSOM_CLOUDTOWER_UNAVAILABLE', 503);
}

// Normalize a `get-vms` row to the bounded inventory projection. Unknown fields
// are dropped: the browser must never receive raw CloudTower responses.
function normalizeVmRow(row) {
  if (!object(row) || !text(row.id, 128)) return null;
  const item = { id: row.id, name: text(row.name, 256) ? row.name : row.id };
  const clusterId = row.cluster?.id ?? row.cluster_id;
  const clusterName = row.cluster?.name ?? row.cluster_name;
  if (text(clusterId, 128)) item.clusterId = clusterId;
  if (text(clusterName, 256)) item.clusterName = clusterName;
  if (text(row.status, 64)) item.status = row.status;
  return item;
}

function wireSafe(value) {
  // Workload responses are canonicalized by the runtime; `undefined` object fields
  // fail that serializer with WORKLOAD_RESPONSE_INVALID. Drop them explicitly.
  return JSON.parse(JSON.stringify(value));
}

function notImplemented(method) {
  return new WorkloadError('RANSOM_SUBMIT_NOT_IMPLEMENTED', 502);
}

function statusForCode(code) {
  if (code === 'RANSOM_CLOUDTOWER_TLS_UNTRUSTED') return 503;
  if (code === 'RANSOM_CLOUDTOWER_REQUIRED') return 503;
  return 502;
}

function cloudTowerWriteFailure(error) {
  const code = typeof error?.code === 'string' ? error.code
    : typeof error?.message === 'string' ? error.message : '';
  if (code === 'RANSOM_CLOUDTOWER_TLS_UNTRUSTED' || /CERT|SELF_SIGNED|ALTNAME|ISSUER/i.test(code)) {
    return new WorkloadError('RANSOM_CLOUDTOWER_TLS_UNTRUSTED', 503);
  }
  return new WorkloadError('RANSOM_CLOUDTOWER_WRITE_FAILED', 502);
}

function snapshotName(reason, operationId, now) {
  const generated = `rivetin-alert-${now.replace(/[:.]/g, '-')}-${operationId.slice(0, 8)}`;
  return (typeof reason === 'string' && reason.trim() ? reason.trim() : generated).slice(0, 80);
}

function verifyWebhookSignature(key, bodyUtf8, headers) {
  if (!Buffer.isBuffer(key) || key.length < 32) return false;
  const signature = headers?.['x-rivetin-signature'];
  const match = typeof signature === 'string' ? signaturePattern.exec(signature) : null;
  if (!match) return false;
  const expected = createHmac('sha256', key).update(Buffer.from(bodyUtf8, 'utf8')).digest();
  const provided = Buffer.from(match[1], 'hex');
  if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) return false;
  const timestamp = headers?.['x-rivetin-timestamp'];
  if (timestamp !== undefined) {
    if (typeof timestamp !== 'string' || !/^\d{1,12}$/.test(timestamp)) return false;
    if (Math.abs(Date.now() - Number(timestamp) * 1000) > 300 * 1000) return false;
  }
  return true;
}

export function createMethodHandlers({ store, identity, contract, cloudTower, webhookKey, clock = () => new Date().toISOString(),
  permits = null, version = null, startedAt = clock(), log = null, reconciler = null, alertPoller = null } = {}) {
  if (!store || !identity || !contract) throw new Error('RANSOM_HANDLERS_CONFIGURATION_INVALID');

  const handlers = {
    'ransomware.status': () => Object.freeze({
      backendVersion: version,
      mode: 'workload',
      workloadId: identity.workloadId,
      capability: contract.capability,
      interfaceVersion: contract.interfaceVersion,
      dataSchemaVersion: store.schemaVersion,
      cloudTowerConfigured: cloudTower?.configured === true,
      cloudTowerInsecureTls: cloudTower?.insecureTls === true,
      webhookConfigured: Buffer.isBuffer(webhookKey) && webhookKey.length >= 32,
      permitActive: typeof permits?.current === 'function' ? Boolean(permits.current()) : false,
      startedAt,
      checkedAt: clock(),
      counts: store.counts(),
    }),
    'ransomware.protection.list': () => ({ items: store.policies(), checkedAt: clock() }),
    async 'ransomware.protection.sync'(input) {
      const value = inputOf(input);
      if (!Array.isArray(value.vms) || value.vms.length > 500) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      if (value.revision !== undefined && (!Number.isSafeInteger(value.revision) || value.revision < 0)) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      if (value.enabled !== undefined && typeof value.enabled !== 'boolean') throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      if (value.ensureSnapshotPlan !== undefined && typeof value.ensureSnapshotPlan !== 'boolean') throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      if (value.global !== undefined && (!object(value.global) || !Number.isInteger(value.global.multiplier) ||
          !Number.isInteger(value.global.durationMinutes) || !text(value.global.severity, 16))) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      const seen = new Set(), policies = [];
      for (const row of value.vms) {
        if (!object(row) || typeof row.vmId !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(row.vmId) || seen.has(row.vmId) ||
            (row.vmName !== undefined && !text(row.vmName, 256)) || (row.clusterId !== undefined && !text(row.clusterId, 128)) ||
            (row.effective !== undefined && (!object(row.effective) || !Number.isInteger(row.effective.multiplier) ||
              !Number.isInteger(row.effective.durationMinutes) || !text(row.effective.severity, 16)))) {
          throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
        }
        seen.add(row.vmId);
        policies.push({ vmId: row.vmId, ...(row.vmName === undefined ? {} : { vmName: row.vmName }), syncedAt: clock() });
      }
      await store.syncPolicies(policies);
      let rules = { scheduled: false };
      if (reconciler) rules = await reconciler.syncDesired(value);
      return { count: policies.length, syncedAt: clock(), rules };
    },
    async 'ransomware.rules.status'() {
      if (!reconciler) throw new WorkloadError('RANSOM_SUBMIT_NOT_IMPLEMENTED', 502);
      return wireSafe(reconciler.status());
    },
    async 'ransomware.rules.reconcile'(input, call) {
      if (!reconciler) throw new WorkloadError('RANSOM_SUBMIT_NOT_IMPLEMENTED', 502);
      const value = input === undefined ? {} : inputOf(input);
      const dryRun = value.dryRun === undefined ? true : value.dryRun;
      if (typeof dryRun !== 'boolean') throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      const operationId = typeof call?.operationId === 'string' ? call.operationId : '';
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(operationId)) {
        throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      }
      const result = await reconciler.run({ manual: true, dryRun, force: dryRun });
      if (!result.ok && result.code && !dryRun) {
        const status = result.code === 'RANSOM_CLOUDTOWER_REQUIRED' || result.code === 'RANSOM_CLOUDTOWER_TLS_UNTRUSTED' ? 503 : 502;
        throw new WorkloadError(result.code, status);
      }
      return wireSafe(result);
    },
    async 'ransomware.inventory.vms'(input) {
      const value = input === undefined ? {} : inputOf(input);
      if (value.query !== undefined && !text(value.query, 128)) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      const limit = value.limit === undefined ? 500 : value.limit;
      if (!Number.isInteger(limit) || limit < 1 || limit > 500) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      if (cloudTower?.configured !== true) throw new WorkloadError('RANSOM_CLOUDTOWER_REQUIRED', 503);
      let rows;
      try { rows = await cloudTower.client.getVms({ first: limit }); }
      catch (error) { throw cloudTowerFailure(error); }
      const query = typeof value.query === 'string' ? value.query.trim().toLowerCase() : '';
      const items = (Array.isArray(rows) ? rows : []).map(normalizeVmRow).filter(Boolean)
        .filter(row => !query || row.name.toLowerCase().includes(query) || row.id.toLowerCase().includes(query))
        .sort((left, right) => left.name.localeCompare(right.name)).slice(0, limit);
      return { items, truncated: Array.isArray(rows) && rows.length >= limit };
    },
    'ransomware.events.list': () => ({ items: store.events(), checkedAt: clock() }),
    'ransomware.events.read': input => {
      const value = inputOf(input);
      if (!text(value.eventId, 128)) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      return { event: store.findEvent(value.eventId) };
    },
    async 'ransomware.events.snapshot'(input, call) {
      const value = inputOf(input);
      if (typeof value.vmId !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(value.vmId)) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      if (value.reason !== undefined && (!text(value.reason, 128) || /[\u0000-\u001f\u007f]/.test(value.reason))) {
        throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      }
      const dryRun = value.dryRun === undefined ? true : value.dryRun;
      if (typeof dryRun !== 'boolean') throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      const requestOperationId = typeof call?.operationId === 'string' ? call.operationId : '';
      const operationId = value.idempotencyKey === undefined ? requestOperationId : value.idempotencyKey;
      const operationIdPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
      if (!operationIdPattern.test(requestOperationId) || !operationIdPattern.test(operationId)) {
        throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      }
      // Hard safety gate: only VMs in the synchronized protected set can be
      // addressed. Checked before any CloudTower request.
      if (!store.findPolicy(value.vmId)) throw new WorkloadError('RANSOM_TARGET_NOT_PROTECTED', 409);
      if (!dryRun) {
        const previous = store.findOperation(operationId);
        if (previous) {
          if (previous.status === 'succeeded' && previous.result) return previous.result;
          if (previous.status === 'failed') throw new WorkloadError(previous.code || 'RANSOM_CLOUDTOWER_WRITE_FAILED', statusForCode(previous.code));
          throw new WorkloadError('RANSOM_STATE_CONFLICT', 409);
        }
      }
      if (cloudTower?.configured !== true) throw new WorkloadError('RANSOM_CLOUDTOWER_REQUIRED', 503);
      let rows;
      try { rows = await cloudTower.client.getVms({ first: 500 }); }
      catch (error) { throw cloudTowerWriteFailure(error); }
      const target = (Array.isArray(rows) ? rows : []).find(row => row && row.id === value.vmId);
      if (!target || typeof target.status !== 'string' || target.status === 'DELETED' || target.in_recycle_bin === true) {
        throw new WorkloadError('RANSOM_TARGET_NOT_AVAILABLE', 409);
      }
      const now = clock();
      const name = snapshotName(value.reason, operationId, now);
      if (dryRun) return { dryRun: true, wouldCreate: true, vmId: value.vmId, vmName: typeof target.name === 'string' ? target.name : null,
        status: target.status, snapshotName: name };
      await store.beginOperation({ operationId, requestOperationId, method: 'ransomware.events.snapshot', vmId: value.vmId,
        status: 'started', startedAt: now });
      try {
        const created = await cloudTower.client.createVmSnapshot({ vmId: value.vmId, name });
        let snapshotId = typeof created?.snapshotId === 'string' ? created.snapshotId : null;
        if (!snapshotId) {
          // The create response may only carry a task id; resolve the created
          // snapshot once by its deterministic name (single read, no retry loop).
          const snapshots = await cloudTower.client.getVmSnapshots(value.vmId).catch(() => []);
          snapshotId = (Array.isArray(snapshots) ? snapshots : []).find(row => row && row.name === name && typeof row.id === 'string')?.id ?? null;
        }
        if (!snapshotId) {
          const failure = new WorkloadError('RANSOM_CLOUDTOWER_WRITE_FAILED', 502);
          await store.finishOperation(operationId, { status: 'failed', code: failure.message, finishedAt: clock() });
          log?.('WARN', 'snapshot-write', { method: 'ransomware.events.snapshot', vmId: value.vmId, result: 'unknown', code: failure.message });
          throw failure;
        }
        const result = { snapshotId, vmId: value.vmId, createdAt: clock() };
        await store.finishOperation(operationId, { status: 'succeeded', snapshotId, result, finishedAt: clock() });
        log?.('INFO', 'snapshot-write', { method: 'ransomware.events.snapshot', vmId: value.vmId, snapshotId,
          result: 'succeeded' });
        return result;
      } catch (error) {
        const mapped = error instanceof WorkloadError ? error : cloudTowerWriteFailure(error);
        const current = store.findOperation(operationId);
        if (current?.status !== 'failed') {
          await store.finishOperation(operationId, { status: 'failed', code: mapped.message, finishedAt: clock() });
          log?.('WARN', 'snapshot-write', { method: 'ransomware.events.snapshot', vmId: value.vmId, result: 'failed',
            code: mapped.message });
        }
        throw mapped;
      }
    },
    'ransomware.delivery.read': input => {
      const value = input === undefined ? {} : inputOf(input);
      if (value.deliveryId !== undefined) {
        if (!text(value.deliveryId, 128)) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
        return { delivery: store.findDelivery(value.deliveryId) };
      }
      return { items: store.deliveries(), checkedAt: clock() };
    },
    async 'ransomware.alerts.poll'(input) {
      const value = input === undefined ? {} : inputOf(input);
      if (value.since !== undefined && !text(value.since, 64)) throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      if (alertPoller) return alertPoller.pollOnce();
      if (cloudTower?.configured !== true) throw new WorkloadError('RANSOM_CLOUDTOWER_REQUIRED', 503);
      let alerts;
      try {
        alerts = await cloudTower.client.getAlerts({ where: { ended: false }, first: 100 });
      } catch (error) { throw cloudTowerFailure(error); }
      const normalized = [];
      for (const row of Array.isArray(alerts) ? alerts : []) {
        try { normalized.push(normalizeAlert({ ...row, source: 'poll' })); }
        catch { /* Unnormalizable alerts are skipped, not fabricated. */ }
      }
      const deduped = dedupeAlerts(normalized, { windowMinutes: 5 });
      let added = 0;
      for (const event of deduped) {
        const id = 'poll-' + event.incidentKey;
        if (!store.findEvent(id)) { await store.addEvent({ id, source: 'poll', event, receivedAt: clock() }); added++; }
      }
      return { polledAt: clock(), received: Array.isArray(alerts) ? alerts.length : 0, recorded: added };
    },
    async 'ransomware.webhook.event'(input) {
      const value = inputOf(input);
      if (value.channel !== 'cloudtower' || !Array.isArray(WEBHOOK.channels) || !WEBHOOK.channels.includes(value.channel)) {
        throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      }
      if (!text(value.bodyUtf8, 65536) || !/^[a-f0-9]{64}$/.test(value.bodySha256 ?? '') ||
          !object(value.headers) || !text(value.receivedAt, 64)) {
        throw new WorkloadError('RANSOM_INPUT_INVALID', 400);
      }
      if (!verifyWebhookSignature(webhookKey, value.bodyUtf8, value.headers)) return { result: 'denied' };
      const previous = store.findWebhook(value.bodySha256);
      const nowMs = Date.parse(clock());
      if (previous && Number.isFinite(nowMs) && nowMs - Date.parse(previous.receivedAt) < webhookDedupeMs) {
        return { result: 'duplicate' };
      }
      let normalized = null, errorCode = null;
      try {
        const parsed = JSON.parse(value.bodyUtf8);
        normalized = normalizeAlert({ ...parsed, source: 'webhook' });
      } catch (error) {
        errorCode = /^ALERT_[A-Z_]+$/.test(error?.message ?? '') ? error.message : 'ALERT_UNNORMALIZABLE';
      }
      await store.rememberWebhook({ sha256: value.bodySha256, receivedAt: clock() });
      const id = 'webhook-' + value.bodySha256.slice(0, 24);
      await store.addEvent({ id, source: 'webhook', receivedAt: clock(), normalized, errorCode });
      return { result: errorCode ? 'recorded' : 'accepted' };
    },
  };

  for (const method of Object.keys(METHODS)) {
    if (METHODS[method] === 'submit' && !Object.hasOwn(handlers, method)) {
      handlers[method] = () => { throw notImplemented(method); };
    }
  }

  return {
    methods: Object.freeze({ ...METHODS }),
    async execute(value) {
      if (!ownsMethod(value?.method, value?.kind)) throw new WorkloadError('WORKLOAD_METHOD_UNSUPPORTED', 400);
      if (value.capability !== contract.capability || value.interfaceVersion !== contract.interfaceVersion) {
        throw new WorkloadError('WORKLOAD_METHOD_UNSUPPORTED', 400);
      }
      const handler = handlers[value.method];
      if (typeof handler !== 'function') throw new WorkloadError('WORKLOAD_METHOD_UNSUPPORTED', 400);
      return handler(value.input, value);
    },
  };
}
