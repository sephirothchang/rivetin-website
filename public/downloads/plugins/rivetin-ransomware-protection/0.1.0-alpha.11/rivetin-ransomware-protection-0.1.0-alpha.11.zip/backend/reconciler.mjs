/**
 * Phase 2B reconciler: custom alert rules (CloudTower UI GraphQL) and hourly
 * snapshot plans (CloudTower REST) derived from the plugin's desired state.
 *
 * Safety model:
 *   - only objects recorded in the local ledger are updated/deleted;
 *   - existing unmanaged rules/plans are never adopted or modified;
 *   - every mutation is preceded by a read and followed by a read-back;
 *   - failures back off exponentially (no retry storm) and are audited;
 *   - dryRun computes the exact action list without any mutation.
 */
import { createHash, randomUUID } from 'node:crypto';

const RULE_PREFIX = 'rivetin-ransomware-';
const PLAN_PREFIX = 'rivetin-ransomware-hourly-';
const OBS_CACHE_MS = 30 * 60 * 1000;
const BASE_BACKOFF_MS = 30 * 1000;
const MAX_BACKOFF_MS = 30 * 60 * 1000;
const TASK_TIMEOUT_MS = 60 * 1000;
const TASK_POLL_MS = 2000;

const actionError = (code, extra = {}) => Object.assign(new Error(code), { code, ...extra });
const text = (value, maximum = 255) => typeof value === 'string' && value.length > 0 && value.length <= maximum;
const vmIdOf = value => typeof value === 'string' ? value.replace(/^vm:/, '') : null;
const sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));

function sortedUnique(values) {
  return [...new Set(values)].sort();
}

function hashKey(value) {
  return createHash('sha256').update(value).digest('hex').slice(0, 8);
}

function nextHour(nowIso) {
  const date = new Date(nowIso);
  if (!Number.isFinite(date.getTime())) return new Date(0).toISOString();
  date.setUTCMinutes(0, 0, 0);
  date.setUTCHours(date.getUTCHours() + 1);
  return date.toISOString();
}

function planVmIds(plan) {
  if (!plan || typeof plan !== 'object') return [];
  const rows = Array.isArray(plan.vms) ? plan.vms : [];
  return sortedUnique(rows.map(vm => vmIdOf(vm?.id ?? vm?.vm_id)).filter(Boolean));
}

function ruleVmIds(rule) {
  const whitelist = Array.isArray(rule?.targets?.whitelist) ? rule.targets.whitelist : [];
  return sortedUnique(whitelist.map(vmIdOf).filter(Boolean));
}

function firstGroup(rule) {
  return Array.isArray(rule?.groups) && rule.groups.length > 0 ? rule.groups[0] : null;
}

export function buildDesiredRules(desired) {
  const groups = new Map();
  for (const entry of Array.isArray(desired?.vms) ? desired.vms : []) {
    if (!entry || !text(entry.vmId, 128) || !text(entry.clusterId, 128)) continue;
    const effective = entry.effective && typeof entry.effective === 'object' ? entry.effective : desired.global;
    if (!effective || !Number.isInteger(effective.multiplier) || !Number.isInteger(effective.durationMinutes) ||
        !['CRITICAL', 'NOTICE', 'INFO'].includes(effective.severity)) continue;
    const key = `${entry.clusterId}|${effective.severity}|${effective.multiplier}|${effective.durationMinutes}`;
    if (!groups.has(key)) groups.set(key, { key, clusterId: entry.clusterId, severity: effective.severity,
      multiplier: effective.multiplier, durationMinutes: effective.durationMinutes, vmIds: [] });
    groups.get(key).vmIds.push(entry.vmId);
  }
  const disabled = desired?.enabled !== true;
  return [...groups.values()].map(group => {
    const vmIds = sortedUnique(group.vmIds);
    const name = RULE_PREFIX + `${group.severity.toLowerCase()}-${group.multiplier}x-${group.durationMinutes}m-${hashKey(group.key)}`;
    return { ...group, vmIds, name, disabled,
      body: { name, exclude_system_service_vm: true,
        targets: { vm: [...vmIds], vmfolder: [], cluster: [] },
        groups: [{ for: group.durationMinutes, severity: group.severity,
          triggers: [{ name: 'VM_DISK_IOPS', operator: 'SPIKE_GE', value: group.multiplier }] }],
        disabled, description: 'Rivetin ransomware protection (managed)', alert_description: 'Rivetin ransomware IOPS anomaly' } };
  }).sort((left, right) => left.name.localeCompare(right.name));
}

export function buildDesiredPlans(desired, nowIso) {
  if (desired?.ensureSnapshotPlan !== true) return [];
  const byCluster = new Map();
  for (const entry of Array.isArray(desired?.vms) ? desired.vms : []) {
    if (!entry || !text(entry.vmId, 128) || !text(entry.clusterId, 128)) continue;
    if (!byCluster.has(entry.clusterId)) byCluster.set(entry.clusterId, []);
    byCluster.get(entry.clusterId).push(entry.vmId);
  }
  return [...byCluster.entries()].map(([clusterId, vmIds]) => ({
    clusterId, vmIds: sortedUnique(vmIds), name: PLAN_PREFIX + clusterId,
    body: { name: PLAN_PREFIX + clusterId, cluster_id: clusterId, vm_ids: sortedUnique(vmIds),
      execute_plan_type: 'HOUR', execute_intervals: [1], start_time: nextHour(nowIso), remain_snapshot_num: 8 },
  })).sort((left, right) => left.clusterId.localeCompare(right.clusterId));
}

function ruleMatches(actual, desired) {
  if (!actual) return false;
  const group = firstGroup(actual);
  const actualVmIds = ruleVmIds(actual);
  return actual.name === desired.name && actual.disabled === desired.disabled &&
    JSON.stringify(actualVmIds) === JSON.stringify(desired.vmIds) &&
    group && group.severity === desired.severity && group.for === desired.durationMinutes &&
    Array.isArray(group.triggers) && group.triggers.length === 1 &&
    group.triggers[0].name === 'VM_DISK_IOPS' && group.triggers[0].operator === 'SPIKE_GE' &&
    group.triggers[0].value === desired.multiplier;
}

function planMatches(actual, desired) {
  if (!actual) return false;
  return actual.name === desired.name && actual.execute_plan_type === 'HOUR' &&
    JSON.stringify(Array.isArray(actual.execute_intervals) ? actual.execute_intervals : []) === JSON.stringify([1]) &&
    JSON.stringify(planVmIds(actual)) === JSON.stringify(desired.vmIds);
}

function unmanagedPlanCovers(plans, desired, ledgerIds) {
  return plans.some(plan => plan && !ledgerIds.has(plan.id) && plan.name !== desired.name &&
    plan.execute_plan_type === 'HOUR' && JSON.stringify(Array.isArray(plan.execute_intervals) ? plan.execute_intervals : []) === JSON.stringify([1]) &&
    desired.vmIds.every(vmId => planVmIds(plan).includes(vmId)));
}


async function enrichDesiredClusters(client, desired) {
  const missing = (desired.vms ?? []).some(entry => !text(entry.clusterId, 128));
  if (!missing) return desired;
  const rows = await client.getVms({ first: 500 });
  const clusters = new Map();
  for (const row of Array.isArray(rows) ? rows : []) {
    const clusterId = row?.cluster?.id ?? row?.cluster_id;
    if (row && typeof row.id === 'string' && typeof clusterId === 'string') clusters.set(row.id, clusterId);
  }
  return { ...desired, vms: (desired.vms ?? []).map(entry => entry.clusterId ? entry : { ...entry, clusterId: clusters.get(entry.vmId) }) };
}

export function createReconciler({ rulesStore, cloudTower, log = () => {}, clock = () => new Date().toISOString(), clientFactory = null } = {}) {
  if (!rulesStore) throw new Error('RECONCILE_STORE_REQUIRED');
  let running = null, timer = null, stopped = false, obsCheckedAtMs = 0, obsSupported = null;
  const getClient = () => clientFactory ? clientFactory() : (cloudTower?.configured === true ? cloudTower.client : null);
  const nowMs = () => Date.parse(clock());

  function audit(entry) {
    return rulesStore.audit(entry).catch(() => {});
  }

  async function checkObservability(client, force = false) {
    const now = nowMs();
    if (!force && obsSupported !== null && Number.isFinite(now) && now - obsCheckedAtMs < OBS_CACHE_MS) return obsSupported;
    try {
      const catalog = await client.getAlertTriggerCatalog();
      const metric = catalog.find(row => row.name === 'VM_DISK_IOPS');
      obsSupported = Boolean(metric && Array.isArray(metric.operators) && metric.operators.includes('SPIKE_GE'));
    } catch { obsSupported = false; }
    obsCheckedAtMs = Number.isFinite(now) ? now : Date.now();
    await rulesStore.patchLedger({ obsSupported, obsCheckedAt: clock() }).catch(() => {});
    return obsSupported;
  }

  async function waitTasks(client, taskIds) {
    const ids = taskIds.filter(id => typeof id === 'string' && id.length > 0);
    if (!ids.length) return;
    const deadline = Date.now() + TASK_TIMEOUT_MS;
    while (Date.now() < deadline) {
      const tasks = await client.getTasks(ids);
      if (Array.isArray(tasks) && tasks.length > 0 && tasks.every(task => ['SUCCESSED', 'FAILED'].includes(task.status))) {
        const failed = tasks.find(task => task.status === 'FAILED');
        if (failed) throw actionError('CLOUDTOWER_TASK_FAILED');
        return;
      }
      await sleep(TASK_POLL_MS);
    }
    throw actionError('CLOUDTOWER_TASK_TIMEOUT');
  }

  function schedule(delayMs) {
    if (stopped) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => { timer = null; run({ manual: false }).catch(() => {}); }, Math.max(1000, delayMs));
    timer.unref?.();
  }

  function backoffDelay(attempts) {
    return Math.min(BASE_BACKOFF_MS * 2 ** Math.max(0, attempts - 1), MAX_BACKOFF_MS);
  }

  async function previewAndApplyRules(client, desired, dryRun, actions, ledger) {
    let rules;
    try { rules = await client.listAlertRules({ pageSize: 100 }); }
    catch (error) { throw actionError('RANSOM_RULE_SYNC_FAILED', { cause: error }); }
    const actualById = new Map(rules.rules.map(rule => [rule.id, rule]));
    const managedByKey = new Map(ledger.managedRules.map(row => [row.key, row]));
    const desiredRules = buildDesiredRules(desired);
    const desiredKeys = new Set(desiredRules.map(rule => rule.key));
    const nextManaged = [];
    const orphanRules = rules.rules.filter(rule => typeof rule.name === 'string' && rule.name.startsWith(RULE_PREFIX) &&
      !ledger.managedRules.some(row => row.id === rule.id)).length;

    if (!obsSupported) {
      return { actions, managed: ledger.managedRules, skipped: 'OBSERVABILITY_UNSUPPORTED', orphanRules };
    }

    for (const desiredRule of desiredRules) {
      const managed = managedByKey.get(desiredRule.key);
      const actual = managed ? actualById.get(managed.id) : null;
      if (managed && actual) {
        if (ruleMatches(actual, desiredRule)) {
          nextManaged.push({ ...managed, targetVmIds: desiredRule.vmIds, syncStatus: actual.sync_info?.sync_status ?? managed.syncStatus });
          continue;
        }
        if (actual.sync_info?.sync_status === 'SYNCING') {
          nextManaged.push(managed);
          continue;
        }
        actions.push({ action: 'update', objectType: 'alertRule', objectId: actual.id, key: desiredRule.key,
          name: desiredRule.name, vmCount: desiredRule.vmIds.length });
        if (!dryRun) {
          try {
            await client.updateAlertRule(actual.id, desiredRule.body);
            nextManaged.push({ key: desiredRule.key, id: actual.id, name: desiredRule.name, targetVmIds: desiredRule.vmIds,
              syncStatus: 'SYNCING', severity: desiredRule.severity, multiplier: desiredRule.multiplier,
              durationMinutes: desiredRule.durationMinutes, appliedAt: clock() });
            await audit({ action: 'update', objectType: 'alertRule', objectId: actual.id, name: desiredRule.name, result: 'succeeded', errorCode: null });
          } catch (error) {
            await audit({ action: 'update', objectType: 'alertRule', objectId: actual.id, name: desiredRule.name, result: 'failed', errorCode: 'RANSOM_RULE_SYNC_FAILED' });
            throw actionError('RANSOM_RULE_SYNC_FAILED', { cause: error });
          }
        }
        continue;
      }
      actions.push({ action: 'create', objectType: 'alertRule', objectId: null, key: desiredRule.key,
        name: desiredRule.name, vmCount: desiredRule.vmIds.length });
      if (!dryRun) {
        try {
          const created = await client.createAlertRule(desiredRule.body);
          nextManaged.push({ key: desiredRule.key, id: created.id, name: desiredRule.name, targetVmIds: desiredRule.vmIds,
            syncStatus: created.sync_info?.sync_status ?? 'SYNCING', severity: desiredRule.severity,
            multiplier: desiredRule.multiplier, durationMinutes: desiredRule.durationMinutes, appliedAt: clock() });
          await audit({ action: 'create', objectType: 'alertRule', objectId: created.id, name: desiredRule.name, result: 'succeeded', errorCode: null });
        } catch (error) {
          await audit({ action: 'create', objectType: 'alertRule', objectId: null, name: desiredRule.name, result: 'failed', errorCode: 'RANSOM_RULE_SYNC_FAILED' });
          throw actionError('RANSOM_RULE_SYNC_FAILED', { cause: error });
        }
      }
    }
    for (const managed of ledger.managedRules) {
      if (desiredKeys.has(managed.key)) continue;
      const actual = actualById.get(managed.id);
      if (!actual) continue;
      actions.push({ action: 'delete', objectType: 'alertRule', objectId: managed.id, key: managed.key, name: managed.name, vmCount: 0 });
      if (!dryRun) {
        try {
          await client.deleteAlertRule(managed.id);
          await audit({ action: 'delete', objectType: 'alertRule', objectId: managed.id, name: managed.name, result: 'succeeded', errorCode: null });
        } catch (error) {
          await audit({ action: 'delete', objectType: 'alertRule', objectId: managed.id, name: managed.name, result: 'failed', errorCode: 'RANSOM_RULE_SYNC_FAILED' });
          throw actionError('RANSOM_RULE_SYNC_FAILED', { cause: error });
        }
      }
    }
    return { actions, managed: nextManaged, orphanRules };
  }

  async function previewAndApplyPlans(client, desired, dryRun, actions, ledger) {
    let plans;
    try { plans = await client.getSnapshotPlans({ first: 500 }); }
    catch (error) { throw actionError('RANSOM_PLAN_SYNC_FAILED', { cause: error }); }
    const actualById = new Map(plans.map(plan => [plan.id, plan]));
    const managedByCluster = new Map(ledger.managedPlans.map(row => [row.clusterId, row]));
    const desiredPlans = buildDesiredPlans(desired, clock());
    const desiredClusters = new Set(desiredPlans.map(plan => plan.clusterId));
    const ledgerIds = new Set(ledger.managedPlans.map(row => row.id));
    const nextManaged = [];
    for (const desiredPlan of desiredPlans) {
      const managed = managedByCluster.get(desiredPlan.clusterId);
      const actual = managed ? actualById.get(managed.id) : null;
      if (managed && actual) {
        if (planMatches(actual, desiredPlan)) {
          nextManaged.push({ ...managed, vmIds: desiredPlan.vmIds, status: actual.status ?? managed.status });
          continue;
        }
        actions.push({ action: 'update', objectType: 'snapshotPlan', objectId: actual.id, name: desiredPlan.name,
          clusterId: desiredPlan.clusterId, vmCount: desiredPlan.vmIds.length });
        if (!dryRun) {
          try {
            const result = await client.updateSnapshotPlan({ id: actual.id },
              { vm_ids: desiredPlan.vmIds, execute_plan_type: 'HOUR', execute_intervals: [1] });
            await waitTasks(client, [result.taskId]);
            nextManaged.push({ clusterId: desiredPlan.clusterId, id: actual.id, name: desiredPlan.name, vmIds: desiredPlan.vmIds,
              executePlanType: 'HOUR', executeIntervals: [1], appliedAt: clock() });
            await audit({ action: 'update', objectType: 'snapshotPlan', objectId: actual.id, name: desiredPlan.name, result: 'succeeded', errorCode: null });
          } catch (error) {
            await audit({ action: 'update', objectType: 'snapshotPlan', objectId: actual.id, name: desiredPlan.name, result: 'failed', errorCode: 'RANSOM_PLAN_SYNC_FAILED' });
            throw actionError('RANSOM_PLAN_SYNC_FAILED', { cause: error });
          }
        }
        continue;
      }
      if (!managed && unmanagedPlanCovers(plans, desiredPlan, ledgerIds)) {
        actions.push({ action: 'skip', objectType: 'snapshotPlan', objectId: null, name: desiredPlan.name,
          clusterId: desiredPlan.clusterId, reason: 'covered-by-unmanaged-plan' });
        continue;
      }
      actions.push({ action: 'create', objectType: 'snapshotPlan', objectId: null, name: desiredPlan.name,
        clusterId: desiredPlan.clusterId, vmCount: desiredPlan.vmIds.length });
      if (!dryRun) {
        try {
          const result = await client.createSnapshotPlan(desiredPlan.body);
          await waitTasks(client, [result.taskId]);
          const planId = result.planId ?? result.plan?.id;
          if (!text(planId, 128)) throw actionError('RANSOM_PLAN_SYNC_FAILED');
          nextManaged.push({ clusterId: desiredPlan.clusterId, id: planId, name: desiredPlan.name, vmIds: desiredPlan.vmIds,
            executePlanType: 'HOUR', executeIntervals: [1], appliedAt: clock() });
          await audit({ action: 'create', objectType: 'snapshotPlan', objectId: planId, name: desiredPlan.name, result: 'succeeded', errorCode: null });
        } catch (error) {
          await audit({ action: 'create', objectType: 'snapshotPlan', objectId: null, name: desiredPlan.name, result: 'failed', errorCode: 'RANSOM_PLAN_SYNC_FAILED' });
          throw actionError('RANSOM_PLAN_SYNC_FAILED', { cause: error });
        }
      }
    }
    for (const managed of ledger.managedPlans) {
      if (desiredClusters.has(managed.clusterId)) continue;
      const actual = actualById.get(managed.id);
      if (!actual) continue;
      actions.push({ action: 'delete', objectType: 'snapshotPlan', objectId: managed.id, name: managed.name, clusterId: managed.clusterId, vmCount: 0 });
      if (!dryRun) {
        try {
          const result = await client.deleteSnapshotPlan(managed.id);
          await waitTasks(client, [result.taskId]);
          await audit({ action: 'delete', objectType: 'snapshotPlan', objectId: managed.id, name: managed.name, result: 'succeeded', errorCode: null });
        } catch (error) {
          await audit({ action: 'delete', objectType: 'snapshotPlan', objectId: managed.id, name: managed.name, result: 'failed', errorCode: 'RANSOM_PLAN_SYNC_FAILED' });
          throw actionError('RANSOM_PLAN_SYNC_FAILED', { cause: error });
        }
      }
    }
    return { actions, managed: nextManaged };
  }

  async function run({ manual = false, dryRun = false, force = false } = {}) {
    if (running) return running;
    running = (async () => {
      if (stopped) return { ok: false, code: 'RECONCILER_STOPPED', actions: [] };
      let desired = rulesStore.desired();
      const ledger = rulesStore.ledger();
      const client = getClient();
      if (!client) return { ok: false, code: 'RANSOM_CLOUDTOWER_REQUIRED', actions: [] };
      const now = nowMs();
      if (!manual && !force && ledger.nextAttemptAt && Number.isFinite(now) &&
          Number.isFinite(Date.parse(ledger.nextAttemptAt)) && now < Date.parse(ledger.nextAttemptAt)) {
        return { ok: false, code: 'RANSOM_SYNC_BACKOFF', nextAttemptAt: ledger.nextAttemptAt, actions: [] };
      }
      const actions = [];
      let orphanRules = 0, lastError = null;
      await rulesStore.patchLedger({ lastAttemptAt: clock() }).catch(() => {});
      try {
        await checkObservability(client, manual);
        try { desired = await enrichDesiredClusters(client, desired); }
        catch (error) { lastError = error.code || 'RANSOM_RULE_SYNC_FAILED'; }
        let ruleResult, planResult;
        if (lastError === null) {
          try { ruleResult = await previewAndApplyRules(client, desired, dryRun, actions, ledger); orphanRules = ruleResult.orphanRules; }
          catch (error) { lastError = error.code || 'RANSOM_RULE_SYNC_FAILED'; }
        }
        if (lastError === null) {
          try { planResult = await previewAndApplyPlans(client, desired, dryRun, actions, ledger); }
          catch (error) { lastError = error.code || 'RANSOM_PLAN_SYNC_FAILED'; }
        }
        if (dryRun) {
          for (const action of actions) await audit({ ...action, result: 'preview', errorCode: null, dryRun: true });
          return { ok: lastError === null, dryRun: true, actions, orphanRules, skipped: ruleResult?.skipped ?? null,
            ...(lastError ? { code: lastError } : {}) };
        }
        const managedRules = ruleResult?.managed ?? ledger.managedRules;
        const managedPlans = planResult?.managed ?? ledger.managedPlans;
        const patch = lastError ? { managedRules, managedPlans, lastError: { code: lastError, at: clock() } } : {
          managedRules, managedPlans, desiredRevision: desired.revision, appliedRevision: desired.revision,
          lastSyncAt: clock(), lastError: null, backoffAttempts: 0, nextAttemptAt: null,
        };
        if (lastError) {
          const attempt = (ledger.backoffAttempts ?? 0) + 1;
          patch.backoffAttempts = attempt;
          patch.nextAttemptAt = new Date(now + backoffDelay(attempt)).toISOString();
          patch.lastError = { code: lastError, at: clock() };
        }
        await rulesStore.patchLedger(patch);
        if (lastError) log('WARN', 'reconcile-failed', { code: lastError, nextAttemptAt: patch.nextAttemptAt });
        else log('INFO', 'reconcile-complete', { actions: actions.length, rules: managedRules.length, plans: managedPlans.length });
        return { ok: lastError === null, dryRun: false, actions, orphanRules, ...(lastError ? { code: lastError } : {}) };
      } finally {
        running = null;
        const current = rulesStore.ledger();
        if (!stopped && !dryRun) {
          const delay = current.nextAttemptAt && Number.isFinite(Date.parse(current.nextAttemptAt))
            ? Math.max(1000, Date.parse(current.nextAttemptAt) - nowMs()) : 5 * 60 * 1000;
          schedule(delay);
        }
      }
    })();
    return running;
  }

  async function syncDesired(payload) {
    if (!payload || typeof payload !== 'object' || !Number.isInteger(payload.revision) || payload.revision < 0 ||
        !Array.isArray(payload.vms)) throw actionError('RANSOM_INPUT_INVALID');
    const global = payload.global && typeof payload.global === 'object' ? payload.global : null;
    const vms = payload.vms.map(entry => ({
      vmId: entry.vmId, ...(typeof entry.vmName === 'string' ? { vmName: entry.vmName } : {}),
      ...(typeof entry.clusterId === 'string' ? { clusterId: entry.clusterId } : {}),
      ...(entry.effective && typeof entry.effective === 'object' ? { effective: entry.effective } : {}),
    })).filter(entry => typeof entry.vmId === 'string' && entry.vmId.length > 0);
    await rulesStore.setDesired({ revision: payload.revision, enabled: payload.enabled === true,
      ensureSnapshotPlan: payload.ensureSnapshotPlan === true, global: global ?? undefined, vms });
    schedule(10 * 1000);
    return { revision: payload.revision, vms: vms.length, scheduled: true };
  }

  function status() {
    const desired = rulesStore.desired(), ledger = rulesStore.ledger();
    return { supported: { cloudTower: Boolean(getClient()), observability: ledger.obsSupported === true },
      desiredRevision: desired.revision, appliedRevision: ledger.appliedRevision,
      lastSyncAt: ledger.lastSyncAt, lastAttemptAt: ledger.lastAttemptAt, nextAttemptAt: ledger.nextAttemptAt,
      lastError: ledger.lastError, obsSupported: ledger.obsSupported, obsCheckedAt: ledger.obsCheckedAt,
      rules: ledger.managedRules.map(row => ({ name: row.name, id: row.id, vmCount: Array.isArray(row.targetVmIds) ? row.targetVmIds.length : 0, syncStatus: row.syncStatus })),
      plans: ledger.managedPlans.map(row => ({ name: row.name, id: row.id, clusterId: row.clusterId, vmCount: Array.isArray(row.vmIds) ? row.vmIds.length : 0 })),
      managed: true, quarantined: rulesStore.quarantined, desiredVmCount: Array.isArray(desired.vms) ? desired.vms.length : 0 };
  }

  return Object.freeze({ run, syncDesired, status, schedule, start(intervalMs = 5 * 60 * 1000) { schedule(intervalMs); },
    stop() { stopped = true; if (timer) clearTimeout(timer); timer = null; } });
}
