/**
 * Phase 2B durable state for automatic alert rules and snapshot plans.
 *
 * Two files under the framework-owned `/data` volume:
 *   - ransomware-desired.json: the last successfully saved configuration projected
 *     by the plugin center (revision + effective per-VM settings). The backend cannot
 *     read the shared framework configuration directly.
 *   - ransomware-rules.json: the managed-object ledger, sync timestamps, bounded
 *     audit trail and backoff state. Only objects listed here are ever updated or
 *     deleted; unknown/unmanaged CloudTower objects are never adopted.
 *
 * A corrupt file is quarantined (renamed with a timestamp suffix) and an empty
 * document is used instead, so a crash can never cause unrelated CloudTower
 * objects to be deleted.
 */
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';

export const DESIRED_SCHEMA_VERSION = 1;
export const LEDGER_SCHEMA_VERSION = 1;
export const DESIRED_FILE = 'ransomware-desired.json';
export const LEDGER_FILE = 'ransomware-rules.json';
const MAX_AUDIT = 500;

const record = value => Boolean(value) && typeof value === 'object' && !Array.isArray(value);

function defaultDesired(clock) {
  return { schemaVersion: DESIRED_SCHEMA_VERSION, revision: 0, enabled: true, ensureSnapshotPlan: true,
    global: { multiplier: 3, durationMinutes: 5, severity: 'CRITICAL' }, vms: [], updatedAt: clock() };
}

function defaultLedger(clock) {
  return { schemaVersion: LEDGER_SCHEMA_VERSION, desiredRevision: 0, appliedRevision: 0,
    lastSyncAt: null, lastAttemptAt: null, nextAttemptAt: null, backoffAttempts: 0, lastError: null,
    obsSupported: null, obsCheckedAt: null, managedRules: [], managedPlans: [], audit: [], updatedAt: clock() };
}

async function readJson(file) {
  try { return { value: JSON.parse(await readFile(file, 'utf8')) }; }
  catch (error) {
    if (error.code === 'ENOENT') return { value: null };
    return { value: null, error };
  }
}

async function quarantine(file, clock) {
  const suffix = clock().replace(/[:.]/g, '-');
  await rename(file, `${file}.corrupt-${suffix}`).catch(() => {});
}

async function atomicWrite(file, value) {
  const temporary = file + '.tmp';
  await writeFile(temporary, JSON.stringify(value) + '\n', { mode: 0o600 });
  await rename(temporary, file);
}

export async function openRulesStore(directory, { clock = () => new Date().toISOString() } = {}) {
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const desiredPath = path.join(directory, DESIRED_FILE);
  const ledgerPath = path.join(directory, LEDGER_FILE);
  const loadedDesired = await readJson(desiredPath);
  const loadedLedger = await readJson(ledgerPath);
  let quarantined = [];
  let desired = loadedDesired.value;
  if (loadedDesired.error) {
    await quarantine(desiredPath, clock);
    quarantined.push(DESIRED_FILE);
    desired = null;
  }
  if (!record(desired) || desired.schemaVersion !== DESIRED_SCHEMA_VERSION) desired = defaultDesired(clock);
  let ledger = loadedLedger.value;
  if (loadedLedger.error) {
    await quarantine(ledgerPath, clock);
    quarantined.push(LEDGER_FILE);
    ledger = null;
  }
  if (!record(ledger) || ledger.schemaVersion !== LEDGER_SCHEMA_VERSION) ledger = defaultLedger(clock);
  if (!Array.isArray(ledger.managedRules)) ledger.managedRules = [];
  if (!Array.isArray(ledger.managedPlans)) ledger.managedPlans = [];
  if (!Array.isArray(ledger.audit)) ledger.audit = [];
  let desiredDirty = false, ledgerDirty = false;
  async function saveDesired() {
    desired.updatedAt = clock();
    await atomicWrite(desiredPath, desired);
    desiredDirty = false;
  }
  async function saveLedger() {
    ledger.updatedAt = clock();
    ledger.audit = ledger.audit.slice(-MAX_AUDIT);
    await atomicWrite(ledgerPath, ledger);
    ledgerDirty = false;
  }
  return {
    paths: { desired: desiredPath, ledger: ledgerPath },
    quarantined,
    desired: () => structuredClone(desired),
    ledger: () => structuredClone(ledger),
    setDesired(next) {
      desired = { ...defaultDesired(clock), ...next, updatedAt: clock() };
      desiredDirty = true;
      return saveDesired();
    },
    patchLedger(patch) {
      ledger = { ...ledger, ...patch };
      ledgerDirty = true;
      return saveLedger();
    },
    audit(entry) {
      ledger.audit.push({ at: clock(), ...entry });
      ledger.audit = ledger.audit.slice(-MAX_AUDIT);
      ledgerDirty = true;
      return saveLedger();
    },
    async flush() {
      if (desiredDirty) await saveDesired();
      if (ledgerDirty) await saveLedger();
    },
  };
}
