/**
 * Runtime contract loader for the ransomware protection business backend.
 *
 * The framework projects `/run/rivetin/runtime/backend-contract.json` (workload-backend-v1
 * §3.2) and injects the workload identity through env. This module validates both and
 * reads the mTLS material; it never logs credential values or contract secrets.
 */
import { readFile } from 'node:fs/promises';
import path from 'node:path';

export const CONTRACT_PATH = '/run/rivetin/runtime/backend-contract.json';
export const TLS_DIRECTORY = '/run/rivetin/tls';
export const DATA_DIRECTORY = '/data';
export const CLOUDTOWER_DIRECTORY = '/run/rivetin/cloudtower';
export const WEBHOOK_DIRECTORY = '/run/rivetin/webhook';
export const CAPABILITY = 'ransomware.protection';
export const INTERFACE_VERSION = 1;
export const WORKLOAD_ID = 'rivetin-ransomware-protection';

const digestPattern = /^[a-f0-9]{64}$/;
const dataStorePattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const instancePattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const originPattern = /^https:\/\/[a-z0-9][a-z0-9.-]*\.[a-z0-9][a-z0-9.-]*(?::\d{1,5})?$/;

export class BackendConfigError extends Error {
  constructor(code, stage = 'runtime-config') {
    super(code);
    this.code = code;
    this.stage = stage;
  }
}

const fail = (code, stage) => { throw new BackendConfigError(code, stage); };

function object(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function positive(value) {
  return Number.isSafeInteger(value) && value > 0;
}

export function validateBackendContract(value) {
  if (!object(value)) fail('RANSOM_RUNTIME_CONTRACT_INVALID');
  const keys = ['schemaVersion', 'workloadId', 'capability', 'interfaceVersion', 'frameworkOrigin', 'frameworkPin', 'dataStoreId', 'limits'];
  if (Object.keys(value).some(key => !keys.includes(key))) fail('RANSOM_RUNTIME_CONTRACT_INVALID');
  if (value.schemaVersion !== 1 || value.workloadId !== WORKLOAD_ID || value.capability !== CAPABILITY ||
      value.interfaceVersion !== INTERFACE_VERSION || typeof value.frameworkOrigin !== 'string' ||
      !originPattern.test(value.frameworkOrigin) || typeof value.frameworkPin !== 'string' ||
      !digestPattern.test(value.frameworkPin) || typeof value.dataStoreId !== 'string' ||
      !dataStorePattern.test(value.dataStoreId) || !object(value.limits) ||
      !positive(value.limits.requestBytes) || !positive(value.limits.responseBytes)) {
    fail('RANSOM_RUNTIME_CONTRACT_INVALID');
  }
  return Object.freeze({
    schemaVersion: 1, workloadId: WORKLOAD_ID, capability: CAPABILITY, interfaceVersion: INTERFACE_VERSION,
    frameworkOrigin: value.frameworkOrigin, frameworkPin: value.frameworkPin, dataStoreId: value.dataStoreId,
    limits: Object.freeze({ requestBytes: value.limits.requestBytes, responseBytes: value.limits.responseBytes }),
  });
}

export async function loadBackendContract(file = process.env.RIVETIN_BACKEND_CONTRACT || CONTRACT_PATH) {
  let bytes;
  try { bytes = await readFile(file); }
  catch { fail('RANSOM_RUNTIME_CONTRACT_MISSING'); }
  if (bytes.length > 65536) fail('RANSOM_RUNTIME_CONTRACT_INVALID');
  let value;
  try { value = JSON.parse(bytes.toString('utf8')); } catch { fail('RANSOM_RUNTIME_CONTRACT_INVALID'); }
  return validateBackendContract(value);
}

export function runtimeIdentity(env = process.env) {
  const instanceId = env.RIVETIN_INSTANCE_ID;
  const generation = env.RIVETIN_GENERATION;
  const podUid = env.RIVETIN_POD_UID;
  if (typeof instanceId !== 'string' || !instancePattern.test(instanceId)) fail('RANSOM_RUNTIME_IDENTITY_REQUIRED', 'identity');
  if (typeof generation !== 'string' || !/^[1-9][0-9]{0,14}$/.test(generation)) fail('RANSOM_RUNTIME_IDENTITY_REQUIRED', 'identity');
  if (typeof podUid !== 'string' || !/^[A-Za-z0-9-]{1,128}$/.test(podUid)) fail('RANSOM_RUNTIME_IDENTITY_REQUIRED', 'identity');
  return Object.freeze({ transportVersion: 1, instanceId, generation: Number(generation), podUid });
}

async function readTlsFile(file) {
  let bytes;
  try { bytes = await readFile(file); }
  catch { fail('RANSOM_RUNTIME_TLS_UNAVAILABLE', 'tls'); }
  if (!bytes.length || bytes.length > 65536) fail('RANSOM_RUNTIME_TLS_UNAVAILABLE', 'tls');
  return bytes;
}

export async function loadTlsMaterial(directory = process.env.RIVETIN_TLS_DIRECTORY || TLS_DIRECTORY) {
  const root = path.resolve(directory);
  const [ca, cert, key] = await Promise.all(['ca.crt', 'tls.crt', 'tls.key'].map(name => readTlsFile(path.join(root, name))));
  return { ca, cert, key };
}

export function dataDirectory(env = process.env) {
  const value = env.RIVETIN_DATA === undefined ? DATA_DIRECTORY : env.RIVETIN_DATA;
  if (typeof value !== 'string' || !path.isAbsolute(value)) fail('RANSOM_RUNTIME_DATA_INVALID', 'data');
  return value;
}
