"""Ransomware protection backend bootstrap (Runtime payload root entrypoint).

Draft bootstrap for the `rivetin-ransomware-protection` backend workload. The
framework side contract `framework/docs/workload-backend-v1.md` is still being
prepared by FW-Core; this wrapper only validates the Runtime-injected identity and
execs the Node draft backend located under `backend/`.

After the contract lands this entrypoint is replaced by the workload-v1 runtime:
inner mTLS server on 9443 (`/run/rivetin/tls`), local probes on 18081, permit
polling and method dispatch (see PLAN `.local/ransomware-bridge-r1/PLAN.md` §A6).
The draft backend does not serve that contract yet and must not be treated as an
installed capability.

Never prints credentials, tokens or request bodies.
"""

import json
import os
import re
import shutil
import sys
from pathlib import Path

IDENTITY_ENV = ('RIVETIN_INSTANCE_ID', 'RIVETIN_GENERATION', 'RIVETIN_POD_UID')
SAFE_INSTANCE = re.compile(r'[A-Za-z0-9-]{1,128}')
SAFE_GENERATION = re.compile(r'[1-9][0-9]{0,14}')


def package_version(root):
    try:
        return json.loads((root / 'metadata').read_bytes())['version']
    except (OSError, ValueError, KeyError, TypeError):
        return None


def runtime_identity():
    identity = {name: os.environ.get(name, '') for name in IDENTITY_ENV}
    if (not SAFE_INSTANCE.fullmatch(identity['RIVETIN_INSTANCE_ID'])
            or not SAFE_GENERATION.fullmatch(identity['RIVETIN_GENERATION'])
            or not SAFE_INSTANCE.fullmatch(identity['RIVETIN_POD_UID'])):
        raise ValueError('RANSOM_RUNTIME_IDENTITY_REQUIRED')
    return identity


def node_executable():
    fixed = Path('/usr/local/bin/node')
    if fixed.is_file():
        return str(fixed)
    found = shutil.which('node')
    if found:
        return found
    raise OSError('RANSOM_RUNTIME_NODE_MISSING')


def main():
    root = Path(__file__).resolve().parent
    identity = runtime_identity()
    backend = root / 'backend' / 'main.mjs'
    if not backend.is_file():
        raise OSError('RANSOM_RUNTIME_BACKEND_MISSING')
    node = node_executable()
    data = os.environ.get('RIVETIN_DATA') or '/data'
    environment = {
        'PATH': '/usr/local/bin:/usr/bin:/bin',
        'RIVETIN_WORKLOAD_ID': identity['RIVETIN_INSTANCE_ID'],
        'RIVETIN_INSTANCE_ID': identity['RIVETIN_INSTANCE_ID'],
        'RIVETIN_GENERATION': identity['RIVETIN_GENERATION'],
        'RIVETIN_POD_UID': identity['RIVETIN_POD_UID'],
        'RIVETIN_DATA': data,
    }
    os.execve(node, [node, str(backend)], environment)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError) as error:
        code = error.args[0] if error.args else 'RANSOM_RUNTIME_START_FAILED'
        print(json.dumps({
            'level': 'ERROR', 'component': 'rivetin-ransomware-protection',
            'version': package_version(Path(__file__).resolve().parent),
            'event': 'startup-failed', 'stage': 'runtime-entrypoint',
            'errorCode': code if isinstance(code, str) and code.startswith('RANSOM_') else 'RANSOM_RUNTIME_START_FAILED',
        }), file=sys.stderr)
        raise SystemExit(78) from None
