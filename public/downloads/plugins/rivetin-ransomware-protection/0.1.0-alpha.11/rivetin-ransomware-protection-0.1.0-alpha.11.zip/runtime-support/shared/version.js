export const FRAMEWORK_VERSION = '0.3.1-alpha.19';
// Future releases add only reviewed predecessors whose settings can be adopted.
export const FRAMEWORK_METADATA_PREDECESSORS = Object.freeze(['0.2.18-alpha.2', '0.3.0-alpha.1', '0.3.0-alpha.2', '0.3.0-alpha.3', '0.3.0-alpha.4', '0.3.1-alpha.5', '0.3.1-alpha.6', '0.3.1-alpha.7', '0.3.1-alpha.8', '0.3.1-alpha.10', '0.3.1-alpha.11', '0.3.1-alpha.12', '0.3.1-alpha.13', '0.3.1-alpha.14', '0.3.1-alpha.15', '0.3.1-alpha.16', '0.3.1-alpha.17', '0.3.1-alpha.18']);
