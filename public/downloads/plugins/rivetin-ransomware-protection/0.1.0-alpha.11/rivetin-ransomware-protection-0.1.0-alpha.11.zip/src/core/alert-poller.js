/**
 * `get-alerts` polling fallback for the event channel.
 *
 * Webhook delivery is the primary channel in the design, but its payload
 * contract is still unknown and a dropped delivery must not lose the incident.
 * This module turns `client.getAlerts(...)` into normalized, de-duplicated
 * alerts with a monotonic cursor. It owns no timers: the caller (backend
 * scheduler / demo control) drives `pollOnce`.
 */

import { dedupeAlerts, normalizeAlert } from './events.js';

function fail(code, details) {
  const error = new Error(code);
  if (details !== undefined) error.details = details;
  return error;
}

function nowIso(clock) {
  if (typeof clock === 'function') {
    const value = clock();
    if (value instanceof Date && Number.isFinite(value.getTime())) return value.toISOString();
    if (typeof value === 'string' && Number.isFinite(Date.parse(value))) return new Date(value).toISOString();
  }
  return new Date().toISOString();
}

function compareTime(left, right) {
  const leftTime = Date.parse(left);
  const rightTime = Date.parse(right);
  if (!Number.isFinite(leftTime) || !Number.isFinite(rightTime)) return 0;
  return leftTime === rightTime ? 0 : leftTime < rightTime ? -1 : 1;
}

/**
 * @param {{
 *   client: {getAlerts: (filter?: object) => Promise<unknown>},
 *   clock?: () => unknown,
 *   pageSize?: number,
 *   windowMinutes?: number,
 * }} options
 */
export function createAlertPoller(options = {}) {
  const { client, clock, pageSize = 100, windowMinutes = 5 } = options;
  if (!client || typeof client.getAlerts !== 'function') throw fail('POLLER_INVALID_CLIENT');
  if (!Number.isInteger(pageSize) || pageSize < 1 || pageSize > 500) throw fail('POLLER_INVALID_PAGE_SIZE');
  if (!Number.isInteger(windowMinutes) || windowMinutes < 1) throw fail('POLLER_INVALID_WINDOW');

  let cursor = null;
  let lastPollAt = null;
  let inFlight = false;
  const delivered = new Set();

  function state() {
    return { cursor, lastPollAt, delivered: delivered.size };
  }

  /**
   * Poll once. New alerts only: alerts seen in any previous poll are filtered
   * out by `incidentKey`, and the same-VM window is applied inside the batch.
   */
  async function pollOnce(input = {}) {
    if (inFlight) throw fail('POLL_IN_PROGRESS');
    inFlight = true;
    try {
      const since = input.since ?? cursor;
      const where = {};
      if (typeof since === 'string' && since.length > 0) where.create_time_gt = since;
      else where.ended = false;
      const first = input.first ?? pageSize;
      const rawAlerts = await client.getAlerts({
        where,
        first,
        orderBy: input.orderBy ?? 'create_time_ASC',
      });
      if (!Array.isArray(rawAlerts)) throw fail('POLLER_INVALID_RESPONSE');
      const polledAt = nowIso(clock);

      const normalized = [];
      const errors = [];
      for (const raw of rawAlerts) {
        try {
          const event = normalizeAlert(raw, { clock: () => polledAt });
          if (!delivered.has(event.incidentKey)) normalized.push(event);
        } catch (error) {
          errors.push({
            errorCode: typeof error?.message === 'string' && /^[A-Z][A-Z0-9_]+$/.test(error.message)
              ? error.message
              : 'ALERT_UNNORMALIZABLE',
          });
        }
      }

      const events = dedupeAlerts(normalized, { windowMinutes });
      for (const event of events) delivered.add(event.incidentKey);
      while (delivered.size > 2048) {
        const oldest = delivered.values().next().value;
        delivered.delete(oldest);
      }

      let nextCursor = cursor;
      for (const event of events) {
        if (nextCursor === null || compareTime(event.createdAt, nextCursor) > 0) nextCursor = event.createdAt;
      }
      cursor = nextCursor;
      lastPollAt = polledAt;
      return {
        events,
        errors,
        received: rawAlerts.length,
        cursor: nextCursor,
        hasMore: rawAlerts.length >= first,
        polledAt,
      };
    } finally {
      inFlight = false;
    }
  }

  function reset() {
    cursor = null;
    lastPollAt = null;
    delivered.clear();
  }

  function isPolling() {
    return inFlight;
  }

  return Object.freeze({ pollOnce, reset, state, isPolling });
}
