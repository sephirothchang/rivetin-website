/**
 * CloudTower login / token session helpers for the future backend adapter.
 *
 * The measured environment uses `POST /v2/api/login` with
 * `{username, password, source:"LOCAL"}` and sends the returned token as the
 * `Authorization` header for both REST and GraphQL. The browser plugin must not
 * hold credentials; these helpers are for a future trusted backend workload
 * only and never log or persist the password/token.
 *
 * Pure module: fetch is injected for tests. No timers.
 */

const LOGIN_PATH = '/v2/api/login';
const DEFAULT_SOURCE = 'LOCAL';

function fail(code, details) {
  const error = new Error(code);
  if (details !== undefined) error.details = details;
  return error;
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function normalizeSource(source) {
  if (source === undefined || source === null) return DEFAULT_SOURCE;
  if (!['LOCAL', 'LDAP', 'SSO', 'AUTHN'].includes(source)) throw fail('LOGIN_INVALID_SOURCE');
  return source;
}

/**
 * Build the measured login body; validates credential shape only.
 * @param {{username: string, password: string, source?: string}} credentials
 */
export function buildLoginBody(credentials = {}) {
  const { username, password, source } = credentials;
  if (!isNonEmptyString(username)) throw fail('LOGIN_INVALID_USERNAME');
  if (!isNonEmptyString(password)) throw fail('LOGIN_INVALID_PASSWORD');
  return { username: username.trim(), password, source: normalizeSource(source) };
}

function readToken(response) {
  if (!response || typeof response !== 'object') throw fail('LOGIN_INVALID_RESPONSE');
  const token = response?.data?.token ?? response?.token;
  if (!isNonEmptyString(token)) throw fail('LOGIN_INVALID_RESPONSE');
  return token.trim();
}

/**
 * Log in once through the injected transport.
 * @param {{transport: (request: {method: string, path: string, body: unknown}) => Promise<unknown>}} options
 */
export async function loginWithPassword({ transport, credentials } = {}) {
  if (typeof transport !== 'function') throw fail('LOGIN_INVALID_TRANSPORT');
  const body = buildLoginBody(credentials);
  const response = await transport({ method: 'POST', path: LOGIN_PATH, body });
  return readToken(response);
}

/**
 * Lazily log in and cache the token. `invalidate()` forces a fresh login.
 * @param {{
 *   transport: (request: {method: string, path: string, body: unknown}) => Promise<unknown>,
 *   credentials: {username: string, password: string, source?: string},
 * }} options
 */
export function createTokenProvider({ transport, credentials } = {}) {
  if (typeof transport !== 'function') throw fail('LOGIN_INVALID_TRANSPORT');
  buildLoginBody(credentials);
  let token = null;
  let request = null;

  async function getAuthorization() {
    if (token !== null) return token;
    if (request === null) {
      request = loginWithPassword({ transport, credentials }).finally(() => { request = null; });
    }
    token = await request;
    return token;
  }

  function invalidate() {
    token = null;
  }

  function issueCount() {
    return token === null ? 0 : 1;
  }

  return Object.freeze({ getAuthorization, invalidate, issueCount });
}

function isResponse(value) {
  return value && typeof value === 'object' && typeof value.status === 'number';
}

/**
 * Convenience session transport for a controlled backend or local smoke test:
 * logs in lazily, sends `Authorization`, retries exactly once after a 401, and
 * never stores credentials outside this closure.
 *
 * @param {{
 *   baseUrl: string,
 *   credentials: {username: string, password: string, source?: string},
 *   fetch?: typeof fetch,
 * }} options
 */
export function createSessionTransport({ baseUrl, credentials, fetch: fetchOption } = {}) {
  if (!isNonEmptyString(baseUrl)) throw fail('LOGIN_INVALID_BASE_URL');
  let base;
  try {
    base = new URL(baseUrl).toString().replace(/\/+$/, '');
  } catch {
    throw fail('LOGIN_INVALID_BASE_URL');
  }
  const body = buildLoginBody(credentials);
  let fetchImpl = fetchOption;
  let token = null;
  let loginRequest = null;

  function resolveFetch() {
    fetchImpl = fetchImpl ?? globalThis.fetch;
    if (typeof fetchImpl !== 'function') throw fail('LOGIN_FETCH_UNAVAILABLE');
    return fetchImpl;
  }

  async function login() {
    if (token !== null) return token;
    if (loginRequest === null) {
      loginRequest = (async () => {
        const response = await resolveFetch()(`${base}${LOGIN_PATH}`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(body),
        });
        if (!isResponse(response) || response.ok !== true) {
          throw fail(`LOGIN_HTTP_${isResponse(response) ? response.status : 'UNKNOWN'}`);
        }
        const payload = await response.json();
        token = readToken(payload);
        return token;
      })().finally(() => { loginRequest = null; });
    }
    return loginRequest;
  }

  async function send(request, authorization) {
    const headers = { 'content-type': 'application/json' };
    if (authorization) headers.Authorization = authorization;
    const response = await resolveFetch()(`${base}${request.path}`, {
      method: request.method ?? 'POST',
      headers,
      body: request.body === undefined ? undefined : JSON.stringify(request.body),
    });
    if (!isResponse(response)) throw fail('LOGIN_INVALID_RESPONSE');
    return response;
  }

  async function transport(request = {}) {
    if (!isNonEmptyString(request.path) || !request.path.startsWith('/')) throw fail('LOGIN_INVALID_PATH');
    let response = await send(request, await login());
    if (response.status === 401) {
      token = null;
      response = await send(request, await login());
    }
    if (response.ok !== true) throw fail(`CLOUDTOWER_HTTP_${response.status}`);
    return response.json();
  }

  function invalidate() {
    token = null;
  }

  return Object.freeze({ transport, invalidate });
}
