/**
 * CloudTower API client for the ransomware protection plugin.
 *
 * Transport is injected so the module stays testable and never owns a network
 * socket itself:
 *
 *   transport: async ({ method, path, body }) => parsedJson
 *   path: '/v2/api/<operation>' for REST, '/api' for GraphQL.
 *
 * The measured interface facts are baked in:
 *   - custom alert rules / trigger catalog use the CloudTower UI GraphQL API
 *     (`POST /api`), not the public REST OpenAPI;
 *   - snapshots / rebuild / tasks / alerts / snapshot plans use REST `/v2/api`;
 *   - async REST operations return `WithTask<T>[] = [{task_id, data}]` and the
 *     measured task terminal state is spelled `SUCCESSED` (not SUCCEEDED).
 *
 * The client only builds requests and validates response shapes. It never
 * stores a token, never reads cookies and never polls: callers poll `getTasks`
 * themselves (no timers/I/O in core).
 *
 * Pure module: no I/O, no timers, no environment probing.
 */

const REST_PREFIX = '/v2/api';
const GRAPHQL_PATH = '/api';

/** TaskStatus values from the public CloudTower schema (measured spelling included). */
export const TASK_STATUS = Object.freeze({
  PENDING: 'PENDING',
  EXECUTING: 'EXECUTING',
  PAUSED: 'PAUSED',
  FAILED: 'FAILED',
  SUCCESSED: 'SUCCESSED',
});

/** Terminal task states. CloudTower spells success `SUCCESSED`. */
export const TASK_TERMINAL_STATUSES = Object.freeze(['SUCCESSED', 'FAILED']);

const RULE_FIELDS = `id name target_type
  targets { whitelist blacklist exclude_system_service_vm }
  groups { for severity triggers { name operator value } }
  resolve_method disabled sync_info { sync_status task_id }
  description alert_description create_time update_time`;

const LIST_ALERT_RULES_QUERY = `query customAlertRules($filter: CustomAlertRulesListFilter, $order_by: String, $page_size: Int, $page_token: Int) {
  customAlertRules(filter: $filter, order_by: $order_by, page_size: $page_size, page_token: $page_token) {
    uni_alerting_rules { ${RULE_FIELDS} }
    next_page_token
    total
  }
}`;

const TRIGGER_CATALOG_QUERY = `query getCustomAlertTrigger {
  customAlertTriggers { name type operators unit }
}`;

const CREATE_ALERT_RULE_MUTATION = `mutation createCustomAlertRule($data: CustomAlertRuleCreateInput!) {
  createCustomAlertRule(data: $data) { ${RULE_FIELDS} }
}`;

const UPDATE_ALERT_RULE_MUTATION = `mutation updateCustomAlertRule($id: String!, $data: CustomAlertRuleCreateInput!) {
  updateCustomAlertRule(id: $id, data: $data) { ${RULE_FIELDS} }
}`;

const DELETE_ALERT_RULE_MUTATION = `mutation deleteCustomAlertRule($id: String!) {
  deleteCustomAlertRule(id: $id) { id }
}`;

function fail(code, details) {
  const error = new Error(code);
  error.code = code;
  if (details !== undefined) {
    error.details = details;
  }
  return error;
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function toNumberOrNull(value) {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function toStringOrNull(value) {
  return typeof value === 'string' && value.trim().length > 0 ? value.trim() : null;
}

function toPositiveInt(value, fallback) {
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

function toNonNegativeInt(value, fallback) {
  return Number.isInteger(value) && value >= 0 ? value : fallback;
}

function summarizeGraphQLError(error) {
  if (!isRecord(error)) {
    return { message: String(error) };
  }
  const summary = {};
  if (typeof error.message === 'string') {
    summary.message = error.message;
  }
  if (Array.isArray(error.path)) {
    summary.path = error.path;
  }
  return summary;
}

function normalizeRestOperation(operation) {
  if (!isNonEmptyString(operation)) {
    throw fail('CLOUDTOWER_INVALID_OPERATION');
  }
  let normalized = operation.trim().replace(/^\/+/, '');
  if (normalized.startsWith('v2/api/')) {
    normalized = normalized.slice('v2/api/'.length);
  }
  if (!/^[a-z0-9][a-z0-9._-]*$/i.test(normalized)) {
    throw fail('CLOUDTOWER_INVALID_OPERATION');
  }
  return normalized;
}

function toEntityArray(response, operation) {
  if (Array.isArray(response)) {
    return response;
  }
  if (isRecord(response)) {
    if (Array.isArray(response.data)) {
      return response.data;
    }
    if (Array.isArray(response.items)) {
      return response.items;
    }
  }
  throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation });
}

function parseWithTaskList(response, operation) {
  const items = toEntityArray(response, operation);
  if (items.length === 0) {
    throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation });
  }
  return items.map((item) => {
    if (!isRecord(item)) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation });
    }
    const hasTaskId = Object.prototype.hasOwnProperty.call(item, 'task_id');
    if (!hasTaskId && !isRecord(item.data)) {
      // Tolerate a bare resource instead of a WithTask envelope.
      const resourceId = toStringOrNull(item.id);
      if (!resourceId) {
        throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation });
      }
      return { taskId: null, resourceId, resource: item };
    }

    const rawTaskId = item.task_id;
    if (rawTaskId !== null && rawTaskId !== undefined && typeof rawTaskId !== 'string') {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation });
    }
    const taskId = toStringOrNull(rawTaskId);
    const resource = isRecord(item.data) ? item.data : null;
    const resourceId = resource ? toStringOrNull(resource.id) : null;
    if (taskId === null && resourceId === null) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation });
    }
    return { taskId, resourceId, resource };
  });
}

function assertCreateRuleInput(input) {
  if (!isRecord(input)) {
    throw fail('CLOUDTOWER_INVALID_INPUT', { operation: 'createCustomAlertRule' });
  }
  if (!isNonEmptyString(input.name) || input.name.trim().length > 255) {
    throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'name' });
  }
  if (typeof input.exclude_system_service_vm !== 'boolean') {
    throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'exclude_system_service_vm' });
  }
  if (!isRecord(input.targets)) {
    throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'targets' });
  }
  const activeTargets = ['vm', 'vmfolder', 'cluster'].filter(
    (key) => Array.isArray(input.targets[key]) && input.targets[key].length > 0,
  );
  if (activeTargets.length !== 1) {
    throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'targets' });
  }
  if (!Array.isArray(input.groups) || input.groups.length === 0) {
    throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'groups' });
  }
  if (typeof input.disabled !== 'boolean') {
    throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'disabled' });
  }
  for (const forbidden of ['target_type', 'resolve_method']) {
    if (forbidden in input) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { field: forbidden });
    }
  }
}

/**
 * Create a CloudTower client bound to an injected transport.
 *
 * @param {{transport: (request: {method: string, path: string, body?: unknown}) => Promise<unknown>}} options
 * @returns {{
 *   rest: (operation: string, body?: unknown) => Promise<unknown>,
 *   graphql: (query: string, variables?: object) => Promise<object>,
 *   createAlertRule: (input: object) => Promise<object>,
 *   deleteAlertRule: (ruleId: string) => Promise<object>,
 *   listAlertRules: (options?: object) => Promise<{rules: Array<object>, total: number|null, nextPageToken: string|null}>,
 *   getAlertTriggerCatalog: () => Promise<Array<object>>,
 *   createVmSnapshot: (input: {vmId: string, name: string}) => Promise<{taskId: string|null, snapshotId: string|null, snapshot: object|null}>,
 *   getVmSnapshots: (vmId: string) => Promise<Array<object>>,
 *   rebuildVmFromSnapshot: (input: {name: string, snapshotId: string, clusterId: string}) => Promise<{taskId: string|null, vmId: string|null, vm: object|null}>,
 *   getTasks: (taskIds: string|Array<string>) => Promise<Array<object>>,
 *   getAlerts: (filter?: object) => Promise<Array<object>>,
 *   getSnapshotPlans: (options?: {first?: number, where?: object}) => Promise<Array<object>>,
 * }}
 */
export function createCloudTowerClient(options = {}) {
  const { transport } = options ?? {};
  if (typeof transport !== 'function') {
    throw fail('CLOUDTOWER_INVALID_TRANSPORT');
  }

  async function callTransport(request) {
    let response;
    try {
      response = await transport(request);
    } catch (error) {
      throw error;
    }
    if (response === undefined || response === null) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { path: request.path });
    }
    return response;
  }

  async function rest(operation, body = {}) {
    const normalizedOperation = normalizeRestOperation(operation);
    const response = await callTransport({
      method: 'POST',
      path: `${REST_PREFIX}/${normalizedOperation}`,
      body,
    });
    if (!isRecord(response) && !Array.isArray(response)) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: normalizedOperation });
    }
    return response;
  }

  async function graphql(query, variables = {}) {
    if (!isNonEmptyString(query)) {
      throw fail('CLOUDTOWER_INVALID_QUERY');
    }
    if (variables !== null && variables !== undefined && !isRecord(variables)) {
      throw fail('CLOUDTOWER_INVALID_VARIABLES');
    }
    const response = await callTransport({
      method: 'POST',
      path: GRAPHQL_PATH,
      body: { query, variables: variables ?? {} },
    });
    if (!isRecord(response)) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'graphql' });
    }
    if (Array.isArray(response.errors) && response.errors.length > 0) {
      throw fail('CLOUDTOWER_GRAPHQL_ERROR', {
        errors: response.errors.map(summarizeGraphQLError),
      });
    }
    if (!isRecord(response.data)) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'graphql' });
    }
    return response.data;
  }

  async function createAlertRule(input) {
    assertCreateRuleInput(input);
    const data = await graphql(CREATE_ALERT_RULE_MUTATION, { data: input });
    const rule = data.createCustomAlertRule;
    if (!isRecord(rule) || !isNonEmptyString(rule.id)) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'createCustomAlertRule' });
    }
    return rule;
  }

  async function updateAlertRule(ruleId, input) {
    if (!isNonEmptyString(ruleId)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'ruleId' });
    }
    assertCreateRuleInput(input);
    const data = await graphql(UPDATE_ALERT_RULE_MUTATION, { id: ruleId.trim(), data: input });
    const rule = data.updateCustomAlertRule;
    if (!isRecord(rule) || !isNonEmptyString(rule.id)) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'updateCustomAlertRule' });
    }
    return rule;
  }

  async function deleteAlertRule(ruleId) {
    if (!isNonEmptyString(ruleId)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'ruleId' });
    }
    const data = await graphql(DELETE_ALERT_RULE_MUTATION, { id: ruleId.trim() });
    const result = data.deleteCustomAlertRule;
    if (!isRecord(result)) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'deleteCustomAlertRule' });
    }
    return result;
  }

  async function listAlertRules(options = {}) {
    if (options === null || options === undefined) {
      options = {};
    }
    if (!isRecord(options)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'options' });
    }
    const variables = {
      page_size: toPositiveInt(options.pageSize ?? options.page_size, 100),
      page_token: toNonNegativeInt(options.pageToken ?? options.page_token, 0),
    };
    const filter = options.filter;
    if (isRecord(filter)) {
      variables.filter = filter;
    }
    const orderBy = options.orderBy ?? options.order_by;
    if (typeof orderBy === 'string' && orderBy.length > 0) {
      variables.order_by = orderBy;
    }

    const data = await graphql(LIST_ALERT_RULES_QUERY, variables);
    const connection = data.customAlertRules;
    if (!isRecord(connection) || !Array.isArray(connection.uni_alerting_rules)) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'customAlertRules' });
    }
    const rules = connection.uni_alerting_rules.map((rule) => {
      if (!isRecord(rule)) {
        throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'customAlertRules' });
      }
      return rule;
    });
    return {
      rules,
      total: toNumberOrNull(connection.total),
      nextPageToken: toStringOrNull(connection.next_page_token),
    };
  }

  async function getAlertTriggerCatalog() {
    const data = await graphql(TRIGGER_CATALOG_QUERY);
    const catalog =
      data.customAlertTriggers ??
      data.getCustomAlertTrigger ??
      data.alertTriggers ??
      data.triggers;
    if (!Array.isArray(catalog)) {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'getCustomAlertTrigger' });
    }
    return catalog.map((entry) => {
      if (!isRecord(entry) || !isNonEmptyString(entry.name)) {
        throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'getCustomAlertTrigger' });
      }
      return {
        name: entry.name.trim(),
        type: toStringOrNull(entry.type),
        unit: toStringOrNull(entry.unit),
        operators: Array.isArray(entry.operators)
          ? entry.operators.filter((operator) => typeof operator === 'string')
          : [],
      };
    });
  }

  async function createVmSnapshot({ vmId, name } = {}) {
    if (!isNonEmptyString(vmId) || !isNonEmptyString(name)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { operation: 'create-vm-snapshot' });
    }
    const response = await rest('create-vm-snapshot', {
      data: [
        {
          vm_id: vmId.trim(),
          name: name.trim(),
          consistent_type: 'CRASH_CONSISTENT',
        },
      ],
    });
    const [first] = parseWithTaskList(response, 'create-vm-snapshot');
    return { taskId: first.taskId, snapshotId: first.resourceId, snapshot: first.resource };
  }

  async function getVmSnapshots(vmId) {
    if (!isNonEmptyString(vmId)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'vmId' });
    }
    const response = await rest('get-vm-snapshots', {
      where: { vm: { id: vmId.trim() } },
      first: 20,
      orderBy: 'local_created_at_DESC',
    });
    return toEntityArray(response, 'get-vm-snapshots');
  }

  async function rebuildVmFromSnapshot({ name, snapshotId, clusterId } = {}) {
    if (!isNonEmptyString(name) || !isNonEmptyString(snapshotId) || !isNonEmptyString(clusterId)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { operation: 'rebuild-vm-from-snapshot' });
    }
    const response = await rest('rebuild-vm-from-snapshot', [
      {
        name: name.trim(),
        rebuild_from_snapshot_id: snapshotId.trim(),
        cluster_id: clusterId.trim(),
        status: 'STOPPED',
        ha: false,
      },
    ]);
    const [first] = parseWithTaskList(response, 'rebuild-vm-from-snapshot');
    return { taskId: first.taskId, vmId: first.resourceId, vm: first.resource };
  }

  async function getVms(options = {}) {
    if (options === null || options === undefined) options = {};
    if (!isRecord(options)) throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'options' });
    const body = { first: toPositiveInt(options.first, 10) };
    if (isRecord(options.where)) body.where = options.where;
    const response = await rest('get-vms', body);
    return toEntityArray(response, 'get-vms');
  }

  async function deleteVm(vmId) {
    if (!isNonEmptyString(vmId)) throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'vmId' });
    const response = await rest('delete-vm', { where: { id: vmId.trim() } });
    const [first] = parseWithTaskList(response, 'delete-vm');
    return { taskId: first.taskId, vmId: first.resourceId ?? vmId.trim(), vm: first.resource };
  }

  async function deleteVmSnapshot(snapshotId) {
    if (!isNonEmptyString(snapshotId)) throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'snapshotId' });
    const response = await rest('delete-vm-snapshot', { where: { id: snapshotId.trim() } });
    const [first] = parseWithTaskList(response, 'delete-vm-snapshot');
    return { taskId: first.taskId, snapshotId: first.resourceId ?? snapshotId.trim(), snapshot: first.resource };
  }

  async function getTasks(taskIds) {
    const ids = Array.isArray(taskIds)
      ? taskIds
      : typeof taskIds === 'string'
        ? [taskIds]
        : null;
    if (!ids) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'taskIds' });
    }
    const normalizedIds = ids.map((taskId) => {
      if (!isNonEmptyString(taskId)) {
        throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'taskIds' });
      }
      return taskId.trim();
    });
    if (normalizedIds.length === 0) {
      return [];
    }
    const response = await rest('get-tasks', { where: { id_in: normalizedIds } });
    const tasks = toEntityArray(response, 'get-tasks');
    return tasks.map((task) => {
      if (!isRecord(task) || typeof task.status !== 'string') {
        throw fail('CLOUDTOWER_INVALID_RESPONSE', { operation: 'get-tasks' });
      }
      return task;
    });
  }

  async function getAlerts(filter = {}) {
    if (filter === null || filter === undefined) {
      filter = {};
    }
    if (!isRecord(filter)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'filter' });
    }
    const envelopeKeys = ['where', 'first', 'last', 'skip', 'after', 'before', 'orderBy'];
    const body = envelopeKeys.some((key) => key in filter)
      ? { ...filter }
      : { where: filter, first: 100 };
    const response = await rest('get-alerts', body);
    return toEntityArray(response, 'get-alerts');
  }

  async function createSnapshotPlan(input) {
    if (!isRecord(input) || !isNonEmptyString(input.name) || !isNonEmptyString(input.cluster_id) ||
        !Array.isArray(input.vm_ids) || input.vm_ids.length === 0 || !isNonEmptyString(input.execute_plan_type) ||
        !Array.isArray(input.execute_intervals) || input.execute_intervals.length === 0) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { operation: 'create-snapshot-plan' });
    }
    const response = await rest('create-snapshot-plan', input);
    const [first] = parseWithTaskList(response, 'create-snapshot-plan');
    return { taskId: first.taskId, planId: first.resourceId, plan: first.resource };
  }

  async function updateSnapshotPlan(where, data) {
    if (!isRecord(where) || !isNonEmptyString(where.id) || !isRecord(data)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { operation: 'update-snapshot-plan' });
    }
    const response = await rest('update-snapshot-plan', { where: { id: where.id.trim() }, data });
    const [first] = parseWithTaskList(response, 'update-snapshot-plan');
    return { taskId: first.taskId, planId: first.resourceId ?? where.id.trim(), plan: first.resource };
  }

  async function deleteSnapshotPlan(planId) {
    if (!isNonEmptyString(planId)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'planId' });
    }
    const response = await rest('delete-snapshot-plan', { where: { id: planId.trim() } });
    const [first] = parseWithTaskList(response, 'delete-snapshot-plan');
    return { taskId: first.taskId, planId: first.resourceId ?? planId.trim() };
  }

  async function getSnapshotPlans(options = {}) {
    if (options === null || options === undefined) {
      options = {};
    }
    if (!isRecord(options)) {
      throw fail('CLOUDTOWER_INVALID_INPUT', { field: 'options' });
    }
    const body = { first: toPositiveInt(options.first, 10) };
    if (isRecord(options.where)) {
      body.where = options.where;
    }
    const response = await rest('get-snapshot-plans', body);
    return toEntityArray(response, 'get-snapshot-plans');
  }

  return Object.freeze({
    rest,
    graphql,
    createAlertRule,
    updateAlertRule,
    deleteAlertRule,
    listAlertRules,
    getAlertTriggerCatalog,
    createVmSnapshot,
    getVmSnapshots,
    rebuildVmFromSnapshot,
    getVms,
    deleteVm,
    deleteVmSnapshot,
    getTasks,
    getAlerts,
    getSnapshotPlans,
    createSnapshotPlan,
    updateSnapshotPlan,
    deleteSnapshotPlan,
  });
}

/**
 * @param {unknown} task
 * @returns {boolean} true when the task status is terminal (`SUCCESSED` / `FAILED`).
 */
export function isTaskTerminal(task) {
  return isRecord(task) && TASK_TERMINAL_STATUSES.includes(task.status);
}

/**
 * @param {unknown} task
 * @returns {boolean} true only for the measured success spelling `SUCCESSED`.
 */
export function isTaskSucceeded(task) {
  return isRecord(task) && task.status === TASK_STATUS.SUCCESSED;
}

/**
 * Create a fetch-based transport for controlled server-side / test use only.
 * The browser plugin runtime must NOT call this (no real CloudTower wiring yet).
 *
 * Authorization is resolved per request through `getAuthorization`; the token is
 * never stored, logged, or read from cookies/document.
 *
 * @param {{
 *   baseUrl: string,
 *   getAuthorization: () => (string|null|undefined|Promise<string|null|undefined>),
 *   fetch?: typeof fetch,
 * }} options
 * @returns {(request: {method?: string, path: string, body?: unknown}) => Promise<unknown>}
 */
export function createFetchTransport(options = {}) {
  const { baseUrl, getAuthorization, fetch: fetchOption } = options ?? {};
  if (!isNonEmptyString(baseUrl)) {
    throw fail('CLOUDTOWER_INVALID_BASE_URL');
  }
  let parsedBaseUrl;
  try {
    parsedBaseUrl = new URL(baseUrl);
  } catch {
    throw fail('CLOUDTOWER_INVALID_BASE_URL');
  }
  if (typeof getAuthorization !== 'function') {
    throw fail('CLOUDTOWER_INVALID_AUTHORIZATION_PROVIDER');
  }
  const base = parsedBaseUrl.toString().replace(/\/+$/, '');

  return async function fetchTransport({ method = 'POST', path, body } = {}) {
    if (!isNonEmptyString(path) || !path.startsWith('/')) {
      throw fail('CLOUDTOWER_INVALID_PATH');
    }
    const fetchImpl = fetchOption ?? globalThis.fetch;
    if (typeof fetchImpl !== 'function') {
      throw fail('CLOUDTOWER_FETCH_UNAVAILABLE');
    }

    const authorization = await getAuthorization();
    const headers = { 'content-type': 'application/json' };
    if (authorization !== null && authorization !== undefined && String(authorization).length > 0) {
      headers.Authorization = String(authorization);
    }

    const response = await fetchImpl(`${base}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });

    if (!response || typeof response.status !== 'number') {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { path });
    }
    if (response.ok !== true) {
      throw fail(`CLOUDTOWER_HTTP_${response.status}`, { status: response.status });
    }
    if (typeof response.json !== 'function') {
      throw fail('CLOUDTOWER_INVALID_RESPONSE', { path });
    }
    try {
      return await response.json();
    } catch {
      throw fail('CLOUDTOWER_INVALID_JSON');
    }
  };
}
