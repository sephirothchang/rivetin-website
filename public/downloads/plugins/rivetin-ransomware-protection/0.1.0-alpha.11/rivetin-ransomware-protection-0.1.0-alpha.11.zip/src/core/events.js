/**
 * Alert normalization and de-duplication for the ransomware protection plugin.
 *
 * Inputs come from three places and none of the webhook payload fields are
 * contractually confirmed yet, so `normalizeAlert` is a deliberately tolerant
 * adapter:
 *   1. CloudTower webhook raw body (structure unknown -> tolerant path lookup);
 *   2. REST `get-alerts` item (`{id, vms:[{id,name}], severity, message, value,
 *      threshold, create_time, ...}` from the measured REST contract);
 *   3. locally simulated alert (demo engine).
 *
 * Missing key fields (VM id and alert id) throw ALERT_UNNORMALIZABLE: the plugin
 * must never fabricate an identity for an alert. Unknown input fields are kept
 * in the caller's raw object and are not leaked into the normalized shape.
 *
 * Pure module: no I/O, no timers, no environment probing.
 */

const WRAPPER_KEYS = Object.freeze([
  'alert',
  'data',
  'payload',
  'event',
  'body',
  'result',
  'notification',
]);

const SOURCES = Object.freeze(['webhook', 'poll', 'simulated']);

const SEVERITY_ALIASES = Object.freeze({
  CRITICAL: 'CRITICAL',
  CRIT: 'CRITICAL',
  ERROR: 'CRITICAL',
  FATAL: 'CRITICAL',
  SEVERE: 'CRITICAL',
  HIGH: 'CRITICAL',
  NOTICE: 'NOTICE',
  WARNING: 'NOTICE',
  WARN: 'NOTICE',
  MEDIUM: 'NOTICE',
  INFO: 'INFO',
  INFORMATIONAL: 'INFO',
  LOW: 'INFO',
});

const DEFAULT_SEVERITY = 'NOTICE';

function fail(code, details) {
  const error = new Error(code);
  error.code = code;
  if (details !== undefined) {
    error.details = details;
  }
  return error;
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function toIdString(value) {
  if (typeof value === 'string' && value.trim().length > 0) {
    return value.trim();
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    return String(value);
  }
  return null;
}

function getPath(record, path) {
  let current = record;
  for (const segment of path.split('.')) {
    if (current === null || current === undefined) {
      return undefined;
    }
    if (!isRecord(current) && !Array.isArray(current)) {
      return undefined;
    }
    current = current[segment];
  }
  return current;
}

function collectCandidates(raw) {
  let root = raw;
  if (typeof root === 'string') {
    try {
      root = JSON.parse(root);
    } catch {
      throw fail('ALERT_UNNORMALIZABLE', { reason: 'invalid_json' });
    }
  }
  if (!isRecord(root)) {
    throw fail('ALERT_UNNORMALIZABLE', { reason: 'not_an_object' });
  }

  const candidates = [root];
  let current = root;
  for (let depth = 0; depth < 4; depth += 1) {
    const key = WRAPPER_KEYS.find((wrapperKey) => isRecord(current[wrapperKey]));
    if (!key) {
      break;
    }
    current = current[key];
    if (candidates.includes(current)) {
      break;
    }
    candidates.push(current);
  }
  return candidates;
}

function pick(candidates, paths) {
  for (const path of paths) {
    for (const candidate of candidates) {
      const value = getPath(candidate, path);
      if (value !== undefined && value !== null && value !== '') {
        return value;
      }
    }
  }
  return undefined;
}

function findRecord(candidates, keys) {
  for (const key of keys) {
    for (const candidate of candidates) {
      if (isRecord(candidate[key])) {
        return candidate[key];
      }
    }
  }
  return null;
}

function findFirstArrayRecord(candidates, keys) {
  for (const key of keys) {
    for (const candidate of candidates) {
      const value = candidate[key];
      if (Array.isArray(value) && isRecord(value[0])) {
        return value[0];
      }
    }
  }
  return null;
}

function normalizeSeverity(value) {
  if (typeof value !== 'string') {
    return DEFAULT_SEVERITY;
  }
  return SEVERITY_ALIASES[value.trim().toUpperCase()] ?? DEFAULT_SEVERITY;
}

function toFiniteNumberOrNull(value) {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === 'string' && value.trim().length > 0) {
    const parsed = Number(value.trim());
    if (Number.isFinite(parsed)) {
      return parsed;
    }
  }
  return null;
}

function toIsoTimestamp(value) {
  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? null : value.toISOString();
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    // Accept epoch seconds as well as epoch milliseconds.
    const milliseconds = value > 0 && value < 1e11 ? value * 1000 : value;
    const date = new Date(milliseconds);
    return Number.isNaN(date.getTime()) ? null : date.toISOString();
  }
  if (typeof value === 'string' && value.trim().length > 0) {
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? null : new Date(parsed).toISOString();
  }
  return null;
}

function readClockIso(clock) {
  let value;
  try {
    if (typeof clock === 'function') {
      value = clock();
    } else if (isRecord(clock) && typeof clock.now === 'function') {
      value = clock.now();
    }
  } catch {
    value = undefined;
  }
  return toIsoTimestamp(value) ?? new Date().toISOString();
}

function detectSource(raw, candidates) {
  const explicit = pick(candidates, ['source', 'eventSource', 'event_source']);
  if (typeof explicit === 'string') {
    const lowered = explicit.trim().toLowerCase();
    if (SOURCES.includes(lowered)) {
      return lowered;
    }
  }
  const rawSource = typeof raw === 'object' && raw !== null ? raw.source : undefined;
  if (typeof rawSource === 'string' && SOURCES.includes(rawSource.trim().toLowerCase())) {
    return rawSource.trim().toLowerCase();
  }
  if (
    candidates.some(
      (candidate) =>
        Array.isArray(candidate.vms) ||
        'local_create_time' in candidate ||
        'local_id' in candidate,
    )
  ) {
    return 'poll';
  }
  return 'webhook';
}

/**
 * Normalize a raw alert from a webhook body, a REST get-alerts item, or a
 * simulated alert.
 *
 * @param {unknown} raw webhook raw body (object or JSON string), get-alerts item, or simulated alert
 * @param {{clock?: (() => unknown) | {now?: () => unknown}}} [options] clock used when the raw alert has no timestamp
 * @returns {{
 *   incidentKey: string,
 *   alertId: string,
 *   vmId: string,
 *   vmName: string,
 *   severity: 'CRITICAL'|'NOTICE'|'INFO',
 *   message: string,
 *   value: number|null,
 *   threshold: number|null,
 *   createdAt: string,
 *   source: 'webhook'|'poll'|'simulated'
 * }}
 * @throws {Error} ALERT_UNNORMALIZABLE when a key field is missing or malformed
 */
export function normalizeAlert(raw, options = {}) {
  const { clock } = options ?? {};
  const candidates = collectCandidates(raw);

  const vmRecord = findRecord(candidates, ['vm', 'virtualMachine', 'virtual_machine', 'targetVm', 'target_vm']);
  const firstVm = findFirstArrayRecord(candidates, ['vms', 'virtualMachines', 'virtual_machines']);

  const vmIdRaw =
    pick(candidates, ['vmId', 'vm_id']) ??
    (vmRecord ? pick([vmRecord], ['id', 'vm_id']) : undefined) ??
    (firstVm ? pick([firstVm], ['id', 'vm_id']) : undefined);
  const vmId = toIdString(vmIdRaw);
  if (!vmId) {
    throw fail('ALERT_UNNORMALIZABLE', { missing: 'vmId' });
  }

  const alertIdRaw = pick(candidates, ['alertId', 'alert_id', 'id', 'uuid']);
  const alertId = toIdString(alertIdRaw);
  if (!alertId) {
    throw fail('ALERT_UNNORMALIZABLE', { missing: 'alertId' });
  }

  const vmNameRaw =
    pick(candidates, ['vmName', 'vm_name']) ??
    (vmRecord ? pick([vmRecord], ['name', 'vm_name']) : undefined) ??
    (firstVm ? pick([firstVm], ['name', 'vm_name']) : undefined);
  const vmName = isNonEmptyString(vmNameRaw) ? vmNameRaw.trim() : vmId;

  const severity = normalizeSeverity(
    pick(candidates, ['severity', 'alertSeverity', 'alert_severity', 'level', 'riskLevel', 'risk_level']),
  );

  const messageRaw = pick(candidates, [
    'message',
    'title',
    'alertMessage',
    'alert_message',
    'description',
    'summary',
  ]);
  const message = isNonEmptyString(messageRaw) ? messageRaw.trim() : `Alert on ${vmName}`;

  const value = toFiniteNumberOrNull(
    pick(candidates, ['value', 'metricValue', 'metric_value', 'currentValue', 'current_value']),
  );
  const threshold = toFiniteNumberOrNull(
    pick(candidates, ['threshold', 'thresholdValue', 'threshold_value']),
  );

  const createdAtRaw = pick(candidates, [
    'createdAt',
    'created_at',
    'create_time',
    'createTime',
    'local_create_time',
    'localCreateTime',
    'alert_time',
    'timestamp',
    'time',
    'occurredAt',
    'occurred_at',
  ]);
  const createdAt = toIsoTimestamp(createdAtRaw) ?? readClockIso(clock);

  const source = detectSource(raw, candidates);
  const incidentKey = `alert:${alertId}`;

  return {
    incidentKey,
    alertId,
    vmId,
    vmName,
    severity,
    message,
    value,
    threshold,
    createdAt,
    source,
  };
}

/**
 * De-duplicate normalized alerts: for every VM, keep the earliest alert inside
 * a sliding window and drop later alerts that fall within `windowMinutes` of the
 * previously kept alert for the same VM.
 *
 * @param {ReadonlyArray<object>} alerts normalized alerts (see normalizeAlert)
 * @param {{windowMinutes?: number}} [options]
 * @returns {Array<object>} de-duplicated alerts sorted by createdAt ascending
 * @throws {Error} INVALID_ALERT_LIST for a non-array input
 * @throws {Error} INVALID_DEDUPE_WINDOW for an invalid window
 * @throws {Error} ALERT_UNNORMALIZABLE for malformed alert entries
 */
export function dedupeAlerts(alerts, options = {}) {
  const { windowMinutes = 5 } = options ?? {};
  if (!Array.isArray(alerts)) {
    throw fail('INVALID_ALERT_LIST');
  }
  if (typeof windowMinutes !== 'number' || !Number.isFinite(windowMinutes) || windowMinutes < 0) {
    throw fail('INVALID_DEDUPE_WINDOW', { windowMinutes });
  }

  const windowMs = windowMinutes * 60 * 1000;
  const prepared = alerts.map((alert, index) => {
    if (!isRecord(alert)) {
      throw fail('ALERT_UNNORMALIZABLE', { reason: 'not_an_object', index });
    }
    const vmId = toIdString(alert.vmId);
    const timestamp = typeof alert.createdAt === 'string' ? Date.parse(alert.createdAt) : Number.NaN;
    if (!vmId || Number.isNaN(timestamp)) {
      throw fail('ALERT_UNNORMALIZABLE', { reason: 'bad_dedupe_fields', index });
    }
    return { alert, index, timestamp };
  });

  prepared.sort((a, b) => a.timestamp - b.timestamp || a.index - b.index);

  const lastKeptByVm = new Map();
  const result = [];
  for (const item of prepared) {
    const vmId = item.alert.vmId;
    const lastKeptAt = lastKeptByVm.get(vmId);
    if (lastKeptAt !== undefined && item.timestamp - lastKeptAt < windowMs) {
      continue;
    }
    lastKeptByVm.set(vmId, item.timestamp);
    result.push(item.alert);
  }
  return result;
}
