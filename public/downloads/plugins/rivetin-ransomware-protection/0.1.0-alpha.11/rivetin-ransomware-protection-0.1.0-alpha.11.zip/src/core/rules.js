/**
 * Custom alert rule support for the ransomware protection plugin.
 *
 * All shapes below follow the *measured* CloudTower UI GraphQL contract
 * (`CustomAlertRuleCreateInput`), not the public REST OpenAPI document:
 *   - `exclude_system_service_vm` is required (Boolean!);
 *   - `targets` is `{vm:[], vmfolder:[], cluster:[]}` and exactly one is non-empty;
 *   - `groups` is `[{for, severity, triggers:[{name, operator, value}]}]`;
 *   - `target_type` and `resolve_method` must NOT be sent (server-derived);
 *   - duration (`groups[].for`) is minutes; SPIKE_GE values are multiples.
 *
 * Pure module: no I/O, no timers, no environment probing.
 */

/** Severity values accepted by CustomAlertRuleCreateInput. */
export const RULE_SEVERITIES = Object.freeze(['CRITICAL', 'NOTICE', 'INFO']);

/** Numeric limits of the measured contract (used by the builder and by UI validation). */
export const RULE_LIMITS = Object.freeze({
  NAME_MAX_LENGTH: 255,
  TRIGGERS_MIN: 1,
  TRIGGERS_MAX: 8,
  DURATION_MIN: 1,
  DURATION_MAX: 60,
  SPIKE_VALUE_MIN: 1,
  SPIKE_VALUE_MAX: 100,
});

/**
 * VM metric catalog measured via GraphQL `getCustomAlertTrigger`.
 * `SPIKE_GE` means ">= N times the 7-day average"; `GE` is an absolute threshold.
 */
export const RULE_METRICS = Object.freeze([
  Object.freeze({
    name: 'VM_CPU_OVERALL_USAGE_PERCENT',
    unit: 'PERCENT',
    operators: Object.freeze(['GE', 'SPIKE_GE']),
  }),
  Object.freeze({
    name: 'VM_CPU_READY_TIME_PERCENT',
    unit: 'PERCENT',
    operators: Object.freeze(['GE']),
  }),
  Object.freeze({
    name: 'VM_DISK_AVG_IO_LATENCY',
    unit: 'MILLISECOND',
    operators: Object.freeze(['GE']),
  }),
  Object.freeze({
    name: 'VM_DISK_FS_PARTITION_USAGE_PERCENT',
    unit: 'PERCENT',
    operators: Object.freeze(['GE']),
  }),
  Object.freeze({
    name: 'VM_DISK_IOPS',
    unit: 'UNIT_UNSPECIFIED',
    operators: Object.freeze(['GE', 'SPIKE_GE']),
  }),
  Object.freeze({
    name: 'VM_DISK_IO_BANDWIDTH',
    unit: 'MEBIBYTE_PER_SECOND',
    operators: Object.freeze(['GE', 'SPIKE_GE']),
  }),
  Object.freeze({
    name: 'VM_MEMORY_OVERALL_USAGE_PERCENT',
    unit: 'PERCENT',
    operators: Object.freeze(['GE', 'SPIKE_GE']),
  }),
  Object.freeze({
    name: 'VM_NETWORK_TOTAL_BANDWIDTH',
    unit: 'MEGABIT_PER_SECOND',
    operators: Object.freeze(['GE', 'SPIKE_GE']),
  }),
]);

const METRIC_BY_NAME = new Map(RULE_METRICS.map((metric) => [metric.name, metric]));

const FORBIDDEN_INPUT_FIELDS = Object.freeze([
  'target_type',
  'resolve_method',
  'targetType',
  'resolveMethod',
]);

const TARGET_KEYS = Object.freeze(['vm', 'vmfolder', 'cluster']);

function fail(code, details) {
  const error = new Error(code);
  error.code = code;
  if (details !== undefined) {
    error.details = details;
  }
  return error;
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function isNonEmptyString(value, maxLength = Number.POSITIVE_INFINITY) {
  return (
    typeof value === 'string' &&
    value.trim().length > 0 &&
    value.trim().length <= maxLength
  );
}

/**
 * Look up a metric entry from RULE_METRICS.
 * @param {unknown} name
 * @returns {{name: string, unit: string, operators: ReadonlyArray<string>} | null}
 */
export function findMetric(name) {
  return typeof name === 'string' ? METRIC_BY_NAME.get(name) ?? null : null;
}

/**
 * Build a `CustomAlertRuleCreateInput` for GraphQL `createCustomAlertRule`.
 *
 * Targets: pass exactly one of `vmId` / `clusterId` / `vmFolderId`.
 * The returned object intentionally contains no `target_type` / `resolve_method`.
 *
 * @param {object} options
 * @param {string} options.name
 * @param {string} [options.vmId]
 * @param {string} [options.clusterId]
 * @param {string} [options.vmFolderId]
 * @param {Array<{name: string, operator: string, value: number}>} options.triggers
 * @param {number} [options.durationMinutes=5]
 * @param {'CRITICAL'|'NOTICE'|'INFO'} [options.severity='CRITICAL']
 * @param {boolean} [options.disabled=true]
 * @param {boolean} [options.excludeSystemServiceVm=true]
 * @param {string} [options.description='']
 * @param {string} [options.alertDescription='']
 * @returns {object} validated CustomAlertRuleCreateInput
 * @throws {Error} field-specific rule error codes
 */
export function buildRuleInput(options = {}) {
  if (!isRecord(options)) {
    throw fail('INVALID_RULE_INPUT');
  }

  const {
    name,
    vmId,
    clusterId,
    vmFolderId,
    triggers,
    durationMinutes = 5,
    severity = 'CRITICAL',
    disabled = true,
    excludeSystemServiceVm = true,
    description = '',
    alertDescription = '',
  } = options;

  const targets = { vm: [], vmfolder: [], cluster: [] };
  const selected = [];

  if (vmId !== undefined && vmId !== null && vmId !== '') {
    selected.push('vm');
    if (!isNonEmptyString(vmId)) {
      throw fail('INVALID_RULE_TARGET', { field: 'vmId' });
    }
    targets.vm.push(vmId.trim());
  }
  if (vmFolderId !== undefined && vmFolderId !== null && vmFolderId !== '') {
    selected.push('vmfolder');
    if (!isNonEmptyString(vmFolderId)) {
      throw fail('INVALID_RULE_TARGET', { field: 'vmFolderId' });
    }
    targets.vmfolder.push(vmFolderId.trim());
  }
  if (clusterId !== undefined && clusterId !== null && clusterId !== '') {
    selected.push('cluster');
    if (!isNonEmptyString(clusterId)) {
      throw fail('INVALID_RULE_TARGET', { field: 'clusterId' });
    }
    targets.cluster.push(clusterId.trim());
  }
  if (selected.length !== 1) {
    throw fail('INVALID_RULE_TARGET', { selected });
  }

  if (!Array.isArray(triggers)) {
    throw fail('INVALID_RULE_TRIGGER', { field: 'triggers' });
  }

  const normalizedTriggers = triggers.map((trigger) => {
    if (!isRecord(trigger)) {
      return trigger;
    }
    return {
      name: trigger.name,
      operator: trigger.operator,
      value: trigger.value,
    };
  });

  const input = {
    name: typeof name === 'string' ? name.trim() : name,
    exclude_system_service_vm: excludeSystemServiceVm,
    targets,
    groups: [
      {
        for: durationMinutes,
        severity,
        triggers: normalizedTriggers,
      },
    ],
    disabled,
    description,
    alert_description: alertDescription,
  };

  validateRuleInput(input);
  return input;
}

/**
 * Validate a fully-built `CustomAlertRuleCreateInput`.
 * @param {unknown} input
 * @returns {true}
 * @throws {Error} INVALID_RULE_INPUT or a specific field code
 */
export function validateRuleInput(input) {
  if (!isRecord(input)) {
    throw fail('INVALID_RULE_INPUT');
  }

  for (const field of FORBIDDEN_INPUT_FIELDS) {
    if (field in input) {
      throw fail('INVALID_RULE_FORBIDDEN_FIELD', { field });
    }
  }

  if (!isNonEmptyString(input.name, RULE_LIMITS.NAME_MAX_LENGTH)) {
    throw fail('INVALID_RULE_NAME');
  }

  if (typeof input.exclude_system_service_vm !== 'boolean') {
    throw fail('INVALID_RULE_EXCLUDE_SYSTEM_SERVICE_VM');
  }

  validateTargets(input.targets);

  if (!Array.isArray(input.groups) || input.groups.length === 0) {
    throw fail('INVALID_RULE_GROUPS');
  }
  for (const group of input.groups) {
    validateGroup(group);
  }

  if (typeof input.disabled !== 'boolean') {
    throw fail('INVALID_RULE_DISABLED');
  }

  for (const field of ['description', 'alert_description']) {
    if (input[field] !== undefined && typeof input[field] !== 'string') {
      throw fail('INVALID_RULE_DESCRIPTION', { field });
    }
  }

  return true;
}

function validateTargets(targets) {
  if (!isRecord(targets)) {
    throw fail('INVALID_RULE_TARGET');
  }

  let activeTargets = 0;
  for (const key of TARGET_KEYS) {
    const value = targets[key];
    if (value === undefined || value === null) {
      continue;
    }
    if (!Array.isArray(value)) {
      throw fail('INVALID_RULE_TARGET', { field: key });
    }
    if (value.length === 0) {
      continue;
    }
    activeTargets += 1;
    for (const id of value) {
      if (!isNonEmptyString(id)) {
        throw fail('INVALID_RULE_TARGET', { field: key });
      }
    }
  }

  if (activeTargets !== 1) {
    throw fail('INVALID_RULE_TARGET', { activeTargets });
  }
}

function validateGroup(group) {
  if (!isRecord(group)) {
    throw fail('INVALID_RULE_GROUP');
  }

  const duration = group.for;
  if (
    !Number.isInteger(duration) ||
    duration < RULE_LIMITS.DURATION_MIN ||
    duration > RULE_LIMITS.DURATION_MAX
  ) {
    throw fail('INVALID_RULE_DURATION');
  }

  if (!RULE_SEVERITIES.includes(group.severity)) {
    throw fail('INVALID_RULE_SEVERITY');
  }

  const triggers = group.triggers;
  if (
    !Array.isArray(triggers) ||
    triggers.length < RULE_LIMITS.TRIGGERS_MIN ||
    triggers.length > RULE_LIMITS.TRIGGERS_MAX
  ) {
    throw fail('INVALID_RULE_TRIGGER');
  }

  for (const trigger of triggers) {
    validateTrigger(trigger);
  }
}

function validateTrigger(trigger) {
  if (!isRecord(trigger)) {
    throw fail('INVALID_RULE_TRIGGER');
  }

  const metric = findMetric(trigger.name);
  if (!metric) {
    throw fail('INVALID_RULE_TRIGGER_NAME', { name: trigger.name });
  }

  if (!metric.operators.includes(trigger.operator)) {
    throw fail('INVALID_RULE_TRIGGER_OPERATOR', {
      name: metric.name,
      operator: trigger.operator,
    });
  }

  const value = trigger.value;
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw fail('INVALID_RULE_TRIGGER_VALUE', { name: metric.name });
  }

  if (trigger.operator === 'SPIKE_GE') {
    if (
      value < RULE_LIMITS.SPIKE_VALUE_MIN ||
      value > RULE_LIMITS.SPIKE_VALUE_MAX
    ) {
      throw fail('INVALID_RULE_TRIGGER_VALUE', { name: metric.name });
    }
    return;
  }

  if (value < 0) {
    throw fail('INVALID_RULE_TRIGGER_VALUE', { name: metric.name });
  }
}

const RULE_NAME_PREFIX = 'demo-rs';
const RULE_NAME_RANDOM_LENGTH = 8;
const RULE_NAME_VM_PART_MAX = 40;
const RULE_NAME_HINT_PART_MAX = 24;

function slugify(value, maxLength) {
  if (typeof value !== 'string') {
    return '';
  }
  return value
    .normalize('NFKD')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, maxLength)
    .replace(/-+$/g, '');
}

function randomToken8() {
  try {
    const cryptoObject = globalThis.crypto;
    if (cryptoObject && typeof cryptoObject.getRandomValues === 'function') {
      const bytes = new Uint8Array(4);
      cryptoObject.getRandomValues(bytes);
      return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
    }
  } catch {
    // fall through to Math.random
  }
  return Math.floor(Math.random() * 0x100000000)
    .toString(16)
    .padStart(RULE_NAME_RANDOM_LENGTH, '0');
}

function resolveRandomToken(random) {
  if (typeof random === 'function') {
    const candidate = random();
    if (typeof candidate === 'string') {
      const cleaned = candidate
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '')
        .slice(0, RULE_NAME_RANDOM_LENGTH);
      if (cleaned.length === RULE_NAME_RANDOM_LENGTH) {
        return cleaned;
      }
    }
  }
  return randomToken8();
}

/**
 * Build a unique demo rule name of the form `demo-rs-<short-vm>-<hint>-<8 random>`.
 * Only `[a-z0-9-]` is emitted; total length never exceeds 255.
 *
 * @param {{vmName?: string, incidentHint?: string}} [parts]
 * @param {{random?: () => string}} [options] optional deterministic token supplier (tests)
 * @returns {string}
 */
export function ruleNameFor(parts = {}, options = {}) {
  const { vmName, incidentHint } = parts ?? {};
  const { random } = options ?? {};
  const vmPart = slugify(vmName, RULE_NAME_VM_PART_MAX) || 'vm';
  const hintPart = slugify(incidentHint, RULE_NAME_HINT_PART_MAX);
  const token = resolveRandomToken(random);
  const name = [RULE_NAME_PREFIX, vmPart, hintPart, token]
    .filter((part) => typeof part === 'string' && part.length > 0)
    .join('-')
    .slice(0, RULE_LIMITS.NAME_MAX_LENGTH)
    .replace(/-+$/g, '');
  return name;
}
