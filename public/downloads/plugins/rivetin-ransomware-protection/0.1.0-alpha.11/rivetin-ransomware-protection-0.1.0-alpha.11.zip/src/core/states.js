/**
 * Incident state machine for the ransomware protection plugin.
 *
 * Demo chain (architecture.md §3):
 *   ALERTED -> SNAPSHOTTING -> QUARANTINING (optional) -> REBUILDING (optional)
 *           -> QUARANTINED -> SCANNING -> SCAN_REPORTED -> HANDOVER -> CLOSED
 *
 * Quarantine and rebuild are both optional steps: the chain may skip from
 * SNAPSHOTTING directly to REBUILDING or QUARANTINED.
 *
 * Failures enter FAILED_MANUAL; the only continuation from there is HANDOVER
 * (manual hand-over of the evidence package).
 *
 * Pure module: no I/O, no timers, no environment probing.
 */

/** All incident states accepted by the demo state machine, in chain order. */
export const INCIDENT_STATES = Object.freeze([
  'ALERTED',
  'SNAPSHOTTING',
  'QUARANTINING',
  'REBUILDING',
  'QUARANTINED',
  'SCANNING',
  'SCAN_REPORTED',
  'HANDOVER',
  'CLOSED',
  'FAILED_MANUAL',
]);

/** States from which no automatic continuation is possible. */
export const TERMINAL_STATES = Object.freeze(['CLOSED']);

const EMPTY_STATES = Object.freeze([]);

/**
 * Allowed forward transitions. Skipping the optional QUARANTINING / REBUILDING
 * steps is modelled explicitly; backward transitions are never allowed.
 */
export const STATE_TRANSITIONS = Object.freeze({
  ALERTED: Object.freeze(['SNAPSHOTTING', 'FAILED_MANUAL']),
  SNAPSHOTTING: Object.freeze(['QUARANTINING', 'REBUILDING', 'QUARANTINED', 'FAILED_MANUAL']),
  QUARANTINING: Object.freeze(['REBUILDING', 'QUARANTINED', 'FAILED_MANUAL']),
  REBUILDING: Object.freeze(['QUARANTINED', 'FAILED_MANUAL']),
  QUARANTINED: Object.freeze(['SCANNING', 'FAILED_MANUAL']),
  SCANNING: Object.freeze(['SCAN_REPORTED', 'FAILED_MANUAL']),
  SCAN_REPORTED: Object.freeze(['HANDOVER', 'FAILED_MANUAL']),
  HANDOVER: Object.freeze(['CLOSED']),
  FAILED_MANUAL: Object.freeze(['HANDOVER']),
  CLOSED: EMPTY_STATES,
});

function fail(code, details) {
  const error = new Error(code);
  error.code = code;
  if (details !== undefined) {
    error.details = details;
  }
  return error;
}

/**
 * @param {unknown} state
 * @returns {boolean} true when `state` is one of INCIDENT_STATES.
 */
export function isKnownState(state) {
  return typeof state === 'string' && INCIDENT_STATES.includes(state);
}

/**
 * @param {unknown} state
 * @returns {boolean} true when `state` is terminal (no outgoing transition).
 */
export function isTerminalState(state) {
  return typeof state === 'string' && TERMINAL_STATES.includes(state);
}

/**
 * @param {unknown} state
 * @returns {ReadonlyArray<string>} allowed next states (empty for unknown states).
 */
export function nextStatesFor(state) {
  return isKnownState(state) ? STATE_TRANSITIONS[state] : EMPTY_STATES;
}

/**
 * @param {unknown} from
 * @param {unknown} to
 * @returns {boolean} true when `from -> to` is an allowed transition.
 */
export function canTransition(from, to) {
  return nextStatesFor(from).includes(to);
}

/**
 * Assert an allowed transition.
 * @param {unknown} from
 * @param {unknown} to
 * @returns {true}
 * @throws {Error} INVALID_STATE_TRANSITION when the transition is not allowed.
 */
export function assertTransition(from, to) {
  if (!canTransition(from, to)) {
    throw fail('INVALID_STATE_TRANSITION', { from, to });
  }
  return true;
}
