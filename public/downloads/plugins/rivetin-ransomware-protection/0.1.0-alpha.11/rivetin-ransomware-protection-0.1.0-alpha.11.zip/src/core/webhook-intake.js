/**
 * Webhook intake placeholder for the CloudTower -> Rivetin event channel.
 *
 * The measured CloudTower webhook payload is still unknown and the Rivetin
 * backend / ingress contract is not final, so this module is a bounded
 * placeholder: it records the raw body, applies the same normalization as the
 * polling fallback and returns an HTTP-friendly result. It never throws for an
 * unknown payload (the caller should still ACK 2xx to avoid provider retries)
 * and it never logs or stores authorization headers.
 *
 * Pure module: no I/O, no timers. The caller (local demo server or a future
 * backend) owns the HTTP layer.
 */

import { normalizeAlert } from './events.js';

const DEFAULT_MAX_BYTES = 1024 * 1024;
const DEFAULT_DEDUPE_WINDOW_MS = 10 * 60 * 1000;
const MAX_RECORDS = 500;
const ALLOWED_HEADERS = Object.freeze(['content-type', 'x-rivetin-idempotency-key']);

function fail(code, details) {
  const error = new Error(code);
  if (details !== undefined) error.details = details;
  return error;
}

function toBodyString(body) {
  if (typeof body === 'string') return body;
  if (body instanceof Uint8Array) return new TextDecoder('utf-8').decode(body);
  if (body && typeof body === 'object' && typeof body.toString === 'function' && body.constructor?.name === 'Buffer') {
    return body.toString('utf8');
  }
  return null;
}

function byteLength(value) {
  if (typeof TextEncoder === 'function') return new TextEncoder().encode(value).length;
  return value.length;
}

function nowIso(clock) {
  if (typeof clock === 'function') {
    const value = clock();
    if (value instanceof Date && Number.isFinite(value.getTime())) return value.toISOString();
    if (typeof value === 'string' && Number.isFinite(Date.parse(value))) return new Date(value).toISOString();
  }
  return new Date().toISOString();
}

function fnv1aHex(value) {
  let hash = 0x811c9dc5;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash.toString(16).padStart(8, '0');
}

function pickHeaders(headers) {
  const picked = {};
  if (!headers || typeof headers !== 'object') return picked;
  for (const [key, value] of Object.entries(headers)) {
    const name = String(key).toLowerCase();
    if (!ALLOWED_HEADERS.includes(name)) continue;
    if (value === undefined || value === null) continue;
    picked[name] = String(value).slice(0, 512);
  }
  return Object.freeze(picked);
}

/**
 * @param {{clock?: () => unknown, maxBytes?: number, dedupeWindowMs?: number}} [options]
 */
export function createWebhookIntake(options = {}) {
  const maxBytes = Number.isInteger(options.maxBytes) && options.maxBytes > 0 ? options.maxBytes : DEFAULT_MAX_BYTES;
  const dedupeWindowMs = Number.isInteger(options.dedupeWindowMs) && options.dedupeWindowMs > 0
    ? options.dedupeWindowMs
    : DEFAULT_DEDUPE_WINDOW_MS;
  const clock = options.clock;
  const records = [];
  const seen = new Map();
  let sequence = 0;

  function prune(now) {
    const threshold = now - dedupeWindowMs;
    for (const [hash, at] of seen) if (at < threshold) seen.delete(hash);
    while (records.length > MAX_RECORDS) records.shift();
  }

  /**
   * Handle one webhook delivery. Never throws for unparsable/unknown payloads;
   * returns `{ statusCode, status, ... }` for the caller to ACK.
   */
  async function handle(request = {}) {
    if (!request || typeof request !== 'object') throw fail('WEBHOOK_INVALID_REQUEST');
    const rawBody = toBodyString(request.body);
    if (rawBody === null) throw fail('WEBHOOK_UNSUPPORTED_BODY');
    if (rawBody.trim().length === 0) throw fail('WEBHOOK_EMPTY_BODY');
    const bytes = byteLength(rawBody);
    if (bytes > maxBytes) throw fail('WEBHOOK_TOO_LARGE', { bytes, maxBytes });

    const at = nowIso(clock);
    const now = Date.parse(at);
    prune(now);
    const bodyHash = fnv1aHex(rawBody);
    if (seen.has(bodyHash)) {
      return { status: 'duplicate', statusCode: 200, bodyHash, bytes, receivedAt: at };
    }
    seen.set(bodyHash, now);

    const headers = pickHeaders(request.headers);
    let parsed = null;
    let parseError = null;
    try {
      parsed = JSON.parse(rawBody);
    } catch {
      parseError = 'WEBHOOK_INVALID_JSON';
    }

    let event = null;
    let errorCode = parseError;
    if (parsed !== null && parseError === null) {
      try {
        // The intake endpoint is the webhook channel; force the source unless
        // the payload explicitly declares one (e.g. a simulated test message).
        const source = typeof parsed?.source === 'string' ? parsed.source : 'webhook';
        event = normalizeAlert({ ...parsed, source }, { clock: () => at });
        errorCode = null;
      } catch (error) {
        errorCode = typeof error?.message === 'string' && /^[A-Z][A-Z0-9_]+$/.test(error.message)
          ? error.message
          : 'ALERT_UNNORMALIZABLE';
      }
    }

    const record = Object.freeze({
      recordId: `webhook-${String(++sequence).padStart(4, '0')}`,
      receivedAt: at,
      bytes,
      bodyHash,
      headers,
      parsed: parsed !== null,
      event,
      errorCode,
      raw: rawBody,
    });
    records.push(record);
    return {
      status: event ? 'accepted' : 'recorded',
      statusCode: 200,
      recordId: record.recordId,
      bodyHash,
      bytes,
      event,
      errorCode,
      receivedAt: at,
    };
  }

  function list(options = {}) {
    const includeRaw = options?.includeRaw === true;
    return records.map((record) => (includeRaw ? { ...record } : {
      recordId: record.recordId,
      receivedAt: record.receivedAt,
      bytes: record.bytes,
      bodyHash: record.bodyHash,
      headers: record.headers,
      parsed: record.parsed,
      event: record.event,
      errorCode: record.errorCode,
    }));
  }

  function clear() {
    records.length = 0;
    seen.clear();
  }

  return Object.freeze({ handle, list, clear, maxBytes });
}

/**
 * Map an intake result to an HTTP response for the placeholder endpoint.
 * Unknown payloads are still ACKed 200 so CloudTower does not retry forever;
 * they stay visible as `recorded` records for later adaptation.
 */
export function toWebhookResponse(result) {
  if (!result || typeof result !== 'object') return { statusCode: 500, body: { status: 'error' } };
  return {
    statusCode: typeof result.statusCode === 'number' ? result.statusCode : 200,
    body: {
      status: result.status,
      recordId: result.recordId ?? null,
      accepted: result.status === 'accepted',
      duplicate: result.status === 'duplicate',
      errorCode: result.errorCode ?? null,
    },
  };
}
