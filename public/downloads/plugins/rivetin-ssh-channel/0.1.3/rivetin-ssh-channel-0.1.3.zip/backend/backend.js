import { createSshBroker } from './server/ssh-broker.js';

// The transport and framework trust boundary are supplied by the integration layer.
export function createSshBackend(directory, { vault, serviceStatus, inventory, audit, run, permit, prepareResultContext, onResult, revocationEpoch, requestContext, frameworkVersionProvider } = {}) {
  if (typeof directory !== 'string' || !directory) throw new Error('SSH_DATA_DIRECTORY_REQUIRED');
  if (!vault || typeof vault.list !== 'function' || typeof vault.get !== 'function' || typeof vault.revision !== 'function') {
    throw new Error('SSH_VAULT_PROVIDER_REQUIRED');
  }
  if ([serviceStatus, inventory, audit, run, permit?.current].some(provider => typeof provider !== 'function')) {
    throw new Error('SSH_FRAMEWORK_PROVIDER_REQUIRED');
  }
  return createSshBroker(directory, {
    vault,
    serviceStatus: async () => {
      if (!permit.current()) throw new Error('SSH_PERMIT_UNAVAILABLE');
      const status = await serviceStatus();
      if (!permit.current()) throw new Error('SSH_PERMIT_UNAVAILABLE');
      return status;
    },
    inventory, audit, run, prepareResultContext, onResult, revocationEpoch, requestContext, frameworkVersionProvider, manualOnly: true
  });
}
