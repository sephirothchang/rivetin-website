import { AsyncLocalStorage } from 'node:async_hooks';
import { randomUUID } from 'node:crypto';

export function createFrameworkContext({ framework, permits, identity }) {
  const storage = new AsyncLocalStorage();
  function capture() { return storage.getStore() || null; }
  function run(scope, action) {
    if (!scope || typeof scope.requestId !== 'string') throw new Error('SSH_PARENT_REQUEST_REQUIRED');
    return storage.run(scope, action);
  }
  async function call(method, kind, input) {
    const bearer = permits.current();
    if (!bearer) throw new Error('SSH_PERMIT_UNAVAILABLE');
    const requestId = randomUUID();
    return framework.call({ ...identity, requestId, operationId: kind === 'read' ? null : randomUUID(),
      capability: 'framework.ssh-context', interfaceVersion: 1, method, kind, input }, bearer);
  }
  function parent() {
    const scope = capture();
    if (!scope) throw new Error('SSH_PARENT_REQUEST_REQUIRED');
    return scope.requestId;
  }
  return {
    capture, run,
    authorizeInventory(actor) {
      const caller = capture()?.caller;
      return Boolean(caller && caller.source === 'tower' && caller.role === 'ROOT' && caller.admin === true && caller.pluginId === null &&
        actor?.id === caller.id && actor.source === caller.source && actor.role === caller.role && actor.admin === true);
    },
    serviceStatus: () => call('serviceStatus', 'read', {}),
    inventory: () => call('hostInventory', 'read', { parentRequestId: parent() }),
    diskInventory: hostId => call('diskInventory', 'read', { parentRequestId: parent(), hostId }),
    async towerRequest(route, input, actor) {
      if (!this.authorizeInventory(actor)) throw new Error('SSH_PARENT_REQUEST_REQUIRED');
      if (route === '/v2/api/get-hosts' && input?.first === 2 && typeof input?.where?.id === 'string') {
        const inventory = await this.inventory();
        if (!inventory || !Array.isArray(inventory.hosts) || inventory.hosts.length > 10000) throw new Error('SSH_INVENTORY_INVALID');
        return inventory.hosts.filter(host => host.id === input.where.id).map(host => ({ id: host.id, cluster: { id: host.clusterId }, management_ip: host.address }));
      }
      if (route === '/v2/api/get-disks' && input?.first === 1001 && typeof input?.where?.host?.id === 'string') {
        const disks = await this.diskInventory(input.where.host.id);
        if (!Array.isArray(disks)) throw new Error('SSH_INVENTORY_INVALID');
        return disks;
      }
      throw new Error('SSH_INVENTORY_REQUEST_INVALID');
    },
    audit: event => call('audit', 'submit', { parentRequestId: parent(), action: event.action,
      pluginId: event.pluginId ?? null, result: event.result, code: event.code ?? null })
  };
}
