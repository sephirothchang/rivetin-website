import http from 'node:http';

// The listener is bound by the caller to loopback inside the plugin Pod.
export function createHealthServer({ ready }) {
  if (typeof ready !== 'function') throw new Error('SSH_HEALTH_PROVIDER_REQUIRED');
  let pending;
  const server = http.createServer(async (request, response) => {
    if (request.method !== 'GET' || !['/live', '/ready'].includes(request.url)) {
      response.writeHead(404).end();
      return;
    }
    let okay = request.url === '/live';
    if (!okay) {
      if (!pending) {
        pending = Promise.resolve().then(ready).then(value => value === true, () => false);
        pending.finally(() => { pending = undefined; });
      }
      let timer;
      try { okay = await Promise.race([pending, new Promise(resolve => { timer = setTimeout(() => resolve(false), 5000); })]); }
      finally { clearTimeout(timer); }
    }
    response.writeHead(okay ? 200 : 503, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' });
    response.end(okay ? 'ok\n' : 'unavailable\n');
  });
  server.maxConnections = 16;
  server.setTimeout(6000, socket => socket.destroy());
  return server;
}
