import { createDecipheriv, createHash } from 'node:crypto';
import { lstat, readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { validateSshHost } from './server/ssh-vault.js';
import { validateConnectionsDocument } from './server/ssh-connection-settings.js';
import { validateConnectionsLedger, validateConnectionsV2Document } from './server/ssh-connections-v2.js';

const uuid = value => /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(value);
const host = name => /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}\.host\.json$/.test(name);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');

// Validate the encrypted rollback material without writing or disclosing it.
export async function inspectLegacyBackups(directory) {
  const root = path.join(path.resolve(directory), 'ssh-channel', 'vault', 'migrations');
  let names;
  try { const stat = await lstat(root); if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error(); names = await readdir(root); }
  catch (error) { if (error.code === 'ENOENT') return { backups: 0, hostFiles: 0 }; throw new Error('SSH_MIGRATION_BACKUP_INVALID'); }
  if (names.length > 10000) throw new Error('SSH_MIGRATION_BACKUP_INVALID');
  let hostFiles = 0;
  for (const id of names.sort()) {
    if (!uuid(id)) throw new Error('SSH_MIGRATION_BACKUP_INVALID');
    const backup = path.join(root, id), info = await lstat(backup);
    if (!info.isDirectory() || info.isSymbolicLink()) throw new Error('SSH_MIGRATION_BACKUP_INVALID');
    async function file(name, limit = 8 * 1024 * 1024) {
      const p = path.join(backup, name), stat = await lstat(p);
      if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 || stat.size > limit || (process.platform !== 'win32' && (stat.mode & 0o077))) throw new Error('SSH_MIGRATION_BACKUP_INVALID');
      return readFile(p);
    }
    try {
      const manifest = JSON.parse(await file('manifest.json'));
      if (manifest.version !== 2 || manifest.operationId !== id || manifest.direction !== 'upgrade' || !Number.isSafeInteger(manifest.revision) || manifest.revision < 1 || !Array.isArray(manifest.files) || manifest.files.length > 504) throw new Error();
      const contents = new Map();
      for (const row of manifest.files) {
        if (!row || typeof row.name !== 'string' || contents.has(row.name) || !/^[a-f0-9]{64}$/.test(row.sha256) || !(['key.json', 'connections.v1.json', 'operations.v2.json'].includes(row.name) || host(row.name))) throw new Error();
        const bytes = await file(row.name); if (hash(bytes) !== row.sha256) throw new Error(); contents.set(row.name, bytes);
      }
      const extraNames = await readdir(backup);
      if (extraNames.some(name => name !== 'manifest.json' && !contents.has(name) && !['recovery.json', 'rollback-connections.v2.json'].includes(name))) throw new Error();
      if (extraNames.includes('recovery.json')) {
        const recovery = JSON.parse(await file('recovery.json'));
        if (Object.keys(recovery).sort().join(',') !== 'approvalsRevoked,committed,operationId' || recovery.operationId !== id || recovery.committed !== false || recovery.approvalsRevoked !== true) throw new Error();
      }
      let key;
      const needsRollbackKey = extraNames.includes('rollback-connections.v2.json');
      if (contents.has('key.json') || needsRollbackKey) {
        let keyBytes = contents.get('key.json');
        if (!keyBytes) {
          const currentKey = path.join(path.dirname(root), 'key.json'), currentInfo = await lstat(currentKey);
          if (!currentInfo.isFile() || currentInfo.isSymbolicLink() || currentInfo.nlink !== 1 || currentInfo.size > 1024 * 1024 || (process.platform !== 'win32' && (currentInfo.mode & 0o077))) throw new Error();
          keyBytes = await readFile(currentKey);
        }
        const value = JSON.parse(keyBytes);
        if (!/^[A-Za-z0-9+/]{43}=$/.test(value?.key || '')) throw new Error();
        key = Buffer.from(value.key, 'base64');
      }
      try {
        for (const [name, bytes] of contents) {
          if (name === 'operations.v2.json') { validateConnectionsLedger(JSON.parse(bytes)); continue; }
          if (name === 'key.json') continue;
          if (!key) throw new Error();
          const outer = JSON.parse(bytes);
          if (outer?.version !== 1 || !/^[a-f0-9]{24}$/.test(outer.iv || '') || !/^[a-f0-9]{32}$/.test(outer.tag || '') || !/^(?:[a-f0-9]{2})+$/.test(outer.ciphertext || '')) throw new Error();
          const idOrAad = name === 'connections.v1.json' ? 'rivetin-ssh-connections-v1' : name.slice(0, -'.host.json'.length);
          const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(outer.iv, 'hex'));
          decipher.setAAD(Buffer.from(idOrAad)); decipher.setAuthTag(Buffer.from(outer.tag, 'hex'));
          const plaintext = Buffer.concat([decipher.update(Buffer.from(outer.ciphertext, 'hex')), decipher.final()]);
          try {
            const value = JSON.parse(plaintext);
            if (name === 'connections.v1.json') validateConnectionsDocument(value);
            else { if (validateSshHost(value).hostId !== idOrAad) throw new Error(); hostFiles++; }
          } finally { plaintext.fill(0); }
        }
        if (needsRollbackKey) {
          const outer = JSON.parse(await file('rollback-connections.v2.json'));
          if (outer?.version !== 2 || !/^[a-f0-9]{24}$/.test(outer.iv || '') || !/^[a-f0-9]{32}$/.test(outer.tag || '') || !/^(?:[a-f0-9]{2})+$/.test(outer.ciphertext || '')) throw new Error();
          const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(outer.iv, 'hex'));
          decipher.setAAD(Buffer.from('rivetin-ssh-connections-v2')); decipher.setAuthTag(Buffer.from(outer.tag, 'hex'));
          const plaintext = Buffer.concat([decipher.update(Buffer.from(outer.ciphertext, 'hex')), decipher.final()]);
          try { if (validateConnectionsV2Document(JSON.parse(plaintext)).migrationId !== id) throw new Error(); }
          finally { plaintext.fill(0); }
        }
      } finally { key?.fill(0); }
    } catch { throw new Error('SSH_MIGRATION_BACKUP_INVALID'); }
  }
  return { backups: names.length, hostFiles };
}
