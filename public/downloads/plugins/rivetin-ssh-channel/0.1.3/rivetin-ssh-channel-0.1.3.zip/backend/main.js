import { readFile } from 'node:fs/promises';
import { createSshRuntime } from './runtime.js';
import { authorizeOriginalResult } from './result-authorization.js';
import { createHealthServer } from './health.js';
import { createRuntimeLogger } from '../src/runtime-logging.js';

const configPath = '/run/rivetin/runtime/ssh.json';
const dataDirectory = '/data';
const keys = ['frameworkOrigin', 'frameworkPin'];

async function main() {
  const metadata = JSON.parse(await readFile(new URL('../metadata', import.meta.url), 'utf8'));
  if (metadata.id !== 'rivetin-ssh-channel') throw new Error('SSH_RUNTIME_METADATA_INVALID');
  const logger = createRuntimeLogger({ version: metadata.version });
  logger.start();
  try {
  if (typeof process.getuid === 'function' && process.getuid() === 0) throw new Error('SSH_NON_ROOT_REQUIRED');
  const config = JSON.parse(await readFile(configPath, 'utf8'));
  if (!config || typeof config !== 'object' || Array.isArray(config) || Object.keys(config).sort().join() !== keys.sort().join()) {
    throw new Error('SSH_RUNTIME_CONFIG_INVALID');
  }
  const tls = {
    ca: await readFile('/run/rivetin/tls/ca.crt'),
    cert: await readFile('/run/rivetin/tls/tls.crt'),
    key: await readFile('/run/rivetin/tls/tls.key')
  };
  const generation = process.env.RIVETIN_GENERATION;
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const installation = /^[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,61}[A-Za-z0-9])?$/;
  if (!installation.test(process.env.RIVETIN_INSTANCE_ID || '') || ![process.env.RIVETIN_WORKLOAD_ID, process.env.RIVETIN_POD_UID].every(value => uuid.test(value || ''))) throw new Error('SSH_RUNTIME_IDENTITY_INVALID');
  if (!/^[1-9][0-9]*$/.test(generation || '') || !Number.isSafeInteger(Number(generation))) throw new Error('SSH_RUNTIME_CONFIG_INVALID');
  const identity = { transportVersion: 1, instanceId: process.env.RIVETIN_WORKLOAD_ID, generation: Number(generation) };
  const runtime = createSshRuntime({ directory: dataDirectory, tls, identity,
    frameworkOrigin: config.frameworkOrigin, frameworkPin: config.frameworkPin,
    useFrameworkContext: true, ready: async () => true,
    authorizeOperation: authorizeOriginalResult, logger });
  await new Promise((resolve, reject) => {
    runtime.server.once('error', reject);
    runtime.server.listen(9443, '0.0.0.0', resolve);
  });
  const health = createHealthServer({ ready: async () => { const ready = await runtime.isReady(); logger.ready(ready); return ready; } });
  await new Promise((resolve, reject) => {
    health.once('error', reject);
    health.listen(18081, '127.0.0.1', resolve);
  });
  runtime.start();
  let stopping = false;
  const shutdown = async () => {
    if (stopping) return;
    stopping = true;
    const timer = setTimeout(() => process.exit(1), 20000);
    try { await new Promise((resolve, reject) => health.close(error => error ? reject(error) : resolve())); await runtime.stop(); logger.stop(); clearTimeout(timer); process.exit(0); }
    catch { logger.failure('SSH_RUNTIME_STOP_FAILED'); clearTimeout(timer); process.exit(1); }
  };
  process.once('SIGTERM', shutdown);
  process.once('SIGINT', shutdown);
  } catch (error) { logger.failure('SSH_RUNTIME_START_FAILED'); logger.stop(); throw error; }
}

main().catch(() => { process.stderr.write('SSH_RUNTIME_START_FAILED\n'); process.exit(1); });
