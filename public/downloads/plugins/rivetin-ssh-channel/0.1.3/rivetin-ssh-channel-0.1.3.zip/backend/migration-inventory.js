import { validateIdentityStore } from './server/ssh-identity.js';
import { validateConnectionsLedger } from './server/ssh-connections-v2.js';

// Classification only. The caller must capture the files under the writer fence
// and preserve their original bytes; this function does not perform a cutover.
export function classifyOperationSnapshots({ identity, connections, barrier, operations }) {
  const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const validId = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(value);
  const uuid = value => typeof value === 'string' && /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(value);
  const hash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
  const records = [];
  if (identity !== null) {
    try { validateIdentityStore(identity); } catch { throw new Error('SSH_MIGRATION_IDENTITY_INVALID'); }
    if (!object(identity) || identity.version !== 1 || !object(identity.requests) || !object(identity.grants) || Object.keys(identity.requests).length > 5000 || Object.keys(identity.grants).length > 100) throw new Error('SSH_MIGRATION_IDENTITY_INVALID');
    for (const [id, entry] of Object.entries(identity.requests)) {
      if (!uuid(id) || !object(entry) || !object(entry.result) || entry.result.requestId !== id || !['running', 'success', 'failed'].includes(entry.result.status) || (entry.result.status !== 'running' && typeof entry.result.outcomeUnknown !== 'boolean') || !hash(entry.owner) || !hash(entry.binding)) throw new Error('SSH_MIGRATION_IDENTITY_INVALID');
      records.push({ source: 'identity', id, status: entry.result.status === 'running' || entry.result.outcomeUnknown ? 'unknown' : entry.result.status, originalStatus: entry.result.status, owner: entry.owner });
    }
  }
  if (connections !== null) {
    try { validateConnectionsLedger(connections); } catch { throw new Error('SSH_MIGRATION_CONNECTIONS_INVALID'); }
    if (!object(connections) || connections.version !== 2 || !Array.isArray(connections.items) || connections.items.length > 10000) throw new Error('SSH_MIGRATION_CONNECTIONS_INVALID');
    const seen = new Set();
    for (const entry of connections.items) {
      if (!object(entry) || !uuid(entry.id) || seen.has(entry.id) || !['pending', 'committed', 'aborted'].includes(entry.state) || !hash(entry.actor) || !hash(entry.digest) || !Number.isSafeInteger(entry.revision) || entry.revision < 1) throw new Error('SSH_MIGRATION_CONNECTIONS_INVALID');
      seen.add(entry.id);
      records.push({ source: 'connections', id: entry.id, status: entry.state === 'pending' ? 'unknown' : entry.state, owner: entry.actor });
    }
  }
  if (barrier !== null && (!object(barrier) || barrier.version !== 2 || !uuid(barrier.operationId) || !Number.isSafeInteger(barrier.revision) || barrier.revision < 1 || !(barrier.digest === null || hash(barrier.digest)))) throw new Error('SSH_MIGRATION_BARRIER_INVALID');
  if (operations !== null) {
    if (!object(operations) || operations.version !== 1 || !object(operations.operations) || Object.keys(operations.operations).length > 10000) throw new Error('SSH_MIGRATION_OPERATIONS_INVALID');
    for (const [id, entry] of Object.entries(operations.operations)) {
      if (!validId(id) || !object(entry) || !['pending', 'completed'].includes(entry.status) || !hash(entry.owner) || !hash(entry.binding) || (entry.status === 'completed' && !Object.hasOwn(entry, 'result'))) throw new Error('SSH_MIGRATION_OPERATIONS_INVALID');
      records.push({ source: 'operations', id, status: entry.status === 'pending' ? 'unknown' : 'completed', owner: entry.owner });
    }
  }
  records.sort((a, b) => a.source.localeCompare(b.source) || a.id.localeCompare(b.id));
  return { version: 1, records, connectionBarrier: barrier === null ? null : { operationId: barrier.operationId, revision: barrier.revision },
    identityGrantCount: identity === null ? 0 : Object.keys(identity.grants).length,
    legacyInFlight: 'requires-drain-evidence' };
}
