import path from 'node:path';
import { createHash } from 'node:crypto';
import { atomic, json, storage } from './server/storage.js';

const validOperationId = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(value);
const hash = value => createHash('sha256').update(value).digest('hex');

// One active writer must be fenced by the framework before this store is used.
export function createOperationStore(directory) {
  const disk = storage(path.join(directory, 'ssh-operations'));
  const file = path.join(disk.root, 'operations.json');

  function owner(actor) {
    if (!actor || typeof actor.id !== 'string' || !actor.id || typeof actor.source !== 'string' || !actor.source || !Object.hasOwn(actor, 'pluginId') || (actor.pluginId !== null && (typeof actor.pluginId !== 'string' || !actor.pluginId))) {
      throw new Error('SSH_OPERATION_ACTOR_INVALID');
    }
    return hash(JSON.stringify([actor.source, actor.id, actor.pluginId]));
  }

  async function load() {
    const state = await json(file, { version: 1, operations: {} });
    if (state?.version !== 1 || !state.operations || Array.isArray(state.operations) || typeof state.operations !== 'object' || Object.keys(state.operations).length > 10000) {
      throw new Error('SSH_OPERATION_STORE_INVALID');
    }
    for (const [id, entry] of Object.entries(state.operations)) {
      if (!validOperationId(id) || !entry || !/^[a-f0-9]{64}$/.test(entry.owner) || !/^[a-f0-9]{64}$/.test(entry.binding) || !['pending', 'completed'].includes(entry.status) || (entry.status === 'completed' && !Object.hasOwn(entry, 'result'))) {
        throw new Error('SSH_OPERATION_STORE_INVALID');
      }
    }
    return state;
  }

  return {
    async submit({ operationId, actor, method, input, resource }, execute) {
      if (!validOperationId(operationId) || typeof method !== 'string' || !method || input === undefined || typeof execute !== 'function') throw new Error('SSH_OPERATION_INVALID');
      const actorHash = owner(actor);
      // Credential-bearing writes must not leave a digest derived from secrets.
      // Reusing their operation ID is always rejected; the vault owns its own
      // idempotent receipt for connection saves.
      const privateInput = method === 'saveConnections' || method === 'saveHost';
      const binding = hash(JSON.stringify(privateInput ? [method] : [method, input]));
      await disk.locked(async () => {
        const state = await load();
        const prior = Object.hasOwn(state.operations, operationId) ? state.operations[operationId] : null;
        if (prior) throw new Error(prior.owner === actorHash && prior.binding === binding ? 'SSH_OPERATION_ALREADY_ACCEPTED' : 'SSH_OPERATION_CONFLICT');
        if (Object.keys(state.operations).length >= 10000) throw new Error('SSH_OPERATION_STORE_LIMIT');
        state.operations[operationId] = { owner: actorHash, binding, status: 'pending', method, resource: resource ?? null };
        await atomic(file, state);
      });
      const result = await execute();
      const serialized = JSON.stringify(result);
      if (serialized === undefined || Buffer.byteLength(serialized) > 1024 * 1024) throw new Error('SSH_OPERATION_OUTCOME_UNKNOWN');
      if (method === 'saveConnections' && (!Number.isSafeInteger(result?.committedRevision) || result.committedRevision < 1)) throw new Error('SSH_OPERATION_OUTCOME_UNKNOWN');
      await disk.locked(async () => {
        const state = await load();
        const entry = state.operations[operationId];
        if (!entry || entry.owner !== actorHash || entry.binding !== binding || entry.status !== 'pending') throw new Error('SSH_OPERATION_STORE_INVALID');
        entry.status = 'completed';
        entry.result = method === 'saveConnections' ? { committedRevision: result.committedRevision } : result;
        await atomic(file, state);
      });
      return result;
    },
    async observe(operationId, actor) {
      if (!validOperationId(operationId)) throw new Error('SSH_OPERATION_INVALID');
      const actorHash = owner(actor);
      return disk.locked(async () => {
        const operations = (await load()).operations;
        const entry = Object.hasOwn(operations, operationId) ? operations[operationId] : null;
        if (!entry || entry.owner !== actorHash) throw new Error('SSH_OPERATION_NOT_FOUND');
        return entry.status === 'completed' ? { status: 'completed', result: entry.result } : { status: 'unknown' };
      });
    },
    async observeConnectionReceipt(operationId, actor) {
      if (!validOperationId(operationId)) throw new Error('SSH_OPERATION_INVALID');
      const actorHash = owner(actor);
      return disk.locked(async () => {
        const entry = (await load()).operations[operationId];
        if (!entry || entry.owner !== actorHash || entry.method !== 'saveConnections') throw new Error('SSH_OPERATION_NOT_FOUND');
        if (entry.status !== 'completed') return { operationId, state: 'unknown', committedRevision: null };
        const revision = entry.result?.committedRevision;
        if (!Number.isSafeInteger(revision) || revision < 1) throw new Error('SSH_OPERATION_STORE_INVALID');
        return { operationId, state: 'committed', committedRevision: revision };
      });
    },
    async scope(operationId, actor) {
      if (!validOperationId(operationId)) throw new Error('SSH_OPERATION_INVALID');
      const actorHash = owner(actor);
      return disk.locked(async () => {
        const operations = (await load()).operations;
        const entry = Object.hasOwn(operations, operationId) ? operations[operationId] : null;
        if (!entry || entry.owner !== actorHash || typeof entry.method !== 'string' || !entry.resource || typeof entry.resource !== 'object' || Array.isArray(entry.resource)) throw new Error('SSH_OPERATION_NOT_FOUND');
        return { method: entry.method, resource: structuredClone(entry.resource) };
      });
    }
  };
}
