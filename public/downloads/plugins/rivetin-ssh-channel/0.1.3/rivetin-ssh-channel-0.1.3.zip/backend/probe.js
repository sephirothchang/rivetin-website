import http from 'node:http';

const type = process.argv[2];
if (!['live', 'ready'].includes(type)) process.exit(2);
const request = http.get({ host: '127.0.0.1', port: 18081, path: '/' + type, signal: AbortSignal.timeout(6000) }, response => {
  response.resume();
  response.on('end', () => { process.exitCode = response.statusCode === 200 ? 0 : 1; });
});
request.on('error', () => { process.exitCode = 1; });
