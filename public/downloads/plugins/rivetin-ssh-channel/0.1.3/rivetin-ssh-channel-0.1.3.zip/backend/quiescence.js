// This gate proves only calls admitted through it. The framework must also
// fence every other entry point and verify the writer's process identity.
export function createQuiescenceGate({ stop, timeoutMs = 15000 }) {
  if (typeof stop !== 'function' || !Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 120000) {
    throw new Error('SSH_QUIESCENCE_CONFIG_INVALID');
  }
  let closed = false;
  let closePromise;
  const pending = new Set();
  return {
    run(action) {
      if (closed) return Promise.reject(new Error('SSH_QUIESCING'));
      if (typeof action !== 'function') return Promise.reject(new Error('SSH_QUIESCENCE_ACTION_INVALID'));
      const task = Promise.resolve().then(action);
      pending.add(task);
      task.then(() => pending.delete(task), () => pending.delete(task));
      return task;
    },
    close() {
      if (closePromise) return closePromise;
      closed = true;
      closePromise = (async () => {
        let timer;
        try {
          await Promise.race([
            (async () => { await Promise.allSettled([...pending]); await stop(); })(),
            new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('SSH_QUIESCENCE_TIMEOUT')), timeoutMs); })
          ]);
          if (pending.size !== 0) throw new Error('SSH_QUIESCENCE_INCOMPLETE');
          return { closed: true, pending: 0, scope: 'adapter' };
        } finally {
          clearTimeout(timer);
        }
      })();
      return closePromise;
    }
  };
}
