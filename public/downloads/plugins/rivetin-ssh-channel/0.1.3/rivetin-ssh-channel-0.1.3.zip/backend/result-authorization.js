export function authorizeOriginalResult(call, scope) {
  if (call?.caller?.source !== 'tower' || call.caller.role !== 'ROOT' || call.caller.admin !== true || !scope?.resource) return false;
  if (call.method === 'identityResult') return scope.method === 'identityExecute' && typeof scope.resource.hostId === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(scope.resource.hostId);
  if (call.method === 'operation' && scope.method === 'saveConnections') return true;
  return call.method === 'operation' && ['review', 'approve', 'revoke', 'run', 'runTarget'].includes(scope.method) &&
    validId(scope.resource.pluginId);
}
import { validId } from './shared/identity.js';

