import { createSshVault } from './server/ssh-vault.js';
import { createSshTransport } from './server/ssh-transport.js';
import { createBackendServer, createPeerClient } from './server/workload-http.js';
import { createPermitMonitor } from './server/workload-permit.js';
import { createSshBackend } from './backend.js';
import { createOperationStore } from './operations.js';
import { createSshWireAdapter } from './wire-adapter.js';
import { createFrameworkContext } from './framework-context.js';
import { createSshAdmission } from './server/ssh-admission.js';
import { createSshPreflight } from './server/ssh-preflight.js';
import { readdir } from 'node:fs/promises';
import { createSmartTargetAuthority } from './smart-target-authority.js';

// Integration callbacks must come from the authenticated framework adapter.
export function createSshRuntime({ directory, tls, frameworkOrigin, frameworkPin, identity,
  serviceStatus, inventory, audit, authorizeOperation, ready, towerRequest, revocationEpoch, useFrameworkContext = false, logger }) {
  if (typeof directory !== 'string' || !directory || [authorizeOperation, ready].some(value => typeof value !== 'function')) {
    throw new Error('SSH_RUNTIME_PROVIDER_REQUIRED');
  }
  const framework = createPeerClient({ origin: frameworkOrigin, tls, serverPin: frameworkPin });
  const admission = createSshAdmission(directory);
  const transport = createSshTransport({ admission });
  let broker, started = false, quiescing = false;
  const permits = createPermitMonitor({ renew: () => framework.permit(identity), onPause: async () => {
    started = false;
    await broker.stop();
  } });
  const context = useFrameworkContext ? createFrameworkContext({ framework, permits, identity }) : null;
  if (context) {
    serviceStatus = context.serviceStatus;
    inventory = context.inventory;
    audit = context.audit;
    revocationEpoch = async () => {
      const status = await context.serviceStatus();
      if (status.revocationEpoch === null) return null;
      if (!/^[a-f0-9]{32}$/.test(status.revocationEpoch || '')) throw new Error('SSH_REVOCATION_INVALID');
      return { nonce: status.revocationEpoch };
    };
  }
  const vault = createSshVault(directory, {
    request: context ? context.towerRequest.bind(context) : towerRequest,
    authorizeInventory: context ? context.authorizeInventory.bind(context) : undefined
  });
  const smartTargets = createSmartTargetAuthority(vault);
  broker = createSshBackend(directory, { vault, permit: permits, serviceStatus, inventory, audit, run: transport.run,
    revocationEpoch, requestContext: context, frameworkVersionProvider: context ? status => status.frameworkVersion : undefined });
  const preflight = context ? createSshPreflight({ vault, transport, inventory: () => context.inventory(), audit: context.audit,
    assertActive: async () => { const status = await context.serviceStatus(); if (!status?.enabled || !status?.channelInstalled || !status?.channelEnabled) throw new Error('SSH_CHANNEL_DISABLED'); } }) : null;
  async function revokeBeforeSave() {
    await preflight?.cancel();
    const revoked = await broker.invalidate(null, 'CONNECTION_SETTINGS_CHANGED');
    if (revoked.revoked !== true) throw new Error('SSH_CONNECTION_REVOKE_FAILED');
  }
  const wire = createSshWireAdapter({ broker, operations: createOperationStore(directory), authorizeOperation,
    connectionReads: {
      connections: () => vault.v2.connections(),
      policyCapabilities: () => vault.v2.capabilities(),
      deviceInventory: (hostId, category, actor) => vault.v2.inventory(hostId, category, actor),
      smartTargets: actor => smartTargets.list(actor),
      smartTargetDetails: (hostId, deviceId, actor) => smartTargets.details(hostId, deviceId, actor)
    }, connectionActions: {
      saveConnections: (input, actor) => vault.v2.save(input, actor, revokeBeforeSave),
      async saveHost(profile) { await revokeBeforeSave(); return vault.put(profile); },
      async removeHost(hostId) { await revokeBeforeSave(); return vault.remove(hostId); },
      ...(preflight ? { preflightDiscover: (input, actor) => preflight.discover({ ...input, actor }), preflightVerify: (input, actor) => preflight.verify({ ...input, actor }) } : {})
    } });
  const execute = async (call, options) => {
    const action = () => wire.execute(call, options);
    if (call.kind === 'submit') logger?.operation(call.method, 'started', call.operationId);
    try {
      const result = await (context ? context.run({ requestId: call.requestId, caller: call.caller }, action) : action());
      if (call.kind === 'submit') logger?.operation(call.method, 'completed', call.operationId);
      return result;
    } catch (error) {
      if (call.kind === 'submit') logger?.operation(call.method, 'failed', call.operationId);
      logger?.failure(error?.code || error?.message);
      throw error;
    }
  };
  async function isReady() {
      if (quiescing || !permits.current() || !await ready() || quiescing || !permits.current()) return false;
      try {
        let state = await admission.status();
        if (!state.initialized) {
          // Initialize only a genuinely empty new volume, after the FW permit is active.
          if ((await readdir(directory)).length !== 0 || !permits.current()) return false;
          await admission.init(); state = await admission.status();
        }
        if (!state.initialized || state.barrier !== null) return false;
      }
      catch { return false; }
      if (quiescing || !permits.current()) return false;
      if (context) {
        try {
          const status = await context.serviceStatus();
          if (!status || typeof status.frameworkVersion !== 'string' || status.frameworkVersion.length > 100 ||
              !/^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?$/.test(status.frameworkVersion) || typeof status.enabled !== 'boolean' || typeof status.channelInstalled !== 'boolean' ||
              typeof status.channelEnabled !== 'boolean' || !Array.isArray(status.plugins) ||
              !(status.revocationEpoch === null || /^[a-f0-9]{32}$/.test(status.revocationEpoch || ''))) return false;
        } catch { return false; }
      }
      try { await vault.v2.connections(); } catch { return false; }
      if (quiescing || !permits.current()) return false;
      if (!started) { broker.start(); started = true; }
      return true;
  }
  const server = createBackendServer({ tls, frameworkPin, identity, permits, framework, ...wire, execute, ready: isReady });
  return {
    server,
    permits,
    isReady,
    quiesce() { quiescing = true; return wire.quiesce(); },
    start() { permits.start(); },
    async stop() { preflight?.stop(); await permits.stop(); await broker.stop(); await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve())); }
  };
}
