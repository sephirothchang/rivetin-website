// SMART sample validation, aligned with the framework history schema.
const MAX_SMART = 512 * 1024;
const object = value => value && typeof value === 'object' && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
const exact = (value, keys) => object(value) && Object.keys(value).every(key => keys.includes(key));
const fail = () => { throw new Error('SMART_HISTORY_INVALID_DATA'); };
const numeric = value => Number.isSafeInteger(value) && value >= 0;
const digits = value => typeof value === 'string' && /^\d{1,40}$/.test(value);
const attributeNames = new Map([[5, 'Reallocated_Sector_Ct'], [9, 'Power_On_Hours'], [12, 'Power_Cycle_Count'], [194, 'Temperature_Celsius'], [196, 'Reallocated_Event_Count'], [197, 'Current_Pending_Sector'], [198, 'Offline_Uncorrectable'], [187, 'Reported_Uncorrect'], [199, 'UDMA_CRC_Error_Count']]);
function counts(value, fields) {
  if (!exact(value, fields.flatMap(key => [key, key + '_s']))) fail();
  for (const [key, count] of Object.entries(value)) if (!(key.endsWith('_s') ? digits(count) : numeric(count))) fail();
}
function bools(value, fields) { if (!exact(value, fields) || Object.values(value).some(item => typeof item !== 'boolean')) fail(); }
// The caller strips raw output first. This second boundary accepts only documented,
// bounded SMART fields; arbitrary vendor strings and identity/secret fields never persist.
export function validateHistorySmart(value) {
  let nodes = 0;
  function plain(item, depth = 0) {
    if (++nodes > 10000 || depth > 8 || item === undefined || typeof item === 'function' || typeof item === 'symbol' || typeof item === 'bigint' ||
        typeof item === 'number' && !Number.isFinite(item) || typeof item === 'string' && item.length > 128) fail();
    if (item && typeof item === 'object') {
      if (!Array.isArray(item) && !object(item)) fail();
      for (const child of Object.values(item)) plain(child, depth + 1);
    }
  }
  plain(value);
  const keys = ['smartctl', 'smart_support', 'smart_status', 'device', 'temperature', 'power_on_time', 'power_cycle_count', 'power_cycle_count_s',
    'nvme_smart_health_information_log', 'ata_smart_attributes', 'scsi_grown_defect_list', 'scsi_grown_defect_list_s', 'scsi_error_counter_log'];
  if (!exact(value, keys) || !Object.keys(value).length) fail();
  if (value.smartctl !== undefined && (!exact(value.smartctl, ['exit_status']) || !Number.isInteger(value.smartctl.exit_status) || value.smartctl.exit_status < 0 || value.smartctl.exit_status > 255 || (value.smartctl.exit_status & 7))) fail();
  if (value.smart_support !== undefined) bools(value.smart_support, ['available', 'enabled']);
  if (value.smart_status !== undefined) bools(value.smart_status, ['passed']);
  if (value.device !== undefined && (!exact(value.device, ['protocol']) || !['ATA', 'NVMe', 'SCSI'].includes(value.device.protocol))) fail();
  const temperature = item => typeof item === 'number' && Number.isFinite(item) && item >= -100 && item <= 300;
  if (value.temperature !== undefined && (!exact(value.temperature, ['current']) || !temperature(value.temperature.current))) fail();
  if (value.power_on_time !== undefined) counts(value.power_on_time, ['hours']);
  for (const key of ['power_cycle_count', 'scsi_grown_defect_list']) {
    if (value[key] !== undefined && !numeric(value[key])) fail();
    if (value[key + '_s'] !== undefined && !digits(value[key + '_s'])) fail();
  }
  const nvme = value.nvme_smart_health_information_log;
  if (nvme !== undefined) {
    if (!object(nvme)) fail();
    const { temperature: temp, ...rest } = nvme;
    counts(rest, ['critical_warning', 'available_spare', 'available_spare_threshold', 'percentage_used', 'media_errors', 'num_err_log_entries', 'unsafe_shutdowns', 'data_units_read', 'data_units_written', 'power_on_hours', 'power_cycles']);
    if (temp !== undefined && !temperature(temp)) fail();
  }
  if (value.ata_smart_attributes !== undefined) {
    if (!exact(value.ata_smart_attributes, ['table'])) fail();
    const table = value.ata_smart_attributes.table, seen = new Set();
    if (!Array.isArray(table) || table.length > 256) fail();
    for (const row of table) {
      if (!exact(row, ['id', 'name', 'value', 'worst', 'thresh', 'when_failed', 'raw']) || !Number.isInteger(row.id) || row.id < 1 || row.id > 255 || seen.has(row.id)) fail();
      seen.add(row.id);
      if (row.name !== undefined && row.name !== (attributeNames.get(row.id) || `Attribute_${row.id}`)) fail();
      for (const key of ['value', 'worst', 'thresh']) if (row[key] !== undefined && (typeof row[key] !== 'number' || !Number.isFinite(row[key]) || row[key] < 0 || row[key] > 255)) fail();
      if (row.when_failed !== undefined && !['now', 'past', '', '-'].includes(row.when_failed)) fail();
      if (row.raw !== undefined && (!exact(row.raw, ['value_s']) || !digits(row.raw.value_s))) fail();
    }
  }
  if (value.scsi_error_counter_log !== undefined) {
    if (!exact(value.scsi_error_counter_log, ['read', 'write', 'verify'])) fail();
    for (const item of Object.values(value.scsi_error_counter_log)) if (!exact(item, ['total_uncorrected_errors_s']) || !digits(item.total_uncorrected_errors_s)) fail();
  }
  let bytes; try { bytes = Buffer.byteLength(JSON.stringify(value)); } catch { fail(); }
  if (bytes > MAX_SMART) fail();
  return structuredClone(value);
}
