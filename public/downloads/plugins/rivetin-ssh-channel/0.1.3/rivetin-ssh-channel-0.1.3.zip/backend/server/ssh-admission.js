import path from 'node:path';
import { lstat, readFile } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { atomic, storage } from './storage.js';

const maxRecords = 10000;
const maxBytes = 4 * 1024 * 1024;
const kinds = new Set(['discover', 'verify', 'exec']);
const states = new Set(['admitted', 'dispatching', 'no-command', 'exit-observed', 'unknown']);
const origins = new Set(['broker', 'identity']);
const fail = (code, status = 503) => Object.assign(new Error(code), { code, status });
const id = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;
const iso = value => typeof value === 'string' && Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value;
const at = () => new Date().toISOString();
const exact = (value, keys) => value && typeof value === 'object' && Object.keys(value).sort().join(',') === keys;
const referenceValid = value => exact(value, 'bindingSha256,invocationId,operationId,source') &&
  origins.has(value.source) && [value.invocationId, value.operationId].every(key => typeof key === 'string' && id.test(key)) &&
  typeof value.bindingSha256 === 'string' && /^[a-f0-9]{64}$/.test(value.bindingSha256);

export function sshAdmissionReference(source, invocationId, operationId, actor, scope) {
  return { source, invocationId, operationId,
    bindingSha256: createHash('sha256').update(JSON.stringify([source, invocationId, operationId, actor.source, actor.id, ...scope])).digest('hex') };
}

export function createSshAdmission(directory) {
  const disk = storage(path.join(directory, 'ssh-admission'));
  const file = path.join(disk.root, 'ledger.v1.json');
  async function read() {
    let bytes;
    try {
      const info = await lstat(file);
      if (!info.isFile() || info.size > maxBytes) throw fail('SSH_ADMISSION_CORRUPT');
      bytes = await readFile(file);
    }
    catch (error) { if (error.code === 'ENOENT') return null; throw error; }
    if (bytes.length > maxBytes) throw fail('SSH_ADMISSION_CORRUPT');
    let value;
    try { value = JSON.parse(bytes); } catch { throw fail('SSH_ADMISSION_CORRUPT'); }
    if (!exact(value, 'barrier,ledgerId,legacyCoverage,records,schemaVersion,startedAt') || value.schemaVersion !== 1 ||
        typeof value.ledgerId !== 'string' || !id.test(value.ledgerId) || value.legacyCoverage !== 'unknown' || !iso(value.startedAt) ||
        !(value.barrier === null || exact(value.barrier, 'closedAt,operationId') && typeof value.barrier.operationId === 'string' && id.test(value.barrier.operationId) && iso(value.barrier.closedAt)) ||
        !Array.isArray(value.records) || value.records.length > maxRecords ||
        new Set(value.records.map(row => row?.id)).size !== value.records.length ||
        value.records.some(row => !exact(row, 'admittedAt,id,kind,reference,state,updatedAt') || typeof row.id !== 'string' || !id.test(row.id) || !kinds.has(row.kind) ||
          !states.has(row.state) || !iso(row.admittedAt) || !iso(row.updatedAt) ||
          !(row.kind === 'exec' ? referenceValid(row.reference) : row.reference === null) ||
          (row.kind !== 'exec' && ['dispatching', 'exit-observed', 'unknown'].includes(row.state)))) throw fail('SSH_ADMISSION_CORRUPT');
    return { value, sha256: createHash('sha256').update(bytes).digest('hex') };
  }
  async function initialized() {
    const current = await read();
    if (!current) throw fail('SSH_ADMISSION_NOT_INITIALIZED');
    return current.value;
  }
  async function write(value, reserve = 0) {
    const bytes = Buffer.from(JSON.stringify(value) + '\n');
    if (bytes.length + reserve > maxBytes) throw fail('SSH_ADMISSION_CAPACITY');
    await atomic(file, bytes);
  }
  async function update(recordId, change) {
    return disk.locked(async () => {
      const value = await initialized();
      const row = value.records.find(entry => entry.id === recordId);
      if (!row) throw fail('SSH_ADMISSION_CORRUPT');
      return change(value, row);
    });
  }
  function set(row, state) { row.state = state; row.updatedAt = at(); }
  return {
    async init() {
      return disk.locked(async () => {
        if (!await read()) await write({ schemaVersion: 1, ledgerId: randomUUID(), legacyCoverage: 'unknown', startedAt: at(), barrier: null, records: [] });
        return { initialized: true, legacyCoverage: 'unknown' };
      });
    },
    async status() {
      const current = await read();
      if (!current) return { initialized: false, legacyCoverage: 'unknown', migrationEligible: false };
      const { value, sha256 } = current;
      return { initialized: true, ...value, sha256, migrationEligible: false,
        unresolved: value.records.filter(row => ['admitted', 'dispatching', 'unknown'].includes(row.state)).length };
    },
    async close(operationId) {
      if (typeof operationId !== 'string' || !id.test(operationId)) throw fail('SSH_ADMISSION_OPERATION_INVALID', 400);
      return disk.locked(async () => {
        const value = await initialized();
        if (value.barrier?.operationId === operationId) return value.barrier;
        if (value.barrier) throw fail('SSH_ADMISSION_ALREADY_CLOSED', 409);
        value.barrier = { operationId, closedAt: at() };
        await write(value);
        return value.barrier;
      });
    },
    async track(kind, reference, work) {
      if (!kinds.has(kind) || !(kind === 'exec' ? referenceValid(reference) : reference === null)) throw fail('SSH_ADMISSION_OPERATION_INVALID', 400);
      const recordId = randomUUID();
      await disk.locked(async () => {
        const value = await initialized();
        if (value.barrier) throw fail('SSH_ADMISSION_CLOSED');
        if (value.records.length >= maxRecords) throw fail('SSH_ADMISSION_CAPACITY');
        const now = at();
        value.records.push({ id: recordId, kind, reference, state: 'admitted', admittedAt: now, updatedAt: now });
        // Leave space for the barrier and longer terminal states even at capacity.
        await write(value, 1024 + maxRecords * 8);
      });
      const dispatch = invoke => update(recordId, async (value, row) => {
        if (value.barrier) throw fail('SSH_ADMISSION_CLOSED');
        if (row.kind !== 'exec' || row.state !== 'admitted') throw fail('SSH_ADMISSION_OPERATION_INVALID');
        set(row, 'dispatching');
        await write(value);
        // Serialize the SSH client submission with close. The client may queue its wire request.
        invoke();
      });
      let result, error;
      try { result = await work(dispatch); } catch (failure) { error = failure; }
      await update(recordId, async (value, row) => {
        if (!['admitted', 'dispatching'].includes(row.state)) throw fail('SSH_ADMISSION_CORRUPT');
        set(row, row.state === 'admitted' ? 'no-command' : error ? 'unknown' : 'exit-observed');
        await write(value);
      });
      if (error) throw error;
      return result;
    },
  };
}
