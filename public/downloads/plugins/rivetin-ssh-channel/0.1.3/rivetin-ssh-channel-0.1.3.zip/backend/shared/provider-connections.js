export const PROTOCOL = Object.freeze({ major: 1, minor: 0 });
export const LIMITS = Object.freeze({ maxUsedKeys: 65536, maxIndexBytes: 64 * 1024 ** 2,
  maxDetailBytes: 256 * 1024 ** 2, maxOperationDetailBytes: 256 * 1024,
  maxNonterminal: 96, maxRecoveryBytes: 64 * 1024 ** 2, reservedControlBytes: 8 * 1024 ** 2,
  reservedRecoveryBytesPerOperation: 512 * 1024, queryReservedSlots: 4,
  detailRetentionMs: 30 * 86400000, maxRequestBytes: 65536, maxSecretBytes: 16384,
  attemptMs: 600000, proofMs: 120000, maxAttempts: 256, maxActorAttempts: 3,
  maxPage: 200, defaultPage: 100, maxObjects: 2000, maxDiscoveryBytes: 4 * 1024 ** 2,
  maxDiscoveryCalls: 40, discoveryMs: 60000, callMs: 15000 });
export class ConnectionError extends Error {
  constructor(code, outcome = 'not-accepted') { super(code); this.code = code; this.outcome = outcome; }
}
const errorCodes = new Set(['SCHEMA_INVALID', 'LIMIT_EXCEEDED', 'PROTOCOL_UNSUPPORTED', 'PERMISSION_DENIED', 'MODE_UNSUPPORTED',
  'REGISTRY_INVALID', 'PROVIDER_UNAVAILABLE', 'NETWORK_POLICY_DENIED', 'TLS_TRUST_REQUIRED', 'TLS_IDENTITY_CHANGED',
  'AUTHENTICATION_FAILED', 'ADAPTATION_UNSUPPORTED', 'RESPONSE_INVALID', 'PROOF_EXPIRED', 'PROOF_MISMATCH',
  'INSTANCE_CHANGED', 'DISCOVERY_INCOMPLETE', 'TIMEOUT', 'REVISION_CONFLICT', 'CREDENTIAL_VERSION_CONFLICT',
  'OPERATION_ID_REUSED', 'BUSY', 'STORAGE_UNAVAILABLE', 'STORAGE_PERMISSIONS', 'RECOVERY_PENDING', 'STORE_BUSY',
  'CAPACITY_EXHAUSTED', 'SAVE_OUTCOME_UNKNOWN', 'OPERATIONS_PENDING', 'NOT_FOUND'].map(code => 'CONNECTION_' + code));
export const safeErrorCode = error => error instanceof ConnectionError && errorCodes.has(error.code) ? error.code : 'CONNECTION_PROVIDER_UNAVAILABLE';
export const fail = (code, outcome) => { throw new ConnectionError(code, outcome); };
export const object = value => value !== null && typeof value === 'object' && !Array.isArray(value) &&
  [Object.prototype, null].includes(Object.getPrototypeOf(value));
export function fields(value, required, optional = []) {
  if (!object(value) || required.some(key => !Object.hasOwn(value, key)) ||
      Object.keys(value).some(key => ![...required, ...optional].includes(key))) fail('CONNECTION_SCHEMA_INVALID');
  return value;
}
export function text(value, max = 128) {
  if (typeof value !== 'string' || !value.length || value.length > max || /[\x00-\x1f\x7f]/.test(value)) fail('CONNECTION_SCHEMA_INVALID');
  return value;
}
export const identifier = value => { text(value); if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]*$/.test(value)) fail('CONNECTION_SCHEMA_INVALID'); return value; };
export const digest = value => { if (!/^[a-f0-9]{64}$/.test(value)) fail('CONNECTION_SCHEMA_INVALID'); return value; };
export const uuid = value => { if (typeof value !== 'string' || !/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(value)) fail('CONNECTION_SCHEMA_INVALID'); return value; };
export function integer(value, min = 0, max = Number.MAX_SAFE_INTEGER) {
  if (!Number.isSafeInteger(value) || value < min || value > max) fail('CONNECTION_SCHEMA_INVALID'); return value;
}
export function canonical(value, depth = 0) {
  if (depth > 16) fail('CONNECTION_SCHEMA_INVALID');
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(item => canonical(item, depth + 1)).join(',') + ']';
  if (!object(value)) fail('CONNECTION_SCHEMA_INVALID');
  return '{' + Object.keys(value).sort().map(key => {
    if (['__proto__', 'prototype', 'constructor'].includes(key)) fail('CONNECTION_SCHEMA_INVALID');
    return JSON.stringify(key) + ':' + canonical(value[key], depth + 1);
  }).join(',') + '}';
}
export function bounded(value, bytes = LIMITS.maxRequestBytes) {
  const json = canonical(value); if (new TextEncoder().encode(json).length > bytes) fail('CONNECTION_LIMIT_EXCEEDED');
  return JSON.parse(json);
}
// Dedicated decoder for future transport consumers; JSON.parse alone loses duplicate keys.
export function parseConnectionJson(source, max = LIMITS.maxRequestBytes) {
  if (typeof source !== 'string' || new TextEncoder().encode(source).length > max) fail('CONNECTION_SCHEMA_INVALID');
  let pos = 0;
  const white = () => { while (/[ \t\r\n]/.test(source[pos] || '') && pos < source.length) pos++; };
  const string = () => {
    const start = pos++;
    while (pos < source.length) { const char = source[pos++]; if (char === '\\') pos++; else if (char === '"') return JSON.parse(source.slice(start, pos)); }
    fail('CONNECTION_SCHEMA_INVALID');
  };
  function read(depth = 0) {
    if (depth > 16) fail('CONNECTION_SCHEMA_INVALID'); white();
    if (source[pos] === '"') return string();
    if (source[pos] === '{') {
      pos++; const result = Object.create(null), seen = new Set(); white();
      if (source[pos] === '}') { pos++; return result; }
      for (;;) {
        white(); if (source[pos] !== '"') fail('CONNECTION_SCHEMA_INVALID'); const key = string();
        if (seen.has(key)) fail('CONNECTION_SCHEMA_INVALID'); seen.add(key); white();
        if (source[pos++] !== ':') fail('CONNECTION_SCHEMA_INVALID'); result[key] = read(depth + 1); white();
        const char = source[pos++]; if (char === '}') return result; if (char !== ',') fail('CONNECTION_SCHEMA_INVALID');
      }
    }
    if (source[pos] === '[') {
      pos++; const values = []; white(); if (source[pos] === ']') { pos++; return values; }
      for (;;) { values.push(read(depth + 1)); white(); const char = source[pos++]; if (char === ']') return values; if (char !== ',') fail('CONNECTION_SCHEMA_INVALID'); }
    }
    const match = /^(?:true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(source.slice(pos));
    if (!match) fail('CONNECTION_SCHEMA_INVALID'); pos += match[0].length; return JSON.parse(match[0]);
  }
  try { const value = read(); white(); if (pos !== source.length) fail('CONNECTION_SCHEMA_INVALID'); return bounded(value, max); }
  catch { fail('CONNECTION_SCHEMA_INVALID'); }
}
export function schemaDefinition(schema, depth = 0) {
  if (depth > 8) fail('CONNECTION_SCHEMA_INVALID');
  fields(schema, ['type'], ['properties', 'required', 'items', 'enum', 'maxLength', 'minLength', 'minimum', 'maximum', 'maxItems']);
  if (!['object', 'array', 'string', 'integer', 'boolean', 'number', 'null'].includes(schema.type)) fail('CONNECTION_SCHEMA_INVALID');
  if (schema.enum && (!Array.isArray(schema.enum) || !schema.enum.length || schema.enum.length > 64)) fail('CONNECTION_SCHEMA_INVALID');
  for (const key of ['maxLength', 'minLength', 'maxItems']) if (Object.hasOwn(schema, key)) integer(schema[key]);
  for (const key of ['minimum', 'maximum']) if (Object.hasOwn(schema, key)) integer(schema[key], Number.MIN_SAFE_INTEGER);
  if (Object.hasOwn(schema, 'minimum') && Object.hasOwn(schema, 'maximum') && schema.minimum > schema.maximum) fail('CONNECTION_SCHEMA_INVALID');
  if (schema.type === 'object') {
    if (!object(schema.properties) || Object.keys(schema.properties).length > 96 || !Array.isArray(schema.required) ||
      schema.required.some(key => !Object.hasOwn(schema.properties, key))) fail('CONNECTION_SCHEMA_INVALID');
    for (const child of Object.values(schema.properties)) schemaDefinition(child, depth + 1);
  } else if (schema.type === 'array') { integer(schema.maxItems, 0, 2000); schemaDefinition(schema.items, depth + 1); }
  bounded(schema, 8192); return schema;
}
export function validateSchema(value, schema) {
  if (schema.enum && !schema.enum.some(item => canonical(item) === canonical(value))) fail('CONNECTION_SCHEMA_INVALID');
  if (schema.type === 'object') {
    fields(value, schema.required, Object.keys(schema.properties));
    for (const key of Object.keys(value)) validateSchema(value[key], schema.properties[key]);
  } else if (schema.type === 'array') {
    if (!Array.isArray(value) || value.length > schema.maxItems) fail('CONNECTION_SCHEMA_INVALID');
    value.forEach(item => validateSchema(item, schema.items));
  } else if (schema.type === 'string') { text(value, schema.maxLength ?? 128); if (value.length < (schema.minLength ?? 1)) fail('CONNECTION_SCHEMA_INVALID'); }
  else if (schema.type === 'integer') integer(value, schema.minimum ?? 0, schema.maximum ?? Number.MAX_SAFE_INTEGER);
  else if (schema.type === 'number') { if (typeof value !== 'number' || !Number.isFinite(value) || value < (schema.minimum ?? -Infinity) || value > (schema.maximum ?? Infinity)) fail('CONNECTION_SCHEMA_INVALID'); }
  else if (schema.type === 'null' ? value !== null : typeof value !== schema.type) fail('CONNECTION_SCHEMA_INVALID');
  return value;
}
export function candidate(value) {
  fields(value, ['label', 'origin', 'tls', 'adaptation']); text(value.label, 80); text(value.origin, 512);
  let url; try { url = new URL(value.origin); } catch { fail('CONNECTION_SCHEMA_INVALID'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash || url.pathname !== '/' || value.origin !== url.origin) fail('CONNECTION_SCHEMA_INVALID');
  fields(value.tls, ['trustRef']); identifier(value.tls.trustRef);
  fields(value.adaptation, ['mode', 'schemaId', 'schemaVersion', 'values']);
  if (!['auto', 'manual'].includes(value.adaptation.mode)) fail('CONNECTION_SCHEMA_INVALID');
  identifier(value.adaptation.schemaId); integer(value.adaptation.schemaVersion, 1); bounded(value.adaptation.values, 8192);
  return value;
}
export function resource(value, types) { fields(value, ['objectType', 'objectId']); identifier(value.objectType); text(value.objectId); if (!types.includes(value.objectType)) fail('CONNECTION_SCHEMA_INVALID'); return value; }
export function credential(value) {
  if (value?.action === 'keep') { fields(value, ['action', 'credentialVersion']); identifier(value.credentialVersion); }
  else if (value?.action === 'replace') { fields(value, ['action', 'stagedSecretRef']); identifier(value.stagedSecretRef); }
  else if (value?.action === 'clear') fields(value, ['action']); else fail('CONNECTION_SCHEMA_INVALID');
  return value;
}


export function businessOperationRequest(value) {
  fields(value, ['version', 'operationId'], ['credentialInputs']);
  if (value.version !== 1) fail('CONNECTION_SCHEMA_INVALID'); uuid(value.operationId);
  if (value.credentialInputs !== undefined) {
    if (!Array.isArray(value.credentialInputs) || value.credentialInputs.length > 1) fail('CONNECTION_SCHEMA_INVALID');
    for (const row of value.credentialInputs) { fields(row, ['name', 'credentialInputRef', 'credentialInputVersion']); identifier(row.name); uuid(row.credentialInputRef); identifier(row.credentialInputVersion); }
  }
  return bounded(value, 4096);
}
