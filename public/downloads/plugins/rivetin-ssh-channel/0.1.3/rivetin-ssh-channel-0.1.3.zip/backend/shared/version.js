export const FRAMEWORK_VERSION = '0.3.0-alpha.1';
// Future releases add only reviewed predecessors whose settings can be adopted.
export const FRAMEWORK_METADATA_PREDECESSORS = Object.freeze(['0.2.18-alpha.2']);
