const id = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(value);
const failure = code => Object.assign(new Error(code), { code });

// Only project fresh, policy-filtered targets; never return credential material.
export function createSmartTargetAuthority(vault) {
  if (!vault?.v2?.targets || !vault?.v2?.connections) throw failure('SSH_TARGET_AUTHORITY_REQUIRED');
  async function rows(actor) {
    if (actor?.source !== 'tower' || actor.role !== 'ROOT' || actor.admin !== true || actor.pluginId !== null) throw failure('SSH_ROOT_REQUIRED');
    const hosts = await vault.v2.targets(actor);
    if (hosts === null) {
      const summary = await vault.v2.connections();
      if (summary?.migration?.required) throw failure('SSH_CONNECTION_MIGRATION_REQUIRED');
      return [];
    }
    if (!Array.isArray(hosts)) throw failure('SSH_TARGET_UNAVAILABLE');
    const result = [], seen = new Set();
    for (const host of hosts) {
      if (!id(host.hostId) || !Array.isArray(host.devices)) throw failure('SSH_TARGET_UNAVAILABLE');
      for (const device of host.devices) {
        if (!id(device.deviceId)) throw failure('SSH_TARGET_UNAVAILABLE');
        const key = JSON.stringify([host.hostId, device.deviceId]);
        if (seen.has(key)) throw failure('SSH_TARGET_UNAVAILABLE');
        seen.add(key); result.push({ host, device });
        if (result.length > 100) throw failure('SSH_TARGET_LIMIT');
      }
    }
    return result;
  }
  return {
    async list(actor) { return { items: (await rows(actor)).map(({ host, device }) => ({ hostId: host.hostId, deviceId: device.deviceId })) }; },
    async details(hostId, deviceId, actor) {
      if (!id(hostId) || !id(deviceId)) throw failure('SSH_TARGET_NOT_APPROVED');
      const row = (await rows(actor)).find(item => item.host.hostId === hostId && item.device.deviceId === deviceId);
      if (!row) throw failure('SSH_TARGET_UNAVAILABLE');
      const { host, device } = row;
      if (typeof host.address !== 'string' || !Number.isInteger(host.port) || typeof host.username !== 'string' ||
          typeof device.serial !== 'string' || !device.serial || typeof device.path !== 'string' || !device.path) throw failure('SSH_TARGET_UNAVAILABLE');
      return { host: { hostId: host.hostId, address: host.address, port: host.port, username: host.username,
        ...(/^[a-f0-9]{64}$/.test(host.hostKeySha256 || '') ? { hostKeySha256: host.hostKeySha256 } : {}) },
        device: { deviceId: device.deviceId, serial: device.serial, path: device.path } };
    }
  };
}
