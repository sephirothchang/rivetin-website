import { createHash } from 'node:crypto';
import { lstat, open, readdir } from 'node:fs/promises';
import path from 'node:path';
import { classifyOperationSnapshots } from './migration-inventory.js';

// This inventories bytes only. It does not establish a writer fence or validate
// the semantic consistency of vault, approval, and operation records.
export async function captureSshFiles(directory) {
  const root = path.resolve(directory);
  const rootStat = await lstat(root, { bigint: true });
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new Error('SSH_SNAPSHOT_ROOT_INVALID');
  const files = [];
  const directories = [];
  const absent = [];
  const documents = { identity: null, connections: null, barrier: null, operations: null };
  const documentPaths = new Map([
    ['ssh-channel/identity.v1.json', 'identity'],
    ['ssh-channel/vault/operations.v2.json', 'connections'],
    ['ssh-channel/vault/mutation.v2.json', 'barrier'],
    ['ssh-operations/operations.json', 'operations']
  ]);
  let total = 0;
  async function visit(relative) {
    const full = path.join(root, ...relative.split('/'));
    let before;
    try { before = await lstat(full, { bigint: true }); }
    catch (error) { if (error.code === 'ENOENT') { absent.push(relative); return; } throw error; }
    if (before.isSymbolicLink()) throw new Error('SSH_SNAPSHOT_LINK');
    if (before.isDirectory()) {
      directories.push(relative);
      const names = (await readdir(full)).sort();
      if (names.length > 10000) throw new Error('SSH_SNAPSHOT_LIMIT');
      for (const name of names) await visit(relative + '/' + name);
      if (JSON.stringify(names) !== JSON.stringify((await readdir(full)).sort())) throw new Error('SSH_SNAPSHOT_CHANGED');
      const after = await lstat(full, { bigint: true });
      if (!after.isDirectory() || after.isSymbolicLink()) throw new Error('SSH_SNAPSHOT_CHANGED_DIRECTORY_TYPE');
      if (after.dev !== before.dev || after.ino !== before.ino) throw new Error('SSH_SNAPSHOT_CHANGED_DIRECTORY_IDENTITY');
      if (after.mtimeNs !== before.mtimeNs) throw new Error('SSH_SNAPSHOT_CHANGED_DIRECTORY_MTIME_' + relative.split('/').length);
      return;
    }
    if (!before.isFile() || before.nlink !== 1n || before.size > 16n * 1024n * 1024n || files.length >= 10000) throw new Error('SSH_SNAPSHOT_FILE_INVALID');
    const size = Number(before.size);
    total += size;
    if (total > 256 * 1024 * 1024) throw new Error('SSH_SNAPSHOT_LIMIT');
    const handle = await open(full, 'r');
    try {
      const first = await handle.stat({ bigint: true });
      if (!first.isFile() || (process.platform !== 'win32' && first.dev !== before.dev) || first.ino !== before.ino || first.size !== before.size || first.mtimeNs !== before.mtimeNs) throw new Error('SSH_SNAPSHOT_CHANGED');
      const digest = createHash('sha256');
      const chunks = documentPaths.has(relative) ? [] : null;
      const buffer = Buffer.alloc(65536);
      let offset = 0;
      while (offset < size) {
        const { bytesRead } = await handle.read(buffer, 0, Math.min(buffer.length, size - offset), offset);
        if (!bytesRead) throw new Error('SSH_SNAPSHOT_CHANGED');
        digest.update(buffer.subarray(0, bytesRead));
        if (chunks) chunks.push(Buffer.from(buffer.subarray(0, bytesRead)));
        offset += bytesRead;
      }
      const last = await handle.stat({ bigint: true });
      const final = await lstat(full, { bigint: true });
      if (last.size !== first.size || last.mtimeNs !== first.mtimeNs || last.ctimeNs !== first.ctimeNs || final.isSymbolicLink() || (process.platform !== 'win32' && final.dev !== first.dev) || final.ino !== first.ino || final.size !== first.size || final.mtimeNs !== first.mtimeNs || final.ctimeNs !== first.ctimeNs) throw new Error('SSH_SNAPSHOT_CHANGED');
      files.push({ path: relative, bytes: size, sha256: digest.digest('hex') });
      if (chunks) {
        try { documents[documentPaths.get(relative)] = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
        catch { throw new Error('SSH_SNAPSHOT_DOCUMENT_INVALID'); }
      }
    } finally { await handle.close(); }
  }
  // Preserve the admission ledger as evidence; copying it never authorizes a writer.
  for (const relative of ['ssh-channel', 'ssh-operations', 'ssh-admission']) await visit(relative);
  try {
    const framework = await lstat(path.join(root, 'framework'));
    if (!framework.isDirectory() || framework.isSymbolicLink()) throw new Error('SSH_SNAPSHOT_LINK');
    await visit('framework/ssh-revocation.json');
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    absent.push('framework/ssh-revocation.json');
  }
  const endRoot = await lstat(root, { bigint: true });
  if (!endRoot.isDirectory() || endRoot.isSymbolicLink() || endRoot.dev !== rootStat.dev || endRoot.ino !== rootStat.ino) throw new Error('SSH_SNAPSHOT_CHANGED');
  const operations = classifyOperationSnapshots(documents);
  return { version: 1, directories, files, absent, totalBytes: total, operations, writerFence: 'required' };
}

export function compareSshFiles(before, after) {
  if (!before || !after || before.version !== 1 || after.version !== 1 || before.writerFence !== 'required' || after.writerFence !== 'required') throw new Error('SSH_SNAPSHOT_INVALID');
  return JSON.stringify(before) === JSON.stringify(after);
}
