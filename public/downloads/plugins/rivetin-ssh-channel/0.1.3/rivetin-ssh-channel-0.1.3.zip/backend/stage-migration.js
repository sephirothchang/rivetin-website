import { constants } from 'node:fs';
import { copyFile, mkdir, realpath } from 'node:fs/promises';
import path from 'node:path';
import { captureSshFiles, compareSshFiles } from './snapshot.js';
import { verifySshMigration } from './verify-migration.js';

// Creates a new offline staging directory. It never promotes or activates it.
// A fenced, quiescent source and an exclusively controlled parent are required.
export async function stageSshMigration(sourceDirectory, targetDirectory) {
  const source = await realpath(sourceDirectory);
  const target = path.resolve(targetDirectory);
  const parent = await realpath(path.dirname(target));
  if (path.resolve(parent) !== path.resolve(path.dirname(target))) throw new Error('SSH_MIGRATION_PATH_INVALID');
  const overlaps = (a, b) => { const relative = path.relative(a, b); return relative === '' || (!relative.startsWith('..' + path.sep) && relative !== '..' && !path.isAbsolute(relative)); };
  if (overlaps(source, target) || overlaps(target, source)) throw new Error('SSH_MIGRATION_PATH_INVALID');
  const before = await captureSshFiles(source);
  await mkdir(target, { mode: 0o700 });
  for (const directory of before.directories) await mkdir(path.join(target, ...directory.split('/')), { mode: 0o700 });
  for (const file of before.files) {
    const destination = path.join(target, ...file.path.split('/'));
    await mkdir(path.dirname(destination), { recursive: true, mode: 0o700 });
    await copyFile(path.join(source, ...file.path.split('/')), destination, constants.COPYFILE_EXCL);
  }
  const after = await captureSshFiles(source);
  if (!compareSshFiles(before, after)) throw new Error('SSH_MIGRATION_SOURCE_CHANGED');
  return verifySshMigration(source, target);
}
