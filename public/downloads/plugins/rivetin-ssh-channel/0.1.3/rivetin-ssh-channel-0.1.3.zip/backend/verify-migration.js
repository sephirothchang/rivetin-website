import path from 'node:path';
import { createSshVault } from './server/ssh-vault.js';
import { captureSshFiles, compareSshFiles } from './snapshot.js';
import { inspectLegacyBackups } from './legacy-backups.js';
import { createSshAdmission } from './server/ssh-admission.js';

// The independent installer must prove writer fencing and data identity. This
// function only verifies read-only snapshots; it never authorizes activation.
export async function verifySshMigration(sourceDirectory, targetDirectory) {
  const source = path.resolve(sourceDirectory), target = path.resolve(targetDirectory);
  const overlaps = (a, b) => { const relative = path.relative(a, b); return relative === '' || (!relative.startsWith('..' + path.sep) && relative !== '..' && !path.isAbsolute(relative)); };
  if (overlaps(source, target) || overlaps(target, source)) throw new Error('SSH_MIGRATION_PATH_INVALID');
  async function inspect(directory) {
    const before = await captureSshFiles(directory);
    const vault = createSshVault(directory);
    const summary = await vault.v2.connections();
    const legacy = await vault.inspectPreservedLegacy();
    const backups = await inspectLegacyBackups(directory);
    const observed = await createSshAdmission(directory).status();
    const admission = observed.initialized ? { initialized: true, ledgerId: observed.ledgerId,
      sha256: observed.sha256, barrier: observed.barrier, unresolved: observed.unresolved,
      legacyCoverage: observed.legacyCoverage, migrationEligible: observed.migrationEligible } : observed;
    const after = await captureSshFiles(directory);
    if (!compareSshFiles(before, after)) throw new Error('SSH_MIGRATION_SOURCE_CHANGED');
    return { snapshot: after, version: summary.migration.persistedVersion, revision: summary.revision, hostCount: summary.hosts.length, legacy, backups, admission };
  }
  const firstSource = await inspect(source);
  const destination = await inspect(target);
  const lastSource = await inspect(source);
  if (!compareSshFiles(firstSource.snapshot, lastSource.snapshot)) throw new Error('SSH_MIGRATION_SOURCE_CHANGED');
  if (!compareSshFiles(firstSource.snapshot, destination.snapshot) || firstSource.version !== destination.version ||
      firstSource.revision !== destination.revision || firstSource.hostCount !== destination.hostCount ||
      JSON.stringify(firstSource.legacy) !== JSON.stringify(destination.legacy) || JSON.stringify(firstSource.backups) !== JSON.stringify(destination.backups) ||
      JSON.stringify(firstSource.admission) !== JSON.stringify(destination.admission)) throw new Error('SSH_MIGRATION_MISMATCH');
  return { matched: true, version: firstSource.version, revision: firstSource.revision, hostCount: firstSource.hostCount,
    legacy: firstSource.legacy, backups: firstSource.backups, admission: firstSource.admission,
    operations: firstSource.snapshot.operations, writerFence: 'required', activationAuthorized: false };
}
