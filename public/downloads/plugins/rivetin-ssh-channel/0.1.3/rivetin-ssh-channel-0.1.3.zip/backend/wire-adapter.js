// Only authenticated framework calls reach these callbacks. The transport
// checks the peer certificate and envelope before invoking them.
export function createSshWireAdapter({ broker, operations, authorizeOperation, connectionReads = {}, connectionActions = {} }) {
  if (!broker || !operations || typeof authorizeOperation !== 'function') throw new Error('SSH_WIRE_DEPENDENCY_REQUIRED');
  const gate = createQuiescenceGate({ stop: async () => { if (typeof broker.stop !== 'function') throw new Error('SSH_BROKER_STOP_REQUIRED'); await broker.stop(); } });
  const methods = {
    status: { kind: 'read', keys: [], run: (_, actor) => broker.status(actor) },
    results: { kind: 'read', keys: ['pluginId'], run: (input, actor) => broker.results(input.pluginId, actor) },
    review: { kind: 'submit', keys: ['pluginId'], run: (input, actor) => broker.review(input.pluginId, actor) },
    approve: { kind: 'submit', keys: ['acknowledged', 'challenge', 'digest', 'pluginId'], run: (input, actor) => broker.approve(input, actor) },
    revoke: { kind: 'submit', keys: ['pluginId'], run: (input, actor) => broker.revoke(input.pluginId, actor) },
    run: { kind: 'submit', keys: ['commandId', 'pluginId'], run: (input, actor) => broker.run(input.pluginId, input.commandId, actor) },
    operation: { kind: 'observe', keys: [] },
    identityRecent: { kind: 'read', keys: [], identity: true, run: (_, actor) => broker.identity.recent(actor) },
    identityReview: { kind: 'submit', keys: ['hostId'], identity: true, run: (input, actor) => broker.identity.review(input.hostId, actor) },
    identityApprove: { kind: 'submit', keys: ['acknowledged', 'challenge', 'digest'], identity: true, run: (input, actor) => broker.identity.approve(input, actor) },
    identityExecute: { kind: 'submit', keys: ['approvalId', 'digest', 'hostId', 'requestId'], identity: true, run: (input, actor) => broker.identity.execute(input, actor) },
    identityResult: { kind: 'observe', keys: [], identity: true, run: (input, actor, operationId) => broker.identity.result(operationId, actor) },
    connections: { kind: 'read', keys: [], provider: 'connections', run: (_, actor) => connectionReads.connections(actor) },
    policyCapabilities: { kind: 'read', keys: [], provider: 'policyCapabilities', run: (_, actor) => connectionReads.policyCapabilities(actor) },
    deviceInventory: { kind: 'read', keys: ['category', 'hostId'], provider: 'deviceInventory', run: (input, actor) => connectionReads.deviceInventory(input.hostId, input.category, actor) },
    smartTargets: { kind: 'read', keys: [], provider: 'smartTargets', identity: true, run: (_, actor) => connectionReads.smartTargets(actor) },
    smartTargetDetails: { kind: 'read', keys: ['deviceId', 'hostId'], provider: 'smartTargetDetails', identity: true, run: (input, actor) => connectionReads.smartTargetDetails(input.hostId, input.deviceId, actor) },
    selectSmartTarget: { kind: 'read', keys: ['deviceId', 'hostId', 'pluginId'], identity: true, run: (input, actor) => broker.selectSmartTarget(input.pluginId, { hostId: input.hostId, deviceId: input.deviceId }, actor) },
    snapshotSmartSelections: { kind: 'read', keys: ['pluginId'], identity: true, run: (input, actor) => broker.snapshotSmartSelections(input.pluginId, actor) },
    runTarget: { kind: 'submit', keys: ['selection'], identity: true, run: (input, actor, _operationId, options) => broker.runTarget(input.selection, actor, { signal: options?.signal, requireSample: true, returnSample: true }) },
    saveConnections: { kind: 'submit', keys: ['clusters', 'expectedRevision', 'global', 'hosts', 'operationId', 'selectionProofs', 'version'], action: true, run: (input, actor) => connectionActions.saveConnections(input, actor) },
    saveHost: { kind: 'submit', keys: ['profile'], action: true, run: (input, actor) => connectionActions.saveHost(input.profile, actor) },
    removeHost: { kind: 'submit', keys: ['hostId'], action: true, run: (input, actor) => connectionActions.removeHost(input.hostId, actor) },
    preflightDiscover: { kind: 'submit', keys: ['address', 'hostId', 'port'], action: true, run: (input, actor) => connectionActions.preflightDiscover(input, actor) },
    preflightVerify: { kind: 'submit', keys: ['hostId'], action: true, run: (input, actor) => connectionActions.preflightVerify(input, actor) }
  };
  function permitted(call) {
    const actor = call?.caller;
    const method = Object.hasOwn(methods, call?.method) ? methods[call.method] : null;
    return Boolean(call?.capability === 'ssh.channel' && call.interfaceVersion === 1 && method && call.kind === method.kind &&
      actor?.admin === true && actor.source === 'tower' && actor.pluginId === null &&
      typeof actor.id === 'string' && actor.id.length > 0 && actor.id.length <= 128 &&
      (!method.provider || typeof connectionReads[method.provider] === 'function') &&
      (!method.action || typeof connectionActions[call.method] === 'function') &&
      (call.method !== 'identityExecute' || call.input?.requestId === call.operationId) &&
      call.credentialLeaseId === null && call.input && typeof call.input === 'object' && !Array.isArray(call.input) &&
      Object.keys(call.input).sort().join(',') === method.keys.join(','));
  }
  async function authorized(call) {
    if (!permitted(call)) return false;
    if (methods[call.method].identity && call.caller.role !== 'ROOT') return false;
    if (call.kind !== 'observe') return true;
    if (call.caller.role !== 'ROOT' || typeof operations.scope !== 'function') return false;
    try { return await authorizeOperation(call, await originalScope(call)) === true; }
    catch { return false; }
  }
  async function originalScope(call) {
    try { return await operations.scope(call.operationId, call.caller); }
    catch (error) {
      if (call.method !== 'identityResult' || error.message !== 'SSH_OPERATION_NOT_FOUND') throw error;
      const result = await broker.identity.result(call.operationId, call.caller);
      return { method: 'identityExecute', resource: { hostId: result.hostId } };
    }
  }
  return {
    authorize: authorized,
    quiesce: () => gate.close(),
    execute(call, options) { return gate.run(async () => {
      if (!await authorized(call)) throw new Error('SSH_WIRE_DENIED');
      const actor = call.caller;
      if (call.kind === 'observe') {
        if (call.method !== 'identityResult') {
          const scope = await originalScope(call);
          if (scope.method === 'saveConnections') return operations.observeConnectionReceipt(call.operationId, actor);
          return operations.observe(call.operationId, actor);
        }
        const scope = await originalScope(call);
        const result = await methods.identityResult.run(call.input, actor, call.operationId);
        if (result?.hostId !== scope.resource.hostId) throw new Error('SSH_WIRE_DENIED');
        return result;
      }
      const method = methods[call.method];
      if (call.kind === 'read') return method.run(call.input, actor);
      const resource = call.method.startsWith('identity') ? { hostId: call.input.hostId ?? null } : { pluginId: call.method === 'runTarget' ? call.input.selection?.pluginId ?? null : call.input.pluginId ?? null };
      return operations.submit({ operationId: call.operationId, actor, method: call.method, input: call.input, resource },
        () => method.run(call.input, actor, call.operationId, options));
    }); }
  };
}
import { createQuiescenceGate } from './quiescence.js';

