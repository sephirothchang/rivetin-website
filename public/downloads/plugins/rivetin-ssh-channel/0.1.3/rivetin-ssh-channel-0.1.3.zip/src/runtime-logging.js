const CODE = /^[A-Z][A-Z0-9_]{0,79}$/;
const VERSION = /^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?$/;

// Restrict fields so transport errors and credentials cannot leak into logs.
export function createRuntimeLogger({ version, write = line => process.stdout.write(line), now = () => new Date(), intervalMs = 30000, schedule = setInterval, cancel = clearInterval }) {
  if (typeof version !== 'string' || !VERSION.test(version)) throw new Error('SSH_LOG_VERSION_INVALID');
  if (!Number.isInteger(intervalMs) || intervalMs < 1000 || intervalMs > 60000) throw new Error('SSH_LOG_INTERVAL_INVALID');
  let state = 'starting', timer;
  const failures = new Map();
  function emit(event, extra = {}) {
    write(JSON.stringify({ time: now().toISOString(), component: 'rivetin-ssh-channel', version, event, ...extra }) + '\n');
  }
  return {
    start() { if (timer) return; emit('started', { state }); timer = schedule(() => emit('status', { state }), intervalMs); timer?.unref?.(); },
    ready(value) { const next = value ? 'ready' : 'not_ready'; if (state !== next) { state = next; emit('state_changed', { state }); } },
    operation(method, state, operationId) {
      if (!/^[A-Za-z][A-Za-z0-9]{0,40}$/.test(method || '') || !['started', 'completed', 'failed'].includes(state)) return;
      const id = typeof operationId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(operationId) ? operationId : null;
      emit('operation', { method, state, ...(id ? { operationId: id } : {}) });
    },
    failure(code) {
      const safeCode = typeof code === 'string' && CODE.test(code) ? code : 'SSH_INTERNAL_ERROR';
      const time = now().getTime();
      if (failures.has(safeCode) && time - failures.get(safeCode) < intervalMs) return;
      if (failures.size >= 32 && !failures.has(safeCode)) failures.delete(failures.keys().next().value);
      failures.delete(safeCode); failures.set(safeCode, time); emit('failure', { code: safeCode });
    },
    stop() { if (!timer) return; cancel(timer); timer = undefined; state = 'stopped'; emit('stopped', { state }); },
  };
}
