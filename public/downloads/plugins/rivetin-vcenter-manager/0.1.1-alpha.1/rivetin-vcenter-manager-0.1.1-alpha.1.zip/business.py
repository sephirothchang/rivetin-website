"""Fixed VC business entry for the actual trusted carrier; never starts a server."""
import copy
from datetime import datetime, timezone
import ipaddress
import json
from pathlib import Path
import re
import threading
import time
from urllib.parse import urlsplit
import uuid

from server.c1_projection import (ProjectionError, SCHEMA_ID, SCHEMA_VERSION, VISIBLE_SCOPE, discovery_slice,
                                  error_code, probe_facts, projection_schemas, revalidate_snapshot, selected_adaptation)
from server.c1_projection import _instance as instance_info
from server.https_transport import PinnedSoapTransport
from server.management_readonly import ManagementReadConnector, RootDiscoveryConnector
from server.profiles import AdapterError, adaptation, choose_profile
from server.resource_scope import identity
from server.vsphere_readonly import ReadOnlyConnector
from server.operation_contract import METHODS as OPERATION_METHODS, operation_methods
from server.operation_ledger import OperationLedger, operation_id
from server.storage_snapshot import binding_storage_snapshot
from server.retained_observations import binding_retained_observations
from server.durable_operations import DurableOperations
from server.iso_library import IsoLibrary, iso_name
from server.managed_executor import ManagedExecutor
from server.trusted_metadata import validate_context, roots_request, root_definitions, host_credential_definitions
from server.alarm_status_protocol import alarm_status_capability
from server.inventory_diagnostics import annotate as annotate_inventory, carry as carry_inventory


def require(condition, code="CONNECTION_SCHEMA_INVALID"):
    if not condition:
        raise ProjectionError(code)


def exact(value, required, optional=()):
    require(isinstance(value, dict) and set(required) <= set(value) <= set(required) | set(optional))


def text(value, limit=128):
    require(isinstance(value, str) and 0 < len(value) <= limit and not any(ord(char) < 32 or ord(char) == 127 for char in value))
    return value


def business_methods():
    schemas = projection_schemas()
    definitions = operation_methods() | {"readInventory": {"capability": "vmware.inventory.read", "credential": "current", "responseBytes": 4 * 1024 * 1024,
            "schema": {"type": "object", "properties": {
                "connectionId": {"type": "string", "maxLength": 128}, "instanceId": {"type": "string", "maxLength": 128},
                "scopeRevision": {"type": "integer", "minimum": 1, "maximum": 9007199254740991},
                "selected": {"type": "array", "maxItems": 2000, "items": {"type": "object", "properties": {
                    "objectType": {"type": "string", "enum": ["ClusterComputeResource"], "maxLength": 80},
                    "objectId": {"type": "string", "maxLength": 128}}, "required": ["objectType", "objectId"]}},
                "adaptation": {"type": "object", "properties": {
                    "schemaId": {"type": "string", "enum": [SCHEMA_ID], "maxLength": 128},
                    "schemaVersion": {"type": "integer", "minimum": 1, "maximum": 1},
                    "values": schemas["adaptationSchema"], "digest": {"type": "string", "maxLength": 128}},
                    "required": ["schemaId", "schemaVersion", "values"]},
                "probeVersion": {"type": "boolean"}}, "required": ["connectionId", "instanceId", "adaptation", "selected", "scopeRevision"]}}}
    authorize = copy.deepcopy(definitions['readInventory'])
    authorize.update(capability='vmware.scope.authorize', responseBytes=32768)
    authorize['schema']['properties']['authorizationRequest'] = {'type': 'object', 'properties': {
        'version': {'type': 'integer', 'minimum': 1, 'maximum': 1},
        'roots': {'type': 'array', 'maxItems': 32, 'items': {'type': 'object', 'properties': {
            'objectType': {'type': 'string', 'enum': ['Datacenter', 'Folder'], 'maxLength': 80},
            'objectId': {'type': 'string', 'maxLength': 128}, 'purposes': {'type': 'array', 'maxItems': 8,
                'items': {'type': 'string', 'maxLength': 128}}}, 'required': ['objectType', 'objectId', 'purposes']}}},
        'required': ['version', 'roots']}
    authorize['schema']['required'].append('authorizationRequest')
    definitions['authorizeRoots'] = authorize
    parent_alarms = copy.deepcopy(definitions['readInventory'])
    parent_alarms.update(capability='vmware.alarm.read', responseBytes=256 * 1024, authorizationRootsVersion=1)
    definitions['readParentAlarms'] = parent_alarms
    events = copy.deepcopy(definitions['readInventory'])
    events.update(responseBytes=256 * 1024)
    events['schema']['properties']['key'] = {'type': 'object', 'properties': {
        'objectType': {'type': 'string', 'enum': ['ClusterComputeResource', 'HostSystem', 'VirtualMachine'], 'maxLength': 80},
        'objectId': {'type': 'string', 'maxLength': 128}}, 'required': ['objectType', 'objectId']}
    events['schema']['required'].append('key')
    definitions['readEvents'] = events
    snapshots = copy.deepcopy(events)
    snapshots['schema']['properties']['key']['properties']['objectType']['enum'] = ['VirtualMachine']
    definitions['readVmSnapshots'] = snapshots
    host_performance = copy.deepcopy(events)
    host_performance['responseBytes'] = 4096
    host_performance['schema']['properties']['key']['properties']['objectType']['enum'] = ['HostSystem']
    definitions['readHostPerformance'] = host_performance
    definitions['readInventory']['schema']['properties']['isoLookup'] = {
        'type': 'object', 'properties': {'key': snapshots['schema']['properties']['key'],
                                          'name': {'type': 'string', 'maxLength': 120}},
        'required': ['key', 'name'],
    }
    definitions['readInventory']['schema']['properties']['hardwareKey'] = snapshots['schema']['properties']['key']
    definitions['readInventory']['schema']['properties']['datastoreIsoBrowse'] = {
        'type': 'object', 'properties': {'key': snapshots['schema']['properties']['key'],
            'datastore': {'type': 'object', 'properties': {
                'objectType': {'type': 'string', 'enum': ['Datastore']}, 'objectId': {'type': 'string', 'maxLength': 128}},
                'required': ['objectType', 'objectId']},
            'directory': {'type': 'string', 'maxLength': 384}},
        'required': ['key', 'datastore'],
    }
    return definitions


def business_extensions():
    """Fixed descriptor additions for a runtime supporting the FW011 contract."""
    return {'credentialInputs': host_credential_definitions(), 'authorizationRoots': root_definitions()}


class Adapter:
    def __init__(self, config, *, transport_factory=PinnedSoapTransport, executor_factory=ManagedExecutor):
        exact(config, ["targets", "testMode", "dataDirectory", "dataStoreId"])
        operation_id(config['dataStoreId'])
        require(type(config["testMode"]) is bool and isinstance(config["targets"], list) and 0 < len(config["targets"]) <= 4)
        self._targets, self._sessions, self._queries, self._cleanup_errors = {}, {}, {}, set()
        self._factory, self._lock = transport_factory, threading.Lock()
        self._data_directory, self._data_store_id, self._ledger, self._executor_factory = config['dataDirectory'], config['dataStoreId'], None, executor_factory
        for target in config["targets"]:
            exact(target, ["origin", "trustRef", "policyVersion"], ["addresses", "serverName", "caFile", "leafSHA256"])
            origin = text(target["origin"], 512)
            parsed = urlsplit(origin)
            require(parsed.scheme == "https" and parsed.hostname and not parsed.username and not parsed.password and not parsed.path and not parsed.query and not parsed.fragment and parsed.port in (None, 443), "CONNECTION_NETWORK_POLICY_DENIED")
            try:
                host = str(ipaddress.ip_address(parsed.hostname))
            except ValueError:
                raise ProjectionError("CONNECTION_NETWORK_POLICY_DENIED") from None
            require(target.get("addresses", [host]) == [host], "CONNECTION_NETWORK_POLICY_DENIED")
            key = (origin, text(target["trustRef"]), text(target["policyVersion"]))
            require(key not in self._targets, "CONNECTION_NETWORK_POLICY_DENIED")
            self._targets[key] = {"host": host, "observedLeaf": target.get("leafSHA256")}

    def _context(self, context, method):
        exact(context, ["actorId", "pluginId", "packageDigest", "providerId", "attemptId", "connectionId", "instanceId",
                        "credentialVersion", "policyVersion", "connectorRelease", "origin", "trustRef", "capability", "sessionKey", "freshReadRequired"], ["credentialLeaseId", "credentialLeaseActive", "operationContext", "authorizationRoots", "dynamicTarget", "recheckTarget"])
        validate_context(context, method)
        if 'credentialLeaseId' in context or 'credentialLeaseActive' in context:
            text(context.get('credentialLeaseId')); require(type(context.get('credentialLeaseActive')) is bool, 'CONNECTION_PROOF_MISMATCH')
        for name in ("actorId", "pluginId", "providerId", "attemptId", "credentialVersion", "policyVersion", "trustRef"):
            text(context[name])
        require(context["pluginId"] == "rivetin-vcenter-manager", "CONNECTION_PERMISSION_DENIED")
        for name in ("packageDigest", "connectorRelease", "sessionKey"):
            require(isinstance(context[name], str) and re.fullmatch(r"[a-f0-9]{64}", context[name]), "CONNECTION_PROOF_MISMATCH")
        require(type(context["freshReadRequired"]) is bool and (method == "discover" or context["freshReadRequired"]), "CONNECTION_PROOF_MISMATCH")
        if method in ("probe", "discover", "revalidate"):
            capability = "connection.read"
        else:
            require(method in business_methods(), "CONNECTION_MODE_UNSUPPORTED")
            capability = business_methods()[method]["capability"]
            text(context["connectionId"]); text(context["instanceId"])
        require(context["capability"] == capability, "CONNECTION_PERMISSION_DENIED")
        key = (context["origin"], context["trustRef"], context["policyVersion"])
        if "dynamicTarget" in context:
            return context["dynamicTarget"]
        require(key in self._targets, "CONNECTION_NETWORK_POLICY_DENIED")
        return self._targets[key]

    def _remaining(self, deadline_ms):
        require(type(deadline_ms) is int, "CONNECTION_TIMEOUT")
        remaining = deadline_ms / 1000 - time.time()
        require(0 < remaining <= 15, "CONNECTION_TIMEOUT")
        return remaining

    def _resolved(self, value):
        exact(value, ["schemaId", "schemaVersion", "values"], ["digest"])
        require(value["schemaId"] == SCHEMA_ID and value["schemaVersion"] == SCHEMA_VERSION, "CONNECTION_ADAPTATION_UNSUPPORTED")
        return selected_adaptation(value["values"])["values"]

    def _session(self, context, target, deadline_ms, soap_path):
        now = time.monotonic()
        for key in list(self._sessions):
            if self._sessions[key]["expires"] <= now:
                self._drop(key)
        key = context["sessionKey"]
        session = self._sessions.get(key)
        if session:
            require(session["binding"] == {name: value for name, value in context.items() if name not in ("instanceId", "freshReadRequired", "recheckTarget")} and session["transport"].path == soap_path, "CONNECTION_PROOF_MISMATCH")
        else:
            require(len(self._sessions) < 8, "CONNECTION_BUSY")
            remaining = self._remaining(deadline_ms)
            transport = self._factory(target["host"], target["observedLeaf"], None, seconds=remaining, max_calls=40, soap_path=soap_path)
            session = {"transport": transport, "binding": {name: value for name, value in context.items() if name not in ("instanceId", "freshReadRequired", "recheckTarget")}, "expires": now + 120, "instanceId": None, "query": None}
            self._sessions[key] = session
        session["transport"].begin_call(self._remaining(deadline_ms))
        return session

    def observe_target(self, call_context, deadline_ms):
        """Observe the selected peer without resolving task credentials."""
        require(self._lock.acquire(blocking=False), "CONNECTION_BUSY")
        try:
            target = self._context(call_context, "probe")
            session = self._session(call_context, target, deadline_ms, "/sdk")
            return session["transport"].observe_peer(min(15, self._remaining(deadline_ms)))
        finally:
            self._lock.release()

    def _read(self, session, context, secret, deadline_ms, values, management=False, selected=None):
        exact(secret, ["username", "password"])
        text(secret["username"], 4096); text(secret["password"], 4096)
        remaining = self._remaining(deadline_ms)
        require(remaining > 0.1, "CONNECTION_TIMEOUT")
        kind = ManagementReadConnector if management else RootDiscoveryConnector
        connector = kind(session["transport"], seconds=min(remaining, 15), max_calls=37)
        if values is not None:
            connector.config = copy.deepcopy(values)
        recheck = context.get("recheckTarget")
        if recheck is None:
            about = connector.service_content()["about"]
        else:
            for attempt in range(8):
                recheck()
                remaining = self._remaining(deadline_ms)
                session["transport"].begin_call(min(remaining, 1.5))
                try:
                    about = connector.service_content()["about"]
                    break
                except AdapterError as error:
                    if error.code not in {"VC_TIMEOUT", "VC_TRANSPORT_UNAVAILABLE"} or attempt == 7:
                        raise
                    time.sleep(min(0.25, self._remaining(deadline_ms)))
            session["transport"].begin_call(self._remaining(deadline_ms))
        profile = choose_profile(about)  # reject a direct ESXi before sending its credentials
        current = about["instanceUuid"]
        if context["instanceId"] is not None:
            require(current == context["instanceId"], "CONNECTION_INSTANCE_CHANGED")
        if session["instanceId"] is not None:
            require(current == session["instanceId"], "CONNECTION_INSTANCE_CHANGED")
        resolved = adaptation(profile, values)
        connector.config = resolved
        if not session["transport"].authenticated:
            if recheck is not None:
                self._remaining(deadline_ms)
                recheck()
            session["transport"].login(connector.service["sessionManager"], lambda _: (secret["username"], secret["password"]), about["apiVersion"])
        session["instanceId"] = current
        snapshot = connector.inventory_selected(selected) if management else connector.inventory()
        require(self._remaining(deadline_ms) > 0, "CONNECTION_TIMEOUT")
        return snapshot, resolved

    def dispatch(self, method, payload, secret, call_context, deadline_ms, *, credential_inputs=None):
        require(self._lock.acquire(blocking=False), "CONNECTION_BUSY")
        try:
            target = self._context(call_context, method)
            self._remaining(deadline_ms)
            require(isinstance(payload, dict))
            parent_roots = validate_context(call_context, method, payload, credential_inputs)
            if method in OPERATION_METHODS:
                return self._operation(method, payload, secret, call_context, target, deadline_ms, parent_roots=parent_roots, credential_inputs=credential_inputs)
            if method in {'readEvents', 'readVmSnapshots', 'readHostPerformance'}:
                return self._read_resource(method, payload, secret, call_context, target, deadline_ms)
            if method == 'readInventory' and 'isoLookup' in payload:
                return self._read_resource('isoLookup', payload, secret, call_context, target, deadline_ms)
            if method == 'readInventory' and 'hardwareKey' in payload:
                return self._read_resource('hardwareCapabilities', payload, secret, call_context, target, deadline_ms)
            if method == 'readInventory' and 'datastoreIsoBrowse' in payload:
                return self._read_resource('datastoreIsoBrowse', payload, secret, call_context, target, deadline_ms)
            if method in {'authorizeRoots', 'readParentAlarms'}:
                return self._authorize_roots(payload, secret, call_context, target, deadline_ms)
            if method == "readInventory" and payload.get("probeVersion") is True:
                exact(payload, ["connectionId", "instanceId", "adaptation", "selected", "scopeRevision", "probeVersion"])
                require(payload["instanceId"] == call_context["instanceId"], "CONNECTION_INSTANCE_CHANGED")
                require(payload["connectionId"] == call_context["connectionId"], "CONNECTION_PROOF_MISMATCH")
                require(type(payload["scopeRevision"]) is int and 1 <= payload["scopeRevision"] <= 9007199254740991)
                require(isinstance(payload["selected"], list) and len(payload["selected"]) <= 2000, "CONNECTION_PERMISSION_DENIED")
                values = self._resolved(payload["adaptation"])
                session = self._session(call_context, target, deadline_ms, values["soapBase"])
                try:
                    exact(secret, ["username", "password"])
                    text(secret["username"], 4096); text(secret["password"], 4096)
                    remaining = self._remaining(deadline_ms)
                    require(remaining > 0.1, "CONNECTION_TIMEOUT")
                    connector = RootDiscoveryConnector(session["transport"], seconds=min(remaining, 15), max_calls=8)
                    connector.config = copy.deepcopy(values)
                    about = connector.service_content()["about"]
                    require(about["instanceUuid"] == payload["instanceId"], "CONNECTION_INSTANCE_CHANGED")
                    if not session["transport"].authenticated:
                        session["transport"].login(connector.service["sessionManager"],
                                                   lambda _: (secret["username"], secret["password"]), about["apiVersion"])
                    version = connector.inventory_version()
                    require(self._remaining(deadline_ms) > 0, "CONNECTION_TIMEOUT")
                    return {"data": {"version": version, "at": datetime.now(timezone.utc).isoformat()}}
                finally:
                    self._drop(call_context["sessionKey"])
            if method == "probe":
                exact(payload, ["candidate"])
                candidate = payload["candidate"]
                exact(candidate, ["label", "origin", "tls", "adaptation"])
                exact(candidate["tls"], ["trustRef"])
                require(candidate["origin"] == call_context["origin"] and candidate["tls"]["trustRef"] == call_context["trustRef"], "CONNECTION_PROOF_MISMATCH")
                request = candidate["adaptation"]
                exact(request, ["mode", "schemaId", "schemaVersion", "values"])
                require(request["mode"] in ("auto", "manual"))
                values = self._resolved({key: request[key] for key in ("schemaId", "schemaVersion", "values")})
                manual = values if request["mode"] == "manual" else None
                session = self._session(call_context, target, deadline_ms, values["soapBase"] if manual else "/sdk")
                snapshot, resolved = self._read(session, call_context, secret, deadline_ms, manual)
                data = probe_facts(snapshot, resolved, authentication="authenticated", authorization="partial", visible_scope=VISIBLE_SCOPE, observed_apis=["soap"], manual=manual)
                return {"data": data}
            if method == "discover":
                exact(payload, ["instanceId", "adaptation", "filter", "cursor", "limit"])
                require(payload["instanceId"] == call_context["instanceId"], "CONNECTION_INSTANCE_CHANGED")
                values = self._resolved(payload["adaptation"])
                session = self._session(call_context, target, deadline_ms, values["soapBase"])
                require(session["instanceId"] == payload["instanceId"], "CONNECTION_INSTANCE_CHANGED")
                cursor = payload["cursor"]
                if cursor is None:
                    if session["query"]:
                        self._queries.pop(session["query"], None)
                    snapshot, _ = self._read(session, call_context, secret, deadline_ms, values)
                    query_id, offset = str(uuid.uuid4()), 0
                    self._queries[query_id] = {"snapshot": snapshot, "binding": call_context["sessionKey"], "expires": time.monotonic() + 60}
                    session["query"] = query_id
                else:
                    exact(cursor, ["queryId", "offset"])
                    query_id, offset = cursor["queryId"], cursor["offset"]
                    require(query_id == session["query"] and query_id in self._queries, "CONNECTION_PROOF_MISMATCH")
                query = self._queries[query_id]
                require(query["binding"] == call_context["sessionKey"] and query["expires"] > time.monotonic(), "CONNECTION_PROOF_EXPIRED")
                result = discovery_slice(query["snapshot"], payload["instanceId"], authentication="authenticated", authorization="partial", filter_value=payload["filter"], offset=offset, limit=payload["limit"])
                next_offset = result.pop("nextOffset")
                continuation = None if next_offset is None else {"queryId": query_id, "offset": next_offset}
                result["nextCursor"] = None  # actual carrier signs continuation before C1 consumes this page
                if continuation is None:
                    self._queries.pop(query_id, None); session["query"] = None
                return {"data": result, "continuation": continuation}
            if method in ("revalidate", "readInventory"):
                required = ["instanceId", "selected", "candidate", "adaptation"] if method == "revalidate" else ["connectionId", "instanceId", "adaptation", "selected", "scopeRevision"]
                exact(payload, required)
                require(payload["instanceId"] == call_context["instanceId"], "CONNECTION_INSTANCE_CHANGED")
                if method == "readInventory":
                    require(payload["connectionId"] == call_context["connectionId"], "CONNECTION_PROOF_MISMATCH")
                    require(type(payload["scopeRevision"]) is int and 1 <= payload["scopeRevision"] <= 9007199254740991)
                    require(isinstance(payload["selected"], list) and bool(payload["selected"]), "CONNECTION_PERMISSION_DENIED")
                    require(len(payload["selected"]) <= 2000, "CONNECTION_LIMIT_EXCEEDED")
                    keys = [identity(key, "ClusterComputeResource") for key in payload["selected"]]
                    require(len(set(keys)) == len(keys), "CONNECTION_PERMISSION_DENIED")
                else:
                    require(payload["candidate"].get("origin") == call_context["origin"] and payload["candidate"].get("tls", {}).get("trustRef") == call_context["trustRef"], "CONNECTION_PROOF_MISMATCH")
                values = self._resolved(payload["adaptation"])
                session = self._session(call_context, target, deadline_ms, values["soapBase"])
                try:
                    snapshot, _ = self._read(session, call_context, secret, deadline_ms, values, management=method == "readInventory", selected=payload.get("selected"))
                except BaseException:
                    if method == "readInventory":
                        try:
                            self._drop(call_context["sessionKey"])
                        except AdapterError:
                            pass  # _drop retains cleanup codes; preserve the original read failure.
                    raise
                if method == "readInventory":
                    # Each business call has a new framework attempt; no cursor needs this login.
                    self._drop(call_context["sessionKey"])
                if method == "revalidate":
                    return {"data": revalidate_snapshot(snapshot, payload["instanceId"], payload["selected"], authentication="authenticated", authorization="partial")}
                data = {"connectionId": payload["connectionId"], "instanceId": payload["instanceId"], "observedAt": snapshot["observedAt"], "complete": snapshot["complete"],
                        "instanceInfo": instance_info(snapshot["about"], payload["instanceId"]),
                        "objects": snapshot["objects"], "capabilities": {"vmPower": "unsupported", "alarmReset": "metadata-profile" if alarm_status_capability(snapshot['about']) else "unsupported"}}
                require(len(json.dumps(data, ensure_ascii=False).encode("utf-8")) <= 4 * 1024 * 1024 - 16384, "CONNECTION_LIMIT_EXCEEDED")
                return {"data": data}
            raise ProjectionError("CONNECTION_MODE_UNSUPPORTED")
        except AdapterError as error:
            extra = {"VC_TLS_IDENTITY_CHANGED": "CONNECTION_TLS_IDENTITY_CHANGED", "VC_TLS_TRUST_REQUIRED": "CONNECTION_TLS_TRUST_REQUIRED", "VC_TARGET_INVALID": "CONNECTION_NETWORK_POLICY_DENIED"}
            projected = ProjectionError(extra.get(error.code, error_code(error)))
            if method == 'readInventory':
                annotate_inventory(error, 0)
                carry_inventory(error, projected)
            raise projected from None
        except ProjectionError as error:
            if method == 'readInventory' and error.code == 'CONNECTION_RESPONSE_INVALID':
                annotate_inventory(error, 5)
            raise
        finally:
            self._lock.release()

    def _read_resource(self, method, payload, secret, context, target, deadline_ms):
        lookup = method == 'isoLookup'
        hardware = method == 'hardwareCapabilities'
        browsing = method == 'datastoreIsoBrowse'
        key_field = 'isoLookup' if lookup else 'datastoreIsoBrowse' if browsing else 'hardwareKey' if hardware else 'key'
        exact(payload, ['connectionId', 'instanceId', 'adaptation', 'selected', 'scopeRevision', key_field])
        if lookup:
            exact(payload['isoLookup'], ['key', 'name'])
            key = payload['isoLookup']['key']
            identity(key, 'VirtualMachine')
            name = iso_name(payload['isoLookup']['name'])
        elif browsing:
            selection = payload[key_field]
            exact(selection, ['key', 'datastore'], ['directory'])
            key = selection['key']
            identity(key, 'VirtualMachine')
            identity(selection['datastore'], 'Datastore')
            directory = text(selection['directory'], 384) if 'directory' in selection else ''
        else:
            key = payload[key_field]
            if hardware:
                identity(key, 'VirtualMachine')
        require(payload['connectionId'] == context['connectionId'] and payload['instanceId'] == context['instanceId'], 'CONNECTION_INSTANCE_CHANGED')
        require(type(payload['scopeRevision']) is int and 1 <= payload['scopeRevision'] <= 9007199254740991)
        require(isinstance(payload['selected'], list) and 0 < len(payload['selected']) <= 2000, 'CONNECTION_PERMISSION_DENIED')
        keys = [identity(key, 'ClusterComputeResource') for key in payload['selected']]
        require(len(set(keys)) == len(keys), 'CONNECTION_PERMISSION_DENIED')
        identity(key)
        values = self._resolved(payload['adaptation'])
        session, library, primary_error = None, None, None
        try:
            exact(secret, ['username', 'password']); text(secret['username'], 4096); text(secret['password'], 4096)
            session = self._session(context, target, deadline_ms, values['soapBase'])
            connector = ReadOnlyConnector(session['transport'], seconds=min(15, self._remaining(deadline_ms)))
            connector.config = copy.deepcopy(values)
            about = connector.service_content()['about']; choose_profile(about)
            require(about.get('instanceUuid') == payload['instanceId'], 'CONNECTION_INSTANCE_CHANGED')
            if not session['transport'].authenticated:
                session['transport'].login(connector.service['sessionManager'], lambda _: (secret['username'], secret['password']), about['apiVersion'])
            executor = self._executor_factory(Path(__file__).resolve().parent, session['transport'], about['apiVersion'], payload['instanceId'], secret['username'], payload['selected'], payload['scopeRevision'], seconds=min(15, self._remaining(deadline_ms)))
            result = {field: payload[field] for field in ('connectionId', 'instanceId', 'scopeRevision')} | {'key': key}
            if method == 'readVmSnapshots':
                identity(payload['key'], 'VirtualMachine')
                result.update(executor.snapshot_tree(payload['key']))
            elif method == 'readHostPerformance':
                identity(payload['key'], 'HostSystem')
                result.update(executor.read_host_performance(payload['key']))
            elif lookup:
                library = executor.iso_library = IsoLibrary(session['transport'], lambda: (secret['username'], secret['password']))
                result['items'] = executor.lookup_library_iso(key, name)
            elif hardware:
                result['options'] = executor.read_hardware_capabilities(key)
            elif browsing:
                result.update(executor.browse_datastore_iso(key, selection['datastore'], directory))
            else: result['items'] = executor.read_events(payload['key'])
            result['observedAt'] = datetime.now(timezone.utc).isoformat()
            require(len(json.dumps(result, ensure_ascii=False).encode()) <= 240 * 1024, 'CONNECTION_LIMIT_EXCEEDED')
            self._remaining(deadline_ms)
            return {'data': result}
        except BaseException as error:
            primary_error = error
            raise
        finally:
            self._close_resource_sessions(context, session, library, primary_error)

    def _close_resource_sessions(self, context, session, library, primary_error):
        try:
            if library is not None:
                library.close()
        except AdapterError:
            if primary_error is None:
                raise
        finally:
            if session is not None:
                try:
                    self._drop(context['sessionKey'])
                except AdapterError:
                    if primary_error is None:
                        raise

    def _authorize_roots(self, payload, secret, context, target, deadline_ms):
        reading = context['capability'] == 'vmware.alarm.read'
        exact(payload, ['connectionId', 'instanceId', 'adaptation', 'selected', 'scopeRevision'] + ([] if reading else ['authorizationRequest']))
        require(payload['connectionId'] == context['connectionId'] and payload['instanceId'] == context['instanceId'], 'CONNECTION_PROOF_MISMATCH')
        require(type(payload['scopeRevision']) is int and payload['scopeRevision'] >= 1)
        require(isinstance(payload['selected'], list) and len(payload['selected']) <= 2000)
        selected = [identity(row, 'ClusterComputeResource') for row in payload['selected']]
        require(bool(selected) and len(set(selected)) == len(selected), 'CONNECTION_PERMISSION_DENIED')
        if reading:
            require('authorizationRoots' in context, 'CONNECTION_MODE_UNSUPPORTED')
            roots = validate_context(context, 'readParentAlarms', payload)
        else:
            request = payload['authorizationRequest']; exact(request, ['version', 'roots'])
            require(type(request['version']) is int and request['version'] == 1)
            roots = roots_request(request['roots'])
        values = self._resolved(payload['adaptation'])
        session, primary_error = None, None
        try:
            exact(secret, ['username', 'password']); text(secret['username'], 4096); text(secret['password'], 4096)
            session = self._session(context, target, deadline_ms, values['soapBase'])
            connector = ReadOnlyConnector(session['transport'], seconds=min(15, self._remaining(deadline_ms)))
            connector.config = copy.deepcopy(values)
            about = connector.service_content()['about']; choose_profile(about)
            require(about.get('instanceUuid') == payload['instanceId'], 'CONNECTION_INSTANCE_CHANGED')
            if not session['transport'].authenticated:
                session['transport'].login(connector.service['sessionManager'], lambda _: (secret['username'], secret['password']), about['apiVersion'])
            options = {'seconds': min(15, self._remaining(deadline_ms))}
            if reading: options['parent_roots'] = roots
            executor = self._executor_factory(Path(__file__).resolve().parent, session['transport'], about['apiVersion'], payload['instanceId'], secret['username'], payload['selected'], payload['scopeRevision'], **options)
            result = {'version': 1, 'entities': executor.parent_alarm_entities(), 'rootCandidates':executor.parent_root_candidates(), 'alarmResetProfile':alarm_status_capability(executor.service.about)} if reading else executor.authorize_roots(roots)
            require(len(json.dumps(result,ensure_ascii=False).encode())<=240*1024,'CONNECTION_LIMIT_EXCEEDED')
            self._remaining(deadline_ms)
            return {'data': result | {name: payload[name] for name in ('connectionId', 'instanceId', 'scopeRevision')}}
        except BaseException as error:
            primary_error = error
            raise
        finally:
            if session is not None:
                try:
                    self._drop(context['sessionKey'])
                except AdapterError:
                    if primary_error is None:
                        raise

    def _operation(self, method, payload, secret, context, target, deadline_ms, *, parent_roots=(), credential_inputs=None):
        fields = ['connectionId', 'instanceId', 'adaptation', 'selected', 'scopeRevision']
        if method == 'prepareOperation':
            fields += ['key', 'operation', 'parameters']
        elif method == 'listOperations':
            if 'beforeId' in payload:
                fields += ['beforeId']
        elif method != 'recoverOperations':
            fields += ['operationId']
            if method == 'submitOperation':
                fields += ['planRef']
        exact(payload, fields)
        require(payload['connectionId'] == context['connectionId'] and payload['instanceId'] == context['instanceId'], 'CONNECTION_PROOF_MISMATCH')
        require(type(payload['scopeRevision']) is int and payload['scopeRevision'] >= 1)
        require(isinstance(payload['selected'], list) and len(payload['selected']) <= 2000, 'CONNECTION_PERMISSION_DENIED')
        selected = [identity(key, 'ClusterComputeResource') for key in payload['selected']]
        require(len(set(selected)) == len(selected), 'CONNECTION_PERMISSION_DENIED')
        bindings = context.get('operationContext', {}).get('credentialInputBindings', [])
        if method == 'prepareOperation':
            require(bool(bindings) == (payload['operation'] == 'host.add'), 'CONNECTION_PERMISSION_DENIED')
        if self._ledger is None:
            self._ledger = OperationLedger(self._data_directory, store_id=self._data_store_id)
        operations = DurableOperations(self._ledger, None)
        if method == 'listOperations':
            exact(secret, [])
            require(bool(selected or parent_roots), 'CONNECTION_PERMISSION_DENIED')
            return {'data': self._ledger.history(context, payload['scopeRevision'], payload['selected'], parent_roots, payload.get('beforeId'))}
        if method == 'readOperation':
            exact(secret, [])
            if not selected:
                self._ledger.credential_binding(context, payload['operationId'], require_active=False)
            return operations.read(context, payload['operationId'])
        if method == 'recoverOperations':
            exact(secret, [])
            require(bool(selected), 'CONNECTION_PERMISSION_DENIED')
            return operations.recover(context)
        require(bool(selected), 'CONNECTION_PERMISSION_DENIED')
        identifier = payload.get('operationId')
        if identifier is not None:
            operation_id(identifier)
        if method == 'submitOperation':
            # Replay never logs in to a target or invokes its native method again.
            existing = self._ledger.read(context, identifier)
            if existing is not None:
                return operations.submit(context, identifier, payload['planRef'])
            try:
                prepared = self._ledger.plan(context, payload['planRef'])
                adding_host = prepared['intent']['operation'] == 'host.add'
                require(adding_host == bool(bindings) and adding_host == (credential_inputs is not None), 'CONNECTION_PERMISSION_DENIED')
            except AdapterError as error:
                return {'data': {'kind': 'not-accepted', 'operationId': identifier, 'errorCode': error.code}, 'credentialLease': 'release'}
        if method == 'refreshOperation':
            record = self._ledger.read(context, identifier)
            if record is not None and record['state'] in {'success', 'error', 'rejected'}:
                return operations.response(record)
            self._ledger.credential_binding(context, identifier)
        values = self._resolved(payload['adaptation'])
        session, library, primary_error = None, None, None
        try:
            exact(secret, ['username', 'password']); text(secret['username'], 4096); text(secret['password'], 4096)
            session = self._session(context, target, deadline_ms, values['soapBase'])
            connector = ReadOnlyConnector(session['transport'], seconds=min(15, self._remaining(deadline_ms)))
            connector.config = copy.deepcopy(values)
            about = connector.service_content()['about']
            choose_profile(about)
            require(about.get('instanceUuid') == payload['instanceId'], 'CONNECTION_INSTANCE_CHANGED')
            if not session['transport'].authenticated:
                session['transport'].login(connector.service['sessionManager'], lambda _: (secret['username'], secret['password']), about['apiVersion'])
            executor_options = {'seconds': min(15, self._remaining(deadline_ms))}
            if 'authorizationRoots' in context:
                executor_options['parent_roots'] = parent_roots
            if credential_inputs is not None:
                executor_options['credential_inputs'] = credential_inputs
            executor = self._executor_factory(Path(__file__).resolve().parent, session['transport'], about['apiVersion'], payload['instanceId'], secret['username'], payload['selected'], payload['scopeRevision'], **executor_options)
            library = executor.iso_library = IsoLibrary(session['transport'], lambda: (secret['username'], secret['password']))
            operations = DurableOperations(self._ledger, executor)
            if method == 'prepareOperation':
                request = {key: payload[key] for key in ('connectionId', 'instanceId', 'key', 'operation', 'parameters', 'scopeRevision')}
                return operations.prepare(context, request)
            if method == 'submitOperation':
                return operations.submit(context, identifier, payload['planRef'])
            return operations.refresh(context, identifier)
        except AdapterError as error:
            primary_error = error
            if method == 'submitOperation' and self._ledger.read(context, identifier) is None:
                return {'data': {'kind': 'not-accepted', 'operationId': identifier, 'errorCode': error.code}, 'credentialLease': 'release'}
            raise
        except BaseException as error:
            primary_error = error
            raise
        finally:
            self._close_resource_sessions(context, session, library, primary_error)

    def _drop(self, key):
        session = self._sessions.pop(key)
        if session["query"]:
            self._queries.pop(session["query"], None)
        try:
            session["transport"].logout()
        except AdapterError as error:
            self._cleanup_errors.add(error_code(error))
            raise

    def close(self):
        with self._lock:
            for key in list(self._sessions):
                try:
                    self._drop(key)
                except AdapterError as error:
                    self._cleanup_errors.add(error_code(error))
            if self._ledger is not None:
                self._ledger.close(); self._ledger = None
        return {"closed": not self._cleanup_errors, "cleanupErrors": sorted(self._cleanup_errors)}


def create_adapter(config):
    return Adapter(config)


def initialize_storage(config):
    """Fixed local bootstrap hook, never dispatched from a browser or RPC method."""
    exact(config, ['dataDirectory', 'dataStoreId'])
    return OperationLedger.initialize(config['dataDirectory'], config['dataStoreId'])
