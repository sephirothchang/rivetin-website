"""Start the VC backend from the plugin's own Runtime payload."""
import json
import os
from pathlib import Path
import re
import sys


def main():
    root = Path(__file__).resolve().parent
    identity = {name: os.environ.get(name, '') for name in
                ('RIVETIN_INSTANCE_ID', 'RIVETIN_GENERATION', 'RIVETIN_POD_UID')}
    if (not re.fullmatch(r'[A-Za-z0-9-]{1,128}', identity['RIVETIN_INSTANCE_ID'])
            or not re.fullmatch(r'[1-9][0-9]{0,14}', identity['RIVETIN_GENERATION'])
            or not re.fullmatch(r'[A-Za-z0-9-]{1,128}', identity['RIVETIN_POD_UID'])):
        raise ValueError('VC_RUNTIME_IDENTITY_REQUIRED')
    os.execve('/usr/local/bin/node', ['/usr/local/bin/node',
              str(root / 'scripts/pod-backend.mjs'), '/run/rivetin/runtime/backend.json'],
              {'PATH': '/usr/local/bin:/usr/bin:/bin', **identity,
               'RIVETIN_WORKLOAD_ID': identity['RIVETIN_INSTANCE_ID']})


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError) as error:
        version = json.loads(Path(__file__).with_name('metadata').read_bytes())['version']
        print(json.dumps({
            'level': 'ERROR', 'component': 'rivetin-vcenter-manager', 'version': version,
            'event': 'startup-failed', 'stage': 'runtime-entrypoint',
            'errorCode': 'VC_RUNTIME_IDENTITY_REQUIRED' if isinstance(error, ValueError) else 'VC_RUNTIME_NODE_EXEC_FAILED',
        }), file=sys.stderr)
        raise SystemExit(78) from None
