import https from 'node:https';
import { createHash } from 'node:crypto';
import { writeSync } from 'node:fs';
import { Readable } from 'node:stream';
import { FRAMEWORK_VERSION } from '../shared/version.js';

const recent = new Map();
const validHash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);

export function observeEndpoint({ protocol, target, sha256, expected, trusted }) {
  const fingerprint = validHash(sha256) ? sha256 : null;
  const key = `${protocol}:${target}`;
  const previous = recent.get(key);
  const reference = validHash(expected) ? expected : previous?.fingerprint;
  const hint = !fingerprint ? 'unavailable' : reference && fingerprint !== reference ? 'changed' :
    trusted === false ? 'untrusted' : reference ? 'unchanged' : 'observed';
  const status = `${hint}:${fingerprint}`;
  if (previous?.status !== status) {
    if (recent.size >= 128) recent.delete(recent.keys().next().value);
    recent.set(key,{status,fingerprint:fingerprint ?? previous?.fingerprint});
    try { writeSync(2,JSON.stringify({time:new Date().toISOString(),level:'INFO',component:'rivetin-framework',version:FRAMEWORK_VERSION,phase:'connection-observation',state:hint,errorCode:null,protocol,hint,sha256:fingerprint})+'\n'); } catch {}
  }
  return { sha256:fingerprint, hint };
}

export function observeTlsSocket(socket, target, expected) {
  let sha256;
  try {
    const raw = socket.getPeerCertificate()?.raw;
    if (raw?.length) sha256 = createHash('sha256').update(raw).digest('hex');
  } catch {}
  return observeEndpoint({protocol:'tls',target,sha256,expected,trusted:socket.authorized});
}

export function observeHttpsRequest(request, target, expected) {
  request.once('socket', socket => socket.once('secureConnect', () => observeTlsSocket(socket,target,expected)));
  return request;
}

// Used only for the explicitly selected HTTPS endpoint. Redirects are returned to the caller and never followed.
export function observedFetch(url, options = {}, { expected } = {}) {
  if (url.protocol !== 'https:') return fetch(url,options);
  const { method, headers, signal, body } = options;
  return new Promise((resolve,reject) => {
    const request = https.request(url,{method,headers,signal,agent:false,rejectUnauthorized:false,minVersion:'TLSv1.2'}, response => {
      const status = response.statusCode;
      try {
        const bodyStream = [204,205,304].includes(status) ? null : Readable.toWeb(response);
        if (bodyStream === null) response.resume();
        resolve(new Response(bodyStream,{status,headers:response.headers}));
      } catch (error) { response.destroy();reject(error); }
    });
    observeHttpsRequest(request,url.origin,expected).once('error',reject);
    request.end(body);
  });
}
