import { parseConnectionJson } from '../shared/provider-connections.js';

const event = 'provider.adapter.native_rejected';
const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const methodName = /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/;

// Diagnostic configuration cannot affect admission/readiness. Only declared method names are copied.
export function adapterDiagnosticMethods(configBytes) {
  const methods = new Set(['probe', 'discover', 'revalidate']);
  try {
    const catalog = JSON.parse(configBytes.toString('utf8')).businessMethods;
    if (catalog && typeof catalog === 'object' && !Array.isArray(catalog) && Object.keys(catalog).length <= 12) {
      for (const name of Object.keys(catalog)) if (methodName.test(name)) methods.add(name);
    }
  } catch { /* Invalid diagnostic configuration only disables additional method logging. */ }
  return methods;
}

export function createAdapterDiagnosticConsumer({ methods, sink = line => console.error(line) }) {
  let line = [], dropping = false, records = 0;
  function consume() {
    if (!line.length || dropping || records >= 8) return;
    try {
      const value = parseConnectionJson(Buffer.from(line).toString('ascii'), 384);
      if (Object.keys(value).sort().join() !== 'diagnostic,event,method,requestId,schemaVersion' || value.event !== event ||
          value.schemaVersion !== 1 || typeof value.requestId !== 'string' || !uuid.test(value.requestId) ||
          typeof value.method !== 'string' || !methodName.test(value.method) || !methods.has(value.method) ||
          !Array.isArray(value.diagnostic) || value.diagnostic.length !== 6 || value.diagnostic[0] !== 1 ||
          !value.diagnostic.every(id => Number.isInteger(id) && id >= 0 && id <= 255)) return;
      const record = { event, schemaVersion: 1, requestId: value.requestId, method: value.method, diagnostic: [...value.diagnostic] };
      const output = JSON.stringify(record);
      if (Buffer.byteLength(output) > 384) return;
      records++;
      Promise.resolve(sink(output)).catch(() => {});
    } catch { /* Unknown stderr and sink errors never become readiness/business errors. */ }
  }
  return bytes => {
    for (const byte of bytes) {
      if (byte === 10) { consume(); line = []; dropping = false; }
      else if (!dropping) {
        // This protocol is ASCII-only; malformed/split UTF8 cannot be normalized into an accepted record.
        if (byte > 127 || line.length >= 384) { line = []; dropping = true; }
        else line.push(byte);
      }
    }
  };
}
