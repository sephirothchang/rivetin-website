import { spawn } from 'node:child_process';
import { lstat, readFile, realpath } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fields, digest, integer, fail, ConnectionError } from '../shared/provider-connections.js';
import { adapterDiagnosticMethods, createAdapterDiagnosticConsumer } from './provider-adapter-diagnostics.js';

export function createConnectorProcess({ pythonPath, runtimePath, runtimeSHA256, configPath, configSHA256, release,
  verifyReady, verifyWindowsPermissions, startupMs = 10000, stopMs = 2000, maxRestarts = 3, restartDelayMs = 1000, diagnosticSink } = {}) {
  for (const file of [pythonPath, runtimePath, configPath]) if (!path.isAbsolute(file || '')) fail('CONNECTION_SCHEMA_INVALID');
  [runtimeSHA256, configSHA256, release].forEach(digest);
  integer(startupMs, 10, 10000); integer(stopMs, 10, 5000); integer(maxRestarts, 0, 3); integer(restartDelayMs, 1, 5000);
  if (typeof verifyReady !== 'function') fail('CONNECTION_SCHEMA_INVALID');
  let child = null, starting = null, stopped = true, restarts = 0, restartTimer = null, last = 'stopped';
  async function pinned(file, sha, secret = false) {
    const info = await lstat(file);
    if (!info.isFile() || info.isSymbolicLink() || info.nlink !== 1 || path.resolve(await realpath(file)).toLowerCase() !== path.resolve(file).toLowerCase() ||
        process.platform !== 'win32' && (info.mode & (secret ? 0o077 : 0o022))) fail('CONNECTION_STORAGE_PERMISSIONS');
    if (sha) { const data = await readFile(file); if (data.length > 4 * 1024 * 1024 || createHash('sha256').update(data).digest('hex') !== sha) fail('CONNECTION_PROOF_MISMATCH'); return data; }
  }
  async function launch() {
    if (process.platform === 'win32' && (typeof verifyWindowsPermissions !== 'function' || await verifyWindowsPermissions([runtimePath, configPath]) !== true)) fail('CONNECTION_STORAGE_PERMISSIONS');
    await pinned(pythonPath); await pinned(runtimePath, runtimeSHA256);
    const diagnosticMethods = adapterDiagnosticMethods(await pinned(configPath, configSHA256, true));
    if (stopped) fail('CONNECTION_PROVIDER_UNAVAILABLE');
    last = 'starting';
    return new Promise((resolve, reject) => {
      let ready = false, failed = false, exited = false, buffered = '', errorBytes = 0;
      const env = process.platform === 'win32' ? { SystemRoot: process.env.SystemRoot } : {};
      child = spawn(pythonPath, ['-I', '-B', runtimePath, '--config', configPath], { shell: false, windowsHide: true,
        cwd: path.dirname(runtimePath), env, stdio: ['ignore', 'pipe', 'pipe'] });
      const current = child;
      const diagnostic = createAdapterDiagnosticConsumer({ methods: diagnosticMethods, sink: diagnosticSink });
      const timer = setTimeout(() => bad(), startupMs);
      function bad() { failed = true; clearTimeout(timer); last = 'unavailable'; current.kill('SIGTERM'); if (!ready) reject(new ConnectionError('CONNECTION_PROVIDER_UNAVAILABLE')); }
      current.once('error', bad);
      current.stderr.on('data', bytes => { errorBytes += bytes.length; if (errorBytes > 8192) { bad(); return; } diagnostic(bytes); });
      current.stdout.on('data', async bytes => {
        buffered += bytes.toString('utf8'); if (buffered.length > 4096 || ready) { bad(); return; }
        const newline = buffered.indexOf('\n'); if (newline < 0) return;
        try {
          if (buffered.slice(newline + 1).trim()) fail('CONNECTION_RESPONSE_INVALID');
          const info = JSON.parse(buffered.slice(0, newline)); fields(info, ['ready', 'pid', 'port', 'release']);
          integer(info.port, 1, 65535);
          if (info.ready !== true || info.pid !== current.pid || info.release !== release || await verifyReady(info) !== true || stopped || failed || exited) throw new Error();
          ready = true; last = 'ready'; clearTimeout(timer); resolve(info);
        } catch { bad(); }
      });
      current.once('exit', () => {
        exited = true;
        clearTimeout(timer); if (child === current) child = null;
        if (!ready) { last = 'unavailable'; reject(new ConnectionError('CONNECTION_PROVIDER_UNAVAILABLE')); }
        else if (!stopped && restarts < maxRestarts) {
          last = 'restarting'; restarts++;
          restartTimer = setTimeout(() => { startInternal().catch(() => { last = 'unavailable'; }); }, Math.min(5000, restartDelayMs * restarts));
        } else if (!stopped) last = 'unavailable';
      });
    });
  }
  function startInternal() { if (starting) return starting; starting = launch().catch(() => { throw new ConnectionError('CONNECTION_PROVIDER_UNAVAILABLE'); }).finally(() => { starting = null; }); return starting; }
  return Object.freeze({
    start() { if (child) fail('CONNECTION_BUSY'); stopped = false; return startInternal(); },
    state() { return { state: last, pid: child?.pid || null, restarts }; },
    async stop() {
      stopped = true; clearTimeout(restartTimer); const current = child;
      let forced = false;
      if (current) await new Promise((resolve, reject) => {
        let timer, deadline; const done = () => { clearTimeout(timer); clearTimeout(deadline); resolve(); };
        current.once('exit', done); current.kill('SIGTERM');
        timer = setTimeout(() => { forced = true; current.kill('SIGKILL'); }, stopMs);
        deadline = setTimeout(() => { current.removeListener('exit', done); last = 'unavailable'; reject(new ConnectionError('CONNECTION_PROVIDER_UNAVAILABLE')); }, stopMs + 1000);
      });
      last = 'stopped';
      return { forced, pid: current?.pid || null };
    }
  });
}
