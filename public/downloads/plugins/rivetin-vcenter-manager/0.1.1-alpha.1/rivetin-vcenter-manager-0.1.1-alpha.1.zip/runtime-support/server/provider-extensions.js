import { bounded, canonical, fields, identifier, text, uuid, integer, digest, schemaDefinition, validateSchema, fail } from '../shared/provider-connections.js';
import { validateTargetEvidence, targetEvidenceDigest } from './provider-target-evidence.js';

export const methodExtensionFields = ['operationContextVersion', 'authorizationRootsVersion', 'credentialInputs'];
const methodFields = ['responseBytes', 'credential', 'retainCredential', 'observe', ...methodExtensionFields];
const one = value => { if (value !== 1) fail('CONNECTION_SCHEMA_INVALID'); };
function uniqueIdentifiers(values, maximum = 64) {
  if (!Array.isArray(values) || !values.length || values.length > maximum || new Set(values).size !== values.length) fail('CONNECTION_SCHEMA_INVALID');
  values.forEach(identifier); return values;
}
export function validateBusinessMethod(definition) {
  fields(definition, ['capability', 'schema'], methodFields); identifier(definition.capability); schemaDefinition(definition.schema);
  if (definition.responseBytes !== undefined) integer(definition.responseBytes, 1024, 4 * 1024 ** 2);
  if (definition.credential !== undefined && !['current', 'operation', 'none'].includes(definition.credential) ||
      definition.retainCredential !== undefined && typeof definition.retainCredential !== 'boolean' ||
      definition.retainCredential && definition.credential !== 'operation' || definition.observe !== undefined && typeof definition.observe !== 'boolean') fail('CONNECTION_SCHEMA_INVALID');
  for (const key of ['operationContextVersion', 'authorizationRootsVersion']) if (definition[key] !== undefined) one(definition[key]);
  if (definition.credentialInputs !== undefined) {
    fields(definition.credentialInputs, ['version', 'names', 'delivery']); one(definition.credentialInputs.version);
    uniqueIdentifiers(definition.credentialInputs.names, 1);
    if (definition.operationContextVersion !== 1 || !['metadata', 'secret'].includes(definition.credentialInputs.delivery) ||
        definition.credentialInputs.delivery === 'secret' && (definition.credential !== 'operation' || definition.retainCredential !== true || definition.observe === true)) fail('CONNECTION_SCHEMA_INVALID');
  }
  return definition;
}
export function validateProviderExtensions(descriptor) {
  const inputs = descriptor.credentialInputs, roots = descriptor.authorizationRoots, methods = descriptor.businessMethods || {};
  if (inputs !== undefined) {
    fields(inputs, ['version', 'definitions']); one(inputs.version);
    if (!Array.isArray(inputs.definitions) || inputs.definitions.length !== 1) fail('CONNECTION_SCHEMA_INVALID');
    for (const row of inputs.definitions) {
      fields(row, ['name', 'purpose', 'targetTypes', 'secretSchema']); identifier(row.name); identifier(row.purpose); uniqueIdentifiers(row.targetTypes); schemaDefinition(row.secretSchema);
      if (row.secretSchema.type !== 'object') fail('CONNECTION_SCHEMA_INVALID');
    }
    bounded(inputs, 16384);
  }
  if (roots !== undefined) {
    fields(roots, ['version', 'method', 'definitions']); one(roots.version); identifier(roots.method);
    if (!Array.isArray(roots.definitions) || !roots.definitions.length || roots.definitions.length > 64) fail('CONNECTION_SCHEMA_INVALID');
    const seen = new Set();
    for (const row of roots.definitions) {
      fields(row, ['purpose', 'rootTypes']); identifier(row.purpose); uniqueIdentifiers(row.rootTypes);
      if (seen.has(row.purpose)) fail('CONNECTION_SCHEMA_INVALID'); seen.add(row.purpose);
    }
    const verifier = methods[roots.method];
    if (!verifier || verifier.credential !== 'current' || verifier.retainCredential === true || verifier.observe === true || verifier.credentialInputs?.delivery === 'secret') fail('CONNECTION_SCHEMA_INVALID');
    bounded(roots, 16384);
  }
  for (const definition of Object.values(methods)) {
    validateBusinessMethod(definition);
    if (definition.authorizationRootsVersion !== undefined && !roots || definition.credentialInputs && !inputs) fail('CONNECTION_SCHEMA_INVALID');
    if (definition.credentialInputs?.names.some(name => !inputs.definitions.some(row => row.name === name))) fail('CONNECTION_SCHEMA_INVALID');
  }
}
function objectRef(value) { fields(value, ['objectType', 'objectId']); identifier(value.objectType); text(value.objectId, 256); }
export function validateAuthorizationRoots(value) {
  fields(value, ['version', 'connectionId', 'instanceId', 'scopeRevision', 'roots']); one(value.version); uuid(value.connectionId); text(value.instanceId); integer(value.scopeRevision, 1);
  if (!Array.isArray(value.roots) || value.roots.length > 32) fail('CONNECTION_SCHEMA_INVALID');
  const seen = new Set();
  for (const row of value.roots) {
    fields(row, ['objectType', 'objectId', 'grantId', 'grantVersion', 'purposes']); objectRef({ objectType: row.objectType, objectId: row.objectId }); uuid(row.grantId); identifier(row.grantVersion); uniqueIdentifiers(row.purposes, 8);
    const key = canonical([row.objectType, row.objectId]); if (seen.has(key)) fail('CONNECTION_SCHEMA_INVALID'); seen.add(key);
  }
  bounded(value.roots, 16384); return value;
}
export function validateOperationContext(value) {
  fields(value, ['version', 'operationId', 'credentialInputBindings']); one(value.version); uuid(value.operationId);
  if (!Array.isArray(value.credentialInputBindings) || value.credentialInputBindings.length > 1) fail('CONNECTION_SCHEMA_INVALID');
  for (const row of value.credentialInputBindings) {
    fields(row, ['name', 'purpose', 'credentialInputVersion', 'target', 'endpoint', 'targetEvidenceSHA256', 'targetEvidence']);
    identifier(row.name); identifier(row.purpose); identifier(row.credentialInputVersion); objectRef(row.target);
    fields(row.endpoint, ['origin', 'trustRef']); text(row.endpoint.origin, 512); identifier(row.endpoint.trustRef); digest(row.targetEvidenceSHA256);
    validateTargetEvidence(row.targetEvidence);
    if (targetEvidenceDigest(row.targetEvidence) !== row.targetEvidenceSHA256 || row.targetEvidence.origin !== row.endpoint.origin || row.targetEvidence.trustRef !== row.endpoint.trustRef) fail('CONNECTION_PROOF_MISMATCH');
  }
  return value;
}
export function validateBusinessBindings({ definition, descriptor, binding, payload, credentialInputs }) {
  const operation = binding.operationContext, roots = binding.authorizationRoots;
  if (operation !== undefined) {
    if (definition.operationContextVersion !== 1) fail('CONNECTION_MODE_UNSUPPORTED'); validateOperationContext(operation);
    if (payload.operationId !== undefined && payload.operationId !== operation.operationId) fail('CONNECTION_PROOF_MISMATCH');
    for (const row of operation.credentialInputBindings) {
      const declared = descriptor.credentialInputs?.definitions.find(item => item.name === row.name);
      const allowed = definition.credentialInputs?.names.includes(row.name) || definition.observe === true && binding.credentialLeaseId;
      if (!declared || !allowed || declared.purpose !== row.purpose || !declared.targetTypes.includes(row.target.objectType)) fail('CONNECTION_PERMISSION_DENIED');
    }
  }
  if (roots !== undefined) {
    if (definition.authorizationRootsVersion !== 1) fail('CONNECTION_MODE_UNSUPPORTED'); validateAuthorizationRoots(roots);
    if (roots.connectionId !== binding.connectionId || roots.instanceId !== binding.instanceId || roots.scopeRevision !== payload.scopeRevision) fail('CONNECTION_PROOF_MISMATCH');
    for (const row of roots.roots) for (const purpose of row.purposes) {
      if (!descriptor.authorizationRoots?.definitions.some(item => item.purpose === purpose && item.rootTypes.includes(row.objectType))) fail('CONNECTION_PERMISSION_DENIED');
    }
  }
  const inputs = operation?.credentialInputBindings || [];
  if (credentialInputs !== undefined) {
    if (definition.credentialInputs?.delivery !== 'secret' || !binding.credentialLeaseId || binding.credentialLeaseActive !== true || !inputs.length) fail('CONNECTION_PERMISSION_DENIED');
    fields(credentialInputs, inputs.map(row => row.name)); bounded(credentialInputs, 16384);
    for (const row of inputs) validateSchema(credentialInputs[row.name], descriptor.credentialInputs.definitions.find(item => item.name === row.name).secretSchema);
  } else if (inputs.length && definition.credentialInputs?.delivery === 'secret') fail('CONNECTION_CREDENTIAL_VERSION_CONFLICT');
  return true;
}

export function normalizeAuthorizationRequests(roots, descriptor) {
  if (!descriptor.authorizationRoots || !Array.isArray(roots) || roots.length > 32) fail('CONNECTION_SCHEMA_INVALID');
  const seen = new Set(), result = [];
  for (const row of roots) {
    fields(row, ['objectType', 'objectId', 'purposes']); objectRef({ objectType: row.objectType, objectId: row.objectId }); uniqueIdentifiers(row.purposes, 8);
    const key = canonical([row.objectType, row.objectId]); if (seen.has(key)) fail('CONNECTION_SCHEMA_INVALID'); seen.add(key);
    for (const purpose of row.purposes) if (!descriptor.authorizationRoots.definitions.some(item => item.purpose === purpose && item.rootTypes.includes(row.objectType))) fail('CONNECTION_PERMISSION_DENIED');
    result.push({ objectType: row.objectType, objectId: row.objectId, purposes: [...row.purposes].sort() });
  }
  result.sort((a, b) => Buffer.compare(Buffer.from(a.objectType), Buffer.from(b.objectType)) || Buffer.compare(Buffer.from(a.objectId), Buffer.from(b.objectId)));
  bounded(result, 16384); return result;
}
