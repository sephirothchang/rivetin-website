import { ConnectionError, safeErrorCode } from '../shared/provider-connections.js';

const phases = Object.freeze({
  RPC_AUTHORIZATION: 'authorization', RPC_CALL_EXPIRED: 'authorization', RPC_REQUEST: 'request', RPC_CONNECT: 'connect',
  RPC_RESPONSE_TIMEOUT: 'frame', RPC_RESPONSE_IO: 'frame', RPC_FRAME_BUFFER_LIMIT: 'frame', RPC_FRAME_HEADER: 'frame',
  RPC_FRAME_LENGTH: 'frame', RPC_PARSE: 'parse', RPC_ENVELOPE_FIELDS: 'envelope', RPC_VERSION: 'envelope',
  RPC_ID: 'identity', RPC_NONCE: 'identity', RPC_METHOD: 'identity', RPC_BINDING_DIGEST: 'identity', RPC_REQUEST_DIGEST: 'identity',
  RPC_OBSERVED_TYPE: 'time', RPC_OBSERVED_OLD: 'time', RPC_OBSERVED_FUTURE: 'time', RPC_DEADLINE: 'time',
  RPC_ERROR_SHAPE: 'status', RPC_PROVIDER_ERROR: 'status', RPC_OK_SHAPE: 'status', RPC_LEASE: 'lease', RPC_DATA: 'data',
});
const ranges = Object.freeze({ receivedBytes: [0, 4 * 1024 ** 2 + 5], expectedBytes: [0, 4 * 1024 ** 2 + 1],
  responseLimitBytes: [0, 4 * 1024 ** 2], elapsedMs: [0, 60000], observedOffsetMs: [-60000, 60000], remainingMs: [-60000, 15000] });

// Internal process diagnostics only. Construct a new allowlisted record; never serialize an Error or RPC object.
export function emitRpcDiagnostic(input, sink = line => console.error(line)) {
  try {
    if (!Object.hasOwn(phases, input.diagnosticCode) || typeof input.method !== 'string' ||
        !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}$/.test(input.method)) return;
    const record = { event: 'provider.rpc.rejected', schemaVersion: 1, diagnosticCode: input.diagnosticCode,
      phase: phases[input.diagnosticCode], method: input.method, failureCode: safeErrorCode(new ConnectionError(input.failureCode)) };
    if (typeof input.requestId === 'string' && /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(input.requestId)) record.requestId = input.requestId;
    for (const [name, [min, max]] of Object.entries(ranges)) {
      if (typeof input[name] === 'number' && Number.isFinite(input[name])) record[name] = Math.trunc(Math.max(min, Math.min(max, input[name])));
    }
    const line = JSON.stringify(record);
    if (Buffer.byteLength(line) <= 768) Promise.resolve(sink(line)).catch(() => {});
  } catch { /* A diagnostic sink failure must not replace the original RPC rejection. */ }
}
