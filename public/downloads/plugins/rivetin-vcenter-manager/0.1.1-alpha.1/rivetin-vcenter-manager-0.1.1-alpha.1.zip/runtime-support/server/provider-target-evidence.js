import tls from 'node:tls';
import { createHash, X509Certificate } from 'node:crypto';
import { isIP } from 'node:net';
import { observeTlsSocket } from './connection-observation.js';
import { canonical, fields, identifier, digest, text, integer, bounded, ConnectionError, fail } from '../shared/provider-connections.js';

const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const iso = value => new Date(value).toISOString();
function origin(value) {
  text(value, 512); let parsed;
  try { parsed = new URL(value); } catch { fail('CONNECTION_NETWORK_POLICY_DENIED'); }
  if (parsed.protocol !== 'https:' || parsed.origin !== value || parsed.username || parsed.password || parsed.pathname !== '/' || parsed.search || parsed.hash) fail('CONNECTION_NETWORK_POLICY_DENIED');
  return parsed;
}
function timestamp(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(value) || !Number.isFinite(Date.parse(value)) || iso(Date.parse(value)) !== value) fail('CONNECTION_SCHEMA_INVALID');
  return Date.parse(value);
}

/** Validate public evidence without treating it as a new trust grant. */
export function validateTargetEvidence(value) {
  fields(value, ['version', 'kind', 'origin', 'trustRef', 'policyVersion', 'serverName', 'leafDERBase64', 'leafSHA256', 'notBefore', 'notAfter', 'observedAt', 'expiresAt', 'verification']);
  bounded(value, 32768); origin(value.origin); identifier(value.trustRef); identifier(value.policyVersion); text(value.serverName,253);
  fields(value.verification,['mode']);
  const mode = value.verification.mode;
  if (value.version !== 1 || value.kind !== 'tls-peer-leaf' || !['ca-hostname-and-exact-leaf','observed'].includes(mode)) fail('CONNECTION_SCHEMA_INVALID');
  if (value.leafDERBase64 === null && mode === 'observed') {
    if ([value.leafSHA256,value.notBefore,value.notAfter].some(field=>field!==null)) fail('CONNECTION_SCHEMA_INVALID');
  } else {
    digest(value.leafSHA256);
    if (typeof value.leafDERBase64 !== 'string' || value.leafDERBase64.length > 21848) fail('CONNECTION_SCHEMA_INVALID');
    const der = Buffer.from(value.leafDERBase64,'base64');
    if (!der.length || der.length > 16384 || der.toString('base64') !== value.leafDERBase64 || hash(der) !== value.leafSHA256) fail('CONNECTION_PROOF_MISMATCH');
    let certificate;
    try { certificate = new X509Certificate(der); } catch { fail('CONNECTION_PROOF_MISMATCH'); }
    if (!certificate.raw.equals(der) || iso(Date.parse(certificate.validFrom)) !== value.notBefore || iso(Date.parse(certificate.validTo)) !== value.notAfter) fail('CONNECTION_PROOF_MISMATCH');
  }
  if (timestamp(value.expiresAt) <= timestamp(value.observedAt)) fail('CONNECTION_PROOF_EXPIRED');
  // Historical accepted operations retain the original observation, even after expiry.
  return value;
}
export function targetEvidenceDigest(value) { return hash(Buffer.from(canonical(validateTargetEvidence(value)), 'utf8')); }

/** Anonymous TLS handshake to one operator target. Sends no HTTP or credentials. */
export async function probeProviderTargetEvidence({ target, policy, expiresAt, signal, clock = Date.now, timeoutMs = 15000 }) {
  fields(target, ['origin','trustRef','policyVersion','addresses','serverName'], ['caPem','leafSHA256']);
  const url = origin(target.origin); identifier(target.trustRef); identifier(target.policyVersion); text(target.serverName, 253);
  if (typeof policy?.resolveTarget !== 'function' || !Array.isArray(target.addresses) || !target.addresses.length || target.addresses.length > 8) fail('CONNECTION_SCHEMA_INVALID');
  integer(timeoutMs, 1, 15000); integer(expiresAt, 1); const began = clock();
  if (expiresAt <= began) fail('CONNECTION_PROOF_EXPIRED');
  return new Promise((resolve, reject) => {
    let socket, settled = false;
    const finish = (error, value) => {
      if (settled) return; settled = true; clearTimeout(timer); signal?.removeEventListener('abort', abort); socket?.destroy();
      if (error) reject(error); else resolve(value);
    };
    const abort = () => finish(new ConnectionError('CONNECTION_TIMEOUT'));
    const timer = setTimeout(abort, Math.min(timeoutMs, expiresAt - began));
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) { abort(); return; }
    Promise.resolve().then(() => policy.resolveTarget({ origin: target.origin, trustRef: target.trustRef, policyVersion: target.policyVersion })).then(resolved => {
      if (settled) return;
      if (clock() >= Math.min(began + timeoutMs, expiresAt)) { abort(); return; }
      if (!resolved || resolved.origin !== target.origin || resolved.trustRef !== target.trustRef || resolved.policyVersion !== target.policyVersion ||
          !Array.isArray(resolved.addresses) || !resolved.addresses.length || resolved.addresses.some(ip => !target.addresses.includes(ip))) fail('CONNECTION_NETWORK_POLICY_DENIED');
      socket = tls.connect({ host: resolved.addresses[0], port: Number(url.port || 443),
        ...(isIP(target.serverName) ? {} : { servername: target.serverName }),
        rejectUnauthorized: false, minVersion: 'TLSv1.2' });
      socket.on('error', () => finish(new ConnectionError('CONNECTION_PROVIDER_UNAVAILABLE')));
      socket.once('close', () => finish(new ConnectionError('CONNECTION_PROVIDER_UNAVAILABLE')));
      socket.once('secureConnect', () => {
        if (settled) return;
        try {
          if (clock() >= Math.min(began + timeoutMs, expiresAt)) fail('CONNECTION_TIMEOUT');
          observeTlsSocket(socket,target.origin,target.leafSHA256);
          let certificate;
          try {
            const raw = socket.getPeerCertificate()?.raw;
            if (raw?.length && raw.length <= 16384) certificate = new X509Certificate(raw);
          } catch {}
          const evidence = { version:1,kind:'tls-peer-leaf',origin:target.origin,trustRef:target.trustRef,policyVersion:target.policyVersion,
            serverName:target.serverName,leafDERBase64:certificate?.raw.toString('base64') ?? null,leafSHA256:certificate ? hash(certificate.raw) : null,
            notBefore:certificate ? iso(Date.parse(certificate.validFrom)) : null,notAfter:certificate ? iso(Date.parse(certificate.validTo)) : null,
            observedAt:iso(clock()),expiresAt:iso(expiresAt),verification:{mode:'observed'} };
          const targetEvidenceSHA256 = targetEvidenceDigest(evidence);
          finish(null, Object.freeze({ targetEvidence: Object.freeze(evidence), targetEvidenceSHA256 }));
        } catch (error) { finish(error); }
      });
    }).catch(error => finish(error instanceof ConnectionError ? error : new ConnectionError('CONNECTION_NETWORK_POLICY_DENIED')));
  });
}
