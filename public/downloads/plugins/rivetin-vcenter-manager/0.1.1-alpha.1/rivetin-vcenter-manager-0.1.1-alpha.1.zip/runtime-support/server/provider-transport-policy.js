import { validateOperationContext, validateAuthorizationRoots } from './provider-extensions.js';
import { lookup as resolve } from 'node:dns/promises';
import { isIP } from 'node:net';
import { canonical, fields, identifier, uuid, digest, text, fail } from '../shared/provider-connections.js';

export function validateRpcBinding(value) {
  fields(value, ['actorId', 'pluginId', 'packageDigest', 'providerId', 'attemptId', 'connectionId', 'instanceId',
    'credentialVersion', 'policyVersion', 'connectorRelease', 'origin', 'trustRef', 'capability'], ['credentialLeaseId', 'credentialLeaseActive', 'operationContext', 'authorizationRoots']);
  for (const key of ['actorId', 'pluginId', 'providerId', 'policyVersion', 'trustRef', 'capability']) identifier(value[key]);
  for (const key of ['packageDigest', 'connectorRelease']) digest(value[key]);
  uuid(value.attemptId); uuid(value.credentialVersion); if (value.connectionId !== null) uuid(value.connectionId);
  if (value.credentialLeaseId !== undefined) { digest(value.credentialLeaseId); if (typeof value.credentialLeaseActive !== 'boolean') fail('CONNECTION_SCHEMA_INVALID'); }
  else if (value.credentialLeaseActive !== undefined) fail('CONNECTION_SCHEMA_INVALID');
  if (value.instanceId !== null) text(value.instanceId);
  let url; try { url = new URL(value.origin); } catch { fail('CONNECTION_NETWORK_POLICY_DENIED'); }
  if (url.protocol !== 'https:' || url.origin !== value.origin || url.username || url.password || url.search || url.hash || url.pathname !== '/') fail('CONNECTION_NETWORK_POLICY_DENIED');
  if (value.operationContext !== undefined) validateOperationContext(value.operationContext);
  if (value.authorizationRoots !== undefined) validateAuthorizationRoots(value.authorizationRoots);
  return value;
}
export function deniedAddress(address, allowLoopback = false) {
  if (address.startsWith('::ffff:')) return deniedAddress(address.slice(7), allowLoopback);
  if (isIP(address) === 4) {
    const [a, b] = address.split('.').map(Number);
    return a === 0 || a >= 224 || a === 169 && b === 254 || a === 127 && !allowLoopback;
  }
  return isIP(address) !== 6 || address === '::' || address === '::1' && !allowLoopback || /^fe[89ab]/i.test(address) || /^ff/i.test(address);
}
export function createProviderTransportPolicy({ targets, lookup = resolve, allowLoopbackForTests = false } = {}) {
  if (!Array.isArray(targets) || !targets.length || targets.length > 4) fail('CONNECTION_SCHEMA_INVALID');
  const registered = targets.map(target => {
    fields(target, ['origin', 'trustRef', 'policyVersion', 'addresses']);
    if (!Array.isArray(target.addresses) || !target.addresses.length || target.addresses.length > 8 ||
        target.addresses.some(ip => deniedAddress(ip, allowLoopbackForTests))) fail('CONNECTION_NETWORK_POLICY_DENIED');
    identifier(target.trustRef); identifier(target.policyVersion); return structuredClone(target);
  });
  async function resolveTarget(value) {
    fields(value, ['origin', 'trustRef', 'policyVersion']);
    const target = registered.find(row => row.origin === value.origin && row.trustRef === value.trustRef && row.policyVersion === value.policyVersion);
    if (!target) fail('CONNECTION_NETWORK_POLICY_DENIED');
    const hostname = new URL(target.origin).hostname.replace(/^\[|\]$/g, '');
    let addresses;
    try { addresses = isIP(hostname) ? [{ address: hostname }] : await lookup(hostname, { all: true, verbatim: true }); }
    catch { fail('CONNECTION_NETWORK_POLICY_DENIED'); }
    if (!Array.isArray(addresses) || !addresses.length || addresses.length > 8 || addresses.some(row => deniedAddress(row.address, allowLoopbackForTests) || !target.addresses.includes(row.address))) fail('CONNECTION_NETWORK_POLICY_DENIED');
    return Object.freeze({ ...value, addresses: Object.freeze([...new Set(addresses.map(row => row.address))]) });
  }
  return Object.freeze({
    async authorize(binding) {
      validateRpcBinding(binding);
      await resolveTarget({ origin: binding.origin, trustRef: binding.trustRef, policyVersion: binding.policyVersion });
      for (const input of binding.operationContext?.credentialInputBindings || []) {
        const evidence = input.targetEvidence;
        await resolveTarget({ origin: evidence.origin, trustRef: evidence.trustRef, policyVersion: evidence.policyVersion });
      }
      return true;
    },
    resolveTarget,
    fingerprint() { return canonical(registered); }
  });
}
