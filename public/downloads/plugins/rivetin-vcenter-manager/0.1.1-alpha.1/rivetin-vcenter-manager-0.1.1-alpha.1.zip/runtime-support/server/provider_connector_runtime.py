"""Fixed trusted connector carrier. No frontend package execution or ambient credentials."""
import argparse
import base64
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import socket
import ssl
import struct
import sys
import threading
import time
import uuid

MAX_REQUEST = 96 * 1024
MAX_RESPONSE = 4 * 1024 * 1024
METHODS = {"probe", "discover", "revalidate"}
CODES = {"CONNECTION_" + code for code in ("SCHEMA_INVALID", "PERMISSION_DENIED", "PROOF_MISMATCH", "PROOF_EXPIRED", "MODE_UNSUPPORTED", "CREDENTIAL_VERSION_CONFLICT",
    "INSTANCE_CHANGED", "DISCOVERY_INCOMPLETE", "LIMIT_EXCEEDED", "TIMEOUT", "NETWORK_POLICY_DENIED", "TLS_TRUST_REQUIRED",
    "TLS_IDENTITY_CHANGED", "AUTHENTICATION_FAILED", "ADAPTATION_UNSUPPORTED", "RESPONSE_INVALID", "PROVIDER_UNAVAILABLE", "BUSY")}


class CarrierError(Exception):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


def require(condition, code="CONNECTION_SCHEMA_INVALID"):
    if not condition:
        raise CarrierError(code)


def exact(value, required, optional=()):
    require(isinstance(value, dict) and set(required) <= set(value) and set(value) <= set(required) | set(optional))


def pairs(values):
    result = {}
    for key, value in values:
        require(key not in result and key not in {"__proto__", "constructor", "prototype"})
        result[key] = value
    return result


def decode(raw):
    def nonfinite(_):
        raise CarrierError("CONNECTION_SCHEMA_INVALID")
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def secure_file(file, private=False):
    file = Path(file)
    require(file.is_absolute() and not file.is_symlink() and file.is_file(), "CONNECTION_STORAGE_PERMISSIONS")
    info = file.stat()
    require(info.st_nlink == 1 and (os.name == "nt" or not info.st_mode & (0o077 if private else 0o022)), "CONNECTION_STORAGE_PERMISSIONS")
    return file


def text(value, size=128):
    require(isinstance(value, str) and 0 < len(value) <= size and not any(ord(c) < 32 or ord(c) == 127 for c in value))
    return value


def validate_schema(value, schema, depth=0):
    require(depth <= 8)
    kind = schema.get("type")
    if "enum" in schema:
        require(value in schema["enum"])
    if kind == "object":
        exact(value, schema.get("required", []), schema.get("properties", {}))
        for key, item in value.items():
            validate_schema(item, schema["properties"][key], depth + 1)
    elif kind == "array":
        require(isinstance(value, list) and len(value) <= schema["maxItems"])
        for item in value:
            validate_schema(item, schema["items"], depth + 1)
    elif kind == "string":
        text(value, schema.get("maxLength", 128))
        require(len(value) >= schema.get("minLength", 1))
    elif kind == "integer":
        require(type(value) is int and schema.get("minimum", 0) <= value <= schema.get("maximum", 9007199254740991))
    elif kind == "boolean":
        require(type(value) is bool)
    elif kind == "null":
        require(value is None)
    elif kind == "number":
        require(type(value) in {int, float} and schema.get("minimum", float('-inf')) <= value <= schema.get("maximum", float('inf')))
    else:
        require(False)


def read_frame(connection):
    def take(count):
        output = bytearray()
        while len(output) < count:
            data = connection.recv(count - len(output))
            if not data:
                raise CarrierError("CONNECTION_RESPONSE_INVALID")
            output.extend(data)
        return bytes(output)
    size = struct.unpack("!I", take(4))[0]
    require(2 <= size <= MAX_REQUEST, "CONNECTION_LIMIT_EXCEEDED")
    return decode(take(size).decode("utf-8"))


def identifier(value):
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', text(value)) is not None)
    return value


def version_one(value):
    require(type(value) is int and value == 1)


def operation_uuid(value):
    try:
        parsed = uuid.UUID(text(value))
        require(parsed.version == 4 and str(parsed) == value)
    except (ValueError, AttributeError):
        require(False)


def identifiers(values, maximum=64):
    require(isinstance(values, list) and 0 < len(values) <= maximum and all(isinstance(value, str) for value in values))
    require(len(set(values)) == len(values))
    for value in values:
        identifier(value)


def validate_method_definition(value):
    exact(value, ['capability', 'schema'], ['responseBytes', 'credential', 'retainCredential', 'observe', 'operationContextVersion', 'authorizationRootsVersion', 'credentialInputs'])
    text(value['capability'])
    require(value.get('credential', 'current') in {'current', 'operation', 'none'})
    for name in ('retainCredential', 'observe'):
        require(name not in value or type(value[name]) is bool)
    require(not value.get('retainCredential') or value.get('credential') == 'operation')
    for name in ('operationContextVersion', 'authorizationRootsVersion'):
        if name in value:
            version_one(value[name])
    if 'credentialInputs' in value:
        inputs = value['credentialInputs']; exact(inputs, ['version', 'names', 'delivery']); version_one(inputs['version']); identifiers(inputs['names'], 1)
        require(value.get('operationContextVersion') == 1 and inputs['delivery'] in {'metadata', 'secret'})
        require(inputs['delivery'] != 'secret' or value.get('credential') == 'operation' and value.get('retainCredential') is True and value.get('observe') is not True)


def validate_provider_extensions(config, methods):
    inputs, roots = config.get('credentialInputs'), config.get('authorizationRoots')
    if inputs is not None:
        exact(inputs, ['version', 'definitions']); version_one(inputs['version'])
        require(isinstance(inputs['definitions'], list) and len(inputs['definitions']) == 1)
        for row in inputs['definitions']:
            exact(row, ['name', 'purpose', 'targetTypes', 'secretSchema']); identifier(row['name']); identifier(row['purpose']); identifiers(row['targetTypes'])
            require(isinstance(row['secretSchema'], dict) and row['secretSchema'].get('type') == 'object')
        require(len(canonical(inputs).encode()) <= 16384)
    if roots is not None:
        exact(roots, ['version', 'method', 'definitions']); version_one(roots['version']); identifier(roots['method'])
        require(isinstance(roots['definitions'], list) and 0 < len(roots['definitions']) <= 64)
        purposes = set()
        for row in roots['definitions']:
            exact(row, ['purpose', 'rootTypes']); identifier(row['purpose']); identifiers(row['rootTypes'])
            require(row['purpose'] not in purposes); purposes.add(row['purpose'])
        verifier = methods.get(roots['method'], {})
        require(verifier.get('credential') == 'current' and verifier.get('retainCredential') is not True and verifier.get('observe') is not True and verifier.get('credentialInputs', {}).get('delivery') != 'secret')
        require(len(canonical(roots).encode()) <= 16384)
    for value in methods.values():
        require('authorizationRootsVersion' not in value or roots is not None)
        if 'credentialInputs' in value:
            require(inputs is not None and all(any(row['name'] == name for row in inputs['definitions']) for name in value['credentialInputs']['names']))


def evidence_time(value):
    require(isinstance(value, str) and re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z', value) is not None)
    try:
        return datetime.strptime(value, '%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=timezone.utc).timestamp()
    except ValueError:
        require(False)


def validate_target_evidence(value, targets):
    exact(value, ['version', 'kind', 'origin', 'trustRef', 'policyVersion', 'serverName', 'leafDERBase64', 'leafSHA256', 'notBefore', 'notAfter', 'observedAt', 'expiresAt', 'verification'])
    version_one(value['version']); require(value['kind'] == 'tls-peer-leaf' and len(canonical(value).encode()) <= 32768)
    exact(value['verification'], ['mode']); require(value['verification']['mode'] in ('ca-hostname-and-exact-leaf', 'observed'))
    for key in ('origin', 'trustRef', 'policyVersion', 'serverName'):
        text(value[key], 512 if key == 'origin' else 253 if key == 'serverName' else 128)
    target = next((row for row in targets if all(row.get(key) == value[key] for key in ('origin', 'trustRef', 'policyVersion', 'serverName'))), None)
    require(target is not None, 'CONNECTION_NETWORK_POLICY_DENIED')
    observed, expires = (evidence_time(value[key]) for key in ('observedAt', 'expiresAt'))
    require(observed < expires, 'CONNECTION_PROOF_EXPIRED')
    if value['leafDERBase64'] is None and value['verification']['mode'] == 'observed':
        require(all(value[key] is None for key in ('leafSHA256', 'notBefore', 'notAfter')))
        return
    require(isinstance(value['leafDERBase64'], str) and len(value['leafDERBase64']) <= 21848)
    try:
        der = base64.b64decode(value['leafDERBase64'], validate=True)
    except (ValueError, TypeError):
        require(False)
    require(0 < len(der) <= 16384 and base64.b64encode(der).decode('ascii') == value['leafDERBase64'] and hashlib.sha256(der).hexdigest() == value['leafSHA256'], 'CONNECTION_PROOF_MISMATCH')
    # The Node peer verifier validates X.509; this carrier also refuses trailing DER.
    require(len(der) > 2 and der[0] == 0x30)
    length_bytes = der[1] & 0x7f if der[1] & 0x80 else 0
    require(length_bytes <= 3 and (length_bytes > 0 or der[1] < 0x80))
    size = int.from_bytes(der[2:2+length_bytes], 'big') if length_bytes else der[1]
    require(2 + length_bytes + size == len(der), 'CONNECTION_PROOF_MISMATCH')
    for key in ('notBefore', 'notAfter'):
        evidence_time(value[key])


def validate_business_bindings(config, definition, binding, payload, input_secrets=None):
    operation, roots = binding.get('operationContext'), binding.get('authorizationRoots')
    inputs = []
    if operation is not None:
        require(definition.get('operationContextVersion') == 1, 'CONNECTION_MODE_UNSUPPORTED')
        exact(operation, ['version', 'operationId', 'credentialInputBindings']); version_one(operation['version']); operation_uuid(operation['operationId'])
        require('operationId' not in payload or payload['operationId'] == operation['operationId'], 'CONNECTION_PROOF_MISMATCH')
        inputs = operation['credentialInputBindings']; require(isinstance(inputs, list) and len(inputs) <= 1)
        for row in inputs:
            exact(row, ['name', 'purpose', 'credentialInputVersion', 'target', 'endpoint', 'targetEvidenceSHA256', 'targetEvidence'])
            for key in ('name', 'purpose', 'credentialInputVersion'):
                identifier(row[key])
            exact(row['target'], ['objectType', 'objectId']); identifier(row['target']['objectType']); text(row['target']['objectId'], 256)
            exact(row['endpoint'], ['origin', 'trustRef'])
            validate_target_evidence(row['targetEvidence'], config['targets'])
            require(digest(row['targetEvidence']) == row['targetEvidenceSHA256'] and all(row['endpoint'][key] == row['targetEvidence'][key] for key in ('origin', 'trustRef')), 'CONNECTION_PROOF_MISMATCH')
            declared = next((item for item in config.get('credentialInputs', {}).get('definitions', []) if item['name'] == row['name']), None)
            allowed = row['name'] in definition.get('credentialInputs', {}).get('names', []) or definition.get('observe') is True and binding.get('credentialLeaseId')
            require(declared is not None and allowed and declared['purpose'] == row['purpose'] and row['target']['objectType'] in declared['targetTypes'], 'CONNECTION_PERMISSION_DENIED')
    if roots is not None:
        require(definition.get('authorizationRootsVersion') == 1, 'CONNECTION_MODE_UNSUPPORTED')
        exact(roots, ['version', 'connectionId', 'instanceId', 'scopeRevision', 'roots']); version_one(roots['version'])
        require(roots['connectionId'] == binding['connectionId'] and roots['instanceId'] == binding['instanceId'] and type(roots['scopeRevision']) is int and roots['scopeRevision'] >= 1 and roots['scopeRevision'] == payload.get('scopeRevision'), 'CONNECTION_PROOF_MISMATCH')
        require(isinstance(roots['roots'], list) and len(roots['roots']) <= 32 and len(canonical(roots['roots']).encode()) <= 16384)
        seen = set()
        for row in roots['roots']:
            exact(row, ['objectType', 'objectId', 'grantId', 'grantVersion', 'purposes']); identifier(row['objectType']); text(row['objectId'], 256); operation_uuid(row['grantId']); identifier(row['grantVersion']); identifiers(row['purposes'], 8)
            key = (row['objectType'], row['objectId']); require(key not in seen); seen.add(key)
            for purpose in row['purposes']:
                require(any(item['purpose'] == purpose and row['objectType'] in item['rootTypes'] for item in config.get('authorizationRoots', {}).get('definitions', [])), 'CONNECTION_PERMISSION_DENIED')
    if input_secrets is not None:
        require(definition.get('credentialInputs', {}).get('delivery') == 'secret' and binding.get('credentialLeaseId') and binding.get('credentialLeaseActive') is True and len(inputs) > 0, 'CONNECTION_PERMISSION_DENIED')
        exact(input_secrets, [row['name'] for row in inputs]); require(len(canonical(input_secrets).encode()) <= 16384)
        for row in inputs:
            declared = next(item for item in config['credentialInputs']['definitions'] if item['name'] == row['name'])
            validate_schema(input_secrets[row['name']], declared['secretSchema'])
    else:
        require(not inputs or definition.get('credentialInputs', {}).get('delivery') != 'secret', 'CONNECTION_CREDENTIAL_VERSION_CONFLICT')


class Runtime:
    def __init__(self, config):
        exact(config, ["host", "port", "serverCert", "serverKey", "clientCa", "clientLeafSHA256", "providerId", "pluginId",
                       "packageDigest", "release", "adapterRoot", "adapterSHA256", "targets", "testMode"], ["businessMethods", "dataDirectory", "dataStoreId", "credentialInputs", "authorizationRoots"])
        require(config["host"] == "127.0.0.1" and type(config["port"]) is int and
                (1024 <= config["port"] <= 65535 or config["port"] == 0 and config["testMode"] is True))
        require(os.name != "nt" or config["testMode"] is True, "CONNECTION_STORAGE_PERMISSIONS")
        for field in ("packageDigest", "release", "adapterSHA256", "clientLeafSHA256"):
            require(isinstance(config[field], str) and re.fullmatch(r"[a-f0-9]{64}", config[field]) is not None)
        for field in ("providerId", "pluginId"):
            text(config[field])
        require(isinstance(config["targets"], list) and 0 < len(config["targets"]) <= 4)
        self.methods = config.get("businessMethods", {})
        require(isinstance(self.methods, dict) and len(self.methods) <= 12)
        for method, definition in self.methods.items():
            require(method not in METHODS and re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{0,127}", method) is not None)
            validate_method_definition(definition)
            text(definition["capability"])
            require(type(definition.get("responseBytes", 262144)) is int and 1024 <= definition.get("responseBytes", 262144) <= MAX_RESPONSE)
        validate_provider_extensions(config, self.methods)
        if config.get("dataDirectory"):
            directory = Path(config["dataDirectory"])
            require(directory.is_absolute() and directory.is_dir() and not directory.is_symlink() and
                    (os.name == 'nt' or not directory.stat().st_mode & 0o077), "CONNECTION_STORAGE_PERMISSIONS")
        if "dataStoreId" in config:
            require(isinstance(config["dataStoreId"], str) and re.fullmatch(r'[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}', config["dataStoreId"]) is not None)
        for target in config["targets"]:
            exact(target, ["origin", "trustRef", "policyVersion"], ["addresses", "serverName", "caFile", "leafSHA256"])
            for key in ("origin", "trustRef", "policyVersion"):
                text(target[key], 512)
        adapter_root = Path(config["adapterRoot"])
        require(adapter_root.is_absolute() and adapter_root.is_dir() and not adapter_root.is_symlink())
        file = secure_file(adapter_root / "business.py")
        source = file.read_bytes()
        require(len(source) <= 1024 * 1024 and hashlib.sha256(source).hexdigest() == config["adapterSHA256"], "CONNECTION_PROOF_MISMATCH")
        # One trusted, pinned release directory; never a browser-selected module/command.
        sys.path.insert(0, str(adapter_root))
        sys.path.insert(1, str(Path(__file__).resolve().parent))
        spec = importlib.util.spec_from_file_location("rivetin_trusted_business", str(file))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        adapter_config = {"targets": config["targets"], "testMode": config["testMode"], "dataDirectory": config.get("dataDirectory")}
        if "dataStoreId" in config:
            adapter_config["dataStoreId"] = config["dataStoreId"]
        self.adapter = module.create_adapter(adapter_config)
        require(callable(getattr(self.adapter, "dispatch", None)))
        self.config = config
        self.lock = threading.RLock()
        self.diagnostic_records = 0
        self.nonces, self.sessions, self.cursors = {}, {}, {}
        self.slots = threading.BoundedSemaphore(4)
        self.tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        self.tls.minimum_version = ssl.TLSVersion.TLSv1_2
        self.tls.verify_mode = ssl.CERT_REQUIRED
        self.tls.load_cert_chain(str(secure_file(config["serverCert"])), str(secure_file(config["serverKey"], private=True)))
        self.tls.load_verify_locations(cafile=str(secure_file(config["clientCa"])))

    def validate(self, request):
        exact(request, ["version", "id", "nonce", "method", "binding", "deadline", "payloadJson", "secret", "requestDigest"], ["credentialInputs"])
        now = int(time.time() * 1000)
        require(request["version"] == 1 and request["method"] in METHODS | set(self.methods))
        require(re.fullmatch(r"[a-f0-9-]{36}", text(request["id"])) is not None and re.fullmatch(r"[a-f0-9]{64}", text(request["nonce"])) is not None)
        require(type(request["deadline"]) is int and now < request["deadline"] <= now + 15000, "CONNECTION_TIMEOUT")
        control = dict(request)
        control.pop("requestDigest")
        control["secret"] = None
        if "credentialInputs" in control:
            control["credentialInputs"] = None
        require(digest(control) == request["requestDigest"], "CONNECTION_PROOF_MISMATCH")
        binding = request["binding"]
        exact(binding, ["actorId", "pluginId", "packageDigest", "providerId", "attemptId", "connectionId", "instanceId",
                        "credentialVersion", "policyVersion", "connectorRelease", "origin", "trustRef", "capability"], ["credentialLeaseId", "credentialLeaseActive", "operationContext", "authorizationRoots"])
        for key in ("providerId", "pluginId", "packageDigest"):
            require(binding[key] == self.config[key], "CONNECTION_PERMISSION_DENIED")
        require(binding["connectorRelease"] == self.config["release"], "CONNECTION_PERMISSION_DENIED")
        business = self.methods.get(request["method"])
        require(binding["capability"] == (business["capability"] if business else "connection.read"), "CONNECTION_PERMISSION_DENIED")
        for key in ("actorId", "attemptId", "credentialVersion", "policyVersion", "trustRef", "origin"):
            text(binding[key], 512 if key == "origin" else 128)
        require(any(all(target[key] == binding[key] for key in ("origin", "trustRef", "policyVersion")) for target in self.config["targets"]), "CONNECTION_NETWORK_POLICY_DENIED")
        require(isinstance(request["payloadJson"], str) and len(request["payloadJson"].encode("utf-8")) <= 65536)
        require(isinstance(request["secret"], dict) and len(canonical(request["secret"]).encode("utf-8")) <= 16384)
        payload = decode(request["payloadJson"])
        require(isinstance(payload, dict))
        method_fields = {"probe": ({"candidate"}, set()),
            "discover": ({"instanceId", "adaptation", "filter", "cursor", "limit"}, set()),
            "revalidate": ({"instanceId", "selected", "candidate", "adaptation"}, set())}
        if business:
            require(isinstance(binding["connectionId"], str) and isinstance(binding["instanceId"], str), "CONNECTION_PROOF_MISMATCH")
            validate_schema(payload, business["schema"])
            validate_business_bindings(self.config, business, binding, payload, request.get("credentialInputs"))
        else:
            require("operationContext" not in binding and "authorizationRoots" not in binding and "credentialInputs" not in request, "CONNECTION_MODE_UNSUPPORTED")
            required, optional = method_fields[request["method"]]
            exact(payload, required, optional)
        for key in ("connectionId", "instanceId"):
            if key in payload:
                require(payload[key] == binding[key], "CONNECTION_PROOF_MISMATCH")
        if "candidate" in payload:
            require(payload["candidate"].get("origin") == binding["origin"] and payload["candidate"].get("tls", {}).get("trustRef") == binding["trustRef"], "CONNECTION_PROOF_MISMATCH")
        base = {key: value for key, value in binding.items() if key != "instanceId"}
        base_key = digest(base)
        with self.lock:
            for cache in (self.nonces, self.sessions, self.cursors):
                for key in list(cache):
                    if cache[key]["expires"] <= now:
                        del cache[key]
            require(request["nonce"] not in self.nonces, "CONNECTION_PROOF_MISMATCH")
            require(len(self.nonces) < 1024 and len(self.sessions) < 256, "CONNECTION_LIMIT_EXCEEDED")
            self.nonces[request["nonce"]] = {"expires": request["deadline"]}
            if request["method"] in {"discover", "revalidate"}:
                session = self.sessions.get(base_key)
                require(session is not None and binding["instanceId"] == session["instanceId"] == payload.get("instanceId"), "CONNECTION_INSTANCE_CHANGED")
                adaptation = {key: value for key, value in payload["adaptation"].items() if key != "digest"}
                require(digest(adaptation) == session["adaptationDigest"], "CONNECTION_PROOF_MISMATCH")
                if "candidate" in payload:
                    require(digest(payload["candidate"]) == session["candidateDigest"], "CONNECTION_PROOF_MISMATCH")
        return payload, base_key

    def dispatch(self, request, diagnostic_context=None):
        payload, base_key = self.validate(request)
        if diagnostic_context is not None:
            diagnostic_context.update(requestId=request["id"], method=request["method"])
        binding = request["binding"]
        now = int(time.time() * 1000)
        filter_digest = digest({"filter": payload.get("filter"), "adaptation": payload.get("adaptation")})
        if request["method"] == "discover":
            with self.lock:
                if payload.get("cursor"):
                    cursor = self.cursors.pop(payload["cursor"], None)
                    require(cursor is not None and cursor["base"] == base_key and cursor["filter"] == filter_digest, "CONNECTION_PROOF_MISMATCH")
                    payload["cursor"] = cursor["value"]
                else:
                    for key in list(self.cursors):
                        if self.cursors[key]["base"] == base_key:
                            del self.cursors[key]
        call_context = dict(copy.deepcopy(binding), sessionKey=base_key, freshReadRequired=request["method"] != "discover")
        if "credentialInputs" in request:
            reply = self.adapter.dispatch(request["method"], payload, request["secret"], call_context, request["deadline"], credential_inputs=request["credentialInputs"])
        else:
            reply = self.adapter.dispatch(request["method"], payload, request["secret"], call_context, request["deadline"])
        exact(reply, ["data"], ["continuation", "credentialLease"])
        data = reply["data"]
        require(isinstance(data, dict), "CONNECTION_RESPONSE_INVALID")
        require(int(time.time() * 1000) < request["deadline"], "CONNECTION_TIMEOUT")
        if request["method"] == "probe":
            require(data.get("authentication") == "authenticated" and data.get("authorization", {}).get("status") in {"readable", "partial"}, "CONNECTION_AUTHENTICATION_FAILED")
            instance = data.get("instance", {}).get("instanceId")
            text(instance)
            with self.lock:
                self.sessions[base_key] = {"instanceId": instance, "expires": int(time.time() * 1000) + 120000,
                    "candidateDigest": digest(payload["candidate"]), "adaptationDigest": digest(data.get("selectedAdaptation"))}
        if request["method"] == "discover":
            require(type(data.get("complete")) is bool and data.get("instanceId") == binding["instanceId"], "CONNECTION_RESPONSE_INVALID")
            continuation = reply.get("continuation")
            require(not data["complete"] or continuation is None, "CONNECTION_RESPONSE_INVALID")
            data["nextCursor"] = None
            if continuation is not None:
                with self.lock:
                    require(len(self.cursors) < 256, "CONNECTION_LIMIT_EXCEEDED")
                    token = str(uuid.uuid4())
                    self.cursors[token] = {"base": base_key, "filter": filter_digest, "value": continuation,
                                           "expires": min(self.sessions[base_key]["expires"], now + 120000)}
                    data["nextCursor"] = token
        lease = reply.get("credentialLease")
        require(lease is None or request["method"] in self.methods and lease in {"retain", "release"}, "CONNECTION_RESPONSE_INVALID")
        return data, lease

    def adapter_diagnostic(self, error, context):
        try:
            namespace = object.__getattribute__(error, "__dict__")
            if type(namespace) is not dict:
                return
            value = namespace.get("_rivetin_diagnostic")
            if (type(value) is not tuple or len(value) != 6 or value[0] != 1 or
                    not all(type(item) is int and 0 <= item <= 255 for item in value)):
                return
            request_id, method = context.get("requestId"), context.get("method")
            if (type(request_id) is not str or re.fullmatch(r"[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}", request_id) is None or
                    type(method) is not str or method not in METHODS | set(self.methods)):
                return
            record = {"event": "provider.adapter.native_rejected", "schemaVersion": 1,
                      "requestId": request_id, "method": method, "diagnostic": list(value)}
            line = canonical(record)
            if len(line.encode("utf-8")) > 384:
                return
            with self.lock:
                if self.diagnostic_records >= 8:
                    return
                self.diagnostic_records += 1
                sys.stderr.write(line + "\n")
                sys.stderr.flush()
        except Exception:
            pass  # Diagnostics must never replace the primary error or expose arbitrary attributes.

    def connection(self, raw):
        connection = None
        try:
            raw.settimeout(10)
            connection = self.tls.wrap_socket(raw, server_side=True)
            require(hashlib.sha256(connection.getpeercert(binary_form=True)).hexdigest() == self.config["clientLeafSHA256"], "CONNECTION_PERMISSION_DENIED")
            request = read_frame(connection)
            response = {"version": 1, "id": request.get("id"), "nonce": request.get("nonce"), "method": request.get("method"),
                        "bindingDigest": digest(request.get("binding")), "requestDigest": request.get("requestDigest")}
            diagnostic_context = {}
            try:
                data, lease = self.dispatch(request, diagnostic_context)
                response.update(status="ok", data=data)
                if lease is not None:
                    response["credentialLease"] = lease
            except Exception as error:
                code = getattr(error, "code", "CONNECTION_PROVIDER_UNAVAILABLE")
                response.update(status="error", errorCode=code if code in CODES else "CONNECTION_PROVIDER_UNAVAILABLE")
                self.adapter_diagnostic(error, diagnostic_context)
            response["observedAt"] = int(time.time() * 1000)
            encoded = canonical(response).encode("utf-8")
            limit = self.methods.get(request["method"], {}).get("responseBytes", 262144)
            require(len(encoded) <= limit, "CONNECTION_LIMIT_EXCEEDED")
            connection.sendall(struct.pack("!I", len(encoded)) + encoded)
        except Exception:
            pass  # Never log payloads, secrets, TLS errors or adapter tracebacks.
        finally:
            (connection or raw).close()
            self.slots.release()

    def serve(self):
        listener = socket.create_server((self.config["host"], self.config["port"]), family=socket.AF_INET, backlog=8)
        print(canonical({"ready": True, "port": listener.getsockname()[1], "pid": os.getpid(), "release": self.config["release"]}), flush=True)
        try:
            while True:
                raw, _ = listener.accept()
                if not self.slots.acquire(blocking=False):
                    raw.close()
                    continue
                threading.Thread(target=self.connection, args=(raw,), daemon=True).start()
        finally:
            listener.close()
            close = getattr(self.adapter, "close", None)
            if close:
                close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = decode(secure_file(args.config, private=True).read_text(encoding="utf-8"))
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    Runtime(config).serve()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        sys.exit(1)
