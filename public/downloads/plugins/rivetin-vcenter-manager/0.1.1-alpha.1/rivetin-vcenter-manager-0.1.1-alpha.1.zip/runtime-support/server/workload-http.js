import { createHash, X509Certificate } from 'node:crypto';
import https from 'node:https';
import { isIP } from 'node:net';
import { checkServerIdentity } from 'node:tls';
import { observeHttpsRequest } from './connection-observation.js';
import { callReply, encodeWire, maximumExchangeMs, parseWire, permitRequest, prefix, readReply, requestLimit, responseLimit, safeError,
  standardExchangeMs, validateCall, wireVersion, WorkloadError } from './workload-protocol.js';

const unavailable = () => new WorkloadError('WORKLOAD_UNAVAILABLE', 503);
const denied = () => new WorkloadError('WORKLOAD_DENIED');
function pin(cert) {
  return cert?.raw ? createHash('sha256').update(cert.raw).digest('hex') : null;
}
function checkWorkloadServiceIdentity(host, certificate) {
  const error = checkServerIdentity(host, certificate);
  if (error || isIP(host)) return error;
  if (!new X509Certificate(certificate.raw).checkHost(host, { subject: 'never', wildcards: false })) {
    return Object.assign(new Error('WORKLOAD_SERVICE_SAN_REQUIRED'), { code: 'ERR_TLS_CERT_ALTNAME_INVALID' });
  }
}
async function receive(stream, limit) {
  const chunks = [];
  let size = 0;
  for await (const chunk of stream) {
    size += chunk.length;
    if (size > limit) throw new WorkloadError('WORKLOAD_BODY_LIMIT', 413);
    chunks.push(chunk);
  }
  return parseWire(Buffer.concat(chunks), limit);
}
function send(res, status, value) {
  const body = encodeWire(value, responseLimit);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}
function createServer({ tls, peerAllowed, handler }) {
  const server = https.createServer({ ...tls, minVersion: 'TLSv1.2', requestCert: true, rejectUnauthorized: true,
    requestTimeout: 15_000, headersTimeout: 10_000, handshakeTimeout: 5_000, maxHeaderSize: 8192 }, async (req, res) => {
    let call;
    try {
      const peer = req.socket.authorized ? pin(req.socket.getPeerCertificate()) : null;
      if (!peer || !await peerAllowed(peer)) throw denied();
      if (req.method === 'GET' && req.url === prefix + '/health') {
        return send(res, 200, await handler({ peer, route: 'health' }));
      }
      if (req.method !== 'POST' || !req.url.startsWith(prefix + '/') || req.headers['content-type'] !== 'application/json') {
        throw new WorkloadError('WORKLOAD_ROUTE_INVALID', 404);
      }
      const route = req.url.slice(prefix.length + 1);
      const value = await receive(req, requestLimit);
      const bearer = /^Bearer ([a-f0-9]{64})$/.exec(req.headers.authorization || '')?.[1];
      if (route === 'invoke' || route === 'call') {
        call = validateCall(value, route === 'invoke');
        const result = await handler({ peer, route, bearer, value: call });
        try { return send(res, 200, callReply(call, { ok: true, result })); }
        catch { throw new WorkloadError('WORKLOAD_RESPONSE_INVALID', 503, call.kind === 'submit' ? 'unknown' : 'not-accepted'); }
      }
      return send(res, 200, await handler({ peer, route, bearer, value }));
    } catch (error) {
      if (res.destroyed || res.headersSent) return res.destroy();
      const outcome = safeError(error, call?.kind);
      if (call) return send(res, 200, callReply(call, { ok: false, error: outcome }));
      return send(res, error instanceof WorkloadError ? error.status : 400, { transportVersion: wireVersion, error: outcome });
    }
  });
  server.maxConnections = 64;
  server.setTimeout(maximumExchangeMs + 5000, socket => socket.destroy());
  return server;
}

export function createFrameworkServer({ tls, broker, ready, refresh = async () => {} }) {
  return createServer({ tls, peerAllowed: async peer => { await refresh(); return broker.registered(peer); }, handler: async ({ peer, route, bearer, value }) => {
    if (route === 'health') return { transportVersion: wireVersion, ready: Boolean(await ready()) };
    if (route === 'permit') return broker.permit(peer, value);
    if (route === 'call') return broker.call(peer, bearer, value);
    if (route === 'credential') return broker.credential(peer, bearer, value);
    throw new WorkloadError('WORKLOAD_ROUTE_INVALID', 404);
  } });
}
export function createRestrictedBackendServer({ tls, frameworkPin, ready }) {
  if (typeof ready !== 'function' || !/^[a-f0-9]{64}$/.test(frameworkPin ?? '')) throw denied();
  return createServer({ tls, peerAllowed: peer => peer === frameworkPin, handler: ({ route }) => {
    if (route !== 'health') throw denied();
    return { transportVersion: wireVersion, mode: 'restricted', ready: ready() === true };
  } });
}
export function createBackendServer({ tls, frameworkPin, identity, permits, framework, execute, authorize, ready = () => true }) {
  permitRequest(identity);
  return createServer({ tls, peerAllowed: peer => peer === frameworkPin, handler: async ({ route, value }) => {
    if (route === 'health') return { transportVersion: wireVersion, ready: Boolean(permits.current() && await ready()) };
    if (!['pause', 'invoke'].includes(route)) throw new WorkloadError('WORKLOAD_ROUTE_INVALID', 404);
    if (route === 'pause') permitRequest(value);
    if (value.instanceId !== identity.instanceId || value.generation !== identity.generation) throw denied();
    if (route === 'pause') {
      await permits.pause();
      return { transportVersion: wireVersion, paused: true };
    }
    if (!await authorize(value)) throw denied();
    if (value.kind !== 'observe' && (!await ready() || !permits.current())) throw unavailable();
    const claimCredential = async () => {
      const bearer = permits.current();
      if (!bearer || value.credentialLeaseId === null || !framework) throw denied();
      const reply = await framework.credential({ ...identity, requestId: value.requestId,
        operationId: value.operationId, credentialLeaseId: value.credentialLeaseId }, bearer);
      if (reply.transportVersion !== wireVersion || !Object.hasOwn(reply, 'credential')) throw unavailable();
      return reply.credential;
    };
    return execute(value, { claimCredential });
  } });
}

export function createPeerClient({ origin, tls, serverPin }) {
  const url = new URL(origin);
  if (url.protocol !== 'https:' || url.origin !== origin || url.username || url.password || !tls?.ca?.length) {
    throw new WorkloadError('WORKLOAD_PEER_INVALID', 400);
  }
  async function exchange(route, value, bearer, timeoutMs = standardExchangeMs) {
    if (!Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > maximumExchangeMs) throw unavailable();
    const body = value === undefined ? undefined : encodeWire(value);
    return new Promise((resolve, reject) => {
      const req = https.request(new URL(prefix + '/' + route, url), { ...tls, method: body ? 'POST' : 'GET', agent: false,
        minVersion: 'TLSv1.2', rejectUnauthorized: true, checkServerIdentity: checkWorkloadServiceIdentity,
        signal: AbortSignal.timeout(timeoutMs),
        headers: { ...(body ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } : {}),
          ...(bearer ? { Authorization: 'Bearer ' + bearer } : {}) } }, response => {
        if (response.statusCode !== 200) {
          response.destroy();
          reject(new WorkloadError('WORKLOAD_HTTP_ERROR', response.statusCode, 'unknown'));
          return;
        }
        if (response.headers['content-type'] !== 'application/json') {
          response.destroy();
          reject(unavailable());
          return;
        }
        receive(response, responseLimit).then(resolve, reject);
      });
      observeHttpsRequest(req,origin,serverPin).on('error', reject);
      req.end(body);
    });
  }
  async function call(route, value, bearer, timeoutMs) {
    let reply;
    try { reply = readReply(await exchange(route, value, bearer, timeoutMs), value); }
    catch { throw new WorkloadError('WORKLOAD_TRANSPORT_FAILED', 503, value.kind === 'submit' ? 'unknown' : 'not-accepted'); }
    if (!reply.ok) throw new WorkloadError(reply.error.code, 503, reply.error.outcome);
    return reply.result;
  }
  return {
    health: ({ timeoutMs } = {}) => exchange('health', undefined, undefined, timeoutMs),
    permit: value => exchange('permit', value),
    pause: value => exchange('pause', value),
    invoke: (value, { timeoutMs } = {}) => call('invoke', value, undefined, timeoutMs),
    call: (value, bearer) => call('call', value, bearer),
    credential: (value, bearer) => exchange('credential', value, bearer),
  };
}
