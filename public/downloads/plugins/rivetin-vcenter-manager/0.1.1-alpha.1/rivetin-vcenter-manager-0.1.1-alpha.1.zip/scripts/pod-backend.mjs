import { execFile, spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { once } from 'node:events';
import { lstat, mkdir, mkdtemp, readdir, readFile, rmdir, unlink, writeFile } from 'node:fs/promises';
import { createServer } from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { createVmwarePodBackend, podErrorCode } from '../server/pod_backend.mjs';
import { createVmwarePodConnector } from '../server/pod_connector.mjs';

const run = promisify(execFile);
const snapshot = fileURLToPath(new URL('./pod_store.py', import.meta.url));
const support = new URL('../runtime-support/', import.meta.url);
const carrierMember = 'server/provider_connector_runtime.py';
const pythonPath = '/usr/bin/python3.12';
const component = 'rivetin-vcenter-manager';
let version = null;
let startupStage = 'configuration';
function log(level, event, fields = {}) {
  const stream = level === 'INFO' ? process.stdout : process.stderr;
  stream.write(JSON.stringify({ time: new Date().toISOString(), level, component, version, event, ...fields }) + '\n');
}
const absolute = value => {
  if (typeof value !== 'string' || !path.isAbsolute(value)) throw new Error('VC_POD_CONFIG_INVALID');
  return value;
};
async function readBounded(file, max = 128 * 1024) {
  const bytes = await readFile(absolute(file));
  if (bytes.length > max) throw new Error('VC_POD_CONFIG_INVALID');
  return bytes;
}
async function tls({ caFile, certFile, keyFile }) {
  const [ca, cert, key] = await Promise.all([caFile, certFile, keyFile].map(file => readBounded(file, 65536)));
  return { ca, cert, key };
}
function targetFailure(reason, origin) {
  return Object.assign(new Error('VC_TARGET_APPLY_FAILED'),
    { code: 'VC_TARGET_APPLY_FAILED', reason, ...(origin === undefined ? {} : { origin }) });
}

// The business ledger lives on the Pod's persistent volume. A fresh volume has
// no store yet, so the Pod must run the plugin's existing Python bootstrap
// (business.py initialize_storage) before any connector may verify it. The
// bootstrap is idempotent and refuses to touch a store that belongs to another
// dataStoreId or a directory that contains foreign content.
const businessMarkerName = 'vc-operations-identity.json';
const businessStoreId = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const causeLimit = 200;
function storageFailure(code, reason) {
  return Object.assign(new Error(code), { code, ...(reason === undefined ? {} : { reason }) });
}
// Diagnostic-only cause summary: bounded and stripped of PEM bodies and obvious
// credential assignments so boot logs cannot echo trust material.
function safeCause(error) {
  const causeName = typeof error?.name === 'string' && error.name ? error.name.slice(0, 64) : undefined;
  let causeMessage;
  if (typeof error?.message === 'string' && error.message) {
    causeMessage = error.message
      .replace(/-----BEGIN [A-Z0-9 ]+-----[\s\S]*?(?:-----END [A-Z0-9 ]+-----|$)/g, '[redacted-pem]')
      .replace(/\b(password|passwd|secret|token|authorization)\s*[:=]\s*\S+/gi, '$1=[redacted]')
      .replace(/\s+/g, ' ').trim();
    if (causeMessage.length > causeLimit) causeMessage = causeMessage.slice(0, causeLimit);
  }
  return { ...(causeName === undefined ? {} : { causeName }), ...(causeMessage ? { causeMessage } : {}) };
}
async function inspectPath(file) {
  try { return await lstat(file); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}
async function readBusinessMarker(file, missingCode) {
  const info = await inspectPath(file);
  if (info === null) throw storageFailure(missingCode, 'IDENTITY_MARKER_MISSING');
  if (!info.isFile() || info.isSymbolicLink() || info.size > 4096 || info.size < 2) {
    throw storageFailure('VC_OPERATION_STORAGE_MISMATCH', 'IDENTITY_MARKER_INVALID');
  }
  let value;
  try { value = JSON.parse(await readFile(file, 'utf8')); }
  catch { throw storageFailure('VC_OPERATION_STORAGE_MISMATCH', 'IDENTITY_MARKER_INVALID'); }
  if (value === null || typeof value !== 'object' || Array.isArray(value) ||
      typeof value.storeId !== 'string' || !businessStoreId.test(value.storeId)) {
    throw storageFailure('VC_OPERATION_STORAGE_MISMATCH', 'IDENTITY_MARKER_INVALID');
  }
  return value;
}

/** Run the plugin's own fixed Python bootstrap: verified business.py initialize_storage. */
export function createBusinessStorageInitializer({ pythonPath: python = pythonPath, run: runner = run } = {}) {
  const source = [
    'import hashlib, importlib.util, sys',
    'from pathlib import Path',
    'file = Path(sys.argv[1])',
    'assert hashlib.sha256(file.read_bytes()).hexdigest() == sys.argv[2]',
    'sys.path.insert(0, str(file.parent))',
    "spec = importlib.util.spec_from_file_location('rivetin_trusted_storage_initializer', str(file))",
    'module = importlib.util.module_from_spec(spec)',
    'spec.loader.exec_module(module)',
    "initialize = getattr(module, 'initialize_storage', None)",
    'assert callable(initialize)',
    "result = initialize({'dataDirectory': sys.argv[3], 'dataStoreId': sys.argv[4]})",
    "assert type(result) is dict and set(result) == {'initialized', 'dataStoreId'} and result['initialized'] is True and result['dataStoreId'] == sys.argv[4]",
    "print('initialized')",
  ].join('\n');
  return async function initializeBusinessStorage({ businessPath, businessSHA256, dataDirectory, dataStoreId }) {
    const { stdout } = await runner(python, ['-I', '-B', '-c', source, businessPath, businessSHA256, dataDirectory, dataStoreId],
      { timeout: 15_000, maxBuffer: 4096, env: {} });
    if (String(stdout).trim() !== 'initialized') {
      throw storageFailure('VC_OPERATION_STORAGE_INITIALIZE_FAILED', 'INITIALIZER_RESPONSE_INVALID');
    }
  };
}

/** Ensure the business ledger exists for the configured dataStoreId; never overwrite foreign data. */
export async function ensureBusinessStorage({ dataDirectory, dataStoreId, adapterRoot, adapterSHA256, initialize }) {
  for (const value of [dataDirectory, adapterRoot]) {
    if (typeof value !== 'string' || !path.isAbsolute(value)) {
      throw storageFailure('VC_OPERATION_STORAGE_REQUIRED', 'DATA_DIRECTORY_INVALID');
    }
  }
  if (typeof dataStoreId !== 'string' || !businessStoreId.test(dataStoreId)) {
    throw storageFailure('VC_OPERATION_STORAGE_REQUIRED', 'STORE_ID_INVALID');
  }
  if (typeof adapterSHA256 !== 'string' || !/^[a-f0-9]{64}$/.test(adapterSHA256)) {
    throw storageFailure('VC_OPERATION_STORAGE_REQUIRED', 'ADAPTER_IDENTITY_INVALID');
  }
  if (typeof initialize !== 'function') throw storageFailure('VC_OPERATION_STORAGE_REQUIRED', 'INITIALIZER_MISSING');
  let directory = await inspectPath(dataDirectory);
  if (directory === null) {
    try { await mkdir(dataDirectory, { mode: 0o700 }); }
    catch (error) {
      throw Object.assign(storageFailure('VC_OPERATION_STORAGE_REQUIRED', 'DATA_DIRECTORY_UNAVAILABLE'), { cause: error });
    }
    directory = await inspectPath(dataDirectory);
  }
  if (directory === null || !directory.isDirectory() || directory.isSymbolicLink()) {
    throw storageFailure('VC_OPERATION_STORAGE_REQUIRED', 'DATA_DIRECTORY_INVALID');
  }
  // readdir also rejects a file or inaccessible directory before any mutation.
  const entries = await readdir(dataDirectory);
  const markerPath = path.join(dataDirectory, businessMarkerName);
  if (entries.length > 0) {
    const marker = await readBusinessMarker(markerPath, 'VC_OPERATION_STORAGE_REQUIRED');
    if (marker.storeId !== dataStoreId) {
      throw storageFailure('VC_OPERATION_STORAGE_MISMATCH', 'STORE_ID_MISMATCH');
    }
    return { initialized: false, reused: true };
  }
  const businessPath = path.join(adapterRoot, 'business.py');
  let business;
  try { business = await lstat(businessPath); }
  catch { throw storageFailure('VC_OPERATION_STORAGE_INITIALIZE_FAILED', 'BUSINESS_ADAPTER_UNAVAILABLE'); }
  if (!business.isFile() || business.isSymbolicLink() || business.size > 1024 * 1024) {
    throw storageFailure('VC_OPERATION_STORAGE_INITIALIZE_FAILED', 'BUSINESS_ADAPTER_INVALID');
  }
  if (createHash('sha256').update(await readFile(businessPath)).digest('hex') !== adapterSHA256) {
    throw storageFailure('VC_OPERATION_STORAGE_INITIALIZE_FAILED', 'BUSINESS_ADAPTER_MISMATCH');
  }
  try { await initialize({ businessPath, businessSHA256: adapterSHA256, dataDirectory, dataStoreId }); }
  catch (error) {
    throw Object.assign(storageFailure('VC_OPERATION_STORAGE_INITIALIZE_FAILED', 'INITIALIZER_FAILED'), { cause: error });
  }
  const marker = await readBusinessMarker(markerPath, 'VC_OPERATION_STORAGE_INITIALIZE_FAILED');
  if (marker.storeId !== dataStoreId) {
    throw storageFailure('VC_OPERATION_STORAGE_INITIALIZE_FAILED', 'INITIALIZED_STORE_MISMATCH');
  }
  return { initialized: true, reused: false };
}

/** Bootstrap (or reuse) the business ledger, then prove it with the same verifier the connector uses. */
export async function prepareBusinessStorage({ dataDirectory, dataStoreId, adapterRoot, adapterSHA256, initialize, verify }) {
  const outcome = await ensureBusinessStorage({ dataDirectory, dataStoreId, adapterRoot, adapterSHA256, initialize });
  if (typeof verify !== 'function') throw storageFailure('VC_OPERATION_STORAGE_REQUIRED', 'VERIFIER_MISSING');
  let verified;
  try { verified = await verify(); }
  catch (error) {
    throw Object.assign(storageFailure('VC_OPERATION_STORAGE_INITIALIZE_FAILED', 'STORAGE_PROOF_FAILED'), { cause: error });
  }
  if (verified !== true) throw storageFailure('VC_OPERATION_STORAGE_INITIALIZE_FAILED', 'STORAGE_PROOF_FAILED');
  return outcome;
}

// Generating one single-target connector configuration is a callback because
// targets can be added or removed while the Pod runs. The startup targets keep
// their identity and trust material; a runtime target must present its CA (or
// reuse the CA of a startup target with the same origin).
export function createTargetProcessFactory({ runtime, pythonPath, runtimePath, runtimeSHA256,
  startupTargets = [], materialize, allocatePort }) {
  if (runtime === null || typeof runtime !== 'object' || typeof materialize !== 'function' ||
      typeof allocatePort !== 'function') throw targetFailure('TARGET_RUNTIME_INVALID');
  const startup = new Map();
  for (const target of startupTargets) {
    if (target !== null && typeof target === 'object' && typeof target.origin === 'string' && typeof target.caFile === 'string') {
      startup.set(target.origin, target);
    }
  }
  const certificates = new Map();
  let sequence = 0;
  async function trustedCaFile(target) {
    const pem = typeof target.caPem === 'string' ? target.caPem : '';
    if (pem) {
      const digest = createHash('sha256').update(pem).digest('hex');
      if (!certificates.has(digest)) certificates.set(digest, await materialize(`target-ca-${digest}.pem`, Buffer.from(pem)));
      return certificates.get(digest);
    }
    const known = startup.get(target.origin);
    if (known) return known.caFile;
    throw targetFailure('TARGET_CA_REQUIRED', target.origin);
  }
  return async function createTargetProcess(target) {
    if (target === null || typeof target !== 'object' ||
        typeof target.origin !== 'string' || !target.origin ||
        typeof target.trustRef !== 'string' || !target.trustRef ||
        typeof target.policyVersion !== 'string' || !target.policyVersion ||
        !Array.isArray(target.addresses) || !target.addresses.length ||
        target.addresses.some(address => typeof address !== 'string' || !address)) throw targetFailure('TARGET_INVALID');
    const caFile = await trustedCaFile(target);
    const port = await allocatePort();
    const known = startup.get(target.origin);
    const runtimeTarget = { origin: target.origin, trustRef: target.trustRef, policyVersion: target.policyVersion,
      addresses: [...target.addresses], caFile };
    for (const key of ['serverName', 'leafSHA256']) {
      const value = target[key] ?? known?.[key];
      if (key === 'leafSHA256' ? typeof value === 'string' && /^[a-f0-9]{64}$/.test(value) : typeof value === 'string' && value) {
        runtimeTarget[key] = value;
      }
    }
    const config = { ...runtime, port, targets: [runtimeTarget] };
    const bytes = Buffer.from(JSON.stringify(config));
    const configSHA256 = createHash('sha256').update(bytes).digest('hex');
    const configPath = await materialize(`provider-${++sequence}.json`, bytes);
    return { processConfig: { pythonPath, runtimePath, runtimeSHA256, configPath, configSHA256 }, port };
  };
}

// Bind an ephemeral loopback port for the next connector child. The port is
// released before the child starts, so a lost race is reported as an apply
// failure and safely retried by the control plane.
function createPortAllocator() {
  const reserved = new Set();
  return async function allocatePort() {
    for (let attempt = 0; attempt < 32; attempt++) {
      const server = createServer();
      try { await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); }); }
      catch { continue; }
      const { port } = server.address();
      await new Promise(resolve => server.close(() => resolve()));
      if (Number.isSafeInteger(port) && port >= 1024 && port <= 65535 && !reserved.has(port)) { reserved.add(port); return port; }
    }
    throw targetFailure('TARGET_PORT_UNAVAILABLE');
  };
}

/** Post-mortem spawn: replay the failed child once to capture its bounded stderr. */
export function createConnectorFailureCapture({ spawn: spawnProcess = spawn, timeoutMs = 3_000, limit = 8 * 1024 } = {}) {
  return function captureConnectorFailure(processConfig) {
    if (!processConfig || typeof processConfig.pythonPath !== 'string' || typeof processConfig.runtimePath !== 'string' ||
        typeof processConfig.configPath !== 'string') return Promise.resolve(null);
    return new Promise(resolve => {
      let child, stderr = '', settled = false, timer;
      const finish = (timedOut = false) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        let exitCode = null, signal = null;
        try { exitCode = child?.exitCode ?? null; signal = child?.signalCode ?? null; } catch { /* diagnostics only */ }
        try { child?.kill('SIGKILL'); } catch { /* already gone */ }
        resolve({ child: { exitCode, signal, timedOut }, stderr });
      };
      try {
        child = spawnProcess(processConfig.pythonPath, ['-I', '-B', processConfig.runtimePath, '--config', processConfig.configPath],
          { shell: false, windowsHide: true, cwd: path.dirname(processConfig.runtimePath), env: {}, stdio: ['ignore', 'ignore', 'pipe'] });
      } catch { resolve(null); return; }
      timer = setTimeout(() => finish(true), timeoutMs);
      child.once('error', () => finish(false));
      child.once('exit', () => finish(false));
      child.stderr.on('data', bytes => {
        if (stderr.length >= limit) return;
        stderr += bytes.toString('utf8').slice(0, limit - stderr.length);
      });
    });
  };
}

async function main(materialized) {
  // The common launcher verifies the package metadata before entering this script.
  // Older image layouts carry the component package.json instead.
  try {
    const manifest = JSON.parse(await readBounded(fileURLToPath(new URL('../metadata', import.meta.url)), 1024 * 1024)
      .catch(error => {
        if (error.code !== 'ENOENT') throw error;
        return readBounded(fileURLToPath(new URL('../package.json', import.meta.url)));
      }));
    if ((manifest.id ?? manifest.pluginId ?? manifest.name) === component && typeof manifest.version === 'string' &&
        /^\d{1,8}\.\d{1,8}\.\d{1,8}(?:[-.][a-z0-9.-]{1,80})?$/.test(manifest.version)) version = manifest.version;
  } catch { /* Logging identity must not change workload admission. */ }
  log('INFO', 'starting');
  if (process.argv.length !== 3 || process.argv[2] !== '/run/rivetin/runtime/backend.json') throw new Error('VC_POD_CONFIG_INVALID');
  const config = JSON.parse(await readBounded(process.argv[2]));
  const { frameworkOrigin, frameworkPin, workloadIdentity, legacy } = config;
  const { processConfig, identity, clientTls } = legacy;
  const legacyBytes = await readBounded(processConfig.configPath);
  if (createHash('sha256').update(legacyBytes).digest('hex') !== processConfig.configSHA256) throw new Error('VC_POD_CONFIG_INVALID');
  const runtime = JSON.parse(legacyBytes);
  if (runtime.testMode !== false || runtime.host !== '127.0.0.1' || !Number.isSafeInteger(runtime.port) ||
      runtime.port < 1024 || runtime.port > 65535 ||
      runtime.pluginId !== identity.pluginId || runtime.providerId !== identity.providerId ||
      runtime.packageDigest !== identity.packageDigest || runtime.release !== identity.connectorRelease ||
      !Array.isArray(runtime.targets) || runtime.targets.length > 4 ||
      process.env.RIVETIN_WORKLOAD_ID !== workloadIdentity.instanceId ||
      process.env.RIVETIN_GENERATION !== String(workloadIdentity.generation) ||
      !/^[a-zA-Z0-9-]{1,128}$/.test(process.env.RIVETIN_POD_UID ?? '')) throw new Error('VC_POD_CONFIG_INVALID');

  startupStage = 'plugin-runtime-support';
  const supportPins = JSON.parse(await readBounded(fileURLToPath(new URL('SOURCE-PINS.json', support))));
  const runtimeSHA256 = supportPins.files.find(row => row.path === carrierMember)?.sha256;
  if (!/^[a-f0-9]{64}$/.test(runtimeSHA256 ?? '')) throw new Error('VC_RUNTIME_SUPPORT_INVALID');
  const runtimePath = fileURLToPath(new URL(carrierMember, support));
  const load = name => import(new URL('server/' + name, support).href);
  const [{ createBackendServer, createPeerClient }, { createPermitMonitor }, { createConnectorProcess },
    { createProviderRpc }, { createProviderTransportPolicy }, { createLocalProbeServer }, { pollMs }] = await Promise.all([
    load('workload-http.js'), load('workload-permit.js'), load('provider-connector-process.js'),
    load('provider-rpc.js'), load('provider-transport-policy.js'), load('workload-local-health.js'), load('workload-protocol.js'),
  ]);
  startupStage = 'tls-and-connector-inputs';
  const outer = await tls({ caFile: '/run/rivetin/tls/ca.crt', certFile: '/run/rivetin/tls/tls.crt',
    keyFile: '/run/rivetin/tls/tls.key' });
  const framework = createPeerClient({ origin: frameworkOrigin, tls: outer, serverPin: frameworkPin });

  // Projected mount paths are symlinks. The pinned connector opens only private
  // regular files, so materialize the required inputs in this Pod's emptyDir.
  const runtimeDirectory = await mkdtemp('/tmp/rivetin-vc-');
  const files = [];
  materialized.remove = async () => {
    await Promise.all(files.map(file => unlink(file)));
    await rmdir(runtimeDirectory);
  };
  async function materialize(name, bytes) {
    const file = path.join(runtimeDirectory, name);
    try { await writeFile(file, bytes, { mode: 0o600, flag: 'wx' }); }
    finally { if (Buffer.isBuffer(bytes)) bytes.fill(0); }
    files.push(file);
    return file;
  }
  for (const key of ['serverCert', 'serverKey', 'clientCa']) runtime[key] = await materialize(key, await readBounded(runtime[key], 65536));
  for (const [index, target] of runtime.targets.entries()) {
    if (target.caFile != null) target.caFile = await materialize(`target-${index}.pem`, await readBounded(target.caFile, 65536));
  }
  // Startup targets are the initial desired set; the framework may replace it
  // at runtime through provider.targets.apply without restarting the Pod.
  const startupDefinitions = runtime.targets.map(({ origin, trustRef, policyVersion, addresses }) =>
    ({ origin, trustRef, policyVersion, addresses }));
  async function verifyBusinessStore() {
    const { stdout } = await run(pythonPath, ['-I', '-B', snapshot, '--source', absolute(runtime.dataDirectory),
      '--store-id', runtime.dataStoreId, 'snapshot'], { timeout: 15_000, maxBuffer: 4096, env: {} });
    const proof = JSON.parse(stdout);
    return proof.version === 1 && proof.coverage === 'complete-store' && proof.dataStoreId === runtime.dataStoreId;
  }
  // Fresh persistent volumes have no business ledger. Bootstrap it before the
  // connector may start, and keep the control plane up even if that fails so
  // the applied target error still reports the bounded cause to the framework.
  const storage = { failure: null };
  try {
    const outcome = await prepareBusinessStorage({
      dataDirectory: absolute(runtime.dataDirectory),
      dataStoreId: runtime.dataStoreId,
      adapterRoot: absolute(runtime.adapterRoot),
      adapterSHA256: runtime.adapterSHA256,
      initialize: createBusinessStorageInitializer({ pythonPath }),
      verify: verifyBusinessStore,
    });
    log('INFO', 'business-storage', { state: outcome.initialized ? 'initialized' : 'reused' });
  } catch (error) {
    const errorCode = podErrorCode(error, 'VC_OPERATION_STORAGE_REQUIRED');
    const cause = error?.cause;
    const causeMessage = (typeof cause?.stderr === 'string' && cause.stderr.trim() ? cause.stderr.trim() : undefined) ??
      cause?.message ?? error?.message;
    // Keep the control plane up; the connector gate throws this diagnostic error
    // so every target apply reports the bounded cause to the framework.
    const detail = [errorCode, typeof error?.reason === 'string' ? error.reason : undefined, causeMessage]
      .filter(value => typeof value === 'string' && value).join(': ');
    storage.failure = Object.assign(new Error(detail), { code: errorCode, outcome: 'unknown' });
    log('ERROR', 'startup-failed', { stage: 'business-storage', errorCode,
      ...(typeof error?.reason === 'string' ? { reason: error.reason } : {}),
      ...safeCause({ name: typeof cause?.name === 'string' ? cause.name : error?.name, message: causeMessage }) });
  }
  const createTargetProcess = createTargetProcessFactory({ runtime, pythonPath, runtimePath, runtimeSHA256,
    startupTargets: runtime.targets, materialize, allocatePort: createPortAllocator() });
  const connector = createVmwarePodConnector({ identity, createTargetProcess, initialTargets: startupDefinitions,
    tls: { ...await tls(clientTls), serverName: clientTls.serverName, serverLeafSHA256: clientTls.serverLeafSHA256 },
    contract: runtime, log,
    diagnoseConnector: createConnectorFailureCapture(),
    async verifyStore() {
      if (storage.failure) throw storage.failure;
      return verifyBusinessStore();
    },
    createConnectorProcess, createProviderRpc, createProviderTransportPolicy,
  });
  const backend = createVmwarePodBackend({ tls: outer, frameworkPin, identity: workloadIdentity, framework, connector,
    businessMethods: runtime.businessMethods, createBackendServer, createPermitMonitor, pollIntervalMs: pollMs,
    connectorRequired: startupDefinitions.length > 0,
    initialTargets: startupDefinitions,
    log,
    onStartupFailure(error) {
      log('ERROR', 'startup-failed', { stage: 'connector-start', errorCode: podErrorCode(error, 'VC_POD_START_FAILED') });
      process.exitCode = 1;
      shutdown();
    },
  });
  const probes = createLocalProbeServer({ ready: backend.ready });

  let stopping;
  const stop = () => stopping ??= (async () => {
    const closed = Promise.all([backend.server, probes].map(server => server.listening
      ? new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()))
      : null));
    try {
      await backend.stop();
      materialized.mayBeInUse = false;
    } finally {
      await closed;
    }
    await materialized.remove();
    materialized.remove = null;
    log('INFO', 'stopped');
  })();
  const shutdown = () => { stop().catch(error => {
    log('ERROR', 'shutdown-failed', { errorCode: podErrorCode(error, 'VC_POD_STOP_FAILED') });
    process.exitCode = 1;
  }); };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  try {
    startupStage = 'listen';
    const listening = Promise.all([backend.server, probes].map(server => once(server, 'listening')));
    backend.server.listen(9443, '0.0.0.0');
    probes.listen(18081, '127.0.0.1');
    await listening;
    materialized.mayBeInUse = true;
    backend.start();
  } catch (error) {
    await stop();
    throw error;
  }
}

const entry = process.argv[1] !== undefined && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (entry) {
  const materialized = { remove: null, mayBeInUse: false };
  main(materialized).catch(async error => {
    if (materialized.remove && !materialized.mayBeInUse) await materialized.remove().catch(() => {});
    log('ERROR', 'startup-failed', { stage: startupStage,
      errorCode: podErrorCode(error, startupStage === 'configuration' ? 'VC_POD_CONFIG_INVALID' : 'VC_POD_START_FAILED') });
    process.exitCode = 1;
  });
}
