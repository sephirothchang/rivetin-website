"""Offline VMware ledger proof and staging commands for the installer."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server.pod_storage import active_pod_operations, stage_pod_storage
from server.profiles import AdapterError
from server.storage_snapshot import binding_storage_snapshot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--store-id', required=True)
    modes = parser.add_subparsers(dest='mode', required=True)
    modes.add_parser('snapshot')
    modes.add_parser('originals')
    stage = modes.add_parser('stage', help='stage a copy after the controller has fenced the writer')
    stage.add_argument('--destination', required=True)
    stage.add_argument('--expected-proof', type=Path, required=True)
    args = parser.parse_args()
    config = {'dataDirectory': args.source, 'dataStoreId': args.store_id}
    try:
        if args.mode == 'stage':
            with args.expected_proof.open('rb') as source:
                proof = source.read(4097)
            if len(proof) > 4096:
                raise ValueError
            result = stage_pod_storage(config, args.destination, json.loads(proof))
        elif args.mode == 'originals':
            result = active_pod_operations(config)
        else:
            result = binding_storage_snapshot(config)
    except (OSError, ValueError, AdapterError):
        print('VC_OPERATION_STORAGE_REQUIRED', file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True, separators=(',', ':')))
    return 0


if __name__ == '__main__':
    sys.exit(main())
