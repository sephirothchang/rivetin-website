"""vSphere business adapters; no listener, credential store or runtime loader."""
