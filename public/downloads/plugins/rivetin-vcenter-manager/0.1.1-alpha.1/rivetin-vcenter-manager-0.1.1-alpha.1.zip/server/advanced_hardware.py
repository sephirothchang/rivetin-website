"""Powered-off device edits reviewed and applied in one change-version ConfigSpec."""
import copy
from collections import Counter, defaultdict
import json
import re
import time

from .disk_paths import new_disk_path, verify_disk_path, vmx_path_hash
from .managed_devices import native_ref
from .operation_ledger import operation_id, require
from .profiles import AdapterError
from .resource_scope import identity

CONTROLLERS = {'VirtualLsiLogicSASController', 'VirtualLsiLogicController', 'VirtualBusLogicController', 'ParaVirtualSCSIController'}
NICS = {'VirtualVmxnet3', 'VirtualE1000', 'VirtualE1000e'}
CD_CONTROLLERS = {'VirtualIDEController', 'VirtualAHCIController', 'VirtualSATAController'}
NVME = 'VirtualNVMEController'
BUS_SHARING = {'noSharing', 'virtualSharing', 'physicalSharing'}
DISK_MODES = {'persistent', 'independent_persistent', 'independent_nonpersistent'}
PROVISIONING = {'thin': (True, False), 'thick': (False, False), 'eagerZeroedThick': (False, True)}
STATIC_MAC = re.compile(r'00:50:56:[0-3][0-9a-f](?::[0-9a-f]{2}){2}')
ADVANCED_FIELDS = {
    'controller.add': {'type', 'busNumber', 'sharedBus'},
    'controller.edit': {'deviceKey', 'type', 'sharedBus'},
    'controller.remove': {'deviceKey'},
    'disk.add': {'controllerKey', 'unitNumber', 'datastore', 'capacityGB', 'diskId', 'provisioning', 'diskMode', 'sharing'},
    'disk.edit': {'deviceKey', 'controllerKey', 'unitNumber', 'diskMode'},
    'disk.remove': {'deviceKey', 'retainFiles'},
    'nic.add': {'type', 'network', 'startConnected', 'addressType', 'macAddress'},
    'nic.edit': {'deviceKey', 'type', 'network', 'startConnected', 'addressType', 'macAddress'},
    'nic.remove': {'deviceKey'},
    'cdrom.add': {'controllerKey', 'unitNumber', 'datastore', 'isoPath', 'startConnected'},
    'cdrom.edit': {'deviceKey', 'datastore', 'isoPath', 'startConnected'},
    'cdrom.remove': {'deviceKey'},
    'library.mount': {'itemId', 'version'},
}


def exact_json_pairs(pairs):
    value = dict(pairs)
    require(len(value) == len(pairs), 'VC_OPERATION_INVALID')
    return value


def advanced_changes(raw):
    require(isinstance(raw, str) and 0 < len(raw) <= 4096, 'VC_OPERATION_INVALID')
    try:
        value = json.loads(raw, object_pairs_hook=exact_json_pairs)
    except (ValueError, RecursionError):
        require(False, 'VC_OPERATION_INVALID')
    require(isinstance(value, list) and 0 < len(value) <= 20, 'VC_OPERATION_INVALID')
    for item in value:
        require(isinstance(item, dict) and set(item) == {'operation', 'parameters'}, 'VC_OPERATION_INVALID')
        kind, params = item['operation'], item['parameters']
        require(isinstance(kind, str) and kind in ADVANCED_FIELDS and isinstance(params, dict)
                and set(params) == ADVANCED_FIELDS[kind], 'VC_OPERATION_INVALID')
    return value


def integer(value, low, high):
    require(type(value) is int and low <= value <= high, 'VC_OPERATION_INVALID')
    return value


def choice(value, choices):
    require(isinstance(value, str) and value in choices, 'VC_OPERATION_INVALID')
    return value


def option_values(option):
    return {item.key for item in option.choiceInfo or []} if option is not None else set()


def bool_supported(option):
    return option is not None and option.supported is True


def available_disk_modes(backing):
    mode = backing.diskMode
    return option_values(mode) & DISK_MODES if mode is not None and mode.valueIsReadonly is not True else set()


def matches_storage_controller(types, controller, declared):
    if not isinstance(declared, type):
        return False
    if issubclass(declared, types.VirtualController):
        return isinstance(controller, declared)
    if not issubclass(declared, types.VirtualControllerOption):
        return False
    # AHCI uses the SATA option class in SDKs without a distinct AHCI option.
    for cls in type(controller).__mro__:
        if not issubclass(cls, types.VirtualController):
            break
        option = getattr(types, cls._wsdlName + 'Option', None)
        if isinstance(option, type) and issubclass(option, types.VirtualControllerOption):
            return issubclass(option, declared)
    return False


def generated_nic_signature(item):
    if (item['operation'] == 'nic.add' or item['operation'] == 'nic.edit' and item.get('replacement')) and (
            item['addressType'] == 'generated' and item['macAddress'] is None):
        p = item['parameters']
        return item['type'], p['network']['objectId'], p['startConnected']


def safe_relative_path(value):
    return (isinstance(value, str) and 0 < len(value) <= 384
            and not any(ord(c) < 32 or ord(c) == 127 or c in '[]\\:%*?' for c in value)
            and all(piece and piece == piece.strip() and piece not in ('.', '..') for piece in value.split('/')))


def iso_relative_path(value):
    require(safe_relative_path(value) and value.lower().endswith('.iso'), 'VC_OPERATION_INVALID')
    return value


class AdvancedHardware:
    def read_hardware_capabilities(self, key):
        props, _, _ = self.scoped_vm(key)
        require(props['config.template'] is False and str(props['runtime.powerState']) == 'poweredOff', 'VC_OPERATION_STATE_CONFLICT')
        self.privilege(key, ['System.View'])
        hardware, _ = self.hardware_options(key)
        options = hardware.virtualDeviceOption or []
        types = self.vim.vm.device
        controllers, nics = {}, {}
        for name in sorted(CONTROLLERS | NICS):
            matches = [item for item in options if item.type is getattr(types, name) and item.deprecated is not True]
            if len(matches) != 1:
                continue
            option = matches[0]
            if name in CONTROLLERS and option.sharing is not None:
                controllers[name] = sorted(set(option.sharing) & BUS_SHARING)
            elif name in NICS and option.macType is not None:
                nics[name] = sorted(option_values(option.macType) & {'generated', 'manual'})
        devices = self.devices(key)
        storage = {'disk': {}, 'cdrom': {}}
        for controller in devices:
            name = type(controller)._wsdlName
            if (name in CONTROLLERS and controller.sharedBus == 'noSharing') or name == NVME:
                option, backing, reason = self.storage_option(hardware, 'VirtualDisk', controller)
                modes = sorted(available_disk_modes(backing)) if backing else []
                if reason is None and not modes:
                    reason = 'diskModesMissing'
                provision = []
                if modes:
                    provision = ['thick'] + (['thin'] if bool_supported(backing.thinProvisioned) else []) + (
                        ['eagerZeroedThick'] if bool_supported(backing.eagerlyScrub) else [])
                if name == NVME:
                    if controller.sharedBus not in (None, '', 'noSharing'):
                        reason = 'diskControllerShared'
                    add_reason = 'diskControllerInPlaceOnly'
                else:
                    add_reason = reason or ('deviceDeprecated' if option.deprecated is True else
                                            None if self.disk_capacity_available(option) else 'diskCapacityMissing')
                storage['disk'][str(controller.key)] = {'modes': modes, 'provisioning': provision,
                                                       'editReason': reason, 'addReason': add_reason}
            elif name in CD_CONTROLLERS:
                option, _, reason = self.storage_option(hardware, 'VirtualCdrom', controller)
                storage['cdrom'][str(controller.key)] = {'editReason': reason, 'addReason':
                    reason or ('deviceDeprecated' if option.deprecated is True else None)}
        disk = {field: sorted({value for row in storage['disk'].values() for value in row[field]})
                for field in ('modes', 'provisioning')}
        cdrom = any(row['editReason'] is None for row in storage['cdrom'].values())
        details = []
        for device in devices:
            if type(device)._wsdlName in NICS and re.fullmatch(r'(?:[0-9a-f]{2}:){5}[0-9a-f]{2}', device.macAddress or '', re.I):
                details.append({'key': device.key, 'macAddress': device.macAddress.lower()})
            elif type(device) is types.VirtualCdrom and type(device.backing) is types.VirtualCdrom.IsoBackingInfo:
                name = device.backing.fileName or ''
                match = re.fullmatch(r'\[[^\[\]\r\n]+\] (.+)', name)
                if match:
                    try:
                        path = iso_relative_path(match.group(1))
                    except AdapterError:
                        continue
                    details.append({'key': device.key, 'isoPath': path})
        return {'controllers': controllers, 'nics': nics, 'disk': disk, 'cdrom': cdrom, 'deviceDetails': details, 'storage': storage}

    def storage_option(self, hardware, name, controller):
        types = self.vim.vm.device
        native, option_type = getattr(types, name), getattr(types, name + 'Option')
        declared = [item for item in hardware.virtualDeviceOption or []
                    if type(item) is option_type and item.type is native]
        matches = [item for item in declared if matches_storage_controller(types, controller, item.controllerType)]
        if not matches:
            matches = [item for item in declared if item.controllerType is None]
        if len(matches) != 1:
            return None, None, 'deviceOptionAmbiguous' if matches else 'deviceOptionMissing'
        option = matches[0]
        backing_type = (types.VirtualDiskOption.FlatVer2BackingOption if name == 'VirtualDisk'
                        else types.VirtualCdromOption.IsoBackingOption)
        backing_info = native.FlatVer2BackingInfo if name == 'VirtualDisk' else native.IsoBackingInfo
        backings = [item for item in option.backingOption or []
                    if type(item) is backing_type and item.type is backing_info]
        if len(backings) != 1:
            return option, None, 'backingOptionAmbiguous' if backings else 'backingOptionMissing'
        return option, backings[0], None

    @staticmethod
    def disk_capacity_available(option):
        capacity = option.capacityInKB
        # OptionType defines an omitted valueIsReadonly as writable.
        return (capacity is not None and (capacity.valueIsReadonly is None or capacity.valueIsReadonly is False)
                and isinstance(capacity.min, int) and not isinstance(capacity.min, bool)
                and isinstance(capacity.max, int) and not isinstance(capacity.max, bool)
                and 0 <= capacity.min <= capacity.max and capacity.max > 0)

    def advanced_option(self, hardware, name):
        cls = getattr(self.vim.vm.device, name)
        matches = [item for item in hardware.virtualDeviceOption if item.type is cls and item.deprecated is not True]
        require(len(matches) == 1, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        return matches[0]

    def advanced_datastore(self, host, datastore, privilege):
        identity(datastore, 'Datastore')
        require(any(native_ref(item) == datastore for item in self.read(host, ['datastore'])['datastore']), 'VC_PERMISSION_DENIED')
        props = self.read(datastore, ['name', 'summary.accessible'])
        name = props['name']
        require(isinstance(name, str) and 0 < len(name) <= 80 and not any(ord(c) < 32 or c in '[]/\\' for c in name)
                and props['summary.accessible'] is True, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        self.privilege(datastore, [privilege])
        return name

    def prepare_advanced_hardware(self, key, items, host):
        hardware, _ = self.hardware_options(key)
        devices = self.devices(key)
        existing = {device.key: device for device in devices}
        prior = [{'key': device.key, 'digest': self.device_digest(device)} for device in devices]
        planned, touched, slots, reserved_buses, added_macs, disk_ids = [], set(), set(), set(), set(), set()
        for index, item in enumerate(items):
            operation, p = item['operation'], item['parameters']
            kind, action = operation.split('.')
            device = None
            if action != 'add':
                identifier = integer(p['deviceKey'], 0, 2147483647)
                require(identifier not in touched and identifier in existing, 'VC_OPERATION_STATE_CONFLICT')
                touched.add(identifier)
                device = existing[identifier]
            expected = {'operation': operation, 'parameters': p, 'temporaryKey': -300 - index}
            if kind == 'controller':
                self._advanced_controller(key, action, p, expected, device, devices, hardware, reserved_buses)
            elif kind == 'disk':
                self._advanced_disk(key, host, action, p, expected, device, existing, hardware, slots, disk_ids)
            elif kind == 'nic':
                self._advanced_nic(key, host, action, p, expected, device, devices, hardware, added_macs)
            else:
                self._advanced_cdrom(key, host, action, p, expected, device, existing, hardware, slots)
            planned.append(expected)
        changed_controllers = {item['parameters']['deviceKey'] for item in planned
                               if item['operation'] in {'controller.edit', 'controller.remove'}}
        require(not any(item.get('controllerKey') in changed_controllers for item in planned if not item['operation'].startswith('controller.')),
                'VC_OPERATION_STATE_CONFLICT')
        generated = Counter(signature for item in planned if (signature := generated_nic_signature(item)) is not None)
        require(not any(item.get('replacement') and generated[generated_nic_signature(item)] > 1 for item in planned),
                'VC_OPERATION_STATE_CONFLICT')
        return {'devicesBefore': prior, 'items': planned}

    def _advanced_controller(self, key, action, p, expected, device, devices, hardware, buses):
        if device is not None:
            require(type(device)._wsdlName in CONTROLLERS and not any(item.controllerKey == device.key for item in devices)
                    and not device.device, 'VC_OPERATION_RESOURCE_IN_USE')
        if action == 'remove':
            self.privilege(key, ['VirtualMachine.Config.AddRemoveDevice'])
            return
        kind = choice(p['type'], CONTROLLERS)
        shared = choice(p['sharedBus'], BUS_SHARING)
        option = self.advanced_option(hardware, kind)
        require(shared in (option.sharing or []), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        bus = integer(p['busNumber'] if device is None else device.busNumber, 0, 3)
        require(bus not in buses and not any(item is not device and isinstance(item, self.vim.vm.device.VirtualSCSIController)
                                           and item.busNumber == bus for item in devices), 'VC_OPERATION_STATE_CONFLICT')
        buses.add(bus)
        replacement = device is not None and type(device)._wsdlName != kind
        self.privilege(key, ['VirtualMachine.Config.AddRemoveDevice' if action == 'add' or replacement else 'VirtualMachine.Config.EditDevice'])
        expected.update(type=kind, sharedBus=shared, busNumber=bus, replacement=replacement)

    def _advanced_slot(self, p, expected, device, existing, slots, *, cdrom=False):
        controller = existing.get(integer(p['controllerKey'], 0, 2147483647))
        kinds = CD_CONTROLLERS if cdrom else CONTROLLERS
        require(controller is not None and type(controller)._wsdlName in kinds, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        if not cdrom:
            require(controller.sharedBus == 'noSharing', 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        limit = 1 if type(controller)._wsdlName == 'VirtualIDEController' else 29 if cdrom else 15
        unit = integer(p['unitNumber'], 0, limit)
        require(cdrom or unit not in (7, controller.scsiCtlrUnitNumber), 'VC_OPERATION_STATE_CONFLICT')
        slot = (controller.key, unit)
        require(slot not in slots and not any(other is not device and (other.controllerKey, other.unitNumber) == slot for other in existing.values()),
                'VC_OPERATION_STATE_CONFLICT')
        slots.add(slot)
        expected.update(controllerKey=controller.key, unitNumber=unit)

    def _advanced_disk(self, key, host, action, p, expected, device, existing, hardware, slots, disk_ids):
        native = self.vim.vm.device.VirtualDisk
        if device is not None:
            require(type(device) is native, 'VC_OPERATION_STATE_CONFLICT')
        if action == 'remove':
            require(p['retainFiles'] is True, 'VC_OPERATION_INVALID')
            require(type(device.backing) is native.FlatVer2BackingInfo and device.backing.parent is None
                    and device.backing.keyId is None and device.backing.sharing in (None, 'sharingNone'), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            self.privilege(key, ['VirtualMachine.Config.RemoveDisk'])
            return
        original_controller = existing.get(device.controllerKey) if device is not None else None
        if type(original_controller) is self.vim.vm.device.VirtualNVMEController:
            require(original_controller.sharedBus in (None, '', 'noSharing')
                    and integer(p['controllerKey'], 0, 2147483647) == device.controllerKey
                    and integer(p['unitNumber'], 0, 2147483647) == device.unitNumber, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            expected.update(controllerKey=device.controllerKey, unitNumber=device.unitNumber)
        else:
            self._advanced_slot(p, expected, device, existing, slots)
        option, backing, reason = self.storage_option(hardware, 'VirtualDisk', existing[expected['controllerKey']])
        require(reason is None and (action != 'add' or option.deprecated is not True), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        mode = choice(p['diskMode'], DISK_MODES)
        require(mode in available_disk_modes(backing), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        if action == 'edit':
            original = device.backing
            require(type(original) is native.FlatVer2BackingInfo and original.parent is None and original.keyId is None
                    and original.sharing in (None, 'sharingNone'), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            require(self.read(key, ['snapshot'], optional=('snapshot',))['snapshot'] is None, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            datastore = native_ref(original.datastore, 'Datastore')
            self.advanced_datastore(host, datastore, 'System.View')
            self.privilege(key, ['VirtualMachine.Config.EditDevice'])
            expected['fileName'] = original.fileName
            return
        amount = integer(p['capacityGB'], 1, 65536) * 1048576
        require(self.disk_capacity_available(option)
                and option.capacityInKB.min <= amount <= option.capacityInKB.max, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        provision = choice(p['provisioning'], PROVISIONING)
        sharing = choice(p['sharing'], {'sharingNone', 'sharingMultiWriter'})
        name = self.advanced_datastore(host, p['datastore'], 'Datastore.AllocateSpace')
        if provision == 'thin':
            field = 'capability.perFileThinProvisioningSupported'
            require(bool_supported(backing.thinProvisioned) and self.read(p['datastore'], [field], optional=(field,))[field] is True,
                    'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        if provision == 'eagerZeroedThick':
            require(bool_supported(backing.eagerlyScrub), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        if sharing == 'sharingMultiWriter':
            fields = ('config.changeTrackingEnabled', 'snapshot')
            state = self.read(key, fields, optional=fields)
            store_type = self.read(p['datastore'], ['summary.type'], optional=('summary.type',))['summary.type']
            require(provision == 'eagerZeroedThick' and mode == 'independent_persistent' and store_type == 'VMFS'
                    and state['config.changeTrackingEnabled'] is False and state['snapshot'] is None,
                    'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        token = operation_id(p['diskId'])
        require(token not in disk_ids, 'VC_OPERATION_STATE_CONFLICT')
        disk_ids.add(token)
        vmx = self.read(key, ['config.files.vmPathName'])['config.files.vmPathName']
        expected.update(fileName=new_disk_path(vmx, name, token), vmxPathHash=vmx_path_hash(vmx))
        self.privilege(key, ['VirtualMachine.Config.AddNewDisk'])

    def _advanced_nic(self, key, host, action, p, expected, device, devices, hardware, macs):
        nic = self.vim.vm.device.VirtualEthernetCard
        if device is not None:
            require(type(device)._wsdlName in NICS and type(device.backing) is nic.NetworkBackingInfo
                    and device.connectable is not None, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        if action == 'remove':
            self.privilege(key, ['VirtualMachine.Config.AddRemoveDevice'])
            return
        kind = choice(p['type'], NICS)
        option = self.advanced_option(hardware, kind)
        mode = choice(p['addressType'], {'keep', 'manual', 'generated'})
        require(type(p['startConnected']) is bool and isinstance(p['macAddress'], str), 'VC_OPERATION_INVALID')
        replacement = device is not None and type(device)._wsdlName != kind
        if mode == 'keep':
            require(device is not None and not replacement and p['macAddress'] == '', 'VC_OPERATION_INVALID')
            expected.update(addressType=device.addressType, macAddress=device.macAddress)
        else:
            require(mode in option_values(option.macType), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            mac = p['macAddress'].lower()
            require((bool(STATIC_MAC.fullmatch(mac)) if mode == 'manual' else not mac), 'VC_OPERATION_INVALID')
            if mac:
                require(mac not in macs and not any(isinstance(other, nic) and other is not device and
                        (other.macAddress or '').lower() == mac for other in devices), 'VC_OPERATION_STATE_CONFLICT')
                macs.add(mac)
            expected.update(addressType=mode, macAddress=mac or None)
        expected.update(type=kind, networkName=self.device_network(host, p['network']), replacement=replacement)
        privileges = ['VirtualMachine.Config.AddRemoveDevice'] if action == 'add' or replacement else ['VirtualMachine.Config.EditDevice']
        self.privilege(key, privileges + ['VirtualMachine.Interact.DeviceConnection'])

    def _advanced_cdrom(self, key, host, action, p, expected, device, existing, hardware, slots):
        native = self.vim.vm.device.VirtualCdrom
        if device is not None:
            require(type(device) is native and device.connectable is not None, 'VC_OPERATION_STATE_CONFLICT')
        if action == 'remove':
            self.privilege(key, ['VirtualMachine.Config.AddRemoveDevice'])
            return
        require(type(p['startConnected']) is bool, 'VC_OPERATION_INVALID')
        if action == 'add':
            self._advanced_slot(p, expected, None, existing, slots, cdrom=True)
        else:
            expected.update(controllerKey=device.controllerKey, unitNumber=device.unitNumber)
        controller = existing.get(expected['controllerKey'])
        require(controller is not None and type(controller)._wsdlName in CD_CONTROLLERS, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        option, _, reason = self.storage_option(hardware, 'VirtualCdrom', controller)
        require(reason is None and (action != 'add' or option.deprecated is not True), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        name = self.advanced_datastore(host, p['datastore'], 'Datastore.Browse')
        relative_path = iso_relative_path(p['isoPath'])
        self.check_datastore_iso(p['datastore'], name, relative_path)
        expected['fileName'] = '[' + name + '] ' + relative_path
        self.privilege(key, ['VirtualMachine.Interact.DeviceConnection', 'VirtualMachine.Interact.SetCDMedia',
                            'VirtualMachine.Config.AddRemoveDevice' if action == 'add' else 'VirtualMachine.Config.EditDevice'])

    def search_datastore_folder(self, datastore, folder, spec):
        browser_type = self.vim.host.DatastoreBrowser
        try:
            browser = self.read(datastore, ['browser'])['browser']
            require(isinstance(browser, browser_type), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            task = native_ref(browser.SearchDatastore_Task(datastorePath=folder, searchSpec=spec), 'Task')
            # Directory searches are asynchronous even when the path is local to ESXi.
            for delay in (0, 0.2, 0.4, 0.8, 1.2, 1.5, 1.5, 1.5):
                require(time.monotonic() + delay < self._native_deadline, 'VC_TIMEOUT')
                if delay:
                    time.sleep(delay)
                self.cache.pop(identity(task), None)
                state = self.read(task, ['info.state', 'info.result', 'info.error'], optional=('info.result', 'info.error'))
                if state['info.state'] == 'success':
                    result = state['info.result']
                    break
                if state['info.state'] == 'error':
                    fault = state['info.error']
                    if isinstance(fault, self.vmodl.LocalizedMethodFault):
                        fault = fault.fault
                    if isinstance(fault, (self.vim.fault.NoPermission, self.vim.fault.NotAuthenticated)):
                        raise fault
                require(state['info.state'] in ('queued', 'running'), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            else:
                raise AdapterError('VC_TIMEOUT')
        except self.vim.fault.NoPermission:
            raise AdapterError('VC_PERMISSION_DENIED') from None
        except self.vim.fault.NotAuthenticated:
            raise AdapterError('VC_AUTHENTICATION_FAILED') from None
        except (self.vim.fault.FileNotFound, self.vim.fault.InvalidDatastore) as error:
            raise AdapterError('VC_OPERATION_CAPABILITY_UNAVAILABLE') from error
        require(isinstance(result, browser_type.SearchResults) and isinstance(result.folderPath, str)
                and result.folderPath.rstrip('/ ') == folder
                and (result.datastore is None or native_ref(result.datastore) == datastore), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        return result.file or []

    def check_datastore_iso(self, datastore, name, relative_path):
        browser_type = self.vim.host.DatastoreBrowser
        directory, _, basename = relative_path.rpartition('/')
        folder = '[' + name + ']' + (' ' + directory if directory else '')
        spec = browser_type.SearchSpec(query=[browser_type.IsoImageQuery()],
                                      matchPattern=[basename], searchCaseInsensitive=False)
        files = self.search_datastore_folder(datastore, folder, spec)
        require(len(files) == 1 and isinstance(files[0], browser_type.IsoImageInfo)
                and files[0].path == basename, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')

    def browse_datastore_iso(self, key, datastore, directory):
        require(directory == '' or safe_relative_path(directory), 'VC_OPERATION_INVALID')
        props, host, _ = self.scoped_vm(key)
        require(props['config.template'] is False and str(props['runtime.powerState']) == 'poweredOff', 'VC_OPERATION_STATE_CONFLICT')
        self.privilege(key, ['System.View'])
        name = self.advanced_datastore(host, datastore, 'Datastore.Browse')
        folder = '[' + name + ']' + (' ' + directory if directory else '')
        browser = self.vim.host.DatastoreBrowser
        spec = browser.SearchSpec(query=[browser.FolderQuery(), browser.IsoImageQuery()])
        files = self.search_datastore_folder(datastore, folder, spec)
        require(len(files) <= 2000, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        entries = set()
        for item in files:
            if type(item) not in (browser.FolderInfo, browser.IsoImageInfo):
                continue
            child = item.path
            if not isinstance(child, str) or '/' in child or not safe_relative_path(f'{directory}/{child}' if directory else child):
                continue
            if type(item) is browser.FolderInfo:
                entries.add(('folder', child))
            elif type(item) is browser.IsoImageInfo and child.lower().endswith('.iso'):
                entries.add(('iso', child))
        ordered = sorted(entries, key=lambda entry: (entry[0], entry[1].casefold(), entry[1]))
        return {'datastore': datastore, 'directory': directory, 'truncated': len(ordered) > 200,
                'entries': [{'kind': kind, 'name': child} for kind, child in ordered[:200]]}

    def advanced_device_specs(self, key, plan):
        types = self.vim.vm.device
        devices = {device.key: device for device in self.devices(key)}
        results = []
        for item in plan['items']:
            kind, action = item['operation'].split('.')
            p = item['parameters']
            old = devices.get(p.get('deviceKey'))
            if action == 'remove' or item.get('replacement'):
                results.append(types.VirtualDeviceSpec(operation='remove', device=old))
                if action == 'remove':
                    continue
                action = 'add'
            device = copy.copy(old) if action == 'edit' else None
            if kind == 'controller':
                if device is None:
                    device = getattr(types, item['type'])(key=item['temporaryKey'], busNumber=item['busNumber'])
                device.sharedBus = item['sharedBus']
            elif kind == 'disk':
                if device is None:
                    thin, eager = PROVISIONING[p['provisioning']]
                    backing = types.VirtualDisk.FlatVer2BackingInfo(fileName=item['fileName'], diskMode=p['diskMode'],
                                                                    thinProvisioned=thin, eagerlyScrub=eager, sharing=p['sharing'])
                    device = types.VirtualDisk(key=item['temporaryKey'], capacityInKB=p['capacityGB'] * 1048576, backing=backing)
                else:
                    device.backing = copy.copy(device.backing)
                    device.backing.diskMode = p['diskMode']
                device.controllerKey, device.unitNumber = item['controllerKey'], item['unitNumber']
            elif kind == 'nic':
                if device is None:
                    device = getattr(types, item['type'])(key=item['temporaryKey'])
                if p['addressType'] != 'keep':
                    device.addressType, device.macAddress = item['addressType'], item['macAddress']
                device.backing = types.VirtualEthernetCard.NetworkBackingInfo(deviceName=item['networkName'])
                device.connectable = self._advanced_connectable(types, old, p['startConnected'])
            else:
                if device is None:
                    device = types.VirtualCdrom(key=item['temporaryKey'])
                device.controllerKey, device.unitNumber = item['controllerKey'], item['unitNumber']
                device.backing = types.VirtualCdrom.IsoBackingInfo(fileName=item['fileName'], datastore=self.obj(p['datastore']))
                device.connectable = self._advanced_connectable(types, old, p['startConnected'])
            kwargs = {'fileOperation': 'create'} if kind == 'disk' and action == 'add' else {}
            results.append(types.VirtualDeviceSpec(operation=action, device=device, **kwargs))
        return results

    @staticmethod
    def _advanced_connectable(types, old, start):
        current = copy.copy(old.connectable) if old is not None else types.VirtualDevice.ConnectInfo(allowGuestControl=True, connected=False)
        current.startConnected = start
        return current

    def verify_advanced_devices(self, key, plan):
        devices = self.devices(key)
        old_keys = {item['key'] for item in plan['devicesBefore']}
        candidates, generated = [], defaultdict(list)
        for index, item in enumerate(plan['items']):
            kind, action = item['operation'].split('.')
            identifier = item['parameters'].get('deviceKey')
            signature = generated_nic_signature(item) if action == 'add' else None
            if signature is not None:
                generated[signature].append(index)
                continue
            if action == 'remove':
                verified = all(device.key != identifier for device in devices)
                candidates.append(([index], verified, set()))
            else:
                add = action == 'add' or item.get('replacement')
                matches = {device.key for device in devices if
                           (device.key not in old_keys or item.get('replacement') and device.key == identifier if add else device.key == identifier)
                           and self._advanced_device_matches(key, kind, action, item, device)}
                verified = len(matches) == 1 and (not item.get('replacement') or identifier in matches
                                                 or all(device.key != identifier for device in devices))
                candidates.append(([index], verified, matches))
        nic = self.vim.vm.device.VirtualEthernetCard
        macs = Counter((device.macAddress or '').lower() for device in devices if isinstance(device, nic))
        for indices in generated.values():
            item = plan['items'][indices[0]]
            matches = [device for device in devices if device.key not in old_keys
                       and self._advanced_device_matches(key, 'nic', 'add', item, device)]
            verified = len(matches) == len(indices) and all(
                re.fullmatch(r'(?:[0-9a-f]{2}:){5}[0-9a-f]{2}', mac) and mac != '00:00:00:00:00:00'
                and not int(mac[:2], 16) & 1 and macs[mac] == 1 for mac in ((device.macAddress or '').lower() for device in matches))
            candidates.append((indices, verified, {device.key for device in matches}))
        claims = Counter(device_key for _, _, keys in candidates for device_key in keys)
        results = [{'operation': item['operation'], 'verified': False} for item in plan['items']]
        for indices, verified, keys in candidates:
            unique = verified and all(claims[device_key] == 1 for device_key in keys)
            for index in indices:
                results[index]['verified'] = unique
        return results

    def _advanced_device_matches(self, key, kind, action, item, device):
        p, types = item['parameters'], self.vim.vm.device
        if kind == 'controller':
            return type(device)._wsdlName == item['type'] and device.busNumber == item['busNumber'] and device.sharedBus == item['sharedBus']
        if kind == 'disk':
            if (type(device) is not types.VirtualDisk or type(device.backing) is not types.VirtualDisk.FlatVer2BackingInfo
                    or device.backing.diskMode != p['diskMode'] or (device.controllerKey, device.unitNumber) != (item['controllerKey'], item['unitNumber'])):
                return False
            if action != 'add':
                return device.backing.fileName == item['fileName']
            thin, eager = PROVISIONING[p['provisioning']]
            if (device.capacityInKB != p['capacityGB'] * 1048576 or device.backing.datastore is None
                    or native_ref(device.backing.datastore) != p['datastore'] or bool(device.backing.thinProvisioned) != thin
                    or bool(device.backing.eagerlyScrub) != eager or device.backing.fileName != item['fileName']
                    or (device.backing.sharing or 'sharingNone') != p['sharing']):
                return False
            vmx = self.read(key, ['config.files.vmPathName'])['config.files.vmPathName']
            return verify_disk_path(device.backing.fileName, item['fileName'], vmx, p['diskId'], frozen_vmx_hash=item['vmxPathHash'])
        if kind == 'nic':
            return (type(device)._wsdlName == item['type'] and type(device.backing) is types.VirtualEthernetCard.NetworkBackingInfo
                    and device.backing.network is not None and native_ref(device.backing.network) == p['network']
                    and device.connectable is not None and device.connectable.startConnected is p['startConnected']
                    and device.addressType == item['addressType'] and (item['macAddress'] is None or
                    (device.macAddress or '').lower() == item['macAddress'].lower()))
        return (type(device) is types.VirtualCdrom and type(device.backing) is types.VirtualCdrom.IsoBackingInfo
                and device.backing.datastore is not None and native_ref(device.backing.datastore) == p['datastore']
                and device.backing.fileName == item['fileName'] and (device.controllerKey, device.unitNumber) == (item['controllerKey'], item['unitNumber'])
                and device.connectable is not None and device.connectable.startConnected is p['startConnected'])
