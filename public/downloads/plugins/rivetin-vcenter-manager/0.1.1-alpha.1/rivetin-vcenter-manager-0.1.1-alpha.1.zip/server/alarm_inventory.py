"""Exact alarm occurrences; no acknowledged user names or alarm definitions."""
from datetime import datetime, timezone
from .profiles import AdapterError
from .vsphere_readonly import VIM, ref, text


def timestamp(value):
    try:
        parsed=value if isinstance(value,datetime) else datetime.fromisoformat(value.replace('Z','+00:00'))
        if parsed.utcoffset() is None:raise ValueError()
        return parsed.astimezone(timezone.utc).isoformat(timespec='microseconds')
    except (ValueError,TypeError,AttributeError):raise AdapterError('VC_RESPONSE_INVALID') from None


def alarm_inventory(value):
    if len(value)>200:raise AdapterError('VC_INVENTORY_LIMIT')
    rows,seen=[],set()
    for item in value:
        if item.tag!='{' + VIM + '}AlarmState':raise AdapterError('VC_RESPONSE_INVALID')
        def node(name):
            matches=item.findall('{' + VIM + '}' + name)
            if len(matches)>1:raise AdapterError('VC_RESPONSE_INVALID')
            return matches[0] if matches else None
        def string(name,limit=128):
            found=node(name)
            return text(found.text if found is not None else None,limit)
        key=string('key',256)
        if key in seen:raise AdapterError('VC_RESPONSE_INVALID')
        seen.add(key);status=string('overallStatus',16)
        if status not in ('green','yellow','red','gray'):raise AdapterError('VC_RESPONSE_INVALID')
        row={'key':key,'entity':ref(node('entity')),'alarm':ref(node('alarm'),'Alarm'),'status':status,'time':timestamp(string('time',80))}
        for field in ('acknowledged','disabled'):
            found=node(field)
            if found is not None:
                if found.text not in ('true','false','1','0'):raise AdapterError('VC_RESPONSE_INVALID')
                row[field]=found.text in ('true','1')
        rows.append(row)
    return rows
