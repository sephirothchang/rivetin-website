"""Narrow SetAlarmStatus adapter using locally verified method metadata.

The public locked SDK lacks this method. No SDK type is patched globally;
its bounded serializer/response decoder are reused with private method info.
Only the observed vCenter binary profile is eligible. Functional compatibility
and native permission behavior still require a real-environment test.
"""
import copy
from .operation_ledger import require

PROFILE = 'vc8-u3-set-alarm-status-r1'
PROFILES = {('VirtualCenter','8.0.3.0','8.0.3','25092719'):PROFILE,
            ('VirtualCenter','7.0.3.0','7.0.3','24201990'):'vc7-u3-set-alarm-status-r1'}


def alarm_status_capability(about):
    key=tuple(about.get(name) if isinstance(about,dict) else getattr(about,name,None) for name in ('apiType','apiVersion','version','build'))
    return PROFILES.get(key)


def alarm_status_profile(service):
    about = service.about
    profile=alarm_status_capability(about)
    require(profile is not None, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
    return profile


def set_alarm_green(executor,manager,alarm,entity):
    alarm_status_profile(executor.service)
    sdk = executor.sdk
    info = copy.copy(sdk.vim.alarm.AlarmManager._GetMethodInfo('AcknowledgeAlarm'))
    info.name = info.wsdlName = 'SetAlarmStatus'
    info.version = executor.stub.version
    info.params = tuple(info.params) + (sdk.VmomiSupport.Object(name='status',type=sdk.vim.ManagedEntity.Status,version=info.version,flags=0),)
    return executor.stub.InvokeMethod(executor.obj(manager),info,[executor.obj(alarm),executor.obj(entity),sdk.vim.ManagedEntity.Status('green')])
