"""Pure C1 projections of bounded read-only inventory, without transport or proofs.

The trusted carrier must supply authenticated facts and a fresh snapshot. It owns
endpoint/trust/credential binding, deadlines, snapshot lifetime and cursor state.
This module neither authenticates nor issues cursors, proofs or save receipts.
"""
import copy
import json
from xml.etree import ElementTree as ET

from .profiles import AdapterError, PROFILES, adaptation, choose_profile
from .vsphere_readonly import KINDS, ReadOnlyConnector, ref

SCHEMA_ID = "rivetin-vcenter-readonly-v1"
SCHEMA_VERSION = 1
ROOT_TYPE = "ClusterComputeResource"
VISIBLE_SCOPE = {"kind": "permission-visible", "inventory": "soap", "filter": {}}
ERROR_CODES = {
    "VC_AUTHENTICATION_FAILED": "CONNECTION_AUTHENTICATION_FAILED",
    "VC_PERMISSION_DENIED": "CONNECTION_PERMISSION_DENIED",
    "VC_ADAPTATION_INVALID": "CONNECTION_ADAPTATION_UNSUPPORTED",
    "VC_ADAPTATION_UNSUPPORTED": "CONNECTION_ADAPTATION_UNSUPPORTED",
    "VC_VERSION_UNSUPPORTED": "CONNECTION_ADAPTATION_UNSUPPORTED",
    "VC_TARGET_NOT_VCENTER": "CONNECTION_ADAPTATION_UNSUPPORTED",
    "VC_INSTANCE_IDENTITY_REQUIRED": "CONNECTION_RESPONSE_INVALID",
    "VC_XML_REFUSED": "CONNECTION_RESPONSE_INVALID",
    "VC_RESPONSE_INVALID": "CONNECTION_RESPONSE_INVALID",
    "VC_REFERENCE_INVALID": "CONNECTION_RESPONSE_INVALID",
    "VC_SOAP_FAULT": "CONNECTION_RESPONSE_INVALID",
    "VC_INVENTORY_INCOMPLETE": "CONNECTION_DISCOVERY_INCOMPLETE",
    "VC_INVENTORY_LIMIT": "CONNECTION_LIMIT_EXCEEDED",
    "VC_BUDGET_EXCEEDED": "CONNECTION_LIMIT_EXCEEDED",
    "VC_TIMEOUT": "CONNECTION_TIMEOUT",
    "VC_OPERATION_UNSUPPORTED": "CONNECTION_MODE_UNSUPPORTED",
    "VC_OPERATION_CAPABILITY_UNAVAILABLE": "CONNECTION_MODE_UNSUPPORTED",
    "VC_OPERATION_BINDING_INVALID": "CONNECTION_SCHEMA_INVALID",
    "VC_OPERATION_CREDENTIAL_REQUIRED": "CONNECTION_PERMISSION_DENIED",
    "VC_OPERATION_SCOPE_CHANGED": "CONNECTION_REVISION_CONFLICT",
}


def projection_schemas():
    """Data only; no package/release identity, network policy or registration."""
    empty = {"type": "object", "properties": {}, "required": []}
    properties = {
        "profile": {"type": "string", "enum": sorted(PROFILES), "maxLength": 32},
        "restBase": {"type": "string", "maxLength": 120},
        "soapBase": {"type": "string", "maxLength": 120},
        "soapVersion": {"type": "string", "maxLength": 20},
        "envelope": {"type": "string", "enum": ["raw", "value"], "maxLength": 5},
        "inventory": {"type": "string", "enum": ["soap"], "maxLength": 4},
        "timeoutMs": {"type": "integer", "minimum": 1000, "maximum": 15000},
        "batchLimit": {"type": "integer", "minimum": 1, "maximum": 200},
    }
    return {"schemaId": SCHEMA_ID, "schemaVersion": SCHEMA_VERSION,
            "adaptationSchema": {"type": "object", "properties": properties, "required": list(properties)},
            "filterSchema": copy.deepcopy(empty),
            "visibleScopeSchema": {"type": "object", "properties": {
                "kind": {"type": "string", "enum": ["permission-visible"], "maxLength": 18},
                "inventory": {"type": "string", "enum": ["soap"], "maxLength": 4}, "filter": copy.deepcopy(empty)},
                "required": ["kind", "inventory", "filter"]},
            "resourceTypes": [ROOT_TYPE, "Datacenter"], "rootTypes": [ROOT_TYPE], "capabilities": ["inventory"]}


class ProjectionError(Exception):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


def _fail(code="CONNECTION_RESPONSE_INVALID"):
    raise ProjectionError(code)


def error_code(error):
    """A JS carrier must construct FW ConnectionError from this finite code only."""
    if isinstance(error, ProjectionError):
        allowed = set(ERROR_CODES.values()) | {"CONNECTION_SCHEMA_INVALID", "CONNECTION_INSTANCE_CHANGED"}
        return error.code if error.code in allowed else "CONNECTION_PROVIDER_UNAVAILABLE"
    return ERROR_CODES.get(error.code, "CONNECTION_PROVIDER_UNAVAILABLE") if isinstance(error, AdapterError) else "CONNECTION_PROVIDER_UNAVAILABLE"


def _text(value, limit=128):
    if not isinstance(value, str) or not value or any(ord(c) < 32 or ord(c) == 127 for c in value):
        _fail()
    try:
        units = len(value.encode("utf-16-le")) // 2
    except UnicodeError:
        _fail()
    if units > limit:
        _fail()
    return value


def _key(value, types=KINDS):
    if (not isinstance(value, dict) or set(value) != {"objectType", "objectId"}
            or not isinstance(value.get("objectType"), str) or value["objectType"] not in types):
        _fail()
    element = ET.Element("obj", {"type": value["objectType"]})
    element.text = _text(value["objectId"])
    try:
        return ref(element)
    except AdapterError as error:
        raise ProjectionError(error_code(error)) from None


def _instance(about, expected=None):
    if not isinstance(about, dict):
        _fail()
    for key in ("instanceUuid", "apiType", "version", "build", "apiVersion"):
        _text(about.get(key))
    try:
        choose_profile(about)
    except AdapterError as error:
        raise ProjectionError(error_code(error)) from None
    result = {"instanceId": about.get("instanceUuid"), "product": about.get("apiType"),
              "version": about.get("version"), "build": about.get("build"), "apiVersion": about.get("apiVersion")}
    for value in result.values():
        _text(value)
    if expected is not None and result["instanceId"] != _text(expected):
        _fail("CONNECTION_INSTANCE_CHANGED")
    return result


def _snapshot(snapshot, expected=None):
    if not isinstance(snapshot, dict) or snapshot.get("source") != "vsphere-soap" or snapshot.get("complete") is not True:
        _fail("CONNECTION_DISCOVERY_INCOMPLETE")
    try:
        encoded = json.dumps(snapshot, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, UnicodeError, RecursionError):
        _fail()
    if len(encoded) > 4 * 1024 * 1024:
        _fail("CONNECTION_LIMIT_EXCEEDED")
    instance = _instance(snapshot.get("about"), expected)
    objects = snapshot.get("objects")
    if not isinstance(objects, list) or len(objects) > 2000:
        _fail("CONNECTION_LIMIT_EXCEEDED")
    seen = set()
    for row in objects:
        if not isinstance(row, dict) or set(row) != {"key", "properties"} or not isinstance(row["properties"], dict):
            _fail()
        key = _key(row["key"])
        identity = (key["objectType"], key["objectId"])
        if identity in seen:
            _fail()
        seen.add(identity)
        parent = row["properties"].get("parent")
        if parent is not None:
            _key(parent)
    return instance


def _access(authentication, authorization):
    if authentication != "authenticated":
        _fail("CONNECTION_AUTHENTICATION_FAILED")
    if authorization not in ("readable", "partial"):
        _fail("CONNECTION_PERMISSION_DENIED")


def _scope(value):
    # Business visibility only. Identity/credential/trust binding belongs to FW.
    if not isinstance(value, dict) or value != VISIBLE_SCOPE:
        _fail("CONNECTION_SCHEMA_INVALID")
    return copy.deepcopy(VISIBLE_SCOPE)


def selected_adaptation(values, *, manual=None):
    if (not isinstance(values, dict) or not isinstance(values.get("profile"), str)
            or manual is not None and (not isinstance(manual, dict) or not isinstance(manual.get("profile"), str))):
        _fail("CONNECTION_ADAPTATION_UNSUPPORTED")
    try:
        selected = adaptation(values.get("profile"), values)
        if manual is not None:
            adaptation(manual.get("profile"), manual)
    except AdapterError as error:
        raise ProjectionError(error_code(error)) from None
    if manual is not None and selected != manual:
        _fail("CONNECTION_ADAPTATION_UNSUPPORTED")
    return {"schemaId": SCHEMA_ID, "schemaVersion": SCHEMA_VERSION, "values": copy.deepcopy(selected)}


def _roots(snapshot):
    try:
        roots = ReadOnlyConnector.clusters(snapshot)
    except AdapterError as error:
        raise ProjectionError(error_code(error)) from None
    for root in roots:
        _key(root["key"], {ROOT_TYPE})
        _text(root["name"], 120)
        _key(root["parent"]["key"], {"Datacenter"})
        _text(root["parent"]["name"], 120)
    return sorted(roots, key=lambda row: (row["key"]["objectType"], row["key"]["objectId"]))


def probe_facts(snapshot, values, *, authentication, authorization, visible_scope, observed_apis, manual=None):
    _access(authentication, authorization)
    instance = _snapshot(snapshot)
    _roots(snapshot)
    if not isinstance(observed_apis, list) or not observed_apis or len(observed_apis) > 16:
        _fail()
    for api in observed_apis:
        if api not in ("soap", "rest-legacy", "rest-modern"):
            _fail()
    if "soap" not in observed_apis or len(set(observed_apis)) != len(observed_apis):
        _fail()
    selected = selected_adaptation(values, manual=manual)
    if selected["values"]["profile"] != choose_profile(snapshot["about"]):
        _fail("CONNECTION_ADAPTATION_UNSUPPORTED")
    return {"instance": instance, "observedApis": list(observed_apis),
            "selectedAdaptation": selected, "authentication": authentication,
            "authorization": {"status": authorization, "visibleScope": _scope(visible_scope)},
            "capabilities": [{"id": "inventory", "status": "supported"}]}


def discovery_page(snapshot, instance_id, *, authentication, authorization, visible_scope, filter_value,
                   offset=0, limit=100, next_cursor=None):
    """Slice a carrier-held snapshot; next_cursor is supplied by that carrier.

    offset is internal state, never an authorized browser cursor or native SOAP
    page. The carrier binds the same immutable snapshot to each cursor/actor.
    """
    result = discovery_slice(snapshot, instance_id, authentication=authentication, authorization=authorization,
                             filter_value=filter_value, offset=offset, limit=limit)
    del result["nextOffset"]
    if result["complete"]:
        if next_cursor is not None:
            _fail("CONNECTION_SCHEMA_INVALID")
    else:
        _text(next_cursor, 512)
    return {**result, "visibleScope": _scope(visible_scope), "nextCursor": next_cursor}


def discovery_slice(snapshot, instance_id, *, authentication, authorization, filter_value, offset=0, limit=100):
    """Internal slice metadata for the actual carrier's continuation wrapper.

    No cursor is issued here. Only after the carrier binds/signs continuation is
    this converted to the externally consumable C1 page.
    """
    _access(authentication, authorization)
    instance = _snapshot(snapshot, instance_id)
    if not isinstance(filter_value, dict) or filter_value:
        _fail("CONNECTION_SCHEMA_INVALID")
    roots = _roots(snapshot)
    if type(offset) is not int or not 0 <= offset <= len(roots) or type(limit) is not int or not 1 <= limit <= 200:
        _fail("CONNECTION_SCHEMA_INVALID")
    end = min(offset + limit, len(roots))
    return {"instanceId": instance["instanceId"], "items": copy.deepcopy(roots[offset:end]),
            "visibleScope": copy.deepcopy(VISIBLE_SCOPE), "complete": end == len(roots),
            "nextOffset": None if end == len(roots) else end}


def revalidate_snapshot(snapshot, instance_id, selected, *, authentication, authorization):
    """Caller must reread inventory now; a previous discovery snapshot is no proof."""
    _access(authentication, authorization)
    instance = _snapshot(snapshot, instance_id)
    roots = {(row["key"]["objectType"], row["key"]["objectId"]) for row in _roots(snapshot)}
    if not isinstance(selected, list) or not selected or len(selected) > 2000:
        _fail("CONNECTION_SCHEMA_INVALID")
    result, seen = [], set()
    for value in selected:
        key = _key(value, {ROOT_TYPE})
        identity = (key["objectType"], key["objectId"])
        if identity in seen:
            _fail("CONNECTION_SCHEMA_INVALID")
        if identity not in roots:
            _fail("CONNECTION_DISCOVERY_INCOMPLETE")
        seen.add(identity)
        result.append(key)
    return {"instanceId": instance["instanceId"], "selected": result, "readable": True}
