"""Finite group/rule inventory without SDK paths or arbitrary configuration."""
import re
from .profiles import AdapterError
from .vsphere_readonly import VIM, ref, text


def require(value):
    if not value: raise AdapterError('VC_RESPONSE_INVALID')


def cluster_inventory(value, *, rules=False):
    require(len(value) <= 200)
    rows, seen = [], set()
    for item in value:
        require(item.tag.startswith('{' + VIM + '}'))
        def node(name):
            matches = item.findall('{' + VIM + '}' + name)
            require(len(matches) <= 1)
            return matches[0] if matches else None
        def string(name, optional=False):
            found = node(name)
            if found is None or not found.text:
                if optional: return None
                raise AdapterError('VC_INVENTORY_INCOMPLETE')
            return text(found.text, 80)
        def boolean(name):
            found = node(name)
            if found is None: return None
            require(found.text in ('true','false','1','0'))
            return found.text in ('true','1')
        local = item.tag.split('}', 1)[1]
        family = {'ClusterRuleInfo','ClusterAffinityRuleSpec','ClusterAntiAffinityRuleSpec','ClusterVmHostRuleInfo','ClusterDependencyRuleInfo'} if rules else {'ClusterGroupInfo','ClusterVmGroup','ClusterHostGroup'}
        require(local == ('ClusterRuleInfo' if rules else 'ClusterGroupInfo'))
        type_name = item.get('{http://www.w3.org/2001/XMLSchema-instance}type', local)
        require(bool(re.fullmatch(r'(?:[A-Za-z_][A-Za-z0-9_.-]*:)?[A-Za-z_][A-Za-z0-9_.-]*', type_name)))
        kind = type_name.split(':')[-1]
        require(kind in family and (local in ('ClusterGroupInfo','ClusterRuleInfo') or kind == local))
        kinds = {'ClusterAffinityRuleSpec':'vmAffinity', 'ClusterAntiAffinityRuleSpec':'vmAntiAffinity', 'ClusterVmHostRuleInfo':'vmHost'} if rules else {'ClusterVmGroup':'vm','ClusterHostGroup':'host'}
        row = {'name': string('name'), 'kind': kinds.get(kind, 'unsupported')}
        if rules:
            raw = string('key'); require(bool(re.fullmatch(r'\d{1,10}', raw)) and int(raw) <= 2147483647)
            row['key'] = int(raw)
        for field in ('userCreated','enabled','mandatory') if rules else ('userCreated',):
            result = boolean(field)
            if result is not None: row[field] = result
        if row['kind'] in ('vm','host','vmAffinity','vmAntiAffinity'):
            field, expected = ('host','HostSystem') if row['kind'] == 'host' else ('vm','VirtualMachine')
            members = [ref(found, expected) for found in item.findall('{' + VIM + '}' + field)]
            require(len(members) <= 200 and len({(key['objectType'], key['objectId']) for key in members}) == len(members))
            row['members'] = members
        elif row['kind'] == 'vmHost':
            for field in ('vmGroupName','affineHostGroupName','antiAffineHostGroupName'):
                result = string(field, optional=True)
                if result is not None: row[field] = result
        identifier = row['key'] if rules else row['name']
        require(identifier not in seen); seen.add(identifier); rows.append(row)
    return rows
