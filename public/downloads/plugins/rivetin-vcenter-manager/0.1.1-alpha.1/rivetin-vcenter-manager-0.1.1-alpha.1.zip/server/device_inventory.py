"""Narrow scoped device DTO, with only the settings used by the editor."""
import re
from .profiles import AdapterError
from .vsphere_readonly import VIM, ref, text

# VirtualDevice inheritance closure from the locked pyVmomi 8.0.3.0.1 WSDL types.
# Backing/config/option classes are not inventory devices, even with a Virtual prefix.
DEVICE_TYPES = frozenset('''
ParaVirtualSCSIController VirtualAHCIController VirtualBusLogicController VirtualCdrom
VirtualController VirtualDevice VirtualDisk VirtualE1000 VirtualE1000e VirtualEnsoniq1371
VirtualEthernetCard VirtualFloppy VirtualHdAudioCard VirtualIDEController VirtualKeyboard
VirtualLsiLogicController VirtualLsiLogicSASController VirtualMachineVMCIDevice
VirtualMachineVMIROM VirtualMachineVideoCard VirtualNVDIMM VirtualNVDIMMController
VirtualNVMEController VirtualPCIController VirtualPCIPassthrough VirtualPCNet32
VirtualPS2Controller VirtualParallelPort VirtualPointingDevice VirtualPrecisionClock
VirtualSATAController VirtualSCSIController VirtualSCSIPassthrough VirtualSIOController
VirtualSerialPort VirtualSoundBlaster16 VirtualSoundCard VirtualSriovEthernetCard
VirtualTPM VirtualUSB VirtualUSBController VirtualUSBXHCIController VirtualVmxnet
VirtualVmxnet2 VirtualVmxnet3 VirtualVmxnet3Vrdma VirtualWDT
'''.split())


def require(value, code):
    if not value: raise AdapterError(code)


def device_inventory(value):
    require(value.get('{http://www.w3.org/2001/XMLSchema-instance}nil') not in ('true', '1'), 'VC_INVENTORY_INCOMPLETE')
    array_type = value.get('{http://www.w3.org/2001/XMLSchema-instance}type', '').split(':')[-1]
    require(array_type in ('', 'ArrayOfVirtualDevice') and not (value.text or '').strip(), 'VC_RESPONSE_INVALID')
    require(len(value) <= 200, 'VC_INVENTORY_LIMIT')
    rows, seen = [], set()
    for device in value:
        require(device.tag.startswith('{' + VIM + '}'), 'VC_RESPONSE_INVALID')
        def node(name):
            matches = device.findall('{' + VIM + '}' + name)
            require(len(matches) <= 1, 'VC_RESPONSE_INVALID')
            return matches[0] if matches else None
        def integer(name, optional=False):
            item = node(name)
            if item is None and optional: return None
            raw = item.text if item is not None else ''
            require(isinstance(raw, str) and re.fullmatch(r'\d{1,16}', raw), 'VC_RESPONSE_INVALID')
            result = int(raw)
            require(result <= 9007199254740991, 'VC_RESPONSE_INVALID')
            return result
        type_name = device.get('{http://www.w3.org/2001/XMLSchema-instance}type', '')
        require(bool(re.fullmatch(r'(?:[A-Za-z_][A-Za-z0-9_.-]*:)?[A-Za-z_][A-Za-z0-9_.-]*', type_name)), 'VC_RESPONSE_INVALID')
        kind = type_name.split(':')[-1]
        require(kind in DEVICE_TYPES, 'VC_RESPONSE_INVALID')
        identifier = integer('key')
        require(identifier not in seen, 'VC_RESPONSE_INVALID'); seen.add(identifier)
        info = node('deviceInfo')
        label = info.find('{' + VIM + '}label') if info is not None else None
        row = {'key': identifier, 'type': kind, 'label': text(label.text, 120) if label is not None and label.text else kind + ' #' + str(identifier)}
        for name in ('controllerKey', 'unitNumber', 'busNumber', 'scsiCtlrUnitNumber'):
            number = integer(name, optional=True)
            if number is not None: row[name] = number
        if kind == 'VirtualDisk': row['capacityKB'] = integer('capacityInKB')
        backing, connectable = node('backing'), node('connectable')
        shared = node('sharedBus')
        if shared is not None:
            require(shared.text in ('noSharing', 'virtualSharing', 'physicalSharing'), 'VC_RESPONSE_INVALID')
            row['sharedBus'] = shared.text
        if backing is not None:
            backing_type = backing.get('{http://www.w3.org/2001/XMLSchema-instance}type', '').split(':')[-1]
            if backing_type in ('VirtualDiskFlatVer2BackingInfo', 'VirtualEthernetCardNetworkBackingInfo', 'VirtualEthernetCardDistributedVirtualPortBackingInfo', 'VirtualCdromIsoBackingInfo', 'VirtualCdromRemoteAtapiBackingInfo', 'VirtualCdromRemotePassthroughBackingInfo'):
                row['backingType'] = backing_type
            if backing_type == 'VirtualDiskFlatVer2BackingInfo':
                for field in ('diskMode', 'sharing', 'thinProvisioned', 'eagerlyScrub'):
                    item = backing.find('{' + VIM + '}' + field)
                    if item is not None and item.text:
                        if field in ('thinProvisioned', 'eagerlyScrub'):
                            require(item.text in ('true', 'false', '1', '0'), 'VC_RESPONSE_INVALID')
                            row[field] = item.text in ('true', '1')
                        else:
                            row[field] = text(item.text, 40)
            network = backing.find('{' + VIM + '}network')
            if network is not None: row['network'] = ref(network, 'Network')
            datastore = backing.find('{' + VIM + '}datastore')
            if datastore is not None: row['datastore'] = ref(datastore, 'Datastore')
            if backing_type == 'VirtualEthernetCardDistributedVirtualPortBackingInfo':
                group = backing.find('{' + VIM + '}port/{' + VIM + '}portgroupKey')
                if group is not None and re.fullmatch(r'dvportgroup-[0-9]+', group.text or ''):
                    row['network'] = {'objectType': 'DistributedVirtualPortgroup', 'objectId': group.text}
        if connectable is not None:
            for name in ('startConnected', 'connected'):
                start = connectable.find('{' + VIM + '}' + name)
                if start is not None:
                    require(start.text in ('true', 'false', '1', '0'), 'VC_RESPONSE_INVALID')
                    row[name] = start.text in ('true', '1')
        if kind in ('VirtualVmxnet3', 'VirtualE1000', 'VirtualE1000e'):
            mode = node('addressType')
            if mode is not None and mode.text in ('manual', 'generated', 'assigned'):
                row['addressType'] = mode.text
        rows.append(row)
    return rows
