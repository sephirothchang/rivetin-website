"""Bounded vSphere paths, anchored to the exact VM's configuration directory."""
import hashlib
import re

from .operation_ledger import operation_id, require


def datastore_path(value):
    require(isinstance(value, str) and 0 < len(value) <= 1024 and
            not any(ord(c) < 32 or ord(c) == 127 for c in value), 'VC_OPERATION_DISK_PATH_INVALID')
    match = re.fullmatch(r'\[([^\[\]/\\]{1,80})\] (.+)', value)
    require(match is not None, 'VC_OPERATION_DISK_PATH_INVALID')
    store, relative = match.groups()
    parts = tuple(relative.split('/'))
    require(store == store.strip() and store not in ('.', '..') and not any(c in store for c in ':%') and
            1 <= len(parts) <= 32 and all(0 < len(p) <= 255 and p == p.strip() and p not in ('.', '..') and
            not any(c in p for c in '\\[]:%?*') for p in parts), 'VC_OPERATION_DISK_PATH_INVALID')
    return store, parts


def vm_directory(vmx_path):
    store, parts = datastore_path(vmx_path)
    require(len(parts) >= 2 and parts[-1].endswith('.vmx'), 'VC_OPERATION_VM_DIRECTORY_INVALID')
    return store, parts[:-1]


def vmx_path_hash(vmx_path):
    vm_directory(vmx_path)
    return hashlib.sha256(vmx_path.encode('utf-8')).hexdigest()


def disk_leaf(disk_id):
    return 'rivetin-' + operation_id(disk_id) + '.vmdk'


def new_disk_path(vmx_path, datastore_name, disk_id):
    _, directory = vm_directory(vmx_path)
    value = '[' + datastore_name + '] ' + '/'.join(directory + (disk_leaf(disk_id),))
    datastore_path(value)
    return value


def verify_disk_path(actual, intended, vmx_path, disk_id, *, same_datastore=False, frozen_vmx_hash=None):
    store, intended_parts = datastore_path(intended)
    vm_store, directory = vm_directory(vmx_path)
    leaf = disk_leaf(disk_id)
    # Only the old server-generated leaf intention is VM-home relative. Actual
    # backing paths must include the complete, exact VM directory.
    require(intended_parts in ((leaf,), directory + (leaf,)), 'VC_OPERATION_DISK_INTENT_MISMATCH')
    require(not same_datastore or vm_store == store, 'VC_OPERATION_DISK_PATH_MISMATCH')
    if frozen_vmx_hash is not None:
        require(isinstance(frozen_vmx_hash, str) and re.fullmatch(r'[a-f0-9]{64}', frozen_vmx_hash) and
                vmx_path_hash(vmx_path) == frozen_vmx_hash, 'VC_OPERATION_VM_DIRECTORY_CHANGED')
    actual_store, actual_parts = datastore_path(actual)
    require(actual_store == store and actual_parts == directory + (leaf,), 'VC_OPERATION_DISK_PATH_MISMATCH')
    return True
