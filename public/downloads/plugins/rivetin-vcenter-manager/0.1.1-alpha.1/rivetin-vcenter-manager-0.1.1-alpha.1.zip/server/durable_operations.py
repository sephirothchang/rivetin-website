"""Business operation orchestration, independent of SOAP/REST SDK choice."""
import copy
import re

from .operation_ledger import TERMINAL, canonical, operation_id, require
from .profiles import AdapterError
from .resource_scope import identity


class NativeRejected(AdapterError):
    """Only an authoritative native pre-execution refusal may use this type."""


class DurableOperations:
    def __init__(self, ledger, executor):
        # executor owns actual live reads, per-operation schemas, native privileges,
        # enrolled scope and SDK calls. No user-supplied callback is accepted.
        self.ledger, self.executor = ledger, executor

    @staticmethod
    def response(record):
        return {'data': record, 'credentialLease': 'release' if record['state'] in TERMINAL else 'retain'}

    def prepare(self, binding, request):
        intent, observation = self.executor.prepare(binding, copy.deepcopy(request))
        require(intent['scopeRevision'] == request['scopeRevision'], 'VC_OPERATION_SCOPE_CHANGED')
        return {'data': self.ledger.create_plan(binding, intent, observation)}

    def submit(self, binding, identifier, proof):
        operation_id(identifier)
        plan = self.ledger.plan(binding, proof, for_operation_id=identifier)
        existing = self.ledger.read(binding, identifier)
        if existing:
            require(canonical({key: existing[key] for key in plan['intent']}) == canonical(plan['intent']), 'VC_OPERATION_INTENT_MISMATCH')
            return self.response(existing)
        # Recheck the current server-owned scope/revision, instance, ownership,
        # precise target state and all required native privileges before acceptance.
        self.executor.revalidate(binding, copy.deepcopy(plan['intent']), copy.deepcopy(plan['observation']))
        accepted = self.ledger.accept(binding, identifier, proof, expected_intent=plan['intent'])
        if not accepted['claimed']:
            return self.response(accepted['operation'])
        try:
            result = self.executor.invoke(binding, copy.deepcopy(plan['intent']))
            require(isinstance(result, dict) and set(result) <= {'task', 'result'} and bool(result), 'VC_OPERATION_RESPONSE_INVALID')
            if result.get('task') is not None:
                identity(result['task'], 'Task')
                # A Task ref is evidence of native acceptance, not a queued state.
                record = self.ledger.update(binding, identifier, 'accepted', task=result['task'])
            else:
                canonical(result.get('result'))
                record = self.ledger.update(binding, identifier, 'verifying', result={'nativeReturned': True, 'value': result.get('result')})
                record = self._verify(binding, record)
            return self.response(record)
        except NativeRejected as error:
            return self.response(self.ledger.update(binding, identifier, 'rejected', error_code=error.code))
        except Exception:
            # Even XML/type/response errors may occur after the remote mutation.
            # The accepted row is never removed or made executable again.
            current = self.ledger.read(binding, identifier)
            if current['state'] in TERMINAL or current['state'] == 'verifying':
                return self.response(current)
            return self.response(self.ledger.update(binding, identifier, 'unknown', error_code='VC_OPERATION_OUTCOME_UNKNOWN'))

    def _verify(self, binding, record):
        try:
            verified = self.executor.verify(binding, copy.deepcopy(record))
            require(isinstance(verified, dict) and verified.get('verified') is True, 'VC_OPERATION_POSTCHECK_PENDING')
            canonical(verified)
        except Exception as error:
            code = error.code if isinstance(error, AdapterError) else 'VC_OPERATION_POSTCHECK_UNAVAILABLE'
            if not isinstance(code, str) or not re.fullmatch(r'VC_[A-Z0-9_]{1,96}', code):
                code = 'VC_OPERATION_POSTCHECK_UNAVAILABLE'
            if record.get('errorCode') == code:
                return record
            return self.ledger.update(binding, record['operationId'], 'verifying', error_code=code)
        return self.ledger.update(binding, record['operationId'], 'success', result=verified)

    def refresh(self, binding, identifier):
        record = self.ledger.read(binding, identifier)
        require(record is not None, 'VC_OPERATION_NOT_FOUND')
        if record['state'] in TERMINAL:
            return self.response(record)
        self.ledger.credential_binding(binding, identifier)
        if record['state'] == 'verifying':
            return self.response(self._verify(binding, record))
        if record['task'] is None:
            # No native Task ref survived: never guess from an object state or resubmit.
            return self.response(record)
        task = self.executor.read_task(binding, copy.deepcopy(record))
        require(isinstance(task, dict) and set(task) <= {'key', 'entity', 'state', 'progress', 'errorCode', 'result'}, 'VC_OPERATION_RESPONSE_INVALID')
        identity(task.get('key'), 'Task')
        require(task['key'] == record['task'] and task.get('state') in {'queued', 'running', 'success', 'error'}, 'VC_OPERATION_TASK_MISMATCH')
        if task.get('entity') is not None:
            entities = [record['key']]
            if record['operation'] in {'vm.create', 'vm.provision'}:
                folder = record['expected']['placement']['folder']
                identity(folder, 'Folder')
                entities = [folder]
                # The native Task can identify its created VM. Accept that identity
                # only when the same stored Task reports it as its successful result.
                if task['state'] == 'success' and task.get('result') is not None:
                    identity(task['result'], 'VirtualMachine')
                    entities.append(task['result'])
            elif record['operation'] == 'host.add' and task['state'] == 'success' and task.get('result') is not None:
                identity(task['result'], 'HostSystem')
                entities.append(task['result'])
            require(any(identity(task['entity']) == identity(entity) for entity in entities), 'VC_OPERATION_TASK_MISMATCH')
        if 'progress' in task:
            require(type(task['progress']) is int and 0 <= task['progress'] <= 100, 'VC_OPERATION_RESPONSE_INVALID')
        state = task['state']
        observed = {'nativeState': state, **{key: task[key] for key in ('progress', 'result') if key in task}}
        canonical(observed)
        if state == 'error':
            code = task.get('errorCode') or 'VC_NATIVE_TASK_FAILED'
            record = self.ledger.update(binding, identifier, 'error', task=task['key'], result=observed, error_code=code)
        elif state == 'success':
            record = self.ledger.update(binding, identifier, 'verifying', task=task['key'], result=observed)
            record = self._verify(binding, record)
        else:
            record = self.ledger.update(binding, identifier, state, task=task['key'], result=observed)
        return self.response(record)

    def read(self, binding, identifier):
        record = self.ledger.read(binding, identifier)
        response = {'data': {'kind': 'found', 'operation': record} if record else {'kind': 'not-found', 'operationId': operation_id(identifier), 'knownAccepted': 'undetermined'}}
        if record and record['state'] in TERMINAL:
            response['credentialLease'] = 'release'
        return response

    def recover(self, binding):
        return {'data': {'items': self.ledger.recover(binding)}}
