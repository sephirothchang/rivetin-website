"""Guest reboot evidence: OS uptime reset with an independent VMX continuity check."""
import time
from .operation_ledger import require

SAMPLE_AGE_MS = 90000
UNCERTAINTY_MS = 60000


def continuous(before, after, field, timestamp):
    elapsed = after[timestamp] - before[timestamp]
    return elapsed >= 0 and abs((after[field] - before[field]) * 1000 - elapsed) <= UNCERTAINTY_MS


def same_boot(before, after):
    return (before['instanceUuid'] == after['instanceUuid']
            and continuous(before, after, 'vmUptimeSeconds', 'observedAtMs')
            and continuous(before, after, 'osUptimeSeconds', 'sampleAtMs'))


def reboot_verified(before, after, accepted_ms):
    old_boot = before['sampleAtMs'] - before['osUptimeSeconds'] * 1000
    new_boot = after['sampleAtMs'] - after['osUptimeSeconds'] * 1000
    return (before['instanceUuid'] == after['instanceUuid']
            and continuous(before, after, 'vmUptimeSeconds', 'observedAtMs')
            and after['sampleAtMs'] > before['sampleAtMs'] and after['sampleAtMs'] >= accepted_ms
            and new_boot - UNCERTAINTY_MS > old_boot
            and new_boot >= accepted_ms - UNCERTAINTY_MS)


class GuestReboot:
    def guest_reboot_sample(self, key, *, baseline=False):
        values = self.read(key, ['config.instanceUuid', 'runtime.powerState', 'guest.toolsRunningStatus', 'summary.quickStats.uptimeSeconds'])
        require(str(values['runtime.powerState']) == 'poweredOn' and values['guest.toolsRunningStatus'] == 'guestToolsRunning', 'VC_OPERATION_POSTCHECK_PENDING')
        vm_uptime, identifier = values['summary.quickStats.uptimeSeconds'], values['config.instanceUuid']
        require(type(vm_uptime) is int and vm_uptime >= 0 and isinstance(identifier, str) and 0 < len(identifier) <= 128, 'VC_INVENTORY_INCOMPLETE')
        perf, pc = self.service.perfManager, self.vmodl.query.PropertyCollector
        require(perf is not None, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        spec = pc.FilterSpec(propSet=[pc.PropertySpec(type=self.vim.PerformanceManager, pathSet=['perfCounter'], all=False)], objectSet=[pc.ObjectSpec(obj=perf, skip=False)])
        metadata = self.service.propertyCollector.RetrievePropertiesEx(specSet=[spec], options=pc.RetrieveOptions(maxObjects=1))
        require(not metadata.token and len(metadata.objects) == 1, 'VC_INVENTORY_INCOMPLETE')
        row = metadata.objects[0]
        require(type(row.obj) is self.vim.PerformanceManager and row.obj._moId == perf._moId and not row.missingSet
                and len(row.propSet) == 1 and row.propSet[0].name == 'perfCounter', 'VC_RESPONSE_INVALID')
        counters = row.propSet[0].val
        require(isinstance(counters, (list, tuple)) and len(counters) <= 2000, 'VC_RESPONSE_INVALID')
        matches = [c for c in counters if c.groupInfo.key == 'sys' and c.nameInfo.key == 'osUptime'
                   and str(c.rollupType) == 'latest' and c.unitInfo.key == 'second' and str(c.statsType) == 'absolute']
        require(len(matches) == 1 and type(matches[0].key) is int, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        counter = matches[0].key
        metrics = perf.QueryStats(querySpec=[self.vim.PerformanceManager.QuerySpec(entity=self.obj(key),
            metricId=[self.vim.PerformanceManager.MetricId(counterId=counter, instance='')], intervalId=20, maxSample=3, format='normal')])
        require(len(metrics) == 1, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        metric = metrics[0]
        require(type(metric.entity) is self.vim.VirtualMachine and metric.entity._moId == key['objectId']
                and 1 <= len(metric.sampleInfo) <= 3 and len(metric.value) == 1, 'VC_RESPONSE_INVALID')
        series = metric.value[0]
        require(series.id.counterId == counter and series.id.instance == '' and len(series.value) == len(metric.sampleInfo), 'VC_RESPONSE_INVALID')
        samples = []
        now = int(time.time() * 1000)
        for sample, value in zip(metric.sampleInfo, series.value):
            require(hasattr(sample.timestamp, 'timestamp') and sample.timestamp.tzinfo is not None
                    and type(sample.interval) is int and sample.interval == 20
                    and isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 9007199254740991, 'VC_RESPONSE_INVALID')
            timestamp = int(sample.timestamp.timestamp() * 1000)
            require(timestamp not in [t for t, _ in samples], 'VC_RESPONSE_INVALID')
            samples.append((timestamp, int(value)))
        timestamp, uptime = max(samples)
        require(-5000 <= now - timestamp <= SAMPLE_AGE_MS, 'VC_OPERATION_POSTCHECK_PENDING')
        # Coarse VMware Tools/QuickStats refreshes cannot distinguish resets in
        # a very young guest. Wait for a usable baseline instead of inventing it.
        if baseline:
            require(uptime > 120 and vm_uptime > 120, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        return {'version': 1, 'instanceUuid': identifier, 'counterId': counter, 'sampleAtMs': timestamp,
                'osUptimeSeconds': uptime, 'vmUptimeSeconds': vm_uptime, 'observedAtMs': now}
