"""Read-only finite standard-network/VMK DTOs; exclude MACs and opaque backing."""
import re
from .profiles import AdapterError
from .vsphere_readonly import VIM, text

NETWORK_PATHS=('config.network.vswitch','config.network.portgroup','config.network.pnic','config.network.vnic','config.virtualNicManagerInfo.netConfig')


def require(value):
    if not value: raise AdapterError('VC_RESPONSE_INVALID')


def child(node,name):
    matches=node.findall('{' + VIM + '}' + name);require(len(matches)<=1)
    result=matches[0] if matches else None
    return None if result is not None and result.get('{http://www.w3.org/2001/XMLSchema-instance}nil') in ('true','1') else result


def string(node,name,required=False,limit=128):
    value=child(node,name)
    if value is None or not value.text:
        require(not required);return None
    return text(value.text,limit)


def integer(node,name):
    value=child(node,name)
    if value is None:return None
    require(isinstance(value.text,str) and bool(re.fullmatch(r'\d{1,16}',value.text)) and int(value.text)<=9007199254740991)
    return int(value.text)


def boolean(node,name):
    value=child(node,name)
    if value is None:return None
    require(value.text in ('true','false','1','0'));return value.text in ('true','1')


def host_network_inventory(path,value):
    require(path in NETWORK_PATHS and len(value)<=200)
    kinds={'config.network.vswitch':'HostVirtualSwitch','config.network.portgroup':'HostPortGroup','config.network.pnic':'PhysicalNic','config.network.vnic':'HostVirtualNic','config.virtualNicManagerInfo.netConfig':'VirtualNicManagerNetConfig'}
    rows,seen=[],set()
    for item in value:
        require(item.tag=='{' + VIM + '}' + kinds[path])
        if path.endswith('.vswitch'):
            row={'name':string(item,'name',True,80),'mtu':integer(item,'mtu')};spec=child(item,'spec')
            if spec is not None:
                if row['mtu'] is None:row['mtu']=integer(spec,'mtu')
                row.update(numPorts=integer(spec,'numPorts'))
                bridge=child(spec,'bridge')
                if bridge is None:row['uplinks']=[]
                else:
                    kind=bridge.get('{http://www.w3.org/2001/XMLSchema-instance}type','').split(':')[-1]
                    if kind=='HostVirtualSwitchBondBridge':
                        row['uplinks']=[text(node.text,16) for node in bridge.findall('{' + VIM + '}nicDevice')]
                        require(len(row['uplinks'])<=32 and len(set(row['uplinks']))==len(row['uplinks']))
            identifier=row['name']
        elif path.endswith('.portgroup'):
            spec=child(item,'spec');require(spec is not None)
            row={'name':string(spec,'name',True,80),'vswitchName':string(spec,'vswitchName',True,80),'vlanId':integer(spec,'vlanId')}
            require(row['vlanId'] is not None and 0<=row['vlanId']<=4095);identifier=row['name']
        elif path.endswith('.pnic'):
            row={'device':string(item,'device',True,16),'key':string(item,'key',True),'driver':string(item,'driver')}
            require(bool(re.fullmatch(r'vmnic\d{1,4}',row['device'])))
            link=child(item,'linkSpeed')
            if link is not None:row.update(linkSpeedMbps=integer(link,'speedMb'),fullDuplex=boolean(link,'duplex'))
            identifier=row['device']
        elif path.endswith('.vnic'):
            row={'device':string(item,'device',True,16),'key':string(item,'key',True),'pgName':string(item,'portgroup',False,80)}
            require(bool(re.fullmatch(r'vmk\d{1,4}',row['device'])))
            spec=child(item,'spec');require(spec is not None)
            row.update(mtu=integer(spec,'mtu'),stack=string(spec,'netStackInstanceKey'),systemOwned=boolean(spec,'systemOwned'))
            row['backing']='distributed' if child(spec,'distributedVirtualPort') is not None else 'opaque' if child(spec,'opaqueNetwork') is not None else 'standard'
            ip=child(spec,'ip')
            if ip is not None:row.update(dhcp=boolean(ip,'dhcp'),ipv4Address=string(ip,'ipAddress',False,15),ipv4SubnetMask=string(ip,'subnetMask',False,15))
            identifier=row['device']
        else:
            row={'service':string(item,'nicType',True,80),'nicKeys':[text(node.text,128) for node in item.findall('{' + VIM + '}selectedVnic')]}
            candidates = {}
            for candidate in item.findall('{' + VIM + '}candidateVnic'):
                key, device = string(candidate, 'key', True), string(candidate, 'device', True, 16)
                require(key not in candidates and bool(re.fullmatch(r'vmk\d{1,4}', device)))
                candidates[key] = device
            if all(key in candidates for key in row['nicKeys']):
                row['nicDevices'] = sorted({candidates[key] for key in row['nicKeys']})
            require(len(row['nicKeys'])<=200 and len(set(row['nicKeys']))==len(row['nicKeys']));identifier=row['service']
        require(identifier not in seen);seen.add(identifier)
        rows.append({name:value for name,value in row.items() if value is not None})
    return rows
