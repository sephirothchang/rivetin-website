"""One scoped HostSystem real-time performance query; no interval or counter changes."""
from datetime import datetime, timezone
import re

from .operation_ledger import require
from .profiles import AdapterError

RATES = {
    ('disk', 'read'): 'diskRead',
    ('disk', 'write'): 'diskWrite',
    ('net', 'received'): 'networkReceived',
    ('net', 'transmitted'): 'networkTransmitted',
}
SAFE_INTEGER = 9007199254740991
MAX_SERIES = 256


class HostPerformance:
    def _host_counter_ids(self, perf):
        pc = self.vmodl.query.PropertyCollector
        spec = pc.FilterSpec(propSet=[pc.PropertySpec(type=self.vim.PerformanceManager, pathSet=['perfCounter'], all=False)],
                             objectSet=[pc.ObjectSpec(obj=perf, skip=False)])
        result = self.service.propertyCollector.RetrievePropertiesEx(specSet=[spec], options=pc.RetrieveOptions(maxObjects=1))
        if result.token:
            self.service.propertyCollector.CancelRetrievePropertiesEx(token=result.token)
            raise AdapterError('VC_RESPONSE_INVALID')
        require(len(result.objects) == 1, 'VC_RESPONSE_INVALID')
        row = result.objects[0]
        require(type(row.obj) is self.vim.PerformanceManager and row.obj._moId == perf._moId and not row.missingSet
                and len(row.propSet) == 1 and row.propSet[0].name == 'perfCounter', 'VC_RESPONSE_INVALID')
        counters = row.propSet[0].val
        require(isinstance(counters, (list, tuple)) and len(counters) <= 2000, 'VC_RESPONSE_INVALID')
        matches = {rate: [] for rate in RATES.values()}
        for counter in counters:
            rate = RATES.get((counter.groupInfo.key, counter.nameInfo.key))
            if rate and str(counter.rollupType) == 'average' and str(counter.statsType) == 'rate' and counter.unitInfo.key == 'kiloBytesPerSecond':
                if type(counter.key) is int and counter.key > 0:
                    matches[rate].append(counter.key)
        unique = {rate: ids[0] for rate, ids in matches.items() if len(ids) == 1}
        return {rate: counter for rate, counter in unique.items() if list(unique.values()).count(counter) == 1}

    def _host_perf_devices(self, key, disk):
        field = 'config.storageDevice.scsiLun' if disk else 'config.network.pnic'
        try:
            devices = self.read(key, [field], optional=(field,))[field]
        except AdapterError as error:
            if error.code != 'VC_INVENTORY_INCOMPLETE':
                raise
            return set()
        if not isinstance(devices, (list, tuple)) or len(devices) > MAX_SERIES:
            return set()
        if disk:
            devices = [row for row in devices if isinstance(row, self.vim.host.ScsiDisk)]
            names = [row.canonicalName for row in devices]
            uuids = [row.uuid for row in devices]
            if any(not value for value in uuids) or len(set(uuids)) != len(uuids):
                return set()
        else:
            names = [row.device for row in devices]
            if any(not isinstance(name, str) or not re.fullmatch(r'vmnic\d{1,4}', name) for name in names):
                return set()
        if any(not isinstance(name, str) or not name or len(name) > 256 for name in names) or len(set(names)) != len(names):
            return set()
        return set(names)

    def read_host_performance(self, key):
        from .managed_executor import native_key
        self.cluster(key)
        self.privilege(key, ['System.View'])
        report = {'sampleAt': None, 'intervalSeconds': None, 'rates': dict.fromkeys(RATES.values())}
        perf, host = self.service.perfManager, self.obj(key)
        if perf is None:
            return report
        summary = perf.QueryProviderSummary(entity=host)
        require(native_key(summary.entity) == key, 'VC_RESPONSE_INVALID')
        interval = summary.refreshRate
        if summary.currentSupported is not True or type(interval) is not int or not 1 <= interval <= 300:
            return report
        report['intervalSeconds'] = interval
        counters = self._host_counter_ids(perf)
        if not counters:
            return report
        available = perf.QueryAvailableMetric(entity=host, intervalId=interval)
        require(len(available) <= 4096, 'VC_RESPONSE_INVALID')
        instances = {counter: set() for counter in counters.values()}
        duplicates = set()
        for metric in available:
            if metric.counterId not in instances:
                continue
            require(isinstance(metric.instance, str) and len(metric.instance) <= 256, 'VC_RESPONSE_INVALID')
            if metric.instance in instances[metric.counterId]:
                duplicates.add(metric.counterId)
            instances[metric.counterId].add(metric.instance)

        by_rate = {}
        devices = {}
        for rate, counter in counters.items():
            found = instances[counter]
            # Empty instance is the native aggregate. Other layers are never
            # combined: disk uses canonical LUNs and network uses physical NICs.
            aggregate = '' in found and counter not in duplicates
            comparable = set()
            if found - {''} and counter not in duplicates:
                family = rate.startswith('disk')
                if family not in devices:
                    devices[family] = self._host_perf_devices(key, family)
                expected = devices[family]
                if expected and expected <= found and (not family or found - {''} == expected):
                    comparable = expected
            by_rate[rate] = (counter, aggregate, comparable)
        requested = {(counter, instance) for counter, aggregate, comparable in by_rate.values()
                     for instance in comparable | ({''} if aggregate else set())}
        if not requested or len(requested) > MAX_SERIES:
            return report

        data = perf.QueryStats(querySpec=[self.vim.PerformanceManager.QuerySpec(
            entity=host, intervalId=interval, maxSample=1, format='normal',
            metricId=[self.vim.PerformanceManager.MetricId(counterId=counter, instance=instance)
                      for counter, instance in sorted(requested)])])
        if not data:
            return report
        require(len(data) == 1 and isinstance(data[0], self.vim.PerformanceManager.EntityMetric)
                and native_key(data[0].entity) == key and len(data[0].sampleInfo) <= 1
                and len(data[0].value) <= len(requested), 'VC_RESPONSE_INVALID')
        metric = data[0]
        if not metric.sampleInfo:
            return report
        sample = metric.sampleInfo[0]
        if sample.interval != interval or not isinstance(sample.timestamp, datetime) or sample.timestamp.utcoffset() is None:
            return report
        age = (datetime.now(timezone.utc) - sample.timestamp).total_seconds()
        if not -5 <= age <= min(180, max(30, interval * 3)):
            return report

        values, seen = {}, set()
        for series in metric.value:
            pair = (series.id.counterId, series.id.instance)
            require(pair in requested and pair not in seen, 'VC_RESPONSE_INVALID')
            seen.add(pair)
            if isinstance(series, self.vim.PerformanceManager.IntSeries) and len(series.value) == 1:
                value = series.value[0]
                if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= SAFE_INTEGER:
                    values[pair] = int(value)
        for rate, (counter, aggregate, comparable) in by_rate.items():
            value, source = values.get((counter, '')) if aggregate else None, 'aggregate'
            if value is None and comparable and all((counter, name) in values for name in comparable):
                value, source = sum(values[counter, name] for name in comparable), 'devices'
            if value is not None and value <= SAFE_INTEGER:
                report['rates'][rate] = {'value': value, 'source': source}
        if any(value is not None for value in report['rates'].values()):
            report['sampleAt'] = sample.timestamp.isoformat()
        return report
