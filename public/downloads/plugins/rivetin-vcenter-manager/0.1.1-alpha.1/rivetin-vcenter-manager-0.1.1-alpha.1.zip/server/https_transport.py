"""SOAP transport to the selected target, with observational TLS identity.

No browser or arbitrary URL entry, proxy, redirects, secret persistence,
logging or RPC listener. Reads and finite typed management methods have separate
entry points. TLS protects transport; vCenter credentials authenticate the session.
"""
import hashlib
import http.client
import ipaddress
import re
import socket
import ssl
import threading
import time
from http.cookies import SimpleCookie, CookieError
from xml.etree import ElementTree as ET

from .profiles import AdapterError
from .vsphere_readonly import METHODS, NS, SOAP, VIM, _SoapTreeBuilder, parse_response, ref, sub


class PinnedSoapTransport:
    def __init__(self, host, leaf_sha256=None, leaf_der=None, *, port=443, seconds=15, max_calls=40, soap_path="/sdk"):
        try:
            self.host = str(ipaddress.ip_address(host))
        except ValueError:
            raise AdapterError("VC_TARGET_INVALID") from None
        if (self.host != host or port != 443
                or type(seconds) not in (int, float) or not 0 < seconds <= 60
                or type(max_calls) is not int or not 1 <= max_calls <= 100
                or not isinstance(soap_path, str) or not re.fullmatch(r"/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*", soap_path) or len(soap_path) > 120):
            raise AdapterError("VC_TARGET_INVALID")
        self.port, self.path = port, soap_path
        self._previous_leaf = leaf_sha256
        self.deadline, self.max_calls, self.calls, self.cleanup_calls = time.monotonic() + seconds, max_calls, 0, 0
        self._call_start = 0
        self._cookie, self.authenticated, self._manager, self._version = None, False, None, "2.0"
        self.cleanup_failed = False
        self.observed_leaf_sha256 = None
        self.tls_observation = "unavailable"
        # Construct directly: do not consume SSLKEYLOGFILE or system/proxy env.
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        self._context = context

    def begin_call(self, seconds):
        if type(seconds) not in (int, float) or not 0 < seconds <= 15:
            raise AdapterError("VC_BUDGET_EXCEEDED")
        self.deadline, self._call_start, self.cleanup_calls = time.monotonic() + seconds, self.calls, 0

    def observe_peer(self, timeout=15):
        connection = self._connect(self._timeout(timeout))
        connection.close()
        return self.observed_leaf_sha256

    def _timeout(self, maximum, cleanup=False):
        if type(maximum) not in (int, float) or not 0 < maximum <= 15:
            raise AdapterError("VC_BUDGET_EXCEEDED")
        remaining = self.deadline - time.monotonic()
        if not cleanup and (remaining <= 0 or self.calls - self._call_start >= self.max_calls - 3):
            raise AdapterError("VC_BUDGET_EXCEEDED")
        if cleanup and (self.cleanup_calls >= 3 or self.calls - self._call_start >= self.max_calls):
            raise AdapterError("VC_BUDGET_EXCEEDED")
        return min(maximum, 3 if cleanup else remaining)

    def _connect(self, timeout):
        connection = http.client.HTTPSConnection(self.host, self.port, timeout=timeout, context=self._context)
        deadline = time.monotonic() + timeout
        raw = None
        try:
            raw = socket.create_connection((self.host, self.port), timeout=timeout)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise AdapterError("VC_TIMEOUT")
            raw.settimeout(remaining)
            connection.sock = self._context.wrap_socket(raw, server_hostname=self.host)
            try:
                der = connection.sock.getpeercert(binary_form=True)
            except (OSError, ValueError, NotImplementedError):
                der = None
            observed = hashlib.sha256(der).hexdigest() if der else None
            if observed is None:
                self.tls_observation = "unavailable"
            else:
                if observed != self.observed_leaf_sha256:
                    self.tls_observation = "changed" if self._previous_leaf and observed != self._previous_leaf else "observed"
                self._previous_leaf = observed
            self.observed_leaf_sha256 = observed
            return connection
        except AdapterError:
            connection.close()
            if raw is not None:
                raw.close()
            raise
        except TimeoutError:
            connection.close()
            if raw is not None:
                raw.close()
            raise AdapterError("VC_TIMEOUT") from None
        except (ssl.SSLError, ValueError, KeyError):
            connection.close()
            if raw is not None:
                raw.close()
            raise AdapterError("VC_TRANSPORT_UNAVAILABLE") from None
        except (OSError, http.client.HTTPException):
            connection.close()
            if raw is not None:
                raw.close()
            raise AdapterError("VC_TRANSPORT_UNAVAILABLE") from None

    def _request(self, method, version, body, timeout, *, connection=None, cleanup=False):
        timeout = self._timeout(timeout, cleanup)
        if not isinstance(version, str) or not re.fullmatch(r"(?:2\.0|[78]\.\d+(?:\.\d+){0,2})", version):
            raise AdapterError("VC_ADAPTATION_INVALID")
        self.calls += 1
        if cleanup:
            self.cleanup_calls += 1
        deadline = time.monotonic() + timeout
        connection = connection or self._connect(timeout)
        request_socket = connection.sock
        def expire():
            try:
                request_socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            connection.close()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            connection.close()
            raise AdapterError("VC_TIMEOUT")
        timer = threading.Timer(remaining, expire)
        timer.daemon = True
        timer.start()
        response = None
        try:
            headers = {"Content-Type": "text/xml; charset=utf-8", "SOAPAction": '"urn:vim25/' + version + '"', "Connection": "close"}
            if self._cookie:
                headers["Cookie"] = self._cookie
            connection.request("POST", self.path, body=body, headers=headers)
            if time.monotonic() >= deadline:
                raise AdapterError("VC_TIMEOUT")
            request_socket.settimeout(max(0.001, deadline - time.monotonic()))
            response = connection.getresponse()
            if response.status in (401, 403):
                raise AdapterError("VC_AUTHENTICATION_FAILED" if response.status == 401 else "VC_PERMISSION_DENIED")
            if response.status not in (200, 500) or response.getheader("Location") is not None:
                raise AdapterError("VC_RESPONSE_INVALID")
            if response.getheader("Content-Encoding", "identity") != "identity":
                raise AdapterError("VC_RESPONSE_INVALID")
            length = response.getheader("Content-Length")
            if length is not None and (not re.fullmatch(r"\d{1,10}", length) or int(length) > 4 * 1024 * 1024):
                raise AdapterError("VC_XML_REFUSED")
            if method == "Login":
                cookie_headers = response.getheaders()
                for key, value in cookie_headers:
                    if key.lower() != "set-cookie":
                        continue
                    if len(value) > 8192:
                        raise AdapterError("VC_RESPONSE_INVALID")
                    cookies = SimpleCookie()
                    try:
                        cookies.load(value)
                    except CookieError:
                        raise AdapterError("VC_RESPONSE_INVALID") from None
                    if "vmware_soap_session" in cookies:
                        if not cookies["vmware_soap_session"].value:
                            raise AdapterError("VC_RESPONSE_INVALID")
                        cookie = cookies["vmware_soap_session"].OutputString(attrs=[])
                        if len(cookie) > 4096 or any(ord(char) < 32 or ord(char) == 127 for char in cookie):
                            raise AdapterError("VC_RESPONSE_INVALID")
                        self._cookie = cookie
            result = bytearray()
            while True:
                # HTTPResponse may release its detached socket on the last byte.
                if length is not None and len(result) == int(length):
                    break
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise AdapterError("VC_TIMEOUT")
                request_socket.settimeout(remaining)
                # read1 bounds one underlying read so slow chunks cannot reset deadline.
                chunk = response.read1(min(65536, 4 * 1024 * 1024 + 1 - len(result)))
                if not chunk:
                    break
                result.extend(chunk)
                if len(result) > 4 * 1024 * 1024:
                    raise AdapterError("VC_XML_REFUSED")
            if length is not None and len(result) != int(length):
                raise AdapterError("VC_RESPONSE_INVALID")
            if time.monotonic() >= deadline:
                raise AdapterError("VC_TIMEOUT")
            return bytes(result)
        except TimeoutError:
            raise AdapterError("VC_TIMEOUT") from None
        except (OSError, http.client.HTTPException):
            if time.monotonic() >= deadline:
                raise AdapterError("VC_TIMEOUT") from None
            raise AdapterError("VC_TRANSPORT_UNAVAILABLE") from None
        except (ValueError, AttributeError):
            raise AdapterError("VC_TIMEOUT" if time.monotonic() >= deadline else "VC_RESPONSE_INVALID") from None
        finally:
            timer.cancel()
            if response is not None:
                response.close()
            connection.close()

    def soap(self, method, path, version, body, timeout):
        if method not in METHODS:
            raise AdapterError("VC_OPERATION_UNSUPPORTED")
        return self._soap(method, path, version, body, timeout)

    def sdk_soap(self, method, path, version, body, timeout):
        from .vmomi_bridge import SDK_READ, SDK_WRITE
        if method not in SDK_READ | SDK_WRITE:
            raise AdapterError("VC_OPERATION_UNSUPPORTED")
        return self._soap(method, path, version, body, timeout)

    def _soap(self, method, path, version, body, timeout):
        if path != self.path:
            raise AdapterError("VC_OPERATION_UNSUPPORTED")
        if method != "RetrieveServiceContent" and not self.authenticated:
            raise AdapterError("VC_AUTHENTICATION_FAILED")
        if not isinstance(body, bytes) or len(body) > 4 * 1024 * 1024:
            raise AdapterError("VC_RESPONSE_INVALID")
        try:
            root = ET.fromstring(body, parser=ET.XMLParser(target=_SoapTreeBuilder()))
            actions = list(root.find("s:Body", NS))
        except (ET.ParseError, TypeError, ValueError, LookupError):
            raise AdapterError("VC_RESPONSE_INVALID") from None
        if root.tag != "{%s}Envelope" % SOAP or len(actions) != 1 or actions[0].tag != "{%s}%s" % (VIM, method):
            raise AdapterError("VC_OPERATION_UNSUPPORTED")
        cleanup = method in ("CancelRetrievePropertiesEx", "DestroyView", "DestroyCollector")
        return self._request(method, version, body, timeout, cleanup=cleanup)

    def login(self, manager, credential_supplier, version):
        if self.authenticated or self._cookie or not callable(credential_supplier):
            raise AdapterError("VC_AUTHENTICATION_FAILED")
        manager_node = ET.Element("obj", {"type": manager.get("objectType", "")})
        manager_node.text = manager.get("objectId")
        self._manager = ref(manager_node, "SessionManager")
        timeout = self._timeout(15)
        deadline = time.monotonic() + timeout
        connection = self._connect(timeout)
        self._version = version
        try:
            credentials = credential_supplier(self.observed_leaf_sha256)
            if not isinstance(credentials, tuple) or len(credentials) != 2 or any(not isinstance(value, str) or not value or len(value) > 4096 for value in credentials):
                raise AdapterError("VC_AUTHENTICATION_FAILED")
            root = ET.Element("{%s}Envelope" % SOAP)
            action = ET.SubElement(ET.SubElement(root, "{%s}Body" % SOAP), "Login", {"xmlns": VIM})
            sub(action, "_this", self._manager["objectId"], type="SessionManager")
            sub(action, "userName", credentials[0]); sub(action, "password", credentials[1])
            body = ET.tostring(root, encoding="utf-8", xml_declaration=True)
            credentials = None
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise AdapterError("VC_TIMEOUT")
            parse_response(self._request("Login", version, body, min(remaining, 15), connection=connection), "Login")
            if not self._cookie:
                raise AdapterError("VC_AUTHENTICATION_FAILED")
            self.authenticated = True
        except Exception:
            connection.close()
            if self._cookie:
                try:
                    self.logout()
                except AdapterError:
                    self.cleanup_failed = True
            raise

    def logout(self):
        if not self._cookie:
            self.authenticated = False
            return
        try:
            root = ET.Element("{%s}Envelope" % SOAP)
            action = ET.SubElement(ET.SubElement(root, "{%s}Body" % SOAP), "Logout", {"xmlns": VIM})
            sub(action, "_this", self._manager["objectId"], type="SessionManager")
            parse_response(self._request("Logout", self._version, ET.tostring(root, encoding="utf-8"), 3, cleanup=True), "Logout")
        finally:
            self._cookie, self.authenticated = None, False
