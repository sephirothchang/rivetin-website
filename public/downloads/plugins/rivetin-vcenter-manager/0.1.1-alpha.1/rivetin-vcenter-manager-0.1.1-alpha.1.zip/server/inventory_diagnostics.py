"""Finite internal inventory-error metadata; no logging, values, storage or transport."""
from types import MappingProxyType
import re
from xml.etree import ElementTree as ET

ATTRIBUTE = '_rivetin_diagnostic'
NATIVE_CODES = MappingProxyType({name: index for index, name in enumerate((
    'unclassified-safe-code', 'VC_RESPONSE_INVALID', 'VC_XML_REFUSED', 'VC_REFERENCE_INVALID',
    'VC_SOAP_FAULT', 'VC_INVENTORY_INCOMPLETE', 'VC_INVENTORY_LIMIT', 'VC_BUDGET_EXCEEDED',
    'VC_PERMISSION_DENIED', 'VC_AUTHENTICATION_FAILED', 'VC_TIMEOUT', 'VC_CLEANUP_FAILED'))})
OBJECT_KINDS = MappingProxyType({name: index for index, name in enumerate((
    'not-classified', 'VirtualMachine', 'HostSystem', 'ClusterComputeResource', 'Datastore',
    'Folder', 'Datacenter', 'Network', 'DistributedVirtualPortgroup', 'Alarm', 'ComputeResource'))})
# IDs1..52 match the accepted draft; append new names instead of sorting again.
FIELD_NAMES = (
    'config.hardware.device', 'config.hardware.memoryMB', 'config.hardware.numCPU',
    'config.network.pnic', 'config.network.portgroup', 'config.network.vnic', 'config.network.vswitch',
    'config.product.build', 'config.product.fullName', 'config.product.version', 'config.template',
    'config.virtualNicManagerInfo.netConfig', 'configurationEx', 'datastore', 'guest.guestFullName',
    'guest.toolsRunningStatus', 'hardware.systemInfo.uuid', 'host', 'info.name', 'name', 'network',
    'parent', 'runtime.connectionState', 'runtime.host', 'runtime.inMaintenanceMode', 'runtime.powerState',
    'summary.accessible', 'summary.capacity', 'summary.effectiveCpu', 'summary.effectiveMemory',
    'summary.freeSpace', 'summary.hardware.cpuMhz', 'summary.hardware.cpuModel', 'summary.hardware.memorySize',
    'summary.hardware.model', 'summary.hardware.numCpuCores', 'summary.hardware.numCpuPkgs',
    'summary.hardware.numCpuThreads', 'summary.hardware.numHBAs', 'summary.hardware.numNics',
    'summary.hardware.vendor', 'summary.numCpuCores', 'summary.numCpuThreads', 'summary.numEffectiveHosts',
    'summary.numHosts', 'summary.quickStats.guestMemoryUsage', 'summary.quickStats.overallCpuUsage',
    'summary.quickStats.overallMemoryUsage', 'summary.quickStats.uptime', 'summary.totalCpu',
    'summary.totalMemory', 'triggeredAlarmState', 'config.annotation', 'config.guestId',
    'config.cpuHotAddEnabled', 'config.memoryHotAddEnabled', 'config.hotPlugMemoryLimit',
    'config.hotPlugMemoryIncrementSize', 'runtime.toolsInstallerMounted')
FIELDS = MappingProxyType({name: index + 1 for index, name in enumerate(FIELD_NAMES)})
FAULT_NAMES = ('NoPermission', 'NotAuthenticated', 'InvalidState', 'ManagedObjectNotFound', 'ConcurrentAccess',
               'InvalidProperty', 'NotSupported', 'RuntimeFault', 'InvalidLogin', 'TaskInProgress', 'RequestCanceled', 'InvalidRequest')
FAULTS = MappingProxyType({name: index + 128 for index, name in enumerate(FAULT_NAMES)})


def _namespace(error):
    try:
        result = object.__getattribute__(error, '__dict__')
        return result if type(result) is dict else None
    except BaseException:
        return None


def valid(value):
    if type(value) is not tuple or len(value) != 6 or any(type(item) is not int for item in value):
        return False
    version, native, stage, kind, field, shape = value
    return (version == 1 and 0 <= native < len(NATIVE_CODES) and 0 <= stage <= 5 and
            0 <= kind < len(OBJECT_KINDS) and 0 <= shape <= 7 and
            (0 <= field <= len(FIELD_NAMES) if stage == 2 else field == 0 or stage in (1, 4) and 128 <= field < 128 + len(FAULT_NAMES)))


def read(error):
    try:
        namespace = _namespace(error)
        value = dict.get(namespace, ATTRIBUTE) if namespace is not None else None
        return value if valid(value) else None
    except BaseException:
        return None


def _shape(value):
    if value is None: return 1
    if type(value) is not ET.Element: return 0
    if value.get('{http://www.w3.org/2001/XMLSchema-instance}nil') in ('true', '1'): return 2
    if len(value): return 7
    text = value.text
    if text is None or text == '': return 3
    if type(text) is not str: return 0
    if re.fullmatch(r'-\d{1,20}', text): return 4
    if re.fullmatch(r'\d{1,20}', text): return 5
    return 6


def annotate(error, stage, *, field=None, kind=None, value=None, fault=None):
    try:
        if not isinstance(error, BaseException) or read(error) is not None: return error
        namespace = _namespace(error)
        if namespace is None or type(stage) is not int: return error
        code = dict.get(namespace, 'code')
        native = NATIVE_CODES.get(code, 0) if type(code) is str else 0
        field_id = FIELDS.get(field, 0) if stage == 2 and type(field) is str else 0
        if stage in (1, 4) and type(fault) is str:
            field_id = FAULTS.get(fault, 0)
        record = (1, native, stage, OBJECT_KINDS.get(kind, 0) if type(kind) is str else 0,
                  field_id, _shape(value) if stage == 2 else 0)
        if valid(record): dict.__setitem__(namespace, ATTRIBUTE, record)
    except BaseException:
        pass
    return error


def carry(source, destination):
    try:
        value, namespace = read(source), _namespace(destination)
        if value is not None and namespace is not None and read(destination) is None:
            dict.__setitem__(namespace, ATTRIBUTE, value)
    except BaseException:
        pass
    return destination
