"""Finite Content Library ISO operations over the current pinned vCenter peer."""
import base64
import http.client
import json
import re
import socket
import threading
import time
import uuid
from urllib.parse import quote, unquote

from .advanced_hardware import exact_json_pairs, iso_relative_path
from .durable_operations import NativeRejected
from .managed_devices import native_ref
from .operation_ledger import require
from .profiles import AdapterError

MAX_REST_BODY = 128 * 1024


def library_id(value):
    try:
        parsed = uuid.UUID(value)
    except (ValueError, AttributeError, TypeError):
        raise AdapterError('VC_OPERATION_INVALID') from None
    require(str(parsed) == value, 'VC_OPERATION_INVALID')
    return value


def iso_name(value, limit=120):
    require(isinstance(value, str) and 0 < len(value) <= limit and not any(ord(c) < 32 or ord(c) == 127 for c in value),
            'VC_OPERATION_INVALID')
    return value


def rest_segment(value, maximum=128):
    require(isinstance(value, str) and len(value) <= maximum and re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]*', value),
            'VC_OPERATION_INVALID')
    return value


def datastore_iso_uri(value):
    require(isinstance(value, str) and 0 < len(value) <= 1024 and
            not any(ord(char) <= 32 or ord(char) == 127 or char in '#?' for char in value) and
            not re.search(r'%(?![0-9a-fA-F]{2})|%(?:2f|5c|25)', value, re.I), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
    match = re.fullmatch(r'ds:///vmfs/volumes/([A-Za-z0-9:_-]{1,128})/(.+)', value)
    require(match is not None, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
    volume, path = match.groups()
    try:
        return volume, iso_relative_path(unquote(path, errors='strict'))
    except (UnicodeError, AdapterError):
        raise AdapterError('VC_OPERATION_CAPABILITY_UNAVAILABLE') from None


class IsoLibrary:
    def __init__(self, transport, credentials):
        self.transport = transport
        self.credentials = credentials
        self._token = None

    def _request(self, method, path, body=None, *, basic=None, cleanup=False, dispatch=False):
        transport = self.transport
        timeout = transport._timeout(8, cleanup)
        transport.calls += 1
        if cleanup:
            transport.cleanup_calls += 1
        deadline = time.monotonic() + timeout
        connection = transport._connect(timeout)
        wire = connection.sock
        response = None

        def expire():
            try:
                wire.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            connection.close()

        timer = threading.Timer(max(0, deadline - time.monotonic()), expire)
        timer.daemon = True
        timer.start()
        try:
            headers = {'Accept': 'application/json', 'Connection': 'close'}
            if basic is not None:
                headers['Authorization'] = 'Basic ' + basic
            elif self._token:
                headers['vmware-api-session-id'] = self._token
            if body is not None:
                headers['Content-Type'] = 'application/json'
                body = json.dumps(body, separators=(',', ':'), ensure_ascii=False).encode()
            connection.request(method, path, body=body, headers=headers)
            response = connection.getresponse()
            require(not response.getheader('Location') and response.getheader('Content-Encoding', 'identity') == 'identity',
                    'VC_RESPONSE_INVALID')
            if cleanup and response.status in (200, 204, 401):
                return None
            if response.status not in (200, 201):
                if dispatch and response.status in (400, 401, 403, 404, 409):
                    raise NativeRejected('VC_NATIVE_PRECONDITION_REJECTED')
                raise AdapterError('VC_PERMISSION_DENIED' if response.status in (401, 403) else 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            length = response.getheader('Content-Length')
            if length is not None:
                require(re.fullmatch(r'[0-9]{1,6}', length) and not response.chunked, 'VC_RESPONSE_INVALID')
                length = int(length)
                require(0 < length <= MAX_REST_BODY, 'VC_RESPONSE_INVALID')
            result = bytearray()
            while length is None or len(result) < length:
                remaining = deadline - time.monotonic()
                require(remaining > 0, 'VC_TIMEOUT')
                wire.settimeout(remaining)
                chunk = response.read1(min(32768, MAX_REST_BODY + 1 - len(result)))
                if not chunk:
                    break
                result.extend(chunk)
                require(len(result) <= MAX_REST_BODY, 'VC_RESPONSE_INVALID')
            require(length is None or len(result) == length, 'VC_RESPONSE_INVALID')
            require(time.monotonic() < deadline, 'VC_TIMEOUT')
            return json.loads(result, object_pairs_hook=exact_json_pairs)
        except (ValueError, RecursionError, UnicodeError):
            raise AdapterError('VC_RESPONSE_INVALID') from None
        except TimeoutError:
            raise AdapterError('VC_TIMEOUT') from None
        except (OSError, http.client.HTTPException):
            raise AdapterError('VC_TIMEOUT' if time.monotonic() >= deadline else 'VC_TRANSPORT_UNAVAILABLE') from None
        finally:
            timer.cancel()
            if response is not None:
                response.close()
            connection.close()

    def _session(self):
        if self._token is None:
            user, password = self.credentials()
            require(isinstance(user, str) and isinstance(password, str) and ':' not in user, 'VC_AUTHENTICATION_FAILED')
            basic = base64.b64encode((user + ':' + password).encode()).decode('ascii')
            token = self._request('POST', '/api/session', basic=basic)
            require(isinstance(token, str) and re.fullmatch(r'[a-zA-Z0-9._~-]{1,512}', token), 'VC_RESPONSE_INVALID')
            self._token = token

    def close(self):
        if self._token is not None:
            try:
                self._request('DELETE', '/api/session', cleanup=True)
            finally:
                self._token = None

    def item(self, identifier):
        identifier = library_id(identifier)
        self._session()
        item = self._request('GET', '/api/content/library/item/' + identifier)
        require(isinstance(item, dict) and item.get('id') == identifier and item.get('type') == 'iso'
                and item.get('cached') is True, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        return {'id': identifier, 'name': iso_name(item.get('name')), 'version': iso_name(item.get('content_version'), 80)}

    def find(self, name):
        name = iso_name(name)
        self._session()
        ids = self._request('POST', '/api/content/library/item?action=find', {'name': name, 'type': 'iso', 'cached': True})
        require(isinstance(ids, list) and len(ids) <= 12, 'VC_INVENTORY_LIMIT')
        ids = [library_id(identifier) for identifier in ids]
        require(len(set(ids)) == len(ids), 'VC_RESPONSE_INVALID')
        items = [self.item(identifier) for identifier in ids]
        require(all(item['name'].casefold() == name.casefold() for item in items), 'VC_RESPONSE_INVALID')
        return items

    def confirm(self, identifier, version):
        item = self.item(identifier)
        require(item['version'] == version, 'VC_OPERATION_STATE_CONFLICT')
        entries = self._request('GET', '/api/content/library/item/' + identifier + '/file')
        require(isinstance(entries, list) and len(entries) <= 32 and all(isinstance(row, dict) for row in entries),
                'VC_RESPONSE_INVALID')
        files = [row for row in entries if iso_name(row.get('name'), 384).lower().endswith('.iso')]
        require(len(files) == 1 and files[0].get('cached') is True, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        name = iso_relative_path(files[0]['name'])
        require('/' not in name, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        file_version = iso_name(files[0].get('version'), 80)
        storage = self._request('GET', '/api/content/library/item/' + identifier + '/storage?file_name=' + quote(name, safe=''))
        require(isinstance(storage, list) and len(storage) == 1 and isinstance(storage[0], dict), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        row = storage[0]
        backing, uris = row.get('storage_backing'), row.get('storage_uris')
        require(row.get('name') == name and row.get('version') == file_version and row.get('cached') is True and
                isinstance(backing, dict) and backing.get('type') == 'DATASTORE' and
                isinstance(uris, list) and len(uris) == 1, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        volume, path = datastore_iso_uri(uris[0])
        require(path.rsplit('/', 1)[-1] == name, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        return item | {'isoName': name, 'fileVersion': file_version, 'volume': volume, 'relativePath': path,
                       'datastoreId': rest_segment(backing.get('datastore_id'))}

    def mount(self, vm, item):
        self._session()
        result = self._request('POST', '/api/vcenter/iso/image?action=mount',
                               {'vm': rest_segment(vm), 'library_item': library_id(item)}, dispatch=True)
        return rest_segment(result, 64)

    def read_mount(self, vm, cdrom):
        self._session()
        path = '/api/vcenter/vm/' + rest_segment(vm) + '/hardware/cdrom/' + rest_segment(cdrom, 64)
        return self._request('GET', path)


class IsoLibraryOperations:
    iso_library = None

    def lookup_library_iso(self, key, name):
        props, _, _ = self.scoped_vm(key)
        require(props['config.template'] is False and str(props['runtime.powerState']) == 'poweredOff', 'VC_OPERATION_STATE_CONFLICT')
        self.privilege(key, ['System.View'])
        return self.iso_library.find(name)

    def library_mount_source(self, host, params):
        require(self.iso_library is not None, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        item = self.iso_library.confirm(params['itemId'], iso_name(params['version'], 80))
        store = {'objectType': 'Datastore', 'objectId': item['datastoreId']}
        name = self.advanced_datastore(host, store, 'System.View')
        url = self.read(store, ['summary.url'], optional=('summary.url',))['summary.url']
        require(isinstance(url, str) and url.rstrip('/') == 'ds:///vmfs/volumes/' + item['volume'],
                'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        backing = {'datastore': store, 'fileName': '[' + name + '] ' + item['relativePath'], 'fileVersion': item['fileVersion']}
        return {'item': {name: item[name] for name in ('id', 'name', 'version', 'isoName')}, 'backing': backing}

    def prepare_library_mount(self, key, params, host):
        self.privilege(key, ['VirtualMachine.Config.AddRemoveDevice'])
        source = self.library_mount_source(host, params)
        return source | {'deviceKeysBefore': sorted(device.key for device in self.devices(key))}

    def invoke_library_mount(self, intent):
        try:
            self.cache.clear()
            key, expected = intent['key'], intent['expected']
            props, host, cluster = self.scoped_vm(key)
            require(props['config.template'] is False and str(props['runtime.powerState']) == 'poweredOff'
                    and host == expected['host'] and cluster == expected['cluster']
                    and props['config.changeVersion'] == expected['changeVersion'], 'VC_OPERATION_STATE_CONFLICT')
            plan = expected['hardware']['libraryMount']
            item = plan['item']
            current = self.prepare_library_mount(key, {'itemId': item['id'], 'version': item['version']}, host)
            require(current == plan, 'VC_OPERATION_STATE_CONFLICT')
        except AdapterError as error:
            raise NativeRejected(error.code) from None
        cdrom = self.iso_library.mount(key['objectId'], item['id'])
        return {'result': {'cdrom': cdrom}}

    def verify_library_mount(self, record, plan, host):
        result = record.get('result', {}).get('value')
        require(isinstance(result, dict) and set(result) == {'cdrom'} and 'backing' in plan and 'deviceKeysBefore' in plan,
                'VC_OPERATION_POSTCHECK_PENDING')
        cdrom = rest_segment(result['cdrom'], 64)
        if not re.fullmatch(r'(?:0|[1-9][0-9]{0,9})', cdrom) or int(cdrom) in plan['deviceKeysBefore']:
            return {'verified': False}
        key, item = record['key'], plan['item']
        source = self.library_mount_source(host, {'itemId': item['id'], 'version': item['version']})
        if source != {'item': item, 'backing': plan['backing']}:
            return {'verified': False}
        drive = self.iso_library.read_mount(key['objectId'], cdrom)
        backing = drive.get('backing') if isinstance(drive, dict) else None
        file_name = backing.get('iso_file') if isinstance(backing, dict) and backing.get('type') == 'ISO_FILE' else None
        expected = source['backing']
        if file_name != expected['fileName']:
            return {'verified': False}
        native = self.vim.vm.device.VirtualCdrom
        device = next((item for item in self.devices(key) if item.key == int(cdrom)), None)
        matches = (type(device) is native and type(device.backing) is native.IsoBackingInfo and
                   device.backing.datastore is not None and native_ref(device.backing.datastore) == expected['datastore'] and
                   device.backing.fileName == expected['fileName'])
        return {'verified': matches, 'cdrom': cdrom, 'libraryItem': item['id'], 'backingVerified': matches}

