"""Acknowledgement of a verified entity/alarm occurrence within cluster scope."""
from .operation_ledger import require
from .resource_scope import identity
from .alarm_inventory import timestamp
from .profiles import AdapterError
from .alarm_status_protocol import alarm_status_profile, set_alarm_green

ALARM_OPERATIONS={'alarm.acknowledge':(('ClusterComputeResource','HostSystem','VirtualMachine','Datacenter','Folder'),None)}
ALARM_OPERATIONS['alarm.resetGreen']=(ALARM_OPERATIONS['alarm.acknowledge'][0],None)


class AlarmOperations:
    def parent_root_candidates(self):
        from .managed_executor import native_key, label
        keys={identity(native_key(self.service.rootFolder))}
        for kind,identifier in self.selected:
            keys.add(identity(self.datacenter({'objectType':kind,'objectId':identifier})))
        result=[]
        for kind,identifier in sorted(keys):
            key={'objectType':kind,'objectId':identifier}
            self.privilege(key,['System.Read'])
            result.append({'key':key,'name':label(self.read(key,['name'])['name'],256)})
        return result

    def alarm_entity(self,key,purpose='vmware.alarm.acknowledge'):
        if key['objectType'] in {'Datacenter','Folder'}:
            self.require_parent_root(key,purpose)
            self.authorize_roots([key | {'purposes':[purpose]}])
            return key
        if key['objectType']=='VirtualMachine':return self.scoped_vm(key)[2]
        if key['objectType']=='HostSystem':return self.cluster(key)
        require(identity(key,'ClusterComputeResource') in self.selected,'VC_PERMISSION_DENIED')
        return key

    def parent_alarm_entities(self):
        from .managed_executor import native_key, label
        result=[]
        for root in self.parent_roots:
            key={name:root[name] for name in ('objectType','objectId')}
            self.authorize_roots([root])
            entity={'key':key,'name':label(self.read(key,['name'])['name'],256),'purposes':root['purposes'],'alarms':None}
            if 'vmware.alarm.read' in root['purposes']:
                self.alarm_entity(key,'vmware.alarm.read')
                states=[]
                for value in self.alarm_states(key):
                    state={'key':label(value.key,256),'entity':key,'alarm':native_key(value.alarm),'status':str(value.overallStatus),'time':timestamp(value.time)}
                    require(state['status'] in ('red','yellow','green','gray'),'VC_INVENTORY_INCOMPLETE')
                    if value.acknowledged is not None:state['acknowledged']=value.acknowledged
                    try:state['name']=label(self.read(state['alarm'],['info.name'])['info.name'],256)
                    except AdapterError:
                        pass  # Auxiliary names do not replace proven occurrence state.
                    states.append(state)
                entity['alarms']=states
            result.append(entity)
        return result

    def alarm_states(self,key):
        from .managed_executor import native_key
        values=self.read(key,['triggeredAlarmState'],optional=('triggeredAlarmState',))['triggeredAlarmState'] or []
        require(len(values)<=200,'VC_INVENTORY_LIMIT')
        selected=[value for value in values if native_key(value.entity)==key]
        require(len({value.key for value in selected})==len(selected),'VC_INVENTORY_INCOMPLETE')
        return selected

    def prepare_alarm(self,key,operation,p):
        from .managed_executor import native_key, label
        reset=operation=='alarm.resetGreen'
        require(set(p)=={'alarm','alarmKey','triggeredAt'}|({'confirmResetGreen'} if reset else set()));identity(p['alarm'],'Alarm');label(p['alarmKey'],256)
        if reset:
            require(p['confirmResetGreen'] is True)
            alarm_status_profile(self.service)
        require(timestamp(p['triggeredAt'])==p['triggeredAt'])
        cluster=self.alarm_entity(key,'vmware.alarm.reset' if reset else 'vmware.alarm.acknowledge')
        matches=[state for state in self.alarm_states(key) if state.key==p['alarmKey'] and native_key(state.alarm)==p['alarm'] and timestamp(state.time)==p['triggeredAt']]
        require(len(matches)==1 and (reset or matches[0].acknowledged is False) and str(matches[0].overallStatus) in ('red','yellow'),'VC_OPERATION_STATE_CONFLICT')
        manager=native_key(self.service.alarmManager);identity(manager,'AlarmManager')
        # Alarm is not a ManagedEntity accepted by the privilege-query API.
        # Resolve its definition owner; the native acknowledgement still enforces
        # its own parameter privileges independently.
        definition=self.read(p['alarm'],['info.name','info.entity'])
        definition_entity=native_key(definition['info.entity'])
        require(isinstance(self.obj(definition_entity),self.vim.ManagedEntity),'VC_REFERENCE_INVALID')
        self.privilege(definition_entity,['Alarm.SetStatus' if reset else 'Alarm.Acknowledge']);self.privilege(key,['System.Read']+(['Alarm.SetStatus'] if reset else []))
        name=label(definition['info.name'],256)
        if reset:
            definition_state=self.read(p['alarm'],['info.enabled','info.lastModifiedTime'])
            require(type(definition_state['info.enabled']) is bool,'VC_INVENTORY_INCOMPLETE')
            return ({'cluster':cluster,'manager':manager,'definitionEntity':definition_entity,'status':str(matches[0].overallStatus),
                'definition':{'name':name,'enabled':definition_state['info.enabled'],'lastModifiedTime':timestamp(definition_state['info.lastModifiedTime'])},'protocolProfile':alarm_status_profile(self.service)},
                {'name':name,'entity':key,'alarm':p['alarm'],'triggeredAt':p['triggeredAt'],'impact':'Reset only this exact alarm/entity occurrence to green. Preserve the definition and enabled state. A continuing condition may trigger again. No occurrence CAS exists; recheck immediately before one dispatch. Native SetAlarmStatus metadata is verified only for the matching vCenter 8.0.3 binary profile; functional compatibility remains pending.'})
        return {'cluster':cluster,'manager':manager,'definitionEntity':definition_entity,'status':str(matches[0].overallStatus),'acknowledged':False},{'name':name,'entity':key,'alarm':p['alarm'],'triggeredAt':p['triggeredAt'],
            'impact':'Acknowledges the selected alarm on this entity and preserves its definition. This does not reset severity to green. The native API has no occurrence CAS; a changed trigger is rechecked before dispatch.'}

    def invoke_alarm(self,intent):
        if intent['operation']=='alarm.resetGreen':
            # A changed occurrence is never silently substituted after review.
            self.cache.clear()
            p=intent['parameters']
            from .managed_executor import native_key
            matches=[state for state in self.alarm_states(intent['key']) if state.key==p['alarmKey'] and native_key(state.alarm)==p['alarm'] and timestamp(state.time)==p['triggeredAt'] and str(state.overallStatus)==intent['expected']['status']]
            if len(matches)!=1:
                from .durable_operations import NativeRejected
                raise NativeRejected('VC_OPERATION_STATE_CONFLICT')
            return set_alarm_green(self,intent['expected']['manager'],p['alarm'],intent['key'])
        return self.obj(intent['expected']['manager']).AcknowledgeAlarm(alarm=self.obj(intent['parameters']['alarm']),entity=self.obj(intent['key']))

    def verify_alarm(self,record):
        from .managed_executor import native_key
        reset=record['operation']=='alarm.resetGreen'
        p=record['parameters'];require(self.alarm_entity(record['key'],'vmware.alarm.reset' if reset else 'vmware.alarm.acknowledge')==record['expected']['cluster'],'VC_OPERATION_SCOPE_CHANGED')
        if reset:
            alarm_status_profile(self.service)
            expected=record['expected']['definition'];definition=self.read(p['alarm'],['info.name','info.entity','info.enabled','info.lastModifiedTime'])
            require(definition['info.name']==expected['name'] and native_key(definition['info.entity'])==record['expected']['definitionEntity'] and definition['info.enabled']==expected['enabled'] and timestamp(definition['info.lastModifiedTime'])==expected['lastModifiedTime'],'VC_OPERATION_POSTCHECK_PENDING')
        states=[state for state in self.alarm_states(record['key']) if state.key==p['alarmKey'] and native_key(state.alarm)==p['alarm']]
        original=[state for state in states if timestamp(state.time)==p['triggeredAt']]
        if not original:
            returned=record.get('result',{}).get('nativeReturned') is True
            return {'verified':returned,'originalOccurrenceInactive':True,'newOccurrencePresent':bool(states)}
        if reset:
            return {'verified':len(original)==1 and str(original[0].overallStatus)=='green','definitionPreserved':True}
        return {'verified':len(original)==1 and original[0].acknowledged is True}
