"""Cluster creation core; parent grants must come from a trusted caller.

The current business carrier supplies no parent grants. Its default remains
deny. FW's final root contract must be bound before this can be used there.
"""
from .operation_ledger import require
from .resource_scope import identity

CLUSTER_CREATE_PURPOSE='vmware.cluster.create'


class ClusterCreation:
    def require_parent_root(self,key,purpose):
        marker=identity(key)
        require(any(identity({'objectType':row['objectType'],'objectId':row['objectId']})==marker and purpose in row['purposes'] for row in self.parent_roots),'VC_PERMISSION_DENIED')

    def prepare_cluster_creation(self,key,p):
        from .managed_executor import CLUSTER_FIELDS,valid_cluster_field,native_key,label
        self.require_parent_root(key,CLUSTER_CREATE_PURPOSE);identity(key,'Datacenter')
        require({'name','haEnabled','drsEnabled'}<=set(p)<={'name'}|set(CLUSTER_FIELDS))
        name=label(p['name'],80);require(not any(char in name for char in '%/\\'))
        require(all(valid_cluster_field(field,value) for field,value in p.items() if field!='name'))
        dc=self.read(key,['name','hostFolder']);folder=native_key(dc['hostFolder']);identity(folder,'Folder')
        container=self.read(folder,['childType','parent']);children=container['childType']
        require(native_key(container['parent'])==key,'VC_PERMISSION_DENIED')
        require('ComputeResource' in children or 'vim.ComputeResource' in children,'VC_OPERATION_STATE_CONFLICT')
        self.privilege(folder,['Host.Inventory.CreateCluster'])
        return {'hostFolder':folder,'datacenter':key},{'name':name,'datacenterName':label(dc['name'],120),'hostFolder':folder,
            'impact':'Creates one empty cluster with only reviewed HA/DRS settings. No host is added or removed. After the native result is verified, explicitly add the new cluster to plugin connection scope; existing scope/history are retained.'}

    def invoke_cluster_creation(self,intent):
        from .managed_executor import CLUSTER_FIELDS
        fields={}
        for group,kind in [('dasConfig',self.vim.cluster.DasConfigInfo),('drsConfig',self.vim.cluster.DrsConfigInfo)]:
            values={CLUSTER_FIELDS[name][0].split('.')[1]:value for name,value in intent['parameters'].items() if name!='name' and CLUSTER_FIELDS[name][0].startswith(group+'.')}
            if values:fields[group]=kind(**values)
        return self.obj(intent['expected']['hostFolder']).CreateClusterEx(name=intent['parameters']['name'],spec=self.vim.cluster.ConfigSpecEx(**fields))

    def verify_cluster_creation(self,record):
        from .managed_executor import CLUSTER_FIELDS,native_key
        self.require_parent_root(record['key'],CLUSTER_CREATE_PURPOSE)
        result=record.get('result',{})
        require(result.get('nativeReturned') is True,'VC_OPERATION_POSTCHECK_PENDING')
        created=result.get('value');identity(created,'ClusterComputeResource')
        p=record['parameters'];paths=['configurationEx.'+CLUSTER_FIELDS[field][0] for field in p if field!='name']
        props=self.read(created,['name','parent','host']+paths,optional=('host',))
        current_folder=native_key(self.read(record['key'],['hostFolder'])['hostFolder'])
        valid=props['name']==p['name'] and native_key(props['parent'])==record['expected']['hostFolder']==current_folder and not props['host']
        valid=valid and all(props['configurationEx.'+CLUSTER_FIELDS[field][0]]==value for field,value in p.items() if field!='name')
        return {'verified':valid,'createdKey':created,'enrollmentRequired':True}
