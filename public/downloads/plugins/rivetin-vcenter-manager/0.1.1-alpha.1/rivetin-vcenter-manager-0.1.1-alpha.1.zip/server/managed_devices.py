"""Finite powered-off VM device changes; no arbitrary paths or file destruction."""
import copy
import hashlib

from .operation_ledger import require, operation_id, canonical
from .resource_scope import identity
from .disk_paths import new_disk_path, verify_disk_path, vmx_path_hash

DEVICE_OPERATIONS = {name: ('VirtualMachine', None) for name in (
    'vm.disk.add', 'vm.disk.extend', 'vm.disk.remove', 'vm.nic.add', 'vm.nic.edit', 'vm.nic.remove')}


def native_ref(value, kind=None):
    require(value is not None and hasattr(type(value), '_wsdlName'), 'VC_REFERENCE_INVALID')
    key = {'objectType': type(value)._wsdlName, 'objectId': value._moId}
    identity(key, kind)
    return key


def nic_identity_digest(device):
    info={'mac':device.macAddress,'addressType':device.addressType,'startConnected':device.connectable.startConnected if device.connectable else None,
          'allowGuestControl':device.connectable.allowGuestControl if device.connectable else None}
    return hashlib.sha256(canonical(info).encode('utf-8')).hexdigest()


class DeviceOperations:
    def prepare_initial_devices(self, parameters, placement, datastore_name):
        require(type(parameters['capacityGB']) is int and 1 <= parameters['capacityGB'] <= 65536)
        operation_id(parameters['diskId'])
        require(type(parameters['startConnected']) is bool and parameters['firmware'] in {'bios', 'efi'})
        self.privilege(placement['folder'], ['VirtualMachine.Config.AddNewDisk'])
        network_name = self.device_network(placement['host'], parameters['network'])
        return {'controllerKey': -100, 'busNumber': 0, 'unitNumber': 0,
                'fileName': '[' + datastore_name + '] rivetin-' + parameters['diskId'] + '.vmdk', 'networkName': network_name}

    def initial_device_changes(self, parameters, expected):
        return self.device_changes(None, 'vm.disk.add', parameters, expected) + self.device_changes(None, 'vm.nic.add', parameters, expected)

    def verify_initial_devices(self, key, parameters, expected):
        devices = self.devices(key)
        controllers = [item for item in devices if type(item) is self.vim.vm.device.VirtualLsiLogicSASController and item.busNumber == 0 and item.sharedBus == 'noSharing']
        disks = [item for item in devices if type(item) is self.vim.vm.device.VirtualDisk]
        nics = [item for item in devices if isinstance(item, self.vim.vm.device.VirtualEthernetCard)]
        if len(controllers) != 1 or len(disks) != 1 or len(nics) != 1:
            return False
        disk, nic = disks[0], nics[0]
        backing = self.disk_backing(disk)
        valid = disk.controllerKey == controllers[0].key and disk.unitNumber == 0 and disk.capacityInKB == parameters['capacityGB'] * 1048576 and backing.datastore is not None and native_ref(backing.datastore) == parameters['datastore'] and backing.thinProvisioned is True and type(nic) is self.vim.vm.device.VirtualVmxnet3 and type(nic.backing) is self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo and nic.backing.network is not None and native_ref(nic.backing.network) == parameters['network'] and nic.connectable is not None and nic.connectable.startConnected == parameters['startConnected']
        if not valid:
            return False
        vmx_path = self.read(key, ['config.files.vmPathName'])['config.files.vmPathName']
        return verify_disk_path(backing.fileName, expected['fileName'], vmx_path, parameters['diskId'], same_datastore=True)

    def devices(self, key):
        values = self.read(key, ['config.hardware.device'])['config.hardware.device']
        require(isinstance(values, list) and len(values) <= 200, 'VC_INVENTORY_INCOMPLETE')
        require(all(type(item.key) is int and item.key >= 0 for item in values) and len({item.key for item in values}) == len(values), 'VC_RESPONSE_INVALID')
        return values

    def device_digest(self, device):
        support, soap = self.sdk.VmomiSupport, self.sdk.SoapAdapter
        info = support.Object(name='device', type=type(device), flags=0, version=self.stub.version)
        return hashlib.sha256(soap.Serialize(device, info=info, version=self.stub.version)).hexdigest()

    def disk_backing(self, disk):
        backing = disk.backing
        require(type(backing) is self.vim.vm.device.VirtualDisk.FlatVer2BackingInfo and backing.parent is None and
                backing.keyId is None and backing.diskMode == 'persistent' and backing.sharing in (None, 'sharingNone'), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        require(isinstance(backing.fileName, str) and backing.fileName and isinstance(disk.capacityInKB, int) and disk.capacityInKB > 0, 'VC_INVENTORY_INCOMPLETE')
        return backing

    def device_network(self, host, network):
        identity(network, 'Network')  # DVS/opaque backing is a separate future contract.
        links = self.read(host, ['network'])['network']
        require(any(native_ref(item) == network for item in links), 'VC_PERMISSION_DENIED')
        name = self.read(network, ['name'])['name']
        require(isinstance(name, str) and 0 < len(name) <= 80 and not any(ord(c) < 32 for c in name), 'VC_RESPONSE_INVALID')
        # Standard backing uses deviceName, not its informational network MoRef.
        names = [self.read(native_ref(item), ['name'])['name'] for item in links if type(item) is self.vim.Network]
        require(names.count(name) == 1, 'VC_OPERATION_STATE_CONFLICT')
        _, groups, props = self._network(host)
        require(name in groups, 'VC_OPERATION_STATE_CONFLICT')
        protected = list(props['networkInfo.vnic'] or []) + list(props['networkInfo.consoleVnic'] or [])
        require(not any(nic.portgroup == name for nic in protected), 'VC_OPERATION_MANAGEMENT_NETWORK_PROTECTED')
        self.privilege(network, ['Network.Assign'])
        return name

    def prepare_device(self, key, operation, parameters, host):
        devices = self.devices(key)
        expected = {'devices': [{'key': item.key, 'digest': self.device_digest(item)} for item in devices]}
        observation = {}
        if operation == 'vm.disk.add':
            require(set(parameters) == {'controllerKey', 'datastore', 'capacityGB', 'diskId'})
            require(type(parameters['controllerKey']) is int and parameters['controllerKey'] >= -1)
            require(type(parameters['capacityGB']) is int and 1 <= parameters['capacityGB'] <= 65536)
            token = parameters['diskId']
            operation_id(token)
            datastore = parameters['datastore']; identity(datastore, 'Datastore')
            require(any(native_ref(item) == datastore for item in self.read(host, ['datastore'])['datastore']), 'VC_PERMISSION_DENIED')
            name = self.read(datastore, ['name'])['name']
            require(isinstance(name, str) and 0 < len(name) <= 80 and not any(ord(c) < 32 or c in '[]/\\' for c in name), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            controllers = [item for item in devices if isinstance(item, self.vim.vm.device.VirtualSCSIController)]
            if parameters['controllerKey'] == -1:
                used = {item.busNumber for item in controllers}
                free = [n for n in range(4) if n not in used]
                require(bool(free), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                expected.update(controllerKey=-100, busNumber=free[0], unitNumber=0)
                self.privilege(key, ['VirtualMachine.Config.AddRemoveDevice'])
            else:
                matched = [item for item in controllers if item.key == parameters['controllerKey']]
                require(len(matched) == 1 and matched[0].sharedBus == 'noSharing', 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                used = {item.unitNumber for item in devices if item.controllerKey == matched[0].key}
                reserved = matched[0].scsiCtlrUnitNumber
                free = [n for n in range(16) if n not in (7, reserved) and n not in used]
                require(bool(free), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                expected.update(controllerKey=matched[0].key, unitNumber=free[0])
            vmx_path = self.read(key, ['config.files.vmPathName'])['config.files.vmPathName']
            expected['fileName'] = new_disk_path(vmx_path, name, token)
            expected['vmxPathHash'] = vmx_path_hash(vmx_path)
            self.privilege(key, ['VirtualMachine.Config.AddNewDisk'])
            self.privilege(datastore, ['Datastore.AllocateSpace'])
            observation = {'capacityGB': parameters['capacityGB'], 'controllerKey': expected['controllerKey'], 'unitNumber': expected['unitNumber'], 'newController': 'busNumber' in expected,
                           'impact': 'Creates a new persistent thin VMDK. No existing disk is attached or overwritten.'}
        elif operation == 'vm.nic.add':
            require(set(parameters) == {'network', 'startConnected'} and type(parameters['startConnected']) is bool)
            expected['networkName'] = self.device_network(host, parameters['network'])
            self.privilege(key, ['VirtualMachine.Config.AddRemoveDevice'])
            observation = {'networkName': expected['networkName'], 'impact': 'Adds one VMXNET3 adapter with a generated MAC; existing adapters are preserved.'}
        else:
            fields = {'vm.disk.extend': {'deviceKey', 'capacityGB', 'confirmDevice'}, 'vm.disk.remove': {'deviceKey', 'retainFiles', 'confirmDevice'},
                      'vm.nic.edit': {'deviceKey', 'network', 'startConnected', 'confirmDevice'}, 'vm.nic.remove': {'deviceKey', 'confirmDevice'}}
            require(set(parameters) == fields[operation] and parameters['confirmDevice'] is True and type(parameters['deviceKey']) is int)
            matched = [item for item in devices if item.key == parameters['deviceKey']]
            require(len(matched) == 1, 'VC_OPERATION_STATE_CONFLICT')
            device = matched[0]
            expected['deviceKey'] = device.key
            observation['deviceKey'] = device.key
            observation['deviceLabel'] = (device.deviceInfo.label or '')[:120] if device.deviceInfo else ''
            if operation.startswith('vm.disk.'):
                require(type(device) is self.vim.vm.device.VirtualDisk, 'VC_OPERATION_STATE_CONFLICT')
                backing = self.disk_backing(device)
                expected['fileNameHash'] = hashlib.sha256(backing.fileName.encode('utf-8')).hexdigest()
                if operation == 'vm.disk.extend':
                    require(type(parameters['capacityGB']) is int and 1 <= parameters['capacityGB'] <= 65536 and parameters['capacityGB'] * 1048576 > device.capacityInKB)
                    self.privilege(key, ['VirtualMachine.Config.DiskExtend', 'VirtualMachine.Config.EditDevice'])
                    datastore = native_ref(backing.datastore, 'Datastore')
                    require(any(native_ref(item) == datastore for item in self.read(host, ['datastore'])['datastore']), 'VC_PERMISSION_DENIED')
                    self.privilege(datastore, ['Datastore.AllocateSpace'])
                    observation['before'] = {'capacityGB': str(device.capacityInKB / 1048576)}
                    observation['impact'] = 'Only extends the selected disk. Guest partitions and filesystems are not resized.'
                else:
                    require(parameters['retainFiles'] is True)
                    self.privilege(key, ['VirtualMachine.Config.RemoveDisk'])
                    observation['impact'] = 'Detaches only this device; fileOperation is unset and backing files are retained. Boot disk identity is not inferred.'
            else:
                require(isinstance(device, self.vim.vm.device.VirtualEthernetCard) and type(device.backing) is self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                if operation == 'vm.nic.edit':
                    require(type(parameters['startConnected']) is bool)
                    expected['networkName'] = self.device_network(host, parameters['network'])
                    self.privilege(key, ['VirtualMachine.Config.EditDevice', 'VirtualMachine.Interact.DeviceConnection'])
                    observation.update(before={'network': native_ref(device.backing.network, 'Network') if device.backing.network else None,
                                               'startConnected': device.connectable.startConnected if device.connectable else None}, networkName=expected['networkName'])
                else:
                    self.privilege(key, ['VirtualMachine.Config.AddRemoveDevice'])
                observation['impact'] = 'Changes only the explicitly selected VM adapter; it may disconnect the guest network. Host management adapters are never selected.'
        return expected, observation

    def device_changes(self, key, operation, parameters, expected):
        spec = self.vim.vm.device.VirtualDeviceSpec
        changes = []
        if operation == 'vm.disk.add':
            if 'busNumber' in expected:
                controller = self.vim.vm.device.VirtualLsiLogicSASController(key=expected['controllerKey'], busNumber=expected['busNumber'], sharedBus='noSharing')
                changes.append(spec(operation='add', device=controller))
            backing = self.vim.vm.device.VirtualDisk.FlatVer2BackingInfo(fileName=expected['fileName'], diskMode='persistent', thinProvisioned=True)
            device = self.vim.vm.device.VirtualDisk(key=-101, controllerKey=expected['controllerKey'], unitNumber=expected['unitNumber'], capacityInKB=parameters['capacityGB'] * 1048576, backing=backing)
            changes.append(spec(operation='add', fileOperation='create', device=device))
        elif operation == 'vm.nic.add':
            device = self.vim.vm.device.VirtualVmxnet3(key=-102, addressType='generated', backing=self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo(deviceName=expected['networkName']),
                                                    connectable=self.vim.vm.device.VirtualDevice.ConnectInfo(startConnected=parameters['startConnected'], allowGuestControl=True, connected=False))
            changes.append(spec(operation='add', device=device))
        else:
            device = copy.copy(next(item for item in self.devices(key) if item.key == parameters['deviceKey']))
            if operation == 'vm.disk.extend':
                device.capacityInKB = parameters['capacityGB'] * 1048576
                device.capacityInBytes = parameters['capacityGB'] * 1073741824
            elif operation == 'vm.nic.edit':
                device.backing = self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo(deviceName=expected['networkName'])
                require(device.connectable is not None, 'VC_INVENTORY_INCOMPLETE')
                device.connectable = copy.copy(device.connectable)
                device.connectable.startConnected = parameters['startConnected']
            changes.append(spec(operation='remove' if operation.endswith('.remove') else 'edit', device=device))
        return changes

    def verify_device(self, record):
        devices = self.devices(record['key'])
        operation, parameters, expected = record['operation'], record['parameters'], record['expected']['device']
        previous = {item['key'] for item in expected['devices']}
        if operation.endswith('.remove'):
            return {'verified': all(item.key != parameters['deviceKey'] for item in devices), 'filesRetainedByRequest': operation == 'vm.disk.remove'}
        if operation == 'vm.disk.add':
            matches = [item for item in devices if type(item) is self.vim.vm.device.VirtualDisk and item.key not in previous]
            if len(matches) > 1:
                matches = [item for item in matches if item.backing is not None and item.backing.fileName == expected['fileName']]
            if len(matches) != 1:
                return {'verified': False}
            disk = matches[0]
            backing = self.disk_backing(disk)
            if (disk.capacityInKB != parameters['capacityGB'] * 1048576 or backing.datastore is None or
                    native_ref(backing.datastore) != parameters['datastore'] or backing.thinProvisioned is not True or
                    disk.unitNumber != expected['unitNumber']):
                return {'verified': False}
            if 'busNumber' in expected:
                controllers = [item for item in devices if type(item) is self.vim.vm.device.VirtualLsiLogicSASController and
                               item.busNumber == expected['busNumber'] and item.sharedBus == 'noSharing']
                if len(controllers) != 1 or disk.controllerKey != controllers[0].key:
                    return {'verified': False}
            elif disk.controllerKey != expected['controllerKey']:
                return {'verified': False}
            vmx_path = self.read(record['key'], ['config.files.vmPathName'])['config.files.vmPathName']
            verify_disk_path(backing.fileName, expected['fileName'], vmx_path, parameters['diskId'],
                             frozen_vmx_hash=expected.get('vmxPathHash'))
        elif operation == 'vm.nic.add':
            matches = [item for item in devices if isinstance(item, self.vim.vm.device.VirtualEthernetCard) and item.key not in previous and type(item.backing) is self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo and item.backing.network and native_ref(item.backing.network) == parameters['network'] and item.connectable and item.connectable.startConnected == parameters['startConnected']]
        else:
            matches = [item for item in devices if item.key == parameters['deviceKey']]
            if operation == 'vm.disk.extend':
                matches = [item for item in matches if type(item) is self.vim.vm.device.VirtualDisk and item.capacityInKB == parameters['capacityGB'] * 1048576 and hashlib.sha256(item.backing.fileName.encode('utf-8')).hexdigest() == expected['fileNameHash']]
            else:
                matches = [item for item in matches if isinstance(item, self.vim.vm.device.VirtualEthernetCard) and type(item.backing) is self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo and item.backing.network and native_ref(item.backing.network) == parameters['network'] and item.connectable and item.connectable.startConnected == parameters['startConnected']]
        return {'verified': len(matches) == 1, **({'deviceKey': matches[0].key} if len(matches) == 1 else {})}

    def relocation_store(self, host, datastore, host_stores):
        require(identity(datastore, 'Datastore') in host_stores, 'VC_PERMISSION_DENIED')
        store = self.read(datastore, ['name', 'host'])
        mounts = [item for item in store['host'] if native_ref(item.key) == host]
        require(len(mounts) == 1 and mounts[0].mountInfo is not None and mounts[0].mountInfo.mounted is True and
                mounts[0].mountInfo.accessible is True and mounts[0].mountInfo.accessMode == 'readWrite', 'VC_OPERATION_STATE_CONFLICT')
        return store['name']

    def prepare_relocation(self, key, parameters, source_host, source_cluster, *, live=False):
        confirmation = 'confirmLive' if live else 'confirmOffline'
        mode = parameters.get('mode', 'storage')
        require(mode in ('compute', 'storage', 'both'))
        compute_only = mode == 'compute'
        required = {'host', confirmation} | (set() if compute_only else {'datastore'})
        require(required <= set(parameters) <= required | {'mode', 'folder', 'networkMappings'} and parameters[confirmation] is True)
        host, datastore = parameters['host'], parameters.get('datastore')
        identity(host, 'HostSystem')
        require((host == source_host) == (mode == 'storage'), 'VC_OPERATION_STATE_CONFLICT')
        cluster = self.cluster(host)
        source_dc, target_dc = self.datacenter(source_cluster), self.datacenter(cluster)
        host_state = self.read(host, ['runtime.connectionState', 'runtime.inMaintenanceMode', 'datastore'])
        require(host_state['runtime.connectionState'] == 'connected' and host_state['runtime.inMaintenanceMode'] is False, 'VC_OPERATION_STATE_CONFLICT')
        host_stores = {identity(native_ref(item), 'Datastore') for item in host_state['datastore']}
        props = self.read(key, ['datastore', 'config.files.vmPathName', 'config.keyId', 'resourcePool'], optional=('config.keyId',))
        require(props['config.keyId'] is None, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        vmx = props['config.files.vmPathName']
        require(isinstance(vmx, str) and bool(vmx), 'VC_INVENTORY_INCOMPLETE')
        source_stores = [native_ref(item, 'Datastore') for item in props['datastore']]
        if compute_only:
            require(bool(source_stores), 'VC_INVENTORY_INCOMPLETE')
            store_names = [self.relocation_store(host, store, host_stores) for store in source_stores]
            require(sum(vmx.startswith('[' + name + '] ') for name in store_names if isinstance(name, str) and name) == 1, 'VC_INVENTORY_INCOMPLETE')
        else:
            store_name = self.relocation_store(host, datastore, host_stores)
            require(isinstance(store_name, str) and 0 < len(store_name) <= 80 and not any(ord(c) < 32 or c in '[]/\\' for c in store_name), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            self.privilege(datastore, ['Datastore.AllocateSpace'])
        source_pool = native_ref(props['resourcePool'], 'ResourcePool')
        pool = source_pool if cluster == source_cluster else native_ref(self.read(cluster, ['resourcePool'])['resourcePool'], 'ResourcePool')
        if pool != source_pool:
            self.privilege(pool, ['Resource.AssignVMToPool'])
        devices = self.devices(key)
        mappings=parameters.get('networkMappings',[])
        require(isinstance(mappings,list) and len(mappings)<=200)
        by_nic={}
        for mapping in mappings:
            require(isinstance(mapping,dict) and set(mapping)=={'deviceKey','network'} and type(mapping['deviceKey']) is int and mapping['deviceKey']>=0 and mapping['deviceKey'] not in by_nic)
            identity(mapping['network'],'Network');by_nic[mapping['deviceKey']]=mapping['network']
        network_changes=[]
        topology = []
        for item in devices:
            kind = type(item)._wsdlName
            require(kind not in {'VirtualNVDIMM', 'VirtualUSB', 'VirtualUSBXHCIController', 'VirtualPCIPassthrough', 'VirtualSriovEthernetCard', 'VirtualDiskRawDiskMappingVer1BackingInfo'}, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            row = {'key': item.key, 'type': kind}
            if isinstance(item, self.vim.vm.device.VirtualDisk):
                backing = self.disk_backing(item)
                row['capacityKB'] = int(item.capacityInKB)
                if compute_only:
                    row['datastore'] = native_ref(backing.datastore, 'Datastore')
                    require(row['datastore'] in source_stores, 'VC_INVENTORY_INCOMPLETE')
            if isinstance(item, self.vim.vm.device.VirtualCdrom):
                backing = item.backing
                if type(backing) is self.vim.vm.device.VirtualCdrom.IsoBackingInfo:
                    require(backing.datastore is not None and identity(native_ref(backing.datastore), 'Datastore') in host_stores, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                else:
                    require(type(backing) in (self.vim.vm.device.VirtualCdrom.RemoteAtapiBackingInfo, self.vim.vm.device.VirtualCdrom.RemotePassthroughBackingInfo), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            if isinstance(item, self.vim.vm.device.VirtualEthernetCard):
                require(type(item.backing) is self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo and item.backing.network is not None, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                original_network=native_ref(item.backing.network,'Network')
                row['nicIdentityDigest']=nic_identity_digest(item)
                row['network']=by_nic.pop(item.key,original_network)
                network_name=self.device_network(host,row['network'])
                if row['network']!=original_network:
                    network_changes.append({'deviceKey':item.key,'network':row['network'],'name':network_name})
            topology.append(row)
        source_folder=native_ref(self.read(key,['parent'])['parent'],'Folder')
        folder=source_folder
        if target_dc!=source_dc or 'folder' in parameters:
            root=native_ref(self.read(target_dc,['vmFolder'])['vmFolder'],'Folder')
            folder=parameters.get('folder',root);identity(folder,'Folder');current=folder;seen=set()
            for _ in range(16):
                if current==root:break
                marker=identity(current);require(marker not in seen and current['objectType']=='Folder','VC_PERMISSION_DENIED');seen.add(marker)
                current=native_ref(self.read(current,['parent'])['parent'])
            else:require(False,'VC_PERMISSION_DENIED')
        if folder!=source_folder:
            require(mode != 'storage', 'VC_OPERATION_STATE_CONFLICT')
            self.privilege_entities([key, source_folder, folder], ['VirtualMachine.Inventory.Move'])
        require(not by_nic,'VC_OPERATION_INVALID')
        if not compute_only:
            home_already_there = datastore in source_stores and vmx.startswith('[' + store_name + '] ')
            require(not home_already_there or any(native_ref(item.backing.datastore, 'Datastore') != datastore
                    for item in devices if isinstance(item, self.vim.vm.device.VirtualDisk)), 'VC_OPERATION_STATE_CONFLICT')
        expected = {'cluster': cluster, 'pool': pool, 'folder': folder, 'sourcePathHash': hashlib.sha256(vmx.encode('utf-8')).hexdigest(),
                    'devices': [{'key': item.key, 'digest': self.device_digest(item)} for item in devices], 'topology': topology}
        if mode != 'storage':
            expected['sourceHost'] = source_host
            expected['poolChanges'] = pool != source_pool
        if compute_only:
            expected['sourceDatastores'] = sorted(source_stores, key=identity)
        else:
            expected['datastoreName'] = store_name
        if network_changes:expected['networkChanges']=sorted(network_changes,key=lambda item:item['deviceKey'])
        if live:
            boot=self.read(key,['runtime.bootTime'])['runtime.bootTime'];require(hasattr(boot,'isoformat'),'VC_INVENTORY_INCOMPLETE');expected['bootTime']=boot.isoformat()
        return expected, {'before': {'host': source_host}, 'mode': mode, 'sourceDatacenter':source_dc,'targetDatacenter':target_dc,
            'impact':'Live relocation preserves powered-on state and boot time; native vSphere validates vMotion, CPU and license compatibility. ' if live else 'Cold relocation preserves powered-off state; no implicit power-on. ',
            'placementImpact':'Same-vCenter enrolled destinations only. Cross-datacenter moves use the verified destination VM folder. Standard NIC network changes require exact device-key mappings; names alone are not matched. RelocateSpec has no native configuration CAS.'}

    def relocation_network_changes(self, intent):
        changes=[];devices={item.key:item for item in self.devices(intent['key'])}
        for mapping in intent['expected']['relocation'].get('networkChanges',[]):
            device=copy.copy(devices[mapping['deviceKey']])
            device.backing=self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo(deviceName=mapping['name'],network=self.obj(mapping['network']))
            changes.append(self.vim.vm.device.VirtualDeviceSpec(operation='edit',device=device))
        return changes

    def verify_relocation(self, record):
        parameters, expected = record['parameters'], record['expected']['relocation']
        props, host, cluster = self.scoped_vm(record['key'])
        values = self.read(record['key'], ['config.files.vmPathName', 'resourcePool', 'datastore'])
        devices = self.devices(record['key'])
        by_key = {item.key: item for item in devices}
        desired_power='poweredOn' if record['operation']=='vm.relocateLive' else 'poweredOff'
        valid = host == parameters['host'] and cluster == expected['cluster'] and native_ref(props['parent']) == expected['folder'] and str(props['runtime.powerState']) == desired_power and native_ref(values['resourcePool']) == expected['pool'] and len(devices) == len(expected['topology'])
        vmx = values['config.files.vmPathName']
        if not isinstance(vmx, str) or not vmx:
            return {'verified': False}
        datastores = [native_ref(item, 'Datastore') for item in values['datastore']]
        if 'sourceDatastores' in expected:
            valid = valid and hashlib.sha256(vmx.encode('utf-8')).hexdigest() == expected['sourcePathHash'] and sorted(datastores, key=identity) == expected['sourceDatastores']
        else:
            valid = valid and vmx.startswith('[' + expected['datastoreName'] + '] ') and parameters['datastore'] in datastores
        if 'bootTime' in expected:
            boot=self.read(record['key'],['runtime.bootTime'])['runtime.bootTime'];valid=valid and hasattr(boot,'isoformat') and boot.isoformat()==expected['bootTime']
        for original in expected['topology']:
            item = by_key.get(original['key'])
            valid = valid and item is not None and type(item)._wsdlName == original['type']
            if item is None: continue
            if 'capacityKB' in original:
                datastore = original.get('datastore', parameters.get('datastore'))
                valid = valid and item.capacityInKB == original['capacityKB'] and item.backing.datastore is not None and native_ref(item.backing.datastore) == datastore
            if 'network' in original:
                valid = valid and type(item.backing) is self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo and item.backing.network is not None and native_ref(item.backing.network) == original['network']
                if 'nicIdentityDigest' in original:valid=valid and nic_identity_digest(item)==original['nicIdentityDigest']
        return {'verified': valid}
