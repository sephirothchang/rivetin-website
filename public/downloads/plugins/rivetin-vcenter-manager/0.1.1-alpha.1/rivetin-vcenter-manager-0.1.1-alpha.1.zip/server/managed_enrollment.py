"""Add a host using its own credential and the selected endpoint evidence."""
import base64
import hashlib
import ipaddress
from urllib.parse import urlsplit

from .operation_ledger import require
from .resource_scope import identity
from .trusted_metadata import validate_context


class HostEnrollment:
    def enrollment_binding(self, binding, key):
        validate_context(binding, 'prepareOperation')
        entries = binding.get('operationContext', {}).get('credentialInputBindings', [])
        require(len(entries) == 1 and entries[0]['target'] == key, 'VC_OPERATION_CREDENTIAL_REQUIRED')
        item = entries[0]
        origin = urlsplit(item['endpoint']['origin'])
        try: address = str(ipaddress.ip_address(origin.hostname))
        except ValueError: require(False, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        require(origin.hostname == address, 'VC_OPERATION_BINDING_INVALID')
        encoded = item['targetEvidence']['leafDERBase64']
        thumbprint = None
        if encoded is not None:
            der = base64.b64decode(encoded, validate=True)
            thumbprint = ':'.join(f'{byte:02X}' for byte in hashlib.sha1(der).digest())
        return item, address, thumbprint

    def prepare_enrollment(self, binding, key, parameters):
        from .managed_executor import native_key, label
        require(identity(key,'ClusterComputeResource') in self.selected,'VC_PERMISSION_DENIED')
        require(set(parameters)=={'hostName','confirmHostEnrollment'} and parameters['confirmHostEnrollment'] is True)
        item, address, thumbprint = self.enrollment_binding(binding,key)
        require(parameters['hostName']==address,'VC_OPERATION_BINDING_INVALID')
        props=self.read(key,['name','host','resourcePool'],optional=('host',))
        hosts=[native_key(host) for host in props['host'] or []]
        require(len(hosts)<=2000 and len({identity(host,'HostSystem') for host in hosts})==len(hosts),'VC_INVENTORY_INCOMPLETE')
        self.privilege(key,['Host.Inventory.AddHostToCluster'])
        pool=native_key(props['resourcePool']);identity(pool,'ResourcePool')
        require(native_key(self.read(pool,['owner'])['owner'])==key,'VC_PERMISSION_DENIED')
        self.privilege(pool,['Resource.AssignVMToPool'])
        dc=self.datacenter(key);folder=native_key(self.read(dc,['vmFolder'])['vmFolder']);identity(folder,'Folder')
        require(native_key(self.read(folder,['parent'])['parent'])==dc,'VC_PERMISSION_DENIED')
        self.privilege(folder,['System.View'])
        expected={'hosts':hosts,'pool':pool,'vmFolder':folder,'hostName':address,'sslThumbprint':thumbprint,
            'credentialInputVersion':item['credentialInputVersion'],'targetEvidenceSHA256':item['targetEvidenceSHA256']}
        return expected,{'name':label(props['name'],120),'hostName':address,'sslThumbprint':thumbprint,'hostCertificateSHA256':item['targetEvidence']['leafSHA256'],
            'impact':'Adds and connects this host to the selected cluster with force=false. Existing host VMs are imported into the reviewed datacenter VM folder and cluster root pool. HA/DRS may reconfigure or migrate workloads. A host managed elsewhere is not taken over. No host removal or automatic retry.'}

    def invoke_enrollment(self,binding,intent):
        item,address,thumbprint=self.enrollment_binding(binding,intent['key'])
        expected=intent['expected']
        require(address==expected['hostName'] and thumbprint==expected['sslThumbprint'] and item['credentialInputVersion']==expected['credentialInputVersion'] and item['targetEvidenceSHA256']==expected['targetEvidenceSHA256'],'VC_OPERATION_BINDING_INVALID')
        secret=self.credential_inputs.get('hostEnrollment')
        require(isinstance(secret,dict) and set(secret)=={'username','password'},'VC_OPERATION_CREDENTIAL_REQUIRED')
        certificate = {'sslThumbprint': thumbprint} if thumbprint is not None else {}
        spec=self.vim.host.ConnectSpec(hostName=address,port=443,userName=secret['username'],password=secret['password'],force=False,vmFolder=self.obj(expected['vmFolder']),**certificate)
        return self.obj(intent['key']).AddHost_Task(spec=spec,asConnected=True,resourcePool=self.obj(expected['pool']))

    def verify_enrollment(self,binding,record):
        from .managed_executor import native_key
        item,address,thumbprint=self.enrollment_binding(binding,record['key'])
        expected=record['expected'];result=record.get('result') or {}
        require(result.get('nativeState')=='success','VC_OPERATION_POSTCHECK_PENDING')
        host=result.get('result');identity(host,'HostSystem')
        require(host not in expected['hosts'],'VC_OPERATION_POSTCHECK_PENDING')
        require(address==expected['hostName'] and thumbprint==expected['sslThumbprint'] and item['targetEvidenceSHA256']==expected['targetEvidenceSHA256'],'VC_OPERATION_BINDING_INVALID')
        props=self.read(host,['parent','runtime.connectionState'])
        hosts=self.read(record['key'],['host'])['host']
        valid=native_key(props['parent'])==record['key'] and any(native_key(value)==host for value in hosts) and str(props['runtime.connectionState'])=='connected'
        return {'verified':valid,'createdKey':host}
