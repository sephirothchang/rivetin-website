"""Typed native VM/cluster mutations with fresh scope, state and privilege checks."""
import copy
import time

from .durable_operations import NativeRejected
from .operation_ledger import canonical, require
from .profiles import AdapterError
from .resource_scope import identity
from .vmomi_bridge import create_stub
from .guest_reboot import GuestReboot, same_boot, reboot_verified
from .host_performance import HostPerformance
from .advanced_hardware import AdvancedHardware
from .iso_library import IsoLibraryOperations
from .managed_host import HOST_OPERATIONS, HostOperations
from .managed_devices import DEVICE_OPERATIONS, DeviceOperations
from .managed_hardware import HardwareOperations
from .managed_lifecycle import LIFECYCLE_OPERATIONS, LifecycleOperations
from .managed_groups import GROUP_OPERATIONS, GroupOperations
from .managed_network import NETWORK_OPERATIONS, NetworkOperations
from .managed_alarms import ALARM_OPERATIONS, AlarmOperations
from .managed_cluster_creation import ClusterCreation
from .trusted_metadata import AuthorizationRoots, roots_request
from .managed_enrollment import HostEnrollment
from .managed_snapshots import SnapshotOperations, SNAPSHOT_OPERATIONS

CLUSTER_FIELDS = {
    'haEnabled': ('dasConfig.enabled', bool),
    'drsEnabled': ('drsConfig.enabled', bool),
    'haAdmissionControlEnabled': ('dasConfig.admissionControlEnabled', bool),
    'haHostMonitoring': ('dasConfig.hostMonitoring', ('enabled', 'disabled')),
    'haVmMonitoring': ('dasConfig.vmMonitoring', ('vmMonitoringDisabled', 'vmMonitoringOnly', 'vmAndAppMonitoring')),
    'drsAutomationLevel': ('drsConfig.defaultVmBehavior', ('manual', 'partiallyAutomated', 'fullyAutomated')),
    'drsMigrationThreshold': ('drsConfig.vmotionRate', (1, 5)),
    'drsVmOverridesEnabled': ('drsConfig.enableVmBehaviorOverrides', bool),
}


def valid_cluster_field(name, value):
    rule = CLUSTER_FIELDS[name][1]
    if rule is bool:
        return type(value) is bool
    if type(rule[0]) is int:
        return type(value) is int and rule[0] <= value <= rule[1]
    return isinstance(value, str) and value in rule

OPERATIONS = HOST_OPERATIONS | DEVICE_OPERATIONS | LIFECYCLE_OPERATIONS | GROUP_OPERATIONS | NETWORK_OPERATIONS | ALARM_OPERATIONS | SNAPSHOT_OPERATIONS | {
    'cluster.create':('Datacenter',None),
    'host.add':('ClusterComputeResource',None),
    'vm.create': ('ClusterComputeResource', None),
    'vm.provision': ('ClusterComputeResource', None),
    'vm.powerOn': ('VirtualMachine', 'VirtualMachine.Interact.PowerOn'),
    'vm.powerOff': ('VirtualMachine', 'VirtualMachine.Interact.PowerOff'),
    'vm.suspend': ('VirtualMachine', 'VirtualMachine.Interact.Suspend'),
    'vm.reset': ('VirtualMachine', 'VirtualMachine.Interact.Reset'),
    'vm.shutdownGuest': ('VirtualMachine', 'VirtualMachine.Interact.PowerOff'),
    'vm.rebootGuest': ('VirtualMachine', 'VirtualMachine.Interact.Reset'),
    'vm.mountTools': ('VirtualMachine', 'VirtualMachine.Interact.ToolsInstall'),
    'vm.configure': ('VirtualMachine', None),
    'vm.relocate': ('VirtualMachine', 'Resource.ColdMigrate'),
    'vm.relocateLive': ('VirtualMachine', 'Resource.ColdMigrate'),
    'vm.clone': ('VirtualMachine', 'VirtualMachine.Provisioning.Clone'),
    'vm.cloneTemplate': ('VirtualMachine', 'VirtualMachine.Provisioning.CreateTemplateFromVM'),
    'vm.delete': ('VirtualMachine', 'VirtualMachine.Inventory.Delete'),
    'template.mark': ('VirtualMachine', 'VirtualMachine.Provisioning.MarkAsTemplate'),
    'template.toVM': ('VirtualMachine', 'VirtualMachine.Provisioning.MarkAsVM'),
    'template.deploy': ('VirtualMachine', 'VirtualMachine.Provisioning.DeployTemplate'),
    'template.delete': ('VirtualMachine', 'VirtualMachine.Inventory.Delete'),
    'template.rename': ('VirtualMachine', 'VirtualMachine.Config.Rename'),
    'cluster.configure': ('ClusterComputeResource', 'Host.Inventory.EditCluster')
}
DEFERRED_OPERATIONS = frozenset({'host.add',
                                'network.setUplinks', 'alarm.acknowledge', 'alarm.resetGreen', 'vmk.create', 'vmk.edit', 'vmk.delete'})
ACTIVE_OPERATIONS = {name: definition for name, definition in OPERATIONS.items() if name not in DEFERRED_OPERATIONS}


def native_key(value):
    require(value is not None and hasattr(type(value), '_wsdlName') and isinstance(getattr(value, '_moId', None), str), 'VC_REFERENCE_INVALID')
    result = {'objectType': type(value)._wsdlName, 'objectId': value._moId}
    identity(result)
    return result


def label(value, maximum=80):
    require(isinstance(value, str) and 0 < len(value) <= maximum and not any(ord(char) < 32 for char in value))
    return value


class ManagedExecutor(HostOperations, DeviceOperations, HardwareOperations, LifecycleOperations, GroupOperations, NetworkOperations, AlarmOperations, ClusterCreation, AuthorizationRoots, HostEnrollment, SnapshotOperations, GuestReboot, HostPerformance, AdvancedHardware, IsoLibraryOperations):
    def __init__(self, code_directory, transport, api_version, instance_id, username, selected, revision, *, seconds=15,parent_roots=(),credential_inputs=None):
        self._native_deadline = time.monotonic() + seconds
        self.sdk, self.stub = create_stub(code_directory, transport, api_version, self._native_deadline)
        self.vim, self.vmodl = self.sdk.vim, self.sdk.vmodl
        self.selected = {identity(key, 'ClusterComputeResource') for key in selected}
        require(bool(self.selected) and len(self.selected) == len(selected), 'VC_PERMISSION_DENIED')
        self.instance_id, self.username, self.revision = instance_id, label(username, 4096), revision
        # Only authenticated FW context (or isolated native fixtures) supplies
        # this projection. Cluster enrollment never implies parent authority.
        require(isinstance(parent_roots, (list, tuple)), 'VC_PERMISSION_DENIED')
        self.parent_roots = roots_request(list(parent_roots))
        self.credential_inputs = credential_inputs or {}
        self.service = self.vim.ServiceInstance('ServiceInstance', self.stub).RetrieveContent()
        require(self.service.about.apiType == 'VirtualCenter' and self.service.about.instanceUuid == instance_id, 'VC_INSTANCE_IDENTITY_REQUIRED')
        self.cache = {}
        self._relocation_revalidated = None

    def obj(self, key):
        kind, identifier = identity(key)
        managers = {'VirtualMachineSnapshot': self.vim.vm.Snapshot, 'HostNetworkSystem': self.vim.host.NetworkSystem, 'HostDatastoreSystem': self.vim.host.DatastoreSystem, 'HostVirtualNicManager': self.vim.host.VirtualNicManager,
                    'Alarm':self.vim.alarm.Alarm,'AlarmManager':self.vim.alarm.AlarmManager}
        if kind in managers:
            return managers[kind](identifier, self.stub)
        require(kind in {'VirtualMachine', 'VirtualMachineSnapshot', 'ClusterComputeResource', 'HostSystem', 'Folder', 'Datacenter', 'ResourcePool', 'Datastore', 'Network', 'DistributedVirtualPortgroup', 'Task'}, 'VC_REFERENCE_INVALID')
        return getattr(self.vim, kind)(identifier, self.stub)

    def read(self, key, paths, *, absent=False, optional=()):
        object_key = identity(key)
        cached = self.cache.get(object_key, {})
        missing = [path for path in paths if path not in cached]
        if missing:
            pc = self.vmodl.query.PropertyCollector
            config_paths=[path for path in missing if key['objectType']=='ClusterComputeResource' and path.startswith('configurationEx.')]
            allowed_config={'configurationEx.group','configurationEx.rule'}|{'configurationEx.'+fields[0] for fields in CLUSTER_FIELDS.values()}
            require(set(config_paths)<=allowed_config,'VC_OPERATION_UNSUPPORTED')
            requested=[path for path in missing if path not in config_paths]
            if config_paths and 'configurationEx' not in requested:requested.append('configurationEx')
            spec = pc.FilterSpec(propSet=[pc.PropertySpec(type=type(self.obj(key)), pathSet=requested, all=False)], objectSet=[pc.ObjectSpec(obj=self.obj(key), skip=False)])
            result = self.service.propertyCollector.RetrievePropertiesEx(specSet=[spec], options=pc.RetrieveOptions(maxObjects=2))
            # This exact-object read must fit one page. Never traverse a broad root.
            if result.token:
                self.service.propertyCollector.CancelRetrievePropertiesEx(token=result.token)
                raise AdapterError('VC_INVENTORY_INCOMPLETE')
            rows = list(result.objects or [])
            if not rows and absent:
                return None
            require(len(rows) == 1 and native_key(rows[0].obj) == key and not rows[0].missingSet, 'VC_INVENTORY_INCOMPLETE')
            props = {}
            for prop in rows[0].propSet or []:
                require(prop.name in requested and prop.name not in props, 'VC_RESPONSE_INVALID')
                props[prop.name] = prop.val
            if config_paths:
                config=props.get('configurationEx')
                require(isinstance(config,self.vim.cluster.ConfigInfoEx),'VC_INVENTORY_INCOMPLETE')
                for path in config_paths:
                    value=config
                    for name in path.split('.')[1:]:
                        if value is None:break
                        require(isinstance(value,self.sdk.VmomiSupport.DataObject),'VC_INVENTORY_INCOMPLETE')
                        value=getattr(value,name)
                    if value is not None:props[path]=value
                if 'configurationEx' not in missing:props.pop('configurationEx')
            require(set(missing) - set(props) <= set(optional), 'VC_INVENTORY_INCOMPLETE')
            props.update({path: None for path in missing if path not in props})
            cached = cached | props
            self.cache[object_key] = cached
        return {path: cached[path] for path in paths}

    def cluster(self, host):
        require(identity(host, 'HostSystem'), 'VC_REFERENCE_INVALID')
        parent = native_key(self.read(host, ['parent'])['parent'])
        require(identity(parent, 'ClusterComputeResource') in self.selected, 'VC_PERMISSION_DENIED')
        return parent

    def scoped_vm(self, key):
        props = self.read(key, ['name', 'runtime.host', 'runtime.powerState', 'config.template', 'config.changeVersion', 'parent'])
        require(type(props['config.template']) is bool and props['runtime.powerState'] in ('poweredOn', 'poweredOff', 'suspended'), 'VC_INVENTORY_INCOMPLETE')
        host = native_key(props['runtime.host'])
        cluster = self.cluster(host)
        return props, host, cluster

    def privilege(self, key, privileges):
        self.privilege_entities([key], privileges)

    def privilege_entities(self, keys, privileges):
        privileges = sorted(set(privileges))
        result = self.service.authorizationManager.HasUserPrivilegeOnEntities(
            entities=[self.obj(key) for key in keys], userName=self.username, privId=privileges)
        require(len(result) == len(keys) and {identity(native_key(row.entity)) for row in result} == {identity(key) for key in keys}, 'VC_PERMISSION_DENIED')
        for row in result:
            answers = {item.privId: item.isGranted for item in row.privAvailability}
            require(len(answers) == len(row.privAvailability) and all(answers.get(item) is True for item in privileges), 'VC_PERMISSION_DENIED')

    def datacenter(self, cluster):
        current, seen = cluster, set()
        for _ in range(16):
            marker = identity(current)
            require(marker not in seen, 'VC_INVENTORY_INCOMPLETE'); seen.add(marker)
            if current['objectType'] == 'Datacenter':
                return current
            current = native_key(self.read(current, ['parent'])['parent'])
            require(current['objectType'] in {'Folder', 'Datacenter'}, 'VC_INVENTORY_INCOMPLETE')
        raise AdapterError('VC_INVENTORY_INCOMPLETE')

    def placement(self, parameters, source_cluster, *, create=False, template=False):
        host, datastore = parameters.get('host'), parameters.get('datastore')
        identity(host, 'HostSystem'); identity(datastore, 'Datastore')
        cluster = self.cluster(host)
        links = self.read(host, ['datastore'])['datastore']
        require(any(native_key(item) == datastore for item in links), 'VC_PERMISSION_DENIED')
        require(self.read(datastore, ['summary.accessible'])['summary.accessible'] is True, 'VC_OPERATION_STATE_CONFLICT')
        pool = native_key(self.read(cluster, ['resourcePool'])['resourcePool'])
        identity(pool, 'ResourcePool')
        dc = self.datacenter(cluster)
        root = native_key(self.read(dc, ['vmFolder'])['vmFolder'])
        folder = parameters.get('folder', root)
        identity(folder, 'Folder')
        current, seen = folder, set()
        for _ in range(16):
            if current == root:
                break
            marker = identity(current)
            require(marker not in seen and current['objectType'] == 'Folder', 'VC_PERMISSION_DENIED'); seen.add(marker)
            current = native_key(self.read(current, ['parent'])['parent'])
        else:
            raise AdapterError('VC_PERMISSION_DENIED')
        if create:
            children = self.read(folder, ['childType'])['childType']
            require('VirtualMachine' in children or 'vim.VirtualMachine' in children, 'VC_OPERATION_STATE_CONFLICT')
        self.privilege(folder, ['VirtualMachine.Inventory.Create' if create else 'VirtualMachine.Inventory.CreateFromExisting'])
        if not template:
            self.privilege(pool, ['Resource.AssignVMToPool'])
        self.privilege(datastore, ['Datastore.AllocateSpace'])
        return {'host': host, 'datastore': datastore, **({} if template else {'pool': pool}), 'folder': folder, 'cluster': cluster}

    def prepare(self, binding, request):
        require(isinstance(request, dict) and set(request) == {'connectionId', 'instanceId', 'key', 'operation', 'parameters', 'scopeRevision'})
        require(request['connectionId'] == binding['connectionId'] and request['instanceId'] == binding['instanceId'] == self.instance_id, 'VC_OPERATION_SCOPE_CHANGED')
        require(request['scopeRevision'] == self.revision, 'VC_OPERATION_SCOPE_CHANGED')
        key, operation, parameters = request['key'], request['operation'], request['parameters']
        require(operation in ACTIVE_OPERATIONS, 'VC_OPERATION_UNSUPPORTED')
        require(isinstance(parameters, dict))
        kinds=OPERATIONS[operation][0]
        if isinstance(kinds,tuple):
            require(identity(key)[0] in kinds,'VC_REFERENCE_INVALID')
        else:
            identity(key,kinds)
        expected, observation = {}, {}
        if operation=='cluster.create':
            expected,observation=self.prepare_cluster_creation(key,parameters)
        elif operation=='host.add':
            expected,observation=self.prepare_enrollment(binding,key,parameters)
        elif operation in ALARM_OPERATIONS:
            expected,observation=self.prepare_alarm(key,operation,parameters)
        elif operation in NETWORK_OPERATIONS:
            expected, observation = self.prepare_network(key, operation, parameters)
        elif operation in GROUP_OPERATIONS:
            expected, observation = self.prepare_group(key, operation, parameters)
        elif operation in LIFECYCLE_OPERATIONS:
            expected, observation = self.prepare_lifecycle(key, operation, parameters)
        elif operation in HOST_OPERATIONS:
            expected, observation = self.prepare_host(key, operation, parameters)
        elif operation in {'vm.create', 'vm.provision'}:
            require(identity(key) in self.selected, 'VC_PERMISSION_DENIED')
            required = {'name', 'numCPUs', 'memoryMB', 'guestId', 'host', 'datastore'}
            required |= {'createEmpty'} if operation == 'vm.create' else {'capacityGB', 'diskId', 'network', 'startConnected', 'firmware', 'confirmProvision'}
            require(set(parameters) in (required, required | {'folder'}))
            require(parameters.get('createEmpty') is True if operation == 'vm.create' else parameters.get('confirmProvision') is True)
            label(parameters['name'])
            require(type(parameters['numCPUs']) is int and 1 <= parameters['numCPUs'] <= 128)
            require(type(parameters['memoryMB']) is int and 128 <= parameters['memoryMB'] <= 1048576)
            require(parameters['guestId'] in {'otherGuest64', 'otherLinux64Guest'})
            placement = self.placement(parameters, key, create=True)
            require(placement['cluster'] == key, 'VC_PERMISSION_DENIED')
            datastore_name = label(self.read(placement['datastore'], ['name'])['name'], 80)
            require(not any(char in datastore_name for char in '[]/\\'), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            expected = {'placement': placement, 'datastoreName': datastore_name}
            if operation == 'vm.provision':
                expected['initialDevices'] = self.prepare_initial_devices(parameters, placement, datastore_name)
            observation = {'name': parameters['name'], 'cluster': key, 'host': placement['host'],
                           'impact': 'Creates a powered-off empty VM and configuration files; no disk, NIC, OS or implicit power-on.' if operation == 'vm.create' else 'Creates one powered-off VM with a new thin disk, LSI SAS controller and standard VMXNET3 adapter in one native Task. No OS installation, existing disk attachment or implicit power-on.',
                           **({'networkName': expected['initialDevices']['networkName']} if operation == 'vm.provision' else {})}
        elif operation == 'cluster.configure':
            require(identity(key) in self.selected, 'VC_PERMISSION_DENIED')
            require(parameters and set(parameters) <= set(CLUSTER_FIELDS) and all(valid_cluster_field(name, value) for name, value in parameters.items()))
            names = {name: 'configurationEx.' + fields[0] for name, fields in CLUSTER_FIELDS.items()}
            props = self.read(key, ['name'] + [names[name] for name in parameters])
            expected = {name: props[names[name]] for name in parameters}
            expected = {name: str(value) if CLUSTER_FIELDS[name][1] is not bool and isinstance(value, str) else value for name, value in expected.items()}
            require(all(valid_cluster_field(name, value) for name, value in expected.items()), 'VC_INVENTORY_INCOMPLETE')
            observation = {'name': label(props['name'], 120), 'before': expected, 'impact': 'Modify only explicitly selected HA/DRS settings. Admission, host/VM monitoring and automated DRS can affect failover or trigger migrations. External writers have no native CAS protection.'}
        else:
            props, host, cluster = self.scoped_vm(key)
            template, power = props['config.template'], str(props['runtime.powerState'])
            expected = {'name': label(props['name'], 120), 'host': host, 'cluster': cluster, 'powerState': power, 'template': template, 'changeVersion': label(props['config.changeVersion'], 128)}
            observation = {'name': label(props['name'], 120), 'cluster': cluster, 'host': host}
            wants_template = operation in {'template.toVM', 'template.deploy', 'template.delete', 'template.rename'}
            require(template is wants_template, 'VC_OPERATION_STATE_CONFLICT')
            if operation in SNAPSHOT_OPERATIONS:
                extra, detail = self.prepare_snapshot(key, operation, parameters, power)
                expected.update(extra); observation.update(detail)
            elif operation == 'vm.mountTools':
                require(parameters == {'confirmToolsMedia': True} and power == 'poweredOn', 'VC_OPERATION_STATE_CONFLICT')
                state = self.read(key, ['runtime.toolsInstallerMounted', 'config.guestId'])
                require(state['runtime.toolsInstallerMounted'] is False, 'VC_OPERATION_STATE_CONFLICT')
                label(state['config.guestId'], 80)
                optical = [device for device in self.devices(key) if isinstance(device, self.vim.vm.device.VirtualCdrom)]
                require(bool(optical), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                # Native selection must not overwrite any existing ISO/media.
                for device in optical:
                    require(type(device.backing) in (self.vim.vm.device.VirtualCdrom.RemoteAtapiBackingInfo, self.vim.vm.device.VirtualCdrom.RemotePassthroughBackingInfo) and not device.backing.deviceName and device.connectable is not None and device.connectable.connected is False and device.connectable.startConnected is False, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                expected['toolsMedia'] = {'guestId': state['config.guestId'], 'drives': [{'key': device.key, 'digest': self.device_digest(device)} for device in optical]}
                observation['impact'] = 'Mounts VMware Tools installation media in an empty virtual CD/DVD drive. Installation inside the guest remains manual.'
            elif operation in {'vm.powerOn', 'vm.powerOff', 'vm.suspend', 'vm.reset', 'vm.shutdownGuest', 'vm.rebootGuest', 'template.mark'}:
                require(not parameters)
                allowed = {'poweredOff', 'suspended'} if operation == 'vm.powerOn' else {'poweredOff'} if operation == 'template.mark' else {'poweredOn'}
                require(power in allowed, 'VC_OPERATION_STATE_CONFLICT')
                if operation in {'vm.shutdownGuest', 'vm.rebootGuest'}:
                    tools = self.read(key, ['guest.toolsRunningStatus'])['guest.toolsRunningStatus']
                    require(tools == 'guestToolsRunning', 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                    if operation == 'vm.rebootGuest':
                        expected['guestReboot'] = self.guest_reboot_sample(key, baseline=True)
            elif operation in {'vm.relocate','vm.relocateLive'}:
                live=operation=='vm.relocateLive'
                require(power == ('poweredOn' if live else 'poweredOff'), 'VC_OPERATION_STATE_CONFLICT')
                if live:self.privilege(key,['Resource.HotMigrate'])
                expected['relocation'], detail = self.prepare_relocation(key, parameters, host, cluster,live=live)
                observation.update(detail)
            elif operation in DEVICE_OPERATIONS:
                require(power == 'poweredOff', 'VC_OPERATION_STATE_CONFLICT')
                expected['device'], detail = self.prepare_device(key, operation, parameters, host)
                observation.update(detail)
            elif operation == 'vm.configure':
                expected['hardware'], detail = self.prepare_hardware(key, parameters, host, power)
                observation.update(detail)
            elif operation == 'template.rename':
                require(set(parameters) == {'name'} and power == 'poweredOff', 'VC_OPERATION_STATE_CONFLICT')
                label(parameters['name'])
                require(parameters['name'] != expected['name'], 'VC_OPERATION_STATE_CONFLICT')
                observation['before'] = {'name': expected['name']}
                observation['impact'] = 'Renames this traditional template without converting or deploying it; native Rename has no configuration CAS.'
            elif operation in {'vm.clone', 'vm.cloneTemplate', 'template.deploy'}:
                require(set(parameters) in ({'name', 'host', 'datastore'}, {'name', 'host', 'datastore', 'folder'}))
                label(parameters['name'])
                expected['placement'] = self.placement(parameters, cluster, template=operation == 'vm.cloneTemplate')
                observation['impact'] = 'Creates a separate traditional template; does not convert or modify the source VM. Templates have no resource-pool assignment.' if operation == 'vm.cloneTemplate' else 'Creates a powered-off VM; no implicit power-on or source modification.'
            elif operation == 'template.toVM':
                require(set(parameters) == {'host'})
                target_cluster = self.cluster(parameters['host'])
                pool = native_key(self.read(target_cluster, ['resourcePool'])['resourcePool'])
                self.privilege(pool, ['Resource.AssignVMToPool'])
                expected['placement'] = {'host': parameters['host'], 'pool': pool, 'cluster': target_cluster}
            elif operation in {'vm.delete', 'template.delete'}:
                require(parameters == {'deleteDisks': True} and power == 'poweredOff', 'VC_OPERATION_STATE_CONFLICT')
                observation['impact'] = 'Permanently destroys the remote VM/template and its associated virtual disks; this is not unenrollment.'
        if OPERATIONS[operation][1]:
            self.privilege(key, [OPERATIONS[operation][1]])
        intent = {key: copy.deepcopy(request[key]) for key in ('connectionId', 'instanceId', 'key', 'operation', 'parameters', 'scopeRevision')}
        intent['expected'] = expected
        canonical(intent); canonical(observation)
        return intent, observation

    def revalidate(self, binding, intent, observation):
        self._relocation_revalidated = None
        self.cache.clear()
        request = {key: value for key, value in intent.items() if key != 'expected'}
        current, _ = self.prepare(binding, request)
        if intent['operation'] == 'vm.rebootGuest':
            before, after = intent['expected'].get('guestReboot'), current['expected']['guestReboot']
            require(before is not None and same_boot(before, after), 'VC_OPERATION_STATE_CONFLICT')
            current['expected']['guestReboot'] = copy.deepcopy(before)
        require(canonical(current) == canonical(intent), 'VC_OPERATION_STATE_CONFLICT')
        if intent['operation'] in {'vm.relocate', 'vm.relocateLive'}:
            self._relocation_revalidated = canonical(intent)

    def _refresh_relocation_reads(self):
        # Re-read every exact object/property from the full pre-accept check in
        # one bounded PC request. prepare still rechecks all native privileges.
        previous = self.cache
        require(0 < len(previous) <= 200 and all(0 < len(props) <= 64 for props in previous.values()), 'VC_INVENTORY_LIMIT')
        pc = self.vmodl.query.PropertyCollector
        specs = [pc.FilterSpec(propSet=[pc.PropertySpec(type=type(self.obj({'objectType': kind, 'objectId': identifier})), pathSet=sorted(props), all=False)],
            objectSet=[pc.ObjectSpec(obj=self.obj({'objectType': kind, 'objectId': identifier}), skip=False)]) for (kind, identifier), props in previous.items()]
        result = self.service.propertyCollector.RetrievePropertiesEx(specSet=specs, options=pc.RetrieveOptions(maxObjects=200))
        if result.token:
            self.service.propertyCollector.CancelRetrievePropertiesEx(token=result.token)
            raise AdapterError('VC_INVENTORY_INCOMPLETE')
        require(len(result.objects) == len(previous), 'VC_INVENTORY_INCOMPLETE')
        fresh = {}
        for row in result.objects:
            marker = identity(native_key(row.obj))
            require(marker in previous and marker not in fresh and not row.missingSet, 'VC_INVENTORY_INCOMPLETE')
            values = {}
            for prop in row.propSet or []:
                require(prop.name in previous[marker] and prop.name not in values, 'VC_RESPONSE_INVALID')
                values[prop.name] = prop.val
            require(all(name in values or value is None for name, value in previous[marker].items()), 'VC_INVENTORY_INCOMPLETE')
            fresh[marker] = {name: values.get(name) for name in previous[marker]}
        self.cache = fresh

    def _recheck_relocation(self, binding, intent):
        validated = self._relocation_revalidated == canonical(intent)
        self._relocation_revalidated = None
        try:
            if validated:
                self._refresh_relocation_reads()
                current, _ = self.prepare(binding, {key: value for key, value in intent.items() if key != 'expected'})
                require(canonical(current) == canonical(intent), 'VC_OPERATION_STATE_CONFLICT')
            else:
                self.revalidate(binding, intent, {})
        except AdapterError as error:
            raise NativeRejected(error.code) from None
        finally:
            self._relocation_revalidated = None

    def read_events(self, key):
        kind = identity(key)[0]
        require(kind in {'ClusterComputeResource', 'HostSystem', 'VirtualMachine'}, 'VC_REFERENCE_INVALID')
        if kind == 'ClusterComputeResource':
            require(identity(key) in self.selected, 'VC_PERMISSION_DENIED')
        elif kind == 'HostSystem':
            self.cluster(key)
        else:
            self.scoped_vm(key)
        self.privilege(key, ['System.View'])
        spec = self.vim.event.EventFilterSpec(
            entity=self.vim.event.EventFilterSpec.ByEntity(entity=self.obj(key), recursion='self'),
            maxCount=50, disableFullMessage=False)
        collector, owned_collector, primary_error = None, None, None
        try:
            collector = self.service.eventManager.CreateCollectorForEvents(filter=spec)
            def collector_id(value):
                require(type(value) is self.vim.event.EventHistoryCollector and value._stub is self.stub, 'VC_REFERENCE_INVALID')
                identifier = value._moId
                require(isinstance(identifier, str) and 0 < len(identifier) <= 256 and not any(ord(c) < 32 or ord(c) == 127 for c in identifier), 'VC_REFERENCE_INVALID')
                return identifier
            identifier = collector_id(collector)
            owned_collector = collector
            # latestPage is the recent window; QueryEvents(maxCount) only caps a subset.
            pc = self.vmodl.query.PropertyCollector
            request = pc.FilterSpec(propSet=[pc.PropertySpec(type=self.vim.event.EventHistoryCollector, pathSet=['latestPage'], all=False)],
                                    objectSet=[pc.ObjectSpec(obj=collector, skip=False)])
            result = self.service.propertyCollector.RetrievePropertiesEx(specSet=[request], options=pc.RetrieveOptions(maxObjects=1))
            if result.token:
                self.service.propertyCollector.CancelRetrievePropertiesEx(token=result.token)
                raise AdapterError('VC_RESPONSE_INVALID')
            require(len(result.objects) == 1 and collector_id(result.objects[0].obj) == identifier and not result.objects[0].missingSet, 'VC_RESPONSE_INVALID')
            props = result.objects[0].propSet
            require(len(props) == 1 and props[0].name == 'latestPage', 'VC_RESPONSE_INVALID')
            events = props[0].val
        except BaseException as error:
            primary_error = error
            raise
        finally:
            if owned_collector is not None:
                try:
                    owned_collector.DestroyCollector()
                except BaseException:
                    if primary_error is None: raise
        require(isinstance(events, (list, tuple)) and len(events) <= 50, 'VC_RESPONSE_INVALID')
        rows = []
        for event in events:
            require(type(event.key) is int and hasattr(event.createdTime, 'isoformat'), 'VC_RESPONSE_INVALID')
            def bounded_text(value, maximum):
                require(isinstance(value, str), 'VC_RESPONSE_INVALID')
                return ''.join(c for c in value if ord(c) >= 32 and ord(c) != 127)[:maximum]
            rows.append({'key': event.key, 'createdTime': event.createdTime.isoformat(),
                         'type': bounded_text(type(event)._wsdlName, 128),
                         'userName': bounded_text(event.userName or '', 128),
                         'message': bounded_text(event.fullFormattedMessage or '', 2048)})
        require(len({row['key'] for row in rows}) == len(rows), 'VC_RESPONSE_INVALID')
        return sorted(rows, key=lambda row: (row['createdTime'], row['key']), reverse=True)

    def invoke(self, binding, intent):
        require(intent['operation'] in ACTIVE_OPERATIONS, 'VC_OPERATION_UNSUPPORTED')
        operation, parameters, target = intent['operation'], intent['parameters'], self.obj(intent['key'])
        try:
            if operation in SNAPSHOT_OPERATIONS:
                if operation == 'vm.snapshot.create':
                    try:
                        self.revalidate(binding, intent, {})
                    except AdapterError as error:
                        raise NativeRejected(error.code) from None
                result = self.invoke_snapshot(intent)
            elif operation=='cluster.create':
                result=self.invoke_cluster_creation(intent)
            elif operation=='host.add':
                result=self.invoke_enrollment(binding,intent)
            elif operation in ALARM_OPERATIONS:
                result=self.invoke_alarm(intent)
            elif operation in NETWORK_OPERATIONS:
                result = self.invoke_network(intent)
            elif operation in GROUP_OPERATIONS:
                result = self.invoke_group(intent)
            elif operation in LIFECYCLE_OPERATIONS:
                result = self.invoke_lifecycle(intent, binding)
            elif operation in HOST_OPERATIONS:
                result = self.invoke_host(intent)
            elif operation in {'vm.create', 'vm.provision'}:
                placement = intent['expected']['placement']
                config = self.vim.vm.ConfigSpec(name=parameters['name'], numCPUs=parameters['numCPUs'], memoryMB=parameters['memoryMB'], guestId=parameters['guestId'],
                                                files=self.vim.vm.FileInfo(vmPathName='[' + intent['expected']['datastoreName'] + ']'))
                if operation == 'vm.provision':
                    config.firmware = parameters['firmware']
                    config.deviceChange = self.initial_device_changes(parameters, intent['expected']['initialDevices'])
                result = self.obj(placement['folder']).CreateVM_Task(config=config, pool=self.obj(placement['pool']), host=self.obj(placement['host']))
            elif operation in {'vm.relocate','vm.relocateLive'}:
                placement = intent['expected']['relocation']
                # RelocateSpec has no changeVersion/CAS or power-state argument.
                # Recheck immediately; concurrent external writers remain a limit.
                self._recheck_relocation(binding, intent)
                changes=self.relocation_network_changes(intent)
                spec = self.vim.vm.RelocateSpec(host=self.obj(parameters['host']), folder=self.obj(placement['folder']))
                if placement.get('poolChanges'):
                    spec.pool = self.obj(placement['pool'])
                if 'datastore' in parameters:
                    spec.datastore = self.obj(parameters['datastore'])
                else:
                    spec.disk = [self.vim.vm.RelocateSpec.DiskLocator(diskId=disk['key'], datastore=self.obj(disk['datastore']))
                                 for disk in placement['topology'] if 'datastore' in disk]
                if changes:
                    spec.deviceChange = changes
                result = target.RelocateVM_Task(spec=spec, priority='defaultPriority')
            elif operation in DEVICE_OPERATIONS:
                changes = self.device_changes(intent['key'], operation, parameters, intent['expected']['device'])
                result = target.ReconfigVM_Task(spec=self.vim.vm.ConfigSpec(changeVersion=intent['expected']['changeVersion'], deviceChange=changes))
            elif operation == 'vm.configure':
                if intent['expected'].get('hardware', {}).get('libraryMount'):
                    return self.invoke_library_mount(intent)
                result = target.ReconfigVM_Task(spec=self.hardware_spec(intent))
            elif operation == 'template.rename':
                result = target.Rename_Task(newName=parameters['name'])
            elif operation in {'vm.clone', 'vm.cloneTemplate', 'template.deploy'}:
                placement = intent['expected']['placement']
                relocate = self.vim.vm.RelocateSpec(host=self.obj(placement['host']), datastore=self.obj(placement['datastore']), **({'pool': self.obj(placement['pool'])} if 'pool' in placement else {}))
                result = target.CloneVM_Task(folder=self.obj(placement['folder']), name=parameters['name'], spec=self.vim.vm.CloneSpec(location=relocate, powerOn=False, template=operation == 'vm.cloneTemplate'))
            elif operation == 'cluster.configure':
                fields = {}
                for group, kind in [('dasConfig', self.vim.cluster.DasConfigInfo), ('drsConfig', self.vim.cluster.DrsConfigInfo)]:
                    changes = {CLUSTER_FIELDS[name][0].split('.')[1]: value for name, value in parameters.items() if CLUSTER_FIELDS[name][0].startswith(group + '.')}
                    if changes:
                        fields[group] = kind(**changes)
                result = target.ReconfigureComputeResource_Task(spec=self.vim.cluster.ConfigSpecEx(**fields), modify=True)
            elif operation == 'template.toVM':
                placement = intent['expected']['placement']
                result = target.MarkAsVirtualMachine(pool=self.obj(placement['pool']), host=self.obj(placement['host']))
            else:
                methods = {'vm.powerOn': 'PowerOnVM_Task', 'vm.powerOff': 'PowerOffVM_Task', 'vm.suspend': 'SuspendVM_Task', 'vm.reset': 'ResetVM_Task',
                           'vm.mountTools': 'MountToolsInstaller',
                           'vm.shutdownGuest': 'ShutdownGuest', 'vm.rebootGuest': 'RebootGuest', 'template.mark': 'MarkAsTemplate', 'vm.delete': 'Destroy_Task', 'template.delete': 'Destroy_Task'}
                result = getattr(target, methods[operation])()
            if isinstance(result, self.vim.Task):
                return {'task': native_key(result)}
            if isinstance(result, self.vim.Datastore):
                return {'result': native_key(result)}
            if operation=='cluster.create' and isinstance(result,self.vim.ClusterComputeResource):
                return {'result':native_key(result)}
            if operation == 'vmk.create' and isinstance(result, str):
                from .managed_network import vmk_device
                return {'result': {'device': vmk_device(result)}}
            require(result is None, 'VC_OPERATION_RESPONSE_INVALID')
            return {'result': None}
        except (self.vim.fault.NoPermission, self.vim.fault.InvalidPowerState, self.vmodl.fault.InvalidArgument, self.vim.fault.ConcurrentAccess,
                self.vim.fault.AlreadyBeingManaged, self.vim.fault.AlreadyConnected, self.vim.fault.DuplicateName, self.vim.fault.SSLVerifyFault):
            raise NativeRejected('VC_NATIVE_PRECONDITION_REJECTED') from None

    def read_task(self, binding, record):
        props = self.read(record['task'], ['info.state', 'info.entity', 'info.progress', 'info.result', 'info.error'], optional=('info.entity', 'info.progress', 'info.result', 'info.error'))
        value = {'key': record['task'], 'state': str(props['info.state'])}
        if props['info.entity'] is not None:
            value['entity'] = native_key(props['info.entity'])
        if props['info.progress'] is not None:
            value['progress'] = props['info.progress']
        if isinstance(props['info.result'], self.vim.ManagedEntity) or record.get('operation') == 'vm.snapshot.create' and isinstance(props['info.result'], self.vim.vm.Snapshot):
            value['result'] = native_key(props['info.result'])
        if value['state'] == 'error':
            value['errorCode'] = 'VC_NATIVE_TASK_FAILED'  # native fault text never leaves this process
        return value

    def verify(self, binding, record):
        operation, parameters, key = record['operation'], record['parameters'], record['key']
        self.cache.clear()
        if operation == 'vm.mountTools':
            props, host, cluster = self.scoped_vm(key)
            state = self.read(key, ['runtime.toolsInstallerMounted'])
            return {'verified': host == record['expected']['host'] and cluster == record['expected']['cluster'] and state['runtime.toolsInstallerMounted'] is True, 'installationVerified': False}
        if operation in SNAPSHOT_OPERATIONS:
            return self.verify_snapshot(record)
        if operation=='cluster.create':
            return self.verify_cluster_creation(record)
        if operation=='host.add':
            return self.verify_enrollment(binding,record)
        if operation in ALARM_OPERATIONS:
            return self.verify_alarm(record)
        if operation in NETWORK_OPERATIONS:
            return self.verify_network(record)
        if operation in GROUP_OPERATIONS:
            return self.verify_group(record)
        if operation in LIFECYCLE_OPERATIONS:
            return self.verify_lifecycle(record)
        if operation in HOST_OPERATIONS or operation in {'storage.mountNfs', 'storage.unmountNfs', 'storage.rename'}:
            return self.verify_host(record)
        if operation in DEVICE_OPERATIONS:
            self.scoped_vm(key)
            return self.verify_device(record)
        if operation in {'vm.relocate','vm.relocateLive'}:
            return self.verify_relocation(record)
        if operation in {'vm.delete', 'template.delete'}:
            # Missing exact object is a postcheck, never evidence to replay an unknown write.
            try:
                props = self.read(key, ['name'], absent=True)
            except self.vmodl.fault.ManagedObjectNotFound:
                props = None
            return {'verified': props is None, 'deletedKey': key}
        if operation in {'vm.create', 'vm.provision', 'vm.clone', 'vm.cloneTemplate', 'template.deploy'}:
            result = record.get('result', {}).get('result') if isinstance(record.get('result'), dict) else None
            require(result is not None, 'VC_OPERATION_POSTCHECK_PENDING')
            identity(result, 'VirtualMachine')
            props, host, cluster = self.scoped_vm(result)
            desired = record['expected']['placement']
            verified = props['name'] == parameters['name'] and props['config.template'] is (operation == 'vm.cloneTemplate') and str(props['runtime.powerState']) == 'poweredOff' and cluster == desired['cluster'] and host == desired['host']
            if operation == 'vm.cloneTemplate':
                placed = self.read(result, ['datastore'])
                verified = verified and native_key(props['parent']) == desired['folder'] and any(native_key(item) == desired['datastore'] for item in placed['datastore'])
            if operation in {'vm.clone', 'template.deploy'}:
                placed = self.read(result, ['resourcePool', 'datastore'])
                verified = verified and native_key(props['parent']) == desired['folder'] and native_key(placed['resourcePool']) == desired['pool'] and any(native_key(item) == desired['datastore'] for item in placed['datastore'])
            if operation in {'vm.create', 'vm.provision'}:
                created = self.read(result, ['config.hardware.numCPU', 'config.hardware.memoryMB', 'config.guestId', 'datastore'])
                verified = verified and native_key(props['parent']) == desired['folder'] and created['config.hardware.numCPU'] == parameters['numCPUs'] and created['config.hardware.memoryMB'] == parameters['memoryMB'] and created['config.guestId'] == parameters['guestId'] and any(native_key(item) == desired['datastore'] for item in created['datastore'])
                if operation == 'vm.provision':
                    values = self.read(result, ['config.firmware', 'config.files.vmPathName', 'resourcePool'])
                    verified = verified and values['config.firmware'] == parameters['firmware'] and native_key(values['resourcePool']) == desired['pool'] and values['config.files.vmPathName'].startswith('[' + record['expected']['datastoreName'] + '] ') and self.verify_initial_devices(result, parameters, record['expected']['initialDevices'])
            return {'verified': verified, 'createdKey': result}
        if operation == 'vm.configure':
            return self.verify_hardware(record)
        if operation == 'template.rename':
            props, _, _ = self.scoped_vm(key)
            return {'verified': props['name'] == parameters['name'] and props['config.template'] is True}
        if operation == 'cluster.configure':
            require(identity(key) in self.selected, 'VC_PERMISSION_DENIED')
            fields = {name: 'configurationEx.' + fields[0] for name, fields in CLUSTER_FIELDS.items()}
            props = self.read(key, [fields[name] for name in parameters])
            return {'verified': all(props[fields[name]] == value for name, value in parameters.items())}
        if operation == 'template.toVM':
            props, host, cluster = self.scoped_vm(key)
            pool = self.read(key, ['resourcePool'])['resourcePool']
            desired = record['expected']['placement']
            return {'verified': props['config.template'] is False and host == desired['host'] and cluster == desired['cluster'] and native_key(pool) == desired['pool']}
        props = self.read(key, ['runtime.powerState', 'config.template'])
        if operation == 'template.mark':
            return {'verified': props['config.template'] is True}
        desired = {'vm.powerOn': 'poweredOn', 'vm.powerOff': 'poweredOff', 'vm.suspend': 'suspended', 'vm.shutdownGuest': 'poweredOff'}.get(operation)
        if operation == 'vm.rebootGuest':
            before = record['expected'].get('guestReboot')
            require(before is not None, 'VC_OPERATION_POSTCHECK_PENDING')
            _, host, _ = self.scoped_vm(key)
            after = self.guest_reboot_sample(key)
            return {'verified': host == record['expected']['host'] and reboot_verified(before, after, record['createdAtMs']),
                    'guestRebootEvidence': after}
        verified = str(props['runtime.powerState']) == desired if desired else operation == 'vm.reset' and str(props['runtime.powerState']) == 'poweredOn' and record.get('result', {}).get('nativeState') == 'success'
        return {'verified': verified}
