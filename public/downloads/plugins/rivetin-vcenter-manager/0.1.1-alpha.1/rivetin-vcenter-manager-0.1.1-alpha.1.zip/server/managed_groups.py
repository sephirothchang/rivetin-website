"""Cluster-local user groups and DRS rules; never an implicit cascade."""
import copy
import hashlib
from .operation_ledger import canonical, require
from .resource_scope import identity

GROUP_OPERATIONS = {name: ('ClusterComputeResource', 'Host.Inventory.EditCluster') for name in (
    'cluster.group.create', 'cluster.group.edit', 'cluster.group.delete',
    'cluster.rule.create', 'cluster.rule.edit', 'cluster.rule.delete')}


class GroupOperations:
    def group_configuration(self, key):
        require(identity(key, 'ClusterComputeResource') in self.selected, 'VC_PERMISSION_DENIED')
        paths = ['configurationEx.group', 'configurationEx.rule']
        props = self.read(key, paths, optional=paths)
        groups, rules = list(props[paths[0]] or []), list(props[paths[1]] or [])
        require(len(groups) <= 200 and len(rules) <= 200, 'VC_INVENTORY_LIMIT')
        require(len({group.name for group in groups}) == len(groups) and len({rule.key for rule in rules}) == len(rules), 'VC_INVENTORY_INCOMPLETE')
        return groups, rules

    def group_members(self, cluster, kind, members):
        require(kind in {'vm', 'host'} and isinstance(members, list) and len(members) <= 200)
        expected_kind = 'VirtualMachine' if kind == 'vm' else 'HostSystem'
        require(len({identity(key, expected_kind) for key in members}) == len(members))
        for key in members:
            if kind == 'vm':
                props, _, owner = self.scoped_vm(key)
                require(props['config.template'] is False, 'VC_OPERATION_STATE_CONFLICT')
            else:
                owner = self.cluster(key)
            require(owner == cluster, 'VC_PERMISSION_DENIED')
        return [self.obj(key) for key in members]

    def group_state(self, groups, rules):
        # Preserve opaque native fields in a digest without exposing their values.
        def hashes(values):
            return sorted(hashlib.sha256(self.sdk.SoapAdapter.Serialize(value, version=self.stub.version)).hexdigest() for value in values)
        return {'groups': hashes(groups), 'rules': hashes(rules)}

    def prepare_group(self, key, operation, parameters):
        from .managed_executor import label
        require(parameters.get('confirmRuleImpact') is True)
        groups, rules = self.group_configuration(key)
        group_by_name = {group.name: group for group in groups}
        if operation.startswith('cluster.group.'):
            required = {'groupName', 'groupKind', 'confirmRuleImpact'}
            if not operation.endswith('.delete'): required.add('members')
            require(set(parameters) == required)
            name, kind = label(parameters['groupName']), parameters['groupKind']
            require(kind in {'vm', 'host'})
            existing = group_by_name.get(name)
            require((existing is None) == operation.endswith('.create'), 'VC_OPERATION_STATE_CONFLICT')
            if existing is not None:
                require(type(existing) is (self.vim.cluster.VmGroup if kind == 'vm' else self.vim.cluster.HostGroup) and existing.userCreated is True, 'VC_OPERATION_STATE_CONFLICT')
            if operation.endswith('.delete'):
                require(not any(isinstance(rule, self.vim.cluster.VmHostRuleInfo) and name in [rule.vmGroupName, rule.affineHostGroupName, rule.antiAffineHostGroupName] for rule in rules), 'VC_OPERATION_RESOURCE_IN_USE')
            else:
                self.group_members(key, kind, parameters['members'])
        else:
            required = {'ruleName', 'ruleKind', 'confirmRuleImpact'}
            if not operation.endswith('.create'): required.add('ruleKey')
            if not operation.endswith('.delete'):
                required |= {'enabled', 'mandatory'}
                required |= {'vmGroupName', 'hostGroupName', 'affinity'} if parameters.get('ruleKind') == 'vmHost' else {'members'}
            require(set(parameters) == required)
            name, kind = label(parameters['ruleName']), parameters['ruleKind']
            require(kind in {'vmAffinity', 'vmAntiAffinity', 'vmHost'})
            matches = [rule for rule in rules if rule.key == parameters.get('ruleKey')]
            if operation.endswith('.create'):
                require(not any(rule.name == name for rule in rules), 'VC_OPERATION_STATE_CONFLICT')
            else:
                require(type(parameters['ruleKey']) is int and 0 <= parameters['ruleKey'] <= 2147483647 and len(matches) == 1, 'VC_OPERATION_STATE_CONFLICT')
                expected = {'vmAffinity': self.vim.cluster.AffinityRuleSpec, 'vmAntiAffinity': self.vim.cluster.AntiAffinityRuleSpec, 'vmHost': self.vim.cluster.VmHostRuleInfo}[kind]
                require(type(matches[0]) is expected and matches[0].userCreated is True, 'VC_OPERATION_STATE_CONFLICT')
                if operation.endswith('.delete'):
                    require(matches[0].name == name, 'VC_OPERATION_STATE_CONFLICT')
                require(not any(rule.key != matches[0].key and rule.name == name for rule in rules), 'VC_OPERATION_STATE_CONFLICT')
            if not operation.endswith('.delete'):
                require(type(parameters['enabled']) is bool and type(parameters['mandatory']) is bool)
                if kind == 'vmHost':
                    vm_group, host_group = group_by_name.get(parameters['vmGroupName']), group_by_name.get(parameters['hostGroupName'])
                    require(type(vm_group) is self.vim.cluster.VmGroup and type(host_group) is self.vim.cluster.HostGroup and parameters['affinity'] in {'affine','antiAffine'}, 'VC_OPERATION_STATE_CONFLICT')
                    from .managed_executor import native_key
                    self.group_members(key, 'vm', [native_key(item) for item in vm_group.vm or []])
                    self.group_members(key, 'host', [native_key(item) for item in host_group.host or []])
                else:
                    require(len(parameters['members']) >= 2)
                    self.group_members(key, 'vm', parameters['members'])
        return {'configuration': self.group_state(groups, rules)}, {'name': name, 'cluster': key,
            'impact': 'Changes only this user group or rule. Enabled DRS rules can constrain placement or cause migrations. Referenced groups cannot be deleted; there is no implicit rule removal. Native cluster updates have no configuration CAS.'}

    def invoke_group(self, intent):
        key, operation, p = intent['key'], intent['operation'], intent['parameters']
        groups, rules = self.group_configuration(key)
        action = 'add' if operation.endswith('.create') else 'remove' if operation.endswith('.delete') else 'edit'
        if operation.startswith('cluster.group.'):
            if action == 'remove':
                update = self.vim.cluster.GroupSpec(operation=action, removeKey=p['groupName'])
            else:
                kind = self.vim.cluster.VmGroup if p['groupKind'] == 'vm' else self.vim.cluster.HostGroup
                info = kind(name=p['groupName'], userCreated=True) if action == 'add' else copy.deepcopy(next(group for group in groups if group.name == p['groupName']))
                setattr(info, 'vm' if p['groupKind'] == 'vm' else 'host', [self.obj(key) for key in p['members']])
                update = self.vim.cluster.GroupSpec(operation=action, info=info)
            spec = self.vim.cluster.ConfigSpecEx(groupSpec=[update])
        else:
            if action == 'remove':
                update = self.vim.cluster.RuleSpec(operation=action, removeKey=p['ruleKey'])
            else:
                kind = {'vmAffinity': self.vim.cluster.AffinityRuleSpec, 'vmAntiAffinity': self.vim.cluster.AntiAffinityRuleSpec, 'vmHost': self.vim.cluster.VmHostRuleInfo}[p['ruleKind']]
                info = kind(name=p['ruleName'], userCreated=True) if action == 'add' else copy.deepcopy(next(rule for rule in rules if rule.key == p['ruleKey']))
                info.name, info.enabled, info.mandatory = p['ruleName'], p['enabled'], p['mandatory']
                if p['ruleKind'] == 'vmHost':
                    info.vmGroupName = p['vmGroupName']
                    info.affineHostGroupName = p['hostGroupName'] if p['affinity'] == 'affine' else ''
                    info.antiAffineHostGroupName = p['hostGroupName'] if p['affinity'] == 'antiAffine' else ''
                else:
                    info.vm = [self.obj(key) for key in p['members']]
                update = self.vim.cluster.RuleSpec(operation=action, info=info)
            spec = self.vim.cluster.ConfigSpecEx(rulesSpec=[update])
        return self.obj(key).ReconfigureComputeResource_Task(spec=spec, modify=True)

    def verify_group(self, record):
        from .managed_executor import native_key
        p, operation = record['parameters'], record['operation']
        groups, rules = self.group_configuration(record['key'])
        if operation.startswith('cluster.group.'):
            matches = [group for group in groups if group.name == p['groupName']]
            if operation.endswith('.delete'): return {'verified': not matches}
            kind = self.vim.cluster.VmGroup if p['groupKind'] == 'vm' else self.vim.cluster.HostGroup
            if len(matches) != 1 or type(matches[0]) is not kind or matches[0].userCreated is not True: return {'verified': False}
            members = matches[0].vm if p['groupKind'] == 'vm' else matches[0].host
            self.group_members(record['key'], p['groupKind'], p['members'])
            return {'verified': sorted(identity(native_key(key)) for key in members or []) == sorted(identity(key) for key in p['members'])}
        matches = [rule for rule in rules if rule.name == p['ruleName']] if operation.endswith('.create') else [rule for rule in rules if rule.key == p['ruleKey']]
        if operation.endswith('.delete'): return {'verified': not matches}
        kind = {'vmAffinity': self.vim.cluster.AffinityRuleSpec, 'vmAntiAffinity': self.vim.cluster.AntiAffinityRuleSpec, 'vmHost': self.vim.cluster.VmHostRuleInfo}[p['ruleKind']]
        if len(matches) != 1 or type(matches[0]) is not kind: return {'verified': False}
        rule = matches[0]
        verified = rule.name == p['ruleName'] and rule.enabled is p['enabled'] and rule.mandatory is p['mandatory'] and rule.userCreated is True
        if p['ruleKind'] == 'vmHost':
            verified = verified and rule.vmGroupName == p['vmGroupName'] and (rule.affineHostGroupName or '') == (p['hostGroupName'] if p['affinity'] == 'affine' else '') and (rule.antiAffineHostGroupName or '') == (p['hostGroupName'] if p['affinity'] == 'antiAffine' else '')
            group_map = {group.name: group for group in groups}
            require(type(group_map.get(p['vmGroupName'])) is self.vim.cluster.VmGroup and type(group_map.get(p['hostGroupName'])) is self.vim.cluster.HostGroup, 'VC_OPERATION_POSTCHECK_PENDING')
            self.group_members(record['key'], 'vm', [native_key(item) for item in group_map[p['vmGroupName']].vm or []])
            self.group_members(record['key'], 'host', [native_key(item) for item in group_map[p['hostGroupName']].host or []])
        else:
            self.group_members(record['key'], 'vm', p['members'])
            verified = verified and sorted(identity(native_key(key)) for key in rule.vm or []) == sorted(identity(key) for key in p['members'])
        return {'verified': verified}
