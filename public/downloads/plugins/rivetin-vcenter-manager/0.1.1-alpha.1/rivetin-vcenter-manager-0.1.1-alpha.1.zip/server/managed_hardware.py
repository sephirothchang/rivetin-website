"""One reviewed ConfigSpec, with per-field hot-add and device capability checks."""
from .operation_ledger import require
from .managed_devices import DEVICE_OPERATIONS, native_ref
from .advanced_hardware import advanced_changes

CONFIG_FIELDS = {'name': 'name', 'numCPUs': 'config.hardware.numCPU', 'memoryMB': 'config.hardware.memoryMB',
                 'annotation': 'config.annotation', 'cpuHotAddEnabled': 'config.cpuHotAddEnabled', 'memoryHotAddEnabled': 'config.memoryHotAddEnabled'}


def config_values(parameters):
    fields = {name: value for name, value in parameters.items() if name not in ('deviceChanges', 'annotationLines', 'advancedHardware')}
    if 'annotationLines' in parameters:
        lines = parameters['annotationLines']
        require('annotation' not in fields and isinstance(lines, list) and len(lines) <= 128)
        for line in lines:
            require(isinstance(line, dict) and set(line) <= {'text'} and ('text' not in line or isinstance(line['text'], str) and bool(line['text']) and not any(ord(char) < 32 or ord(char) == 127 for char in line['text'])))
        fields['annotation'] = '\n'.join(line.get('text', '') for line in lines)
    return fields


class HardwareOperations:
    def hardware_options(self, key):
        props = self.read(key, ['environmentBrowser', 'config.guestId'])
        browser = native_ref(props['environmentBrowser'], 'EnvironmentBrowser')
        options = self.vim.EnvironmentBrowser(browser['objectId'], self.stub).QueryConfigOption()
        require(isinstance(options, self.vim.vm.ConfigOption) and options.hardwareOptions is not None and
                len(options.guestOSDescriptor or []) <= 1000 and len(options.hardwareOptions.virtualDeviceOption or []) <= 200, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        guests = [guest for guest in options.guestOSDescriptor or [] if guest.id == props['config.guestId']]
        require(len(guests) == 1, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        return options.hardwareOptions, guests[0]

    def prepare_hardware(self, key, parameters, host, power):
        from .managed_executor import label
        require(parameters and set(parameters) <= set(CONFIG_FIELDS) | {'deviceChanges', 'annotationLines', 'advancedHardware'} and power in ('poweredOff', 'poweredOn'), 'VC_OPERATION_STATE_CONFLICT')
        advanced = 'advancedHardware' in parameters
        require(not advanced or power == 'poweredOff' and 'deviceChanges' not in parameters, 'VC_OPERATION_STATE_CONFLICT')
        fields = config_values(parameters)
        for name, value in fields.items():
            if name == 'name': label(value)
            elif name == 'annotation':
                require(isinstance(value, str) and len(value) <= 1024 and not any((ord(char) < 32 and char not in '\t\n\r') or ord(char) == 127 for char in value))
            elif name in ('cpuHotAddEnabled', 'memoryHotAddEnabled'):
                require(type(value) is bool and power == 'poweredOff', 'VC_OPERATION_STATE_CONFLICT')
            else:
                low, high = (1, 128) if name == 'numCPUs' else (128, 1048576)
                require(type(value) is int and low <= value <= high)
        privileges = {'name': 'Rename', 'numCPUs': 'CPUCount', 'memoryMB': 'Memory', 'annotation': 'Annotation',
                      'cpuHotAddEnabled': 'Settings', 'memoryHotAddEnabled': 'Settings'}
        if fields: self.privilege(key, ['VirtualMachine.Config.' + privileges[name] for name in fields])
        props = self.read(key, [CONFIG_FIELDS[name] for name in fields], optional=('config.annotation', 'config.cpuHotAddEnabled', 'config.memoryHotAddEnabled')) if fields else {}
        before = {name: props[CONFIG_FIELDS[name]] if props[CONFIG_FIELDS[name]] is not None else '' if name == 'annotation' else None for name in fields}
        hot = power == 'poweredOn'
        hardware, guest = self.hardware_options(key) if hot and (set(fields) & {'numCPUs', 'memoryMB'} or parameters.get('deviceChanges')) else (None, None)
        if hot:
            if set(fields) & {'numCPUs', 'memoryMB'}:
                require(not any(isinstance(device, self.vim.vm.device.VirtualPCIPassthrough) for device in self.devices(key)), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            if 'numCPUs' in fields:
                enabled = self.read(key, ['config.cpuHotAddEnabled'], optional=('config.cpuHotAddEnabled',))['config.cpuHotAddEnabled']
                require(enabled is True and guest.supportsCpuHotAdd is True and hardware.numCpuReadonly is False and
                        fields['numCPUs'] > before['numCPUs'] and fields['numCPUs'] <= guest.supportedMaxCPUs and fields['numCPUs'] in hardware.numCPU, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            if 'memoryMB' in fields:
                names = ['config.memoryHotAddEnabled', 'config.hotPlugMemoryLimit', 'config.hotPlugMemoryIncrementSize']
                memory = self.read(key, names, optional=names)
                limit, step = memory[names[1]], memory[names[2]]
                require(memory[names[0]] is True and guest.supportsMemoryHotAdd is True and isinstance(limit, int) and isinstance(step, int) and step > 0 and
                        before['memoryMB'] < fields['memoryMB'] <= limit and fields['memoryMB'] % step == 0 and (fields['memoryMB'] - before['memoryMB']) % step == 0 and
                        hardware.memoryMB is not None and hardware.memoryMB.valueIsReadonly is False and hardware.memoryMB.min <= fields['memoryMB'] <= hardware.memoryMB.max, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        changes = parameters.get('deviceChanges', [])
        require(isinstance(changes, list) and len(changes) <= 20 and ('deviceChanges' not in parameters or bool(changes)))
        prepared, seen, disks, buses = [], set(), set(), set()
        for index, change in enumerate(changes):
            require(isinstance(change, dict) and set(change) == {'operation', 'parameters'} and change['operation'] in DEVICE_OPERATIONS and isinstance(change['parameters'], dict))
            operation, values = change['operation'], change['parameters']
            extra, observation = self.prepare_device(key, operation, values, host)
            if 'deviceKey' in values:
                require(values['deviceKey'] not in seen, 'VC_OPERATION_STATE_CONFLICT'); seen.add(values['deviceKey'])
            if operation == 'vm.disk.add':
                require(values['diskId'] not in disks, 'VC_OPERATION_STATE_CONFLICT'); disks.add(values['diskId'])
                if 'busNumber' in extra:
                    used = {device.busNumber for device in self.devices(key) if isinstance(device, self.vim.vm.device.VirtualSCSIController)} | buses
                    free = [bus for bus in range(4) if bus not in used]
                    require(bool(free), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                    extra['busNumber'] = free[0]; buses.add(free[0]); extra['controllerKey'] = -100 - index * 3
                else:
                    used = {device.unitNumber for device in self.devices(key) if device.controllerKey == extra['controllerKey']}
                    used |= {item['expected']['unitNumber'] for item in prepared if item['operation'] == 'vm.disk.add' and item['expected']['controllerKey'] == extra['controllerKey']}
                    controller = next(device for device in self.devices(key) if device.key == extra['controllerKey'])
                    free = [unit for unit in range(16) if unit not in (7, controller.scsiCtlrUnitNumber) and unit not in used]
                    require(bool(free), 'VC_OPERATION_CAPABILITY_UNAVAILABLE'); extra['unitNumber'] = free[0]
                observation.update(controllerKey=extra['controllerKey'], unitNumber=extra['unitNumber'])
            if hot: self.hot_device(key, operation, values, extra, hardware, guest)
            prepared.append({'operation': operation, 'parameters': values, 'expected': extra, 'observation': observation})
        expected = {'before': before, 'devices': prepared}
        observations = [item['observation'] | {'operation': item['operation']} for item in prepared]
        if advanced:
            items = advanced_changes(parameters['advancedHardware'])
            if any(item['operation'] == 'library.mount' for item in items):
                require(len(items) == 1 and not fields, 'VC_OPERATION_INVALID')
                plan = self.prepare_library_mount(key, items[0]['parameters'], host)
                return {'libraryMount': plan}, {'item': plan['item'], 'impact': 'Mount one cached content-library ISO as a separate device.'}
            plan = self.prepare_advanced_hardware(key, items, host)
            expected['advanced'] = plan
            observations.extend({'operation': item['operation'], **item['parameters']} for item in plan['items'])
        return expected, {'before': before, 'deviceChanges': observations,
                          'impact': 'Sends all reviewed changes in one native reconfiguration task. No automatic shutdown; task completion and each requested field/device are checked separately.'}

    def hot_device(self, key, operation, values, expected, hardware, guest):
        devices = self.devices(key)
        device = next((item for item in devices if item.key == values.get('deviceKey')), None)
        kind = self.vim.vm.device.VirtualDisk if operation == 'vm.disk.add' else self.vim.vm.device.VirtualVmxnet3 if operation == 'vm.nic.add' else type(device)
        options = [item for item in hardware.virtualDeviceOption if item.type is kind]
        require(len(options) == 1 and options[0].deprecated is not True, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        option = options[0]
        if operation.endswith('.remove'):
            require(option.hotRemoveSupported is True, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        elif operation.endswith('.add'):
            require(option.plugAndPlay is True, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        if operation.startswith('vm.disk.'):
            # Only existing nonshared SCSI buses are considered for live edits.
            controller_key = expected.get('controllerKey') if operation == 'vm.disk.add' else device.controllerKey
            controllers = [item for item in devices if item.key == controller_key and isinstance(item, self.vim.vm.device.VirtualSCSIController) and item.sharedBus == 'noSharing']
            require(len(controllers) == 1, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            controller_options = [item for item in hardware.virtualDeviceOption if item.type is type(controllers[0])]
            require(len(controller_options) == 1 and controller_options[0].hotAddRemove is not None and controller_options[0].hotAddRemove.supported is True, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            snapshots = self.read(key, ['snapshot'], optional=('snapshot',))['snapshot']
            require(snapshots is None, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            if operation == 'vm.disk.extend':
                capacity = option.capacityInKB
                require(capacity is not None and capacity.valueIsReadonly is False and capacity.min <= values['capacityGB'] * 1048576 <= capacity.max, 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        else:
            require(guest.supportsHotPlugPCI is True and not any(isinstance(item, self.vim.vm.device.VirtualPCIPassthrough) for item in devices), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')

    def hardware_spec(self, intent):
        fields = config_values(intent['parameters'])
        changes = []
        for index, item in enumerate(intent['expected'].get('hardware', {}).get('devices', [])):
            native = self.device_changes(intent['key'], item['operation'], item['parameters'], item['expected'])
            for change in native:
                if change.device.key < 0:
                    change.device.key = -100 - index * 3 if isinstance(change.device, self.vim.vm.device.VirtualSCSIController) else -101 - index * 3 if isinstance(change.device, self.vim.vm.device.VirtualDisk) else -102 - index * 3
            changes.extend(native)
        advanced = intent['expected'].get('hardware', {}).get('advanced')
        if advanced:
            changes.extend(self.advanced_device_specs(intent['key'], advanced))
        return self.vim.vm.ConfigSpec(changeVersion=intent['expected']['changeVersion'], **fields, **({'deviceChange': changes} if changes else {}))

    def verify_hardware(self, record):
        if 'hardware' in record.get('expected', {}):
            scope, host, cluster = self.scoped_vm(record['key'])
            require(scope['config.template'] is False and cluster == record['expected']['cluster'], 'VC_OPERATION_SCOPE_CHANGED')
        library_mount = record.get('expected', {}).get('hardware', {}).get('libraryMount')
        if library_mount:
            require(host == record['expected']['host'], 'VC_OPERATION_SCOPE_CHANGED')
            return self.verify_library_mount(record, library_mount, host)
        fields = config_values(record['parameters'])
        props = self.read(record['key'], [CONFIG_FIELDS[name] for name in fields], optional=('config.annotation',)) if fields else {}
        values = all((props[CONFIG_FIELDS[name]] if props[CONFIG_FIELDS[name]] is not None else '') == value for name, value in fields.items())
        outcomes = []
        added_nics = set()
        for item in record.get('expected', {}).get('hardware', {}).get('devices', []):
            if item['operation'] == 'vm.nic.add':
                previous = {device['key'] for device in item['expected']['devices']} | added_nics
                matches = [device for device in self.devices(record['key']) if type(device) is self.vim.vm.device.VirtualVmxnet3 and device.key not in previous and type(device.backing) is self.vim.vm.device.VirtualEthernetCard.NetworkBackingInfo and device.backing.network and native_ref(device.backing.network) == item['parameters']['network'] and device.connectable and device.connectable.startConnected == item['parameters']['startConnected']]
                result = {'verified': bool(matches)}
                if matches:
                    added_nics.add(min(device.key for device in matches))
            else:
                result = self.verify_device({'key': record['key'], 'operation': item['operation'], 'parameters': item['parameters'], 'expected': {'device': item['expected']}})
            outcomes.append({'operation': item['operation'], **result})
        advanced = record.get('expected', {}).get('hardware', {}).get('advanced')
        if advanced:
            outcomes.extend(self.verify_advanced_devices(record['key'], advanced))
        return {'verified': values and all(item['verified'] for item in outcomes), 'fieldsVerified': values, 'deviceResults': outcomes}
