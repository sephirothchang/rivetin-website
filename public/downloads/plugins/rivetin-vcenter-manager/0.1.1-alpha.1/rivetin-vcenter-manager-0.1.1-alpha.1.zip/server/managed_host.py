"""Standard-portgroup writes and read-only historical datastore verification."""

from .operation_ledger import require
from .resource_scope import identity

HOST_OPERATIONS = {
    'network.createPortGroup': ('HostSystem', None), 'network.updatePortGroup': ('HostSystem', None), 'network.deletePortGroup': ('HostSystem', None)
}
# History accepts these former intents for observation only, never dispatch.
HISTORICAL_STORAGE_OPERATIONS = {
    'storage.mountNfs': ('HostSystem', None), 'storage.unmountNfs': ('Datastore', None), 'storage.rename': ('Datastore', None)
}


class HostOperations:
    def _manager(self, host, name):
        from .managed_executor import native_key
        field = 'configManager.' + name
        result = native_key(self.read(host, [field])[field])
        identity(result, 'HostNetworkSystem' if name == 'networkSystem' else 'HostDatastoreSystem')
        return result

    def _network(self, host):
        manager = self._manager(host, 'networkSystem')
        props = self.read(manager, ['networkInfo.portgroup', 'networkInfo.vswitch', 'networkInfo.vnic', 'networkInfo.consoleVnic'], optional=('networkInfo.consoleVnic',))
        groups = {group.spec.name: group for group in props['networkInfo.portgroup'] or []}
        require(len(groups) == len(props['networkInfo.portgroup'] or []), 'VC_INVENTORY_INCOMPLETE')
        return manager, groups, props

    @staticmethod
    def _portgroup_before(group):
        return {'name': group.spec.name, 'vlanId': group.spec.vlanId, 'vswitchName': group.spec.vswitchName} if group else None

    def prepare_host(self, key, operation, parameters):
        require(operation in HOST_OPERATIONS, 'VC_OPERATION_UNSUPPORTED')
        from .managed_executor import native_key, label
        if operation.startswith('network.'):
            host = key
            cluster = self.cluster(host)
            self.privilege(host, ['Host.Config.Network'])
            allowed = ({'pgName', 'vlanId', 'vswitchName'},) if operation == 'network.createPortGroup' else ({'pgName'},)
            if operation == 'network.updatePortGroup':
                base = ({'pgName', 'vlanId'}, {'pgName', 'vlanId', 'vswitchName'})
                allowed = base + tuple(fields | {'newName'} for fields in base)
            require(set(parameters) in allowed)
            label(parameters['pgName'])
            manager, groups, props = self._network(host)
            group = groups.get(parameters['pgName'])
            require((group is None) == (operation == 'network.createPortGroup'), 'VC_OPERATION_STATE_CONFLICT')
            if operation != 'network.createPortGroup':
                protected = list(props['networkInfo.vnic'] or []) + list(props['networkInfo.consoleVnic'] or [])
                require(not any(nic.portgroup == parameters['pgName'] for nic in protected), 'VC_OPERATION_MANAGEMENT_NETWORK_PROTECTED')
            if operation != 'network.deletePortGroup':
                require(type(parameters['vlanId']) is int and 0 <= parameters['vlanId'] <= 4095)
                switch_name = parameters.get('vswitchName', group.spec.vswitchName if group else None)
                label(switch_name)
                require(any(switch.name == switch_name for switch in props['networkInfo.vswitch'] or []), 'VC_OPERATION_STATE_CONFLICT')
                if operation == 'network.updatePortGroup':
                    require(switch_name == group.spec.vswitchName, 'VC_OPERATION_STATE_CONFLICT')
                    if 'newName' in parameters:
                        label(parameters['newName'])
                        require(parameters['newName'] == parameters['pgName'] or parameters['newName'] not in groups,'VC_OPERATION_STATE_CONFLICT')
            expected = {'cluster': cluster, 'manager': manager, 'before': self._portgroup_before(group)}
            observation = {'name': parameters['pgName'], 'host': host, 'cluster': cluster,
                           'impact': 'Changes this host standard portgroup only; network traffic using it can be interrupted. VMkernel-connected groups are protected.'}
            if group:
                observation['before'] = self._portgroup_before(group)
                if 'newName' in parameters: observation['before']['newName'] = parameters['pgName']
            return expected, observation
    def invoke_host(self, intent):
        operation, parameters = intent['operation'], intent['parameters']
        require(operation in HOST_OPERATIONS, 'VC_OPERATION_UNSUPPORTED')
        manager = self.obj(intent['expected']['manager'])
        if operation.startswith('network.'):
            if operation == 'network.deletePortGroup':
                return manager.RemovePortGroup(pgName=parameters['pgName'])
            _, groups, _ = self._network(intent['key'])
            original = groups.get(parameters['pgName'])
            policy = original.spec.policy if original else self.vim.host.NetworkPolicy()
            switch_name = parameters['vswitchName'] if operation == 'network.createPortGroup' else intent['expected']['before']['vswitchName']
            spec = self.vim.host.PortGroup.Specification(name=parameters.get('newName',parameters['pgName']), vlanId=parameters['vlanId'], vswitchName=switch_name, policy=policy)
            return manager.AddPortGroup(portgrp=spec) if operation == 'network.createPortGroup' else manager.UpdatePortGroup(pgName=parameters['pgName'], portgrp=spec)

    def verify_host(self, record):
        from .managed_executor import native_key
        self.cache.clear()
        operation, parameters = record['operation'], record['parameters']
        if operation.startswith('network.'):
            _, groups, _ = self._network(record['key'])
            final_name = parameters.get('newName',parameters['pgName'])
            group = groups.get(final_name)
            if operation == 'network.deletePortGroup':
                return {'verified': group is None}
            switch_name = parameters['vswitchName'] if operation == 'network.createPortGroup' else record['expected']['before']['vswitchName']
            return {'verified': group is not None and group.spec.vlanId == parameters['vlanId'] and group.spec.vswitchName == switch_name and (final_name == parameters['pgName'] or parameters['pgName'] not in groups)}
        host = record['key'] if operation == 'storage.mountNfs' else parameters['host']
        attached = [native_key(item) for item in self.read(host, ['datastore'])['datastore']]
        if operation == 'storage.unmountNfs':
            return {'verified': record['key'] not in attached, 'remoteFilesRetained': True}
        if operation == 'storage.rename':
            return {'verified': self.read(record['key'], ['name'])['name'] == parameters['name']}
        created = record.get('result', {}).get('value') if isinstance(record.get('result'), dict) else None
        require(created is not None and created in attached, 'VC_OPERATION_POSTCHECK_PENDING')
        props = self.read(created, ['name', 'summary.type', 'info.nas.remoteHost', 'info.nas.remotePath', 'host'])
        mounts = [mount.mountInfo for mount in props['host'] if native_key(mount.key) == host]
        mode = 'readOnly' if parameters['readOnly'] else 'readWrite'
        mounted = len(mounts) == 1 and mounts[0].mounted is True and mounts[0].accessible is True and mounts[0].accessMode == mode
        return {'verified': mounted and props['name'] == parameters['name'] and props['summary.type'] == 'NFS' and props['info.nas.remoteHost'] == parameters['remoteHost'] and props['info.nas.remotePath'] == parameters['remotePath'], 'createdKey': created}
