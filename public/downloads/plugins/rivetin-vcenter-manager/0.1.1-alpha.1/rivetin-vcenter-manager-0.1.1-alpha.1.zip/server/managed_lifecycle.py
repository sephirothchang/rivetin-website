"""Lifecycle actions on exact enrolled clusters and their hosts."""
from .operation_ledger import require
from .resource_scope import identity

LIFECYCLE_OPERATIONS = {
    'cluster.rename': ('ClusterComputeResource', 'Host.Inventory.RenameCluster'),
    'cluster.delete': ('ClusterComputeResource', 'Host.Inventory.DeleteCluster'),
    'host.enterMaintenance': ('HostSystem', 'Host.Config.Maintenance'),
    'host.exitMaintenance': ('HostSystem', 'Host.Config.Maintenance'),
}


class LifecycleOperations:
    def prepare_lifecycle(self, key, operation, parameters):
        from .managed_executor import native_key, label
        if operation.startswith('cluster.'):
            require(identity(key,'ClusterComputeResource') in self.selected,'VC_PERMISSION_DENIED')
            props=self.read(key,['name','parent'])
            parent=native_key(props['parent']);identity(parent,'Folder')
            name=label(props['name'],120)
            if operation=='cluster.rename':
                require(set(parameters)=={'name'})
                label(parameters['name'],80)
                require(not any(char in parameters['name'] for char in '%/\\'),'VC_OPERATION_INVALID')
                require(parameters['name']!=name,'VC_OPERATION_STATE_CONFLICT')
                return {'name':name,'parent':parent},{'name':name,'before':{'name':name},'impact':'Renames this exact enrolled cluster. Its hosts, VMs and settings are retained. External changes are rechecked before dispatch; the native API has no configuration CAS.'}
            require(parameters=={'name':name,'confirmEmptyCluster':True},'VC_OPERATION_STATE_CONFLICT')
            members=self.read(key,['host','resourcePool'],optional=('host',))
            require(not members['host'],'VC_OPERATION_STATE_CONFLICT')
            pool=native_key(members['resourcePool']);identity(pool,'ResourcePool')
            content=self.read(pool,['owner','vm','resourcePool'],optional=('vm','resourcePool'))
            require(native_key(content['owner'])==key and not content['vm'] and not content['resourcePool'],'VC_OPERATION_STATE_CONFLICT')
            self.privilege(parent,['Host.Inventory.DeleteCluster'])
            return {'name':name,'parent':parent,'pool':pool,'hosts':[],'vms':[],'childPools':[]},{'name':name,'parent':parent,
                'impact':'Permanently deletes only an empty cluster with no hosts, VMs or child resource pools. No host removal or cascading deletion. After success remove this deleted root from the plugin connection scope; operation history remains available. There is no native CAS against external concurrent changes.'}
        cluster = self.cluster(key)
        required = {'timeoutSeconds', 'confirmMaintenance'}
        if operation == 'host.enterMaintenance':
            required.add('evacuatePoweredOffVms')
        require(set(parameters) == required and parameters['confirmMaintenance'] is True)
        require(type(parameters['timeoutSeconds']) is int and 1 <= parameters['timeoutSeconds'] <= 3600)
        if operation == 'host.enterMaintenance':
            require(type(parameters['evacuatePoweredOffVms']) is bool)
        props = self.read(key, ['name', 'runtime.connectionState', 'runtime.inMaintenanceMode', 'vm'])
        require(str(props['runtime.connectionState']) == 'connected' and type(props['runtime.inMaintenanceMode']) is bool, 'VC_OPERATION_STATE_CONFLICT')
        require(props['runtime.inMaintenanceMode'] is (operation == 'host.exitMaintenance'), 'VC_OPERATION_STATE_CONFLICT')
        guests = list(props['vm'] or [])
        require(len(guests) <= 2000, 'VC_INVENTORY_LIMIT')
        before = []
        for guest in guests:
            guest_key = native_key(guest); identity(guest_key, 'VirtualMachine')
            vm, host, owner = self.scoped_vm(guest_key)
            require(host == key and owner == cluster, 'VC_INVENTORY_INCOMPLETE')
            before.append({'key': guest_key, 'powerState': str(vm['runtime.powerState']), 'template': vm['config.template']})
        require(len({identity(row['key']) for row in before}) == len(before), 'VC_INVENTORY_INCOMPLETE')
        before.sort(key=lambda row: identity(row['key']))
        drs = self.read(cluster, ['configurationEx.drsConfig.enabled', 'configurationEx.drsConfig.defaultVmBehavior'], optional=('configurationEx.drsConfig.defaultVmBehavior',))
        require(type(drs['configurationEx.drsConfig.enabled']) is bool, 'VC_INVENTORY_INCOMPLETE')
        drs_state = {'drsEnabled': drs['configurationEx.drsConfig.enabled'], 'drsAutomation': str(drs['configurationEx.drsConfig.defaultVmBehavior'] or 'unknown')}
        return {'cluster': cluster, 'maintenance': props['runtime.inMaintenanceMode'], 'vms': before, **drs_state}, {
            **drs_state, 'virtualMachineCount': len(before),
            'name': label(props['name'], 120), 'host': key, 'cluster': cluster,
            'impact': 'Maintenance prevents VM power-on/provisioning. DRS may automatically migrate VMs; this action does not shut down VMs or the host. Native timeout is bounded, and a timed-out task is not resubmitted.'}

    def invoke_lifecycle(self, intent, binding):
        target, parameters = self.obj(intent['key']), intent['parameters']
        if intent['operation']=='cluster.rename':
            return target.Rename_Task(newName=parameters['name'])
        if intent['operation']=='cluster.delete':
            from .durable_operations import NativeRejected
            from .profiles import AdapterError
            try:self.revalidate(binding,intent,{})
            except AdapterError as error:raise NativeRejected(error.code) from None
            return target.Destroy_Task()
        if intent['operation'] == 'host.enterMaintenance':
            return target.EnterMaintenanceMode_Task(timeout=parameters['timeoutSeconds'], evacuatePoweredOffVms=parameters['evacuatePoweredOffVms'])
        return target.ExitMaintenanceMode_Task(timeout=parameters['timeoutSeconds'])

    def verify_lifecycle(self, record):
        from .managed_executor import native_key
        if record['operation'].startswith('cluster.'):
            require(identity(record['key'],'ClusterComputeResource') in self.selected,'VC_OPERATION_SCOPE_CHANGED')
            if record['operation']=='cluster.delete':
                try:props=self.read(record['key'],['name'],absent=True)
                except self.vmodl.fault.ManagedObjectNotFound:props=None
                return {'verified':props is None,'deletedKey':record['key'],'scopeCleanupRequired':True}
            props=self.read(record['key'],['name','parent'])
            return {'verified':props['name']==record['parameters']['name'] and native_key(props['parent'])==record['expected']['parent']}
        require(self.cluster(record['key']) == record['expected']['cluster'], 'VC_OPERATION_SCOPE_CHANGED')
        props = self.read(record['key'], ['runtime.connectionState', 'runtime.inMaintenanceMode'])
        return {'verified': str(props['runtime.connectionState']) == 'connected' and props['runtime.inMaintenanceMode'] is (record['operation'] == 'host.enterMaintenance')}
