"""Standard switches/uplinks and IPv4 VMkernel adapters; no DVS mutations."""
import copy
import hashlib
import ipaddress
import re
from .operation_ledger import require
from .resource_scope import identity

NETWORK_OPERATIONS = {name: ('HostSystem','Host.Config.Network') for name in (
    'network.createSwitch','network.editSwitch','network.deleteSwitch','network.setUplinks',
    'vmk.create','vmk.edit','vmk.delete')}


def vmk_device(value):
    require(isinstance(value,str) and re.fullmatch(r'vmk\d{1,4}',value))
    return value


def mtu(value):
    require(type(value) is int and 1280 <= value <= 9000)
    return value


def ipv4(parameters):
    require(type(parameters['dhcp']) is bool)
    if parameters['dhcp']:
        require('ipv4Address' not in parameters and 'ipv4SubnetMask' not in parameters)
        return
    require(isinstance(parameters.get('ipv4Address'),str) and isinstance(parameters.get('ipv4SubnetMask'),str))
    require(bool(re.fullmatch(r'(?:\d{1,3}\.){3}\d{1,3}',parameters['ipv4SubnetMask'])))
    try:
        address=ipaddress.IPv4Address(parameters['ipv4Address']); network=ipaddress.IPv4Network(str(address)+'/'+parameters['ipv4SubnetMask'],strict=False)
    except (ValueError,TypeError):
        require(False)
    require(not address.is_unspecified and not address.is_multicast and not address.is_loopback)
    require(network.prefixlen >= 31 or address not in (network.network_address,network.broadcast_address))


class NetworkOperations:
    def vmk_preserved(self,spec):
        values={name:getattr(spec,name) for name in ('mac','netStackInstanceKey','tsoEnabled','ipRouteSpec','pinnedPnic','distributedVirtualPort','opaqueNetwork','externalId','systemOwned','dpuId')}
        values['ipv6']=spec.ip.ipV6Config if spec.ip else None
        return {name:hashlib.sha256(b'null' if value is None else self.sdk.SoapAdapter.Serialize(value,version=self.stub.version)).hexdigest() for name,value in values.items()}

    def network_state(self, host):
        from .managed_executor import native_key
        cluster=self.cluster(host)
        require(str(self.read(host,['runtime.connectionState'])['runtime.connectionState'])=='connected','VC_OPERATION_STATE_CONFLICT')
        manager,groups,props=self._network(host)
        extra=self.read(manager,['networkInfo.pnic','networkInfo.proxySwitch'],optional=('networkInfo.proxySwitch',))
        props=props|extra
        switches={switch.name:switch for switch in props['networkInfo.vswitch'] or []}
        nics={nic.device:nic for nic in props['networkInfo.vnic'] or []}
        pnics={nic.device:nic for nic in props['networkInfo.pnic'] or []}
        require(len(switches)==len(props['networkInfo.vswitch'] or []) and len(nics)==len(props['networkInfo.vnic'] or []) and len(pnics)==len(props['networkInfo.pnic'] or []),'VC_INVENTORY_INCOMPLETE')
        def hashes(values):
            return sorted(hashlib.sha256(self.sdk.SoapAdapter.Serialize(value,version=self.stub.version)).hexdigest() for value in values or [])
        snapshot={path:hashes(values) for path,values in props.items()}
        return cluster,manager,groups,switches,nics,pnics,props,snapshot

    def vmk_services(self, host, nic):
        from .managed_executor import native_key
        path='configManager.virtualNicManager'; manager=native_key(self.read(host,[path])[path]); identity(manager,'HostVirtualNicManager')
        config=self.read(manager,['info.netConfig'])['info.netConfig']
        require(config is not None and len(config)<=100,'VC_INVENTORY_INCOMPLETE')
        services = []
        for item in config:
            candidates = {candidate.key: candidate.device for candidate in item.candidateVnic or []}
            selected = list(item.selectedVnic or [])
            require(len(candidates) == len(item.candidateVnic or []) and len(set(selected)) == len(selected), 'VC_INVENTORY_INCOMPLETE')
            require(all(key in candidates and isinstance(candidates[key], str) and re.fullmatch(r'vmk\d{1,4}', candidates[key]) for key in selected), 'VC_INVENTORY_INCOMPLETE')
            if nic.device in {candidates[key] for key in selected}: services.append(item.nicType)
        return sorted(services)

    @staticmethod
    def switch_uplinks(switch):
        bridge=switch.spec.bridge
        if bridge is None: return []
        value=bridge.nicDevice
        return [value] if isinstance(value,str) else sorted(value or [])

    def prepare_network(self,key,operation,p):
        from .managed_executor import label
        require(p.get('confirmNetworkImpact') is True)
        cluster,manager,groups,switches,nics,pnics,props,snapshot=self.network_state(key)
        expected={'cluster':cluster,'manager':manager,'configuration':snapshot}
        if operation.startswith('network.'):
            required={'vswitchName','confirmNetworkImpact'}
            if operation=='network.createSwitch': required|={'mtu','numPorts'}
            elif operation=='network.editSwitch': required.add('mtu')
            elif operation=='network.setUplinks': required.add('uplinks')
            require(set(p) in (required,required|{'confirmManagementImpact'}))
            name=label(p['vswitchName']); switch=switches.get(name)
            require((switch is None)==(operation=='network.createSwitch'),'VC_OPERATION_STATE_CONFLICT')
            if 'mtu' in p: mtu(p['mtu'])
            if operation=='network.createSwitch': require(type(p['numPorts']) is int and 8<=p['numPorts']<=4096)
            attached=[nic for nic in nics.values() if nic.portgroup in groups and groups[nic.portgroup].spec.vswitchName==name]
            ambiguous=any(nic.portgroup not in groups and nic.spec.distributedVirtualPort is None and nic.spec.opaqueNetwork is None for nic in nics.values())
            if operation=='network.deleteSwitch':
                require(not any(group.spec.vswitchName==name for group in groups.values()) and not attached and not ambiguous,'VC_OPERATION_RESOURCE_IN_USE')
            if operation in {'network.editSwitch','network.setUplinks'} and (attached or ambiguous):
                require(p.get('confirmManagementImpact') is True,'VC_OPERATION_MANAGEMENT_NETWORK_PROTECTED')
            if operation=='network.setUplinks':
                require(isinstance(p['uplinks'],list) and len(p['uplinks'])<=32 and all(isinstance(device,str) for device in p['uplinks']))
                require(len(set(p['uplinks']))==len(p['uplinks']))
                require(all(isinstance(device,str) and re.fullmatch(r'vmnic\d{1,4}',device) and device in pnics for device in p['uplinks']))
                used={device for other in switches.values() if other.name!=name for device in self.switch_uplinks(other)}
                used_keys={pnic for proxy in props['networkInfo.proxySwitch'] or [] for pnic in proxy.pnic or []}
                require(not any(device in used or pnics[device].key in used_keys for device in p['uplinks']),'VC_OPERATION_RESOURCE_IN_USE')
                require(switch.spec.bridge is None or type(switch.spec.bridge) is self.vim.host.VirtualSwitch.BondBridge,'VC_OPERATION_CAPABILITY_UNAVAILABLE')
            expected['before']={'mtu':switch.spec.mtu,'uplinks':self.switch_uplinks(switch)} if switch else None
        else:
            required={'confirmNetworkImpact'}
            if operation!='vmk.create': required.add('device')
            if operation!='vmk.delete': required|={'pgName','mtu','dhcp'}
            if operation!='vmk.delete' and p.get('dhcp') is False: required|={'ipv4Address','ipv4SubnetMask'}
            require(set(p) in (required,required|{'confirmManagementImpact'}))
            nic=None if operation=='vmk.create' else nics.get(vmk_device(p['device']))
            require(operation=='vmk.create' or nic is not None,'VC_OPERATION_STATE_CONFLICT')
            if nic:
                require(nic.spec.distributedVirtualPort is None and nic.spec.opaqueNetwork is None,'VC_OPERATION_CAPABILITY_UNAVAILABLE')
                require(nic.spec.systemOwned is not True,'VC_OPERATION_MANAGEMENT_NETWORK_PROTECTED')
                services=self.vmk_services(key,nic); expected['services']=services
                if operation=='vmk.delete': require(not services,'VC_OPERATION_MANAGEMENT_NETWORK_PROTECTED')
                elif services: require(p.get('confirmManagementImpact') is True,'VC_OPERATION_MANAGEMENT_NETWORK_PROTECTED')
                expected['before']={'device':nic.device,'pgName':nic.portgroup,'mtu':nic.spec.mtu,'dhcp':nic.spec.ip.dhcp if nic.spec.ip else None,
                                    'ipv4Address':nic.spec.ip.ipAddress if nic.spec.ip else None,'ipv4SubnetMask':nic.spec.ip.subnetMask if nic.spec.ip else None}
                expected['preserved']=self.vmk_preserved(nic.spec)
            if operation!='vmk.delete':
                name=label(p['pgName']); require(name in groups,'VC_OPERATION_STATE_CONFLICT'); mtu(p['mtu']); ipv4(p)
                if not p['dhcp']:
                    require(not any(other.device!=p.get('device') and other.spec.ip and other.spec.ip.ipAddress==p['ipv4Address'] for other in nics.values()),'VC_OPERATION_STATE_CONFLICT')
                switch=switches.get(groups[name].spec.vswitchName)
                require(switch is not None and type(switch.spec.mtu) is int and p['mtu']<=switch.spec.mtu,'VC_OPERATION_STATE_CONFLICT')
            name=p.get('device',p.get('pgName'))
        return expected,{'name':name,'host':key,'cluster':cluster,'before':expected.get('before'),
            'impact':'Changes only the selected host standard network/VMkernel configuration. Traffic and host management can be interrupted. Services-in-use adapters and nonempty switches cannot be deleted. Native synchronous results require an exact postcheck; unknown results are not retried.'}

    def invoke_network(self,intent):
        p,operation=intent['parameters'],intent['operation']; target=self.obj(intent['expected']['manager'])
        if operation=='network.createSwitch':
            return target.AddVirtualSwitch(vswitchName=p['vswitchName'],spec=self.vim.host.VirtualSwitch.Specification(numPorts=p['numPorts'],mtu=p['mtu']))
        if operation=='network.deleteSwitch': return target.RemoveVirtualSwitch(vswitchName=p['vswitchName'])
        _,_,_,switches,nics,_,_,_=self.network_state(intent['key'])
        if operation in {'network.editSwitch','network.setUplinks'}:
            spec=copy.deepcopy(switches[p['vswitchName']].spec)
            if operation=='network.editSwitch': spec.mtu=p['mtu']
            elif p['uplinks']:
                bridge=copy.deepcopy(spec.bridge) if spec.bridge else self.vim.host.VirtualSwitch.BondBridge()
                bridge.nicDevice=p['uplinks']; spec.bridge=bridge
            else:
                spec.bridge=None
            return target.UpdateVirtualSwitch(vswitchName=p['vswitchName'],spec=spec)
        if operation=='vmk.delete':
            self.cache.clear()
            require(not self.vmk_services(intent['key'], nics[p['device']]), 'VC_OPERATION_MANAGEMENT_NETWORK_PROTECTED')
            return target.RemoveVirtualNic(device=p['device'])
        spec=copy.deepcopy(nics[p['device']].spec) if operation=='vmk.edit' else self.vim.host.VirtualNic.Specification()
        ip=copy.deepcopy(spec.ip) if spec.ip else self.vim.host.IpConfig()
        ip.dhcp=p['dhcp']; ip.ipAddress=p.get('ipv4Address'); ip.subnetMask=p.get('ipv4SubnetMask')
        spec.ip,spec.mtu=ip,p['mtu']
        if operation=='vmk.create': return target.AddVirtualNic(portgroup=p['pgName'],nic=spec)
        spec.portgroup=p['pgName']
        return target.UpdateVirtualNic(device=p['device'],nic=spec)

    def verify_network(self,record):
        p,operation=record['parameters'],record['operation']
        cluster,_,_,switches,nics,_,_,_=self.network_state(record['key'])
        require(cluster==record['expected']['cluster'],'VC_OPERATION_SCOPE_CHANGED')
        if operation.startswith('network.'):
            switch=switches.get(p['vswitchName'])
            if operation=='network.deleteSwitch': return {'verified':switch is None}
            if switch is None: return {'verified':False}
            if operation=='network.setUplinks': return {'verified':self.switch_uplinks(switch)==sorted(p['uplinks']) and switch.spec.mtu==record['expected']['before']['mtu']}
            return {'verified':switch.spec.mtu==p['mtu'] and (operation!='network.editSwitch' or self.switch_uplinks(switch)==record['expected']['before']['uplinks'])}
        if operation=='vmk.create':
            value=record.get('result',{}).get('value'); require(isinstance(value,dict) and set(value)=={'device'},'VC_OPERATION_POSTCHECK_PENDING')
            device=vmk_device(value['device'])
        else: device=p['device']
        nic=nics.get(device)
        if operation=='vmk.delete': return {'verified':nic is None}
        if nic is None or nic.spec.distributedVirtualPort is not None or nic.spec.opaqueNetwork is not None: return {'verified':False}
        ip=nic.spec.ip
        preserved=operation!='vmk.edit' or self.vmk_preserved(nic.spec)==record['expected']['preserved']
        return {'verified':preserved and nic.portgroup==p['pgName'] and nic.spec.mtu==p['mtu'] and ip is not None and ip.dhcp is p['dhcp'] and (p['dhcp'] or ip.ipAddress==p['ipv4Address'] and ip.subnetMask==p['ipv4SubnetMask']), 'device':device}
