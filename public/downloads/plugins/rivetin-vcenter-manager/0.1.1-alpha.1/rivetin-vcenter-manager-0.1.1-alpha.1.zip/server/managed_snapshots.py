"""Bounded VM-owned snapshots; no bulk removal or implicit power-on."""
import hashlib
from .operation_ledger import require, canonical
from .resource_scope import identity

SNAPSHOT_OPERATIONS = {
    'vm.snapshot.create': ('VirtualMachine', 'VirtualMachine.State.CreateSnapshot'),
    'vm.snapshot.revert': ('VirtualMachine', 'VirtualMachine.State.RevertToSnapshot'),
    'vm.snapshot.delete': ('VirtualMachine', 'VirtualMachine.State.RemoveSnapshot'),
}

class SnapshotOperations:
    def snapshot_tree(self, key):
        from .managed_executor import native_key
        self.scoped_vm(key)
        self.privilege(key, ['System.View'])
        info = self.read(key, ['snapshot'], optional=('snapshot',))['snapshot']
        current = native_key(info.currentSnapshot) if info and info.currentSnapshot else None
        rows, seen = [], set()
        stack = [(row, None, 0) for row in reversed(list(info.rootSnapshotList or []))] if info else []
        while stack:
            row, parent, depth = stack.pop()
            require(depth <= 16 and len(rows) < 200, 'VC_INVENTORY_LIMIT')
            require(native_key(row.vm) == key, 'VC_OPERATION_SCOPE_CHANGED')
            target = native_key(row.snapshot); marker = identity(target, 'VirtualMachineSnapshot')
            require(marker not in seen and hasattr(row.createTime, 'isoformat'), 'VC_INVENTORY_INCOMPLETE'); seen.add(marker)
            def safe(value, maximum):
                require(isinstance(value, str), 'VC_INVENTORY_INCOMPLETE')
                return ''.join(c for c in value if ord(c) >= 32 and ord(c) != 127)[:maximum]
            state = str(row.state)
            require(state in {'poweredOff', 'poweredOn', 'suspended'}, 'VC_INVENTORY_INCOMPLETE')
            rows.append({'key': target, 'parent': parent, 'name': safe(row.name, 256),
                         'description': safe(row.description or '', 1024), 'createdTime': row.createTime.isoformat(), 'powerState': state})
            stack.extend((child, target, depth + 1) for child in reversed(list(row.childSnapshotList or [])))
        require(current is None or identity(current) in seen, 'VC_INVENTORY_INCOMPLETE')
        return {'current': current, 'items': rows}

    def prepare_snapshot(self, key, operation, parameters, power):
        create = operation == 'vm.snapshot.create'
        require(power in {'poweredOff', 'poweredOn'} if create else power == 'poweredOff', 'VC_OPERATION_STATE_CONFLICT')
        require(parameters.get('confirmSnapshot') is True, 'VC_OPERATION_INVALID')
        if create:
            require({'name', 'confirmSnapshot'} <= set(parameters) <= {'name', 'description', 'confirmSnapshot', 'memory'}, 'VC_OPERATION_INVALID')
            memory = parameters.get('memory', False)
            require(type(memory) is bool, 'VC_OPERATION_INVALID')
            require(not memory or power == 'poweredOn', 'VC_OPERATION_STATE_CONFLICT')
            capabilities = ['capability.snapshotOperationsSupported']
            if power == 'poweredOff':
                capabilities.append('capability.poweredOffSnapshotsSupported')
            if memory:
                capabilities.append('capability.memorySnapshotsSupported')
            require(all(value is True for value in self.read(key, capabilities, optional=capabilities).values()), 'VC_OPERATION_CAPABILITY_UNAVAILABLE')
        tree = self.snapshot_tree(key)
        expected = {'snapshotTreeSHA256': hashlib.sha256(canonical(tree).encode('utf-8')).hexdigest(),
                    'snapshotKeys': [row['key'] for row in tree['items']]}
        if create:
            for field, maximum in [('name', 80), ('description', 1024)]:
                value = parameters.get(field, '')
                require(isinstance(value, str) and len(value) <= maximum and not any(ord(c) < 32 or ord(c) == 127 for c in value), 'VC_OPERATION_INVALID')
            require(bool(parameters['name']), 'VC_OPERATION_INVALID')
            name = parameters['name']
        else:
            require(set(parameters) == {'snapshot', 'confirmSnapshot'}, 'VC_OPERATION_INVALID')
            identity(parameters['snapshot'], 'VirtualMachineSnapshot')
            selected = next((row for row in tree['items'] if row['key'] == parameters['snapshot']), None)
            require(selected is not None, 'VC_OPERATION_SCOPE_CHANGED')
            expected['snapshot'] = selected
            if operation == 'vm.snapshot.revert':
                expected['snapshotConfig'] = self.read(parameters['snapshot'], ['config.hardware.numCPU', 'config.hardware.memoryMB'])
            name = selected['name']
        if create:
            return expected, {'name': name, 'memory': memory, 'impact': 'Creates a VM snapshot including memory.' if memory else 'Creates a disk snapshot without memory.'}
        return expected, {'name': name, 'impact': 'Revert discards later disk/configuration changes and stays powered off; delete removes only the selected snapshot and consolidates its disks.'}

    def invoke_snapshot(self, intent):
        operation, p = intent['operation'], intent['parameters']
        if operation == 'vm.snapshot.create':
            return self.obj(intent['key']).CreateSnapshot_Task(name=p['name'], description=p.get('description', ''), memory=p.get('memory', False), quiesce=False)
        snapshot = self.obj(p['snapshot'])
        if operation == 'vm.snapshot.revert': return snapshot.RevertToSnapshot_Task(suppressPowerOn=True)
        require(operation == 'vm.snapshot.delete', 'VC_OPERATION_UNSUPPORTED')
        return snapshot.RemoveSnapshot_Task(removeChildren=False, consolidate=True)

    def verify_snapshot(self, record):
        self.cache.clear()
        tree = self.snapshot_tree(record['key'])
        operation, p = record['operation'], record['parameters']
        by_id = {identity(row['key']): row for row in tree['items']}
        if operation == 'vm.snapshot.create':
            created = record.get('result', {}).get('result')
            identity(created, 'VirtualMachineSnapshot')
            row = by_id.get(identity(created))
            old = {identity(key) for key in record['expected']['snapshotKeys']}
            memory = p.get('memory', False)
            snapshot_power = 'poweredOn' if memory else 'poweredOff'
            verified = (row is not None and identity(created) not in old and tree['current'] == created and
                        row['name'] == p['name'] and row['description'] == p.get('description', '') and row['powerState'] == snapshot_power)
            return {'verified': verified, 'snapshot': created, 'memoryRequested': memory,
                    'snapshotPowerState': row['powerState'] if row else None}
        if operation == 'vm.snapshot.delete':
            old = {identity(key) for key in record['expected']['snapshotKeys']} - {identity(p['snapshot'])}
            consolidated = self.read(record['key'], ['runtime.consolidationNeeded'], optional=('runtime.consolidationNeeded',))['runtime.consolidationNeeded'] is False
            return {'verified': identity(p['snapshot']) not in by_id and old <= set(by_id) and consolidated}
        config = self.read(record['key'], ['config.hardware.numCPU', 'config.hardware.memoryMB', 'runtime.powerState'])
        expected = record['expected']['snapshotConfig']
        return {'verified': tree['current'] == p['snapshot'] and str(config['runtime.powerState']) == 'poweredOff' and all(config[field] == value for field, value in expected.items())}
