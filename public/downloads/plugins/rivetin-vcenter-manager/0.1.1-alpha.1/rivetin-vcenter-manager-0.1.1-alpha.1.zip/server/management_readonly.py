"""Actual read-only resource properties; no lifecycle mutation methods."""
import re
import copy
from xml.etree import ElementTree as ET

from .profiles import AdapterError
from .vsphere_readonly import KINDS, PATHS, ReadOnlyConnector, ref, sub, text
from .resource_scope import enrolled_objects, identity
from .device_inventory import device_inventory
from .cluster_inventory import cluster_inventory
from .host_network_inventory import NETWORK_PATHS, host_network_inventory
from .alarm_inventory import alarm_inventory
from .inventory_diagnostics import annotate

HOST_TEXT = ('summary.hardware.vendor', 'summary.hardware.model', 'summary.hardware.cpuModel', 'config.product.fullName', 'config.product.version', 'config.product.build')
HOST_NUMBERS = ('summary.hardware.memorySize', 'summary.hardware.cpuMhz', 'summary.hardware.numCpuPkgs', 'summary.hardware.numCpuCores', 'summary.hardware.numCpuThreads', 'summary.hardware.numNics', 'summary.hardware.numHBAs', 'summary.quickStats.overallCpuUsage', 'summary.quickStats.overallMemoryUsage', 'summary.quickStats.uptime')
VM_NUMBERS = ('summary.quickStats.overallCpuUsage', 'summary.quickStats.guestMemoryUsage')
VM_CONFIG_BOOLEANS = ('config.cpuHotAddEnabled', 'config.memoryHotAddEnabled', 'runtime.toolsInstallerMounted',
                      'capability.snapshotOperationsSupported', 'capability.poweredOffSnapshotsSupported', 'capability.memorySnapshotsSupported')
VM_CONFIG_NUMBERS = ('config.hotPlugMemoryLimit', 'config.hotPlugMemoryIncrementSize')
VM_CONFIG_TEXT = ('config.annotation', 'config.guestId')
CLUSTER_NUMBERS = ('summary.totalCpu', 'summary.totalMemory', 'summary.numCpuCores', 'summary.numCpuThreads', 'summary.effectiveCpu', 'summary.effectiveMemory', 'summary.numHosts', 'summary.numEffectiveHosts')


class RootDiscoveryConnector(ReadOnlyConnector):
    property_paths = {kind: ("name", "parent") for kind in ("Folder", "Datacenter", "ClusterComputeResource")}
    resource_kinds = frozenset(property_paths)


class ManagementReadConnector(ReadOnlyConnector):
    property_paths = {
        **PATHS,
        "ClusterComputeResource": CLUSTER_NUMBERS + ('configurationEx', 'triggeredAlarmState'),
        "HostSystem": PATHS["HostSystem"] + ("network", "datastore", "runtime.inMaintenanceMode", 'triggeredAlarmState') + HOST_TEXT + HOST_NUMBERS + NETWORK_PATHS,
        "Datastore": PATHS["Datastore"] + ("summary.accessible", "summary.type", "capability.perFileThinProvisioningSupported"),
        "VirtualMachine": PATHS["VirtualMachine"] + ("runtime.powerState", "runtime.connectionState", "config.template", "config.hardware.numCPU", "config.hardware.memoryMB", "guest.guestFullName", "guest.toolsRunningStatus", *VM_NUMBERS, "config.hardware.device", 'triggeredAlarmState') + VM_CONFIG_BOOLEANS + VM_CONFIG_NUMBERS + VM_CONFIG_TEXT,
        "Network": ("name", "parent"),
        'Alarm':('info.name',),
    }
    resource_kinds = KINDS | {"Network", "DistributedVirtualPortgroup", 'Alarm'}
    optional_properties = frozenset({"runtime.powerState", "config.template", "config.hardware.numCPU", "config.hardware.memoryMB", "guest.guestFullName", "guest.toolsRunningStatus", *VM_NUMBERS, "config.hardware.device", "runtime.inMaintenanceMode", "summary.accessible", 'configurationEx', 'triggeredAlarmState'}) | frozenset(HOST_TEXT + HOST_NUMBERS + CLUSTER_NUMBERS + NETWORK_PATHS + VM_NUMBERS + VM_CONFIG_BOOLEANS + VM_CONFIG_NUMBERS + VM_CONFIG_TEXT)
    optional_properties |= {('VirtualMachine', 'runtime.connectionState'), 'summary.type', 'capability.perFileThinProvisioningSupported'}

    def management_snapshot(self,records,selected):
        try:
            return self._management_snapshot(records, selected)
        except AdapterError as error:
            annotate(error, 3)
            raise

    def _management_snapshot(self,records,selected):
        result=self.snapshot(records);result['objects']=enrolled_objects(result,selected)
        for row in result['objects']:
            for field in VM_NUMBERS:
                if row['properties'].get(field, 0) is None: row['properties'].pop(field, None)
            if 'config.annotation' in row['properties'] and row['properties']['config.annotation'] is None:
                row['properties'].pop('config.annotation')
            config=row['properties'].pop('configurationEx',None)
            if config is not None:
                for name,values in config.items():row['properties']['configurationEx.'+name]=values
        allowed={identity(row['key']) for row in result['objects'] if row['key']['objectType'] in ('ClusterComputeResource','HostSystem','VirtualMachine')}
        alarms=set()
        for row in result['objects']:
            states=row['properties'].get('triggeredAlarmState')
            if states is None:continue
            if any(identity(state['entity']) not in allowed for state in states):
                row['properties'].pop('triggeredAlarmState');continue
            alarms|={identity(state['alarm'],'Alarm') for state in states}
        # Exact authorized references only. Names are auxiliary; failed enrichment
        # must not turn a verified state list into a fake empty list.
        if alarms and len(alarms)<=200:
            def fields(action):
                spec=sub(action,'specSet');prop=sub(spec,'propSet');sub(prop,'type','Alarm');sub(prop,'pathSet','info.name')
                for _,identifier in sorted(alarms):
                    obj=sub(spec,'objectSet');sub(obj,'obj',identifier,type='Alarm');sub(obj,'skip','false')
                sub(sub(action,'options'),'maxObjects',self.config['batchLimit'])
            try:
                named=self.collect(fields)
                for row in result['objects']:
                    for state in row['properties'].get('triggeredAlarmState',[]):
                        name=named.get(identity(state['alarm']),{}).get('properties',{}).get('info.name')
                        if name is not None:state['name']=name
            except AdapterError:
                pass  # State identity/status remain proven; name stays unknown.
        return result

    def inventory_selected(self, selected):
        if not isinstance(selected, list) or not selected or len(selected) > 2000:
            raise AdapterError("VC_PERMISSION_DENIED")
        keys = [identity(key, "ClusterComputeResource") for key in selected]
        if len(set(keys)) != len(keys):
            raise AdapterError("VC_PERMISSION_DENIED")
        self.service or self.service_content()
        def first_fields(action):
            spec = self.property_spec(action)
            for _, identifier in keys:
                obj = sub(spec, "objectSet"); sub(obj, "obj", identifier, type="ClusterComputeResource"); sub(obj, "skip", "false")
                host = sub(obj, "selectSet", **{"xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance", "xsi:type": "TraversalSpec"})
                sub(host, "name", "enrolledClusterHosts"); sub(host, "type", "ClusterComputeResource"); sub(host, "path", "host"); sub(host, "skip", "false")
                for path in ("vm", "network", "datastore"):
                    traversal = sub(host, "selectSet", **{"xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance", "xsi:type": "TraversalSpec"})
                    sub(traversal, "name", "enrolledHost" + path); sub(traversal, "type", "HostSystem"); sub(traversal, "path", path); sub(traversal, "skip", "false")
        records = self.collect(first_fields)
        # Read only ancestors of the exact selected clusters, not other roots.
        for _ in range(16):
            missing = set()
            for key in keys:
                row, visited = records.get(key), set()
                if row is None:
                    raise AdapterError("VC_INVENTORY_INCOMPLETE")
                while row["key"]["objectType"] != "Datacenter":
                    parent = row["properties"].get("parent")
                    if parent is None:
                        raise AdapterError("VC_INVENTORY_INCOMPLETE")
                    parent_key = identity(parent)
                    if parent_key[0] not in {"Folder", "Datacenter"} or parent_key in visited:
                        raise AdapterError("VC_INVENTORY_INCOMPLETE")
                    visited.add(parent_key)
                    if parent_key not in records:
                        missing.add(parent_key); break
                    row = records[parent_key]
            if not missing:
                return self.management_snapshot(records,selected)
            def ancestor_fields(action):
                spec = self.property_spec(action)
                for kind, identifier in sorted(missing):
                    obj = sub(spec, "objectSet"); sub(obj, "obj", identifier, type=kind); sub(obj, "skip", "false")
            self.collect(ancestor_fields, records)
            if any(key not in records for key in missing):
                raise AdapterError("VC_INVENTORY_INCOMPLETE")
        raise AdapterError("VC_INVENTORY_LIMIT")

    def parse_property(self, name, value):
        if name=='configurationEx':
            kind=value.get('{http://www.w3.org/2001/XMLSchema-instance}type','').split(':')[-1]
            if kind!='ClusterConfigInfoEx':raise AdapterError('VC_RESPONSE_INVALID')
            result={}
            for field,entry in (('group','ClusterGroupInfo'),('rule','ClusterRuleInfo')):
                array=ET.Element('val')
                for item in value.findall('{urn:vim25}'+field):
                    node=copy.deepcopy(item);node.tag='{urn:vim25}'+entry;array.append(node)
                result[field]=cluster_inventory(array,rules=field=='rule')
            from .managed_executor import CLUSTER_FIELDS, valid_cluster_field
            for field_name, (field, _) in CLUSTER_FIELDS.items():
                node = value.find('/'.join('{urn:vim25}' + part for part in field.split('.')))
                if node is None: continue
                raw = node.text
                rule = CLUSTER_FIELDS[field_name][1]
                if rule is bool:
                    if raw not in ('true', 'false', '1', '0'): raise AdapterError('VC_RESPONSE_INVALID')
                    raw = raw in ('true', '1')
                elif type(rule[0]) is int:
                    if raw not in ('1', '2', '3', '4', '5'): raise AdapterError('VC_RESPONSE_INVALID')
                    raw = int(raw)
                if not valid_cluster_field(field_name, raw): raise AdapterError('VC_RESPONSE_INVALID')
                result[field] = raw
            return result
        if name=='triggeredAlarmState':return alarm_inventory(value)
        if name=='info.name':return text(value.text,256)
        if name in NETWORK_PATHS:
            return host_network_inventory(name,value)
        if name in ('configurationEx.group', 'configurationEx.rule'):
            return cluster_inventory(value, rules=name == 'configurationEx.rule')
        if name in HOST_TEXT:
            return text(value.text)
        if name == "summary.type":
            return text(value.text, 64)
        if name in VM_NUMBERS and value.text == '-1': return None
        if name in HOST_NUMBERS + CLUSTER_NUMBERS + VM_NUMBERS + VM_CONFIG_NUMBERS:
            number = value.text or ''
            if not re.fullmatch(r'\d{1,16}', number) or int(number) > 9007199254740991:
                raise AdapterError('VC_RESPONSE_INVALID')
            return int(number)
        if name == 'config.hardware.device':
            return device_inventory(value)
        if name in ("config.template", "runtime.inMaintenanceMode", "summary.accessible", "capability.perFileThinProvisioningSupported") + VM_CONFIG_BOOLEANS:
            if value.text not in ("true", "false", "1", "0"):
                raise AdapterError("VC_RESPONSE_INVALID")
            return value.text in ("true", "1")
        if name in ("config.hardware.numCPU", "config.hardware.memoryMB"):
            number = value.text or ""
            if not re.fullmatch(r"\d{1,10}", number):
                raise AdapterError("VC_RESPONSE_INVALID")
            return int(number)
        if name == "runtime.powerState":
            if value.text not in ("poweredOn", "poweredOff", "suspended"):
                raise AdapterError("VC_RESPONSE_INVALID")
            return value.text
        if name == "guest.toolsRunningStatus":
            if value.text not in ("guestToolsRunning", "guestToolsNotRunning", "guestToolsExecutingScripts"):
                raise AdapterError("VC_RESPONSE_INVALID")
            return value.text
        if name == "config.annotation":
            annotation = value.text or ''
            if len(value) or any((ord(char) < 32 and char not in '\t\n\r') or ord(char) == 127 for char in annotation):
                raise AdapterError('VC_RESPONSE_INVALID')
            return annotation if len(annotation) <= 4096 else None
        if name == "config.guestId":
            return text(value.text, 80)
        if name == "guest.guestFullName":
            return text(value.text)
        if name in ("network", "datastore"):
            items = [ref(node) for node in value]
            kinds = {"Network", "DistributedVirtualPortgroup"} if name == "network" else {"Datastore"}
            if len(items) > 2000 or any(item["objectType"] not in kinds for item in items) or len({(item["objectType"], item["objectId"]) for item in items}) != len(items):
                raise AdapterError("VC_RESPONSE_INVALID")
            return items
        result = super().parse_property(name, value)
        if name in ("summary.capacity", "summary.freeSpace") and result > 9007199254740991:
            raise AdapterError("VC_RESPONSE_INVALID")
        return result
