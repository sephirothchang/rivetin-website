"""Finite C2 catalog; business operation parameters remain VC-owned."""
import copy
from .c1_projection import SCHEMA_ID, SCHEMA_VERSION, projection_schemas
from .managed_executor import ACTIVE_OPERATIONS as OPERATIONS, CLUSTER_FIELDS

METHODS = frozenset({'prepareOperation', 'submitOperation', 'readOperation', 'refreshOperation', 'recoverOperations', 'listOperations'})


def typed(kinds):
    return {'type': 'object', 'properties': {'objectType': {'type': 'string', 'enum': list(kinds), 'maxLength': 80},
            'objectId': {'type': 'string', 'maxLength': 128}}, 'required': ['objectType', 'objectId']}


def compact_prepare_schema(schema):
    """Omit only constraints already enforced by the FW registry and runtime."""
    if schema['type'] == 'string' and 'maxLength' in schema:
        limit = schema['maxLength']
        choices = schema.get('enum', ())
        if limit == 128 or choices and all(isinstance(value, str) and len(value) <= min(limit, 128) for value in choices):
            del schema['maxLength']
    if schema['type'] == 'integer':
        if schema.get('minimum') == 0:
            del schema['minimum']
        if schema.get('maximum') == 9007199254740991:
            del schema['maximum']
    for child in schema.get('properties', {}).values():
        compact_prepare_schema(child)
    if 'items' in schema:
        compact_prepare_schema(schema['items'])
    return schema


def operation_methods():
    text = lambda size: {'type': 'string', 'maxLength': size}
    values = projection_schemas()['adaptationSchema']
    base = {'connectionId': text(128), 'instanceId': text(128), 'scopeRevision': {'type': 'integer', 'minimum': 1, 'maximum': 9007199254740991},
            'selected': {'type': 'array', 'maxItems': 2000, 'items': typed(['ClusterComputeResource'])},
            'adaptation': {'type': 'object', 'properties': {'schemaId': {'type': 'string', 'enum': [SCHEMA_ID], 'maxLength': 128},
                'schemaVersion': {'type': 'integer', 'minimum': SCHEMA_VERSION, 'maximum': SCHEMA_VERSION}, 'values': values, 'digest': text(128)},
                'required': ['schemaId', 'schemaVersion', 'values']}}
    parameters = {'name': text(80), 'newName': text(80), 'annotation': text(1024), 'numCPUs': {'type': 'integer', 'minimum': 1, 'maximum': 128},
                  'memoryMB': {'type': 'integer', 'minimum': 128, 'maximum': 1048576}, 'host': typed(['HostSystem']),
                  'datastore': typed(['Datastore']), 'folder': typed(['Folder']), 'deleteDisks': {'type': 'boolean'},
                  'haEnabled': {'type': 'boolean'}, 'drsEnabled': {'type': 'boolean'}, 'pgName': text(80), 'vswitchName': text(80),
                  'vlanId': {'type': 'integer', 'minimum': 0, 'maximum': 4095},
                  'retainFiles': {'type': 'boolean'}, 'createEmpty': {'type': 'boolean'},
                  'guestId': {'type': 'string', 'enum': ['otherGuest64', 'otherLinux64Guest'], 'maxLength': 80}}
    parameters.update({'deviceKey': {'type': 'integer', 'minimum': 0, 'maximum': 2147483647},
                       'controllerKey': {'type': 'integer', 'minimum': -1, 'maximum': 2147483647},
                       'capacityGB': {'type': 'integer', 'minimum': 1, 'maximum': 65536}, 'diskId': text(36),
                       'network': typed(['Network']), 'startConnected': {'type': 'boolean'}, 'confirmDevice': {'type': 'boolean'}, 'confirmOffline': {'type': 'boolean'},
                       'firmware': {'type': 'string', 'enum': ['bios', 'efi'], 'maxLength': 8}, 'confirmProvision': {'type': 'boolean'},
                       'timeoutSeconds': {'type': 'integer', 'minimum': 1, 'maximum': 3600},
                       'confirmToolsMedia': {'type': 'boolean'}, 'confirmMaintenance': {'type': 'boolean'}, 'evacuatePoweredOffVms': {'type': 'boolean'}})
    device_fields = {name: copy.deepcopy(parameters[name]) for name in ('deviceKey', 'controllerKey', 'datastore', 'capacityGB', 'diskId', 'network', 'startConnected', 'confirmDevice', 'retainFiles')}
    parameters.update({'cpuHotAddEnabled': {'type': 'boolean'}, 'memoryHotAddEnabled': {'type': 'boolean'},
        'annotationLines': {'type': 'array', 'maxItems': 128, 'items': {'type': 'object', 'properties': {'text': text(1024)}, 'required': []}},
        'deviceChanges': {'type': 'array', 'maxItems': 20, 'items': {'type': 'object', 'properties': {
            'operation': {'type': 'string', 'enum': ['vm.disk.add', 'vm.disk.extend', 'vm.disk.remove', 'vm.nic.add', 'vm.nic.edit', 'vm.nic.remove'], 'maxLength': 80},
            'parameters': {'type': 'object', 'properties': device_fields, 'required': []}}, 'required': ['operation', 'parameters']}}})
    for name, (_, rule) in CLUSTER_FIELDS.items():
        parameters[name] = {'type': 'boolean'} if rule is bool else {'type': 'integer', 'minimum': rule[0], 'maximum': rule[1]} if type(rule[0]) is int else {'type': 'string', 'enum': list(rule), 'maxLength': 40}
    parameters.update({'groupName': text(80), 'groupKind': {'type': 'string', 'enum': ['vm','host'], 'maxLength': 8},
                       'members': {'type': 'array', 'maxItems': 200, 'items': typed(['VirtualMachine','HostSystem'])},
                       'ruleKey': {'type': 'integer', 'minimum': 0, 'maximum': 2147483647}, 'ruleName': text(80),
                       'ruleKind': {'type': 'string', 'enum': ['vmAffinity','vmAntiAffinity','vmHost'], 'maxLength': 20},
                       'enabled': {'type': 'boolean'}, 'mandatory': {'type': 'boolean'}, 'confirmRuleImpact': {'type': 'boolean'},
                       'vmGroupName': text(80), 'hostGroupName': text(80), 'affinity': {'type': 'string', 'enum': ['affine','antiAffine'], 'maxLength': 12}})
    parameters.update({'confirmNetworkImpact': {'type': 'boolean'}, 'confirmManagementImpact': {'type': 'boolean'},
                       'mtu': {'type': 'integer', 'minimum': 1280, 'maximum': 9000}, 'numPorts': {'type': 'integer', 'minimum': 8, 'maximum': 4096},
                       'device': text(16), 'dhcp': {'type': 'boolean'},
                       'ipv4Address': text(15), 'ipv4SubnetMask': text(15)})
    parameters.update({'alarm':typed(['Alarm']),'alarmKey':text(256),'triggeredAt':text(80),'confirmEmptyCluster':{'type':'boolean'},'confirmLive':{'type':'boolean'},'mode':text(8),
                       'networkMappings':{'type':'array','maxItems':200,'items':{'type':'object','properties':{'deviceKey':{'type':'integer','minimum':0,'maximum':2147483647},'network':typed(['Network'])},'required':['deviceKey','network']}}})
    definitions = {}
    # Alarm reset is deferred. Its unused confirmation field does not need a slot in the active schema.
    parameters.update({'hostName':text(45),'confirmHostEnrollment':{'type':'boolean'},
                       'snapshot':typed(['VirtualMachineSnapshot']), 'description':text(1024), 'confirmSnapshot':{'type':'boolean'},
                       'memory':{'type':'boolean'}, 'advancedHardware':text(4096)})
    for name in sorted(METHODS):
        properties, required = copy.deepcopy(base), list(base)
        if name == 'prepareOperation':
            properties.update({'key': typed(['VirtualMachine', 'ClusterComputeResource', 'HostSystem', 'Datastore','Datacenter','Folder']),
                               'operation': {'type': 'string', 'enum': sorted(OPERATIONS), 'maxLength': 80},
                               'parameters': {'type': 'object', 'properties': parameters, 'required': []}})
            required += ['key', 'operation', 'parameters']
        elif name == 'listOperations':
            properties['beforeId'] = text(36)
        elif name != 'recoverOperations':
            properties['operationId'] = text(36); required += ['operationId']
            if name == 'submitOperation':
                properties['planRef'] = text(43); required += ['planRef']
        credential = 'current' if name == 'prepareOperation' else 'operation' if name in {'submitOperation', 'refreshOperation'} else 'none'
        schema = {'type': 'object', 'properties': properties, 'required': required}
        definitions[name] = {'capability': 'vmware.management.write' if name in {'prepareOperation', 'submitOperation'} else 'vmware.management.observe',
                             'credential': credential, 'responseBytes': 256 * 1024, 'schema': compact_prepare_schema(schema) if name == 'prepareOperation' else schema}
        if name == 'submitOperation':
            definitions[name]['retainCredential'] = True
        if name in {'readOperation', 'refreshOperation', 'recoverOperations', 'listOperations'}:
            definitions[name]['observe'] = True
        definitions[name]['operationContextVersion'] = 1
        if name in {'prepareOperation','submitOperation','refreshOperation','listOperations'}:
            definitions[name]['authorizationRootsVersion'] = 1
        if name in {'prepareOperation','submitOperation'}:
            definitions[name]['credentialInputs'] = {'version':1,'names':['hostEnrollment'],'delivery':'metadata' if name=='prepareOperation' else 'secret'}
    return definitions
