"""Durable VC business intent and native Task records; never stores credentials."""
import contextlib
import copy
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import time
import uuid

from .profiles import AdapterError
from .resource_scope import identity

TERMINAL = frozenset({'success', 'error', 'rejected'})
ACTIVE = frozenset({'accepted', 'unknown', 'queued', 'running', 'verifying'})
OWNER_FIELDS = ('actorId', 'pluginId', 'providerId', 'connectionId', 'instanceId', 'origin', 'trustRef')
FORBIDDEN = frozenset({'secret', 'password', 'username', 'cookie', 'authorization', 'token', 'sessionkey', 'stagedsecretref'})
OPTIONAL_BINDINGS = ('operationContext', 'authorizationRoots')


def require(value, code='VC_OPERATION_INVALID'):
    if not value:
        raise AdapterError(code)


def canonical(value, *, max_string=4096):
    def check(node, depth=0):
        require(depth <= 12)
        if isinstance(node, dict):
            require(len(node) <= 80 and all(isinstance(key, str) and key.lower() not in FORBIDDEN for key in node))
            for item in node.values():
                check(item, depth + 1)
        elif isinstance(node, list):
            require(len(node) <= 200)
            for item in node:
                check(item, depth + 1)
        elif isinstance(node, str):
            require(len(node) <= max_string and not any(ord(char) < 32 for char in node))
        else:
            require(node is None or type(node) in (bool, int))
            if type(node) is int:
                require(abs(node) <= 9007199254740991)
    check(value)
    result = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    require(len(result.encode('utf-8')) <= 65536)
    return result


def owner(binding):
    result = {key: binding.get(key) for key in OWNER_FIELDS}
    require(all(isinstance(value, str) and 0 < len(value) <= 512 for value in result.values()))
    return canonical(result)


def operation_id(value):
    try:
        parsed = uuid.UUID(value)
    except (TypeError, ValueError, AttributeError):
        raise AdapterError('VC_OPERATION_INVALID') from None
    require(parsed.version == 4 and str(parsed) == value)
    return value


class OperationLedger:
    """Each accepted ID can be claimed once, including across process crashes.

    Acceptance is committed before network I/O. A crash in that gap sacrifices
    automatic retry, rather than risking a second remote mutation.
    """
    @staticmethod
    def _directory(directory):
        require(isinstance(directory, (str, Path)), 'VC_OPERATION_STORAGE_REQUIRED')
        root = Path(directory)
        require(root.is_absolute() and root.is_dir() and not root.is_symlink(), 'VC_OPERATION_STORAGE_REQUIRED')
        require(all(not parent.is_symlink() for parent in root.parents), 'VC_OPERATION_STORAGE_REQUIRED')
        return root

    @staticmethod
    def _sync_directory(root):
        if os.name != 'nt':
            fd = os.open(root, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
            try:
                os.fsync(fd)
            finally:
                os.close(fd)

    @staticmethod
    def _regular(path, *, minimum=1, maximum=65536):
        info = path.lstat()
        require(path.is_file() and not path.is_symlink() and info.st_nlink == 1 and minimum <= info.st_size <= maximum, 'VC_OPERATION_STORAGE_REQUIRED')
        require(os.name == 'nt' or not info.st_mode & 0o077, 'VC_OPERATION_STORAGE_REQUIRED')
        return info

    @classmethod
    def initialize(cls, directory, store_id):
        """Trusted explicit first provisioning only; normal opens never create files."""
        root = cls._directory(directory)
        operation_id(store_id)
        require(not list(root.iterdir()), 'VC_OPERATION_STORAGE_REQUIRED')
        marker = root / 'vc-operations-identity.json'
        dbpath = root / 'vc-operations.sqlite3'
        initial = {'schemaVersion': 1, 'storeId': store_id, 'generation': 0, 'state': 'initializing',
                   'rootDevice': str(root.stat().st_dev), 'rootInode': str(root.stat().st_ino)}
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(fd, 'wb') as output:
            output.write(canonical(initial).encode()); output.flush(); os.fsync(output.fileno())
        cls._sync_directory(root)
        fd = os.open(dbpath, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        os.close(fd)
        db = sqlite3.connect(dbpath.as_uri() + '?mode=rw', uri=True, isolation_level=None, timeout=1)
        try:
            db.execute('PRAGMA synchronous=FULL')
            db.executescript('''
                PRAGMA user_version=1;
                CREATE TABLE storage_identity(store_id TEXT PRIMARY KEY, generation INTEGER NOT NULL CHECK(generation>=0));
                CREATE TABLE schema_version(version INTEGER PRIMARY KEY CHECK(version=1));
                INSERT INTO schema_version VALUES(1);
                CREATE TABLE plans(proof TEXT PRIMARY KEY, owner TEXT NOT NULL, intent TEXT NOT NULL,
                  observation TEXT NOT NULL, expires REAL NOT NULL, used_by TEXT);
                CREATE TABLE operations(operation_id TEXT PRIMARY KEY, owner TEXT NOT NULL, intent TEXT NOT NULL,
                  intent_hash TEXT NOT NULL, binding TEXT NOT NULL, target TEXT NOT NULL, state TEXT NOT NULL,
                  task TEXT, result TEXT, error_code TEXT, created REAL NOT NULL, updated REAL NOT NULL);
                CREATE UNIQUE INDEX one_active_target ON operations(target)
                  WHERE state IN ('accepted','unknown','queued','running','verifying');
            ''')
            db.execute('INSERT INTO storage_identity VALUES(?,0)', (store_id,))
        finally:
            db.close()
        info = cls._regular(dbpath, minimum=4096, maximum=64 * 1024 * 1024)
        initial.update(state='ready', databaseDevice=str(info.st_dev), databaseInode=str(info.st_ino))
        cls._replace_marker(root, initial)
        return {'dataStoreId': store_id, 'initialized': True}

    @classmethod
    def _replace_marker(cls, root, marker):
        destination = root / 'vc-operations-identity.json'
        cls._regular(destination)
        temporary = root / ('vc-identity-' + secrets.token_hex(16) + '.tmp')
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(fd, 'wb') as output:
            output.write(canonical(marker).encode()); output.flush(); os.fsync(output.fileno())
        os.replace(temporary, destination)
        cls._sync_directory(root)

    def __init__(self, directory, *, store_id, now=time.time, max_records=10000):
        root = self._directory(directory)
        operation_id(store_id)
        self.root, self.store_id = root, store_id
        self.path, self.now, self.max_records = root / 'vc-operations.sqlite3', now, max_records
        require(type(max_records) is int and 1 <= max_records <= 10000)
        self._marker()
        self.db = None
        try:
            self.db = sqlite3.connect(self.path.as_uri() + '?mode=rw', uri=True, isolation_level=None, timeout=1, check_same_thread=False)
            self.db.row_factory = sqlite3.Row
            self.db.execute('BEGIN IMMEDIATE')
            self._healthy()
            require([tuple(row) for row in self.db.execute('PRAGMA quick_check')] == [('ok',)], 'VC_OPERATION_STORAGE_REQUIRED')
            require(self.db.execute('PRAGMA user_version').fetchone()[0] == 1 and [row[0] for row in self.db.execute('SELECT version FROM schema_version')] == [1], 'VC_OPERATION_STORAGE_REQUIRED')
            expected = {'plans': ['proof','owner','intent','observation','expires','used_by'],
                        'operations': ['operation_id','owner','intent','intent_hash','binding','target','state','task','result','error_code','created','updated']}
            for table, names in expected.items():
                require([row[1] for row in self.db.execute('PRAGMA table_info(' + table + ')')] == names, 'VC_OPERATION_STORAGE_REQUIRED')
            require(self.db.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name='one_active_target'").fetchone()[0] == 1, 'VC_OPERATION_STORAGE_REQUIRED')
            self.db.execute('ROLLBACK')
            require(self.db.execute('PRAGMA journal_mode=WAL').fetchone()[0].lower() == 'wal', 'VC_OPERATION_STORAGE_REQUIRED')
            self.db.execute('PRAGMA synchronous=FULL')
            self.db.execute('PRAGMA busy_timeout=1000')
            page_size = self.db.execute('PRAGMA page_size').fetchone()[0]
            self.db.execute('PRAGMA max_page_count=' + str(64 * 1024 * 1024 // page_size))
        except (OSError, ValueError, sqlite3.Error, AdapterError):
            if self.db is not None:
                self.db.close()
            raise AdapterError('VC_OPERATION_STORAGE_REQUIRED') from None

    def _marker(self):
        try:
            root = self._directory(self.root)
            markerpath = root / 'vc-operations-identity.json'
            self._regular(markerpath)
            marker = json.loads(markerpath.read_text(encoding='utf-8'))
            require(set(marker) == {'schemaVersion','storeId','generation','state','rootDevice','rootInode','databaseDevice','databaseInode'}, 'VC_OPERATION_STORAGE_REQUIRED')
            info = self._regular(self.path, minimum=4096, maximum=64 * 1024 * 1024)
            with self.path.open('rb') as source:
                require(source.read(16) == b'SQLite format 3\x00', 'VC_OPERATION_STORAGE_REQUIRED')
            require(marker['schemaVersion'] == 1 and marker['storeId'] == self.store_id and marker['state'] == 'ready' and type(marker['generation']) is int and marker['generation'] >= 0, 'VC_OPERATION_STORAGE_REQUIRED')
            require((marker['rootDevice'],marker['rootInode']) == (str(root.stat().st_dev),str(root.stat().st_ino)) and (marker['databaseDevice'],marker['databaseInode']) == (str(info.st_dev),str(info.st_ino)), 'VC_OPERATION_STORAGE_REQUIRED')
            return marker
        except (OSError, ValueError, TypeError):
            raise AdapterError('VC_OPERATION_STORAGE_REQUIRED') from None

    def _healthy(self):
        marker = self._marker()
        rows = [tuple(row) for row in self.db.execute('SELECT store_id,generation FROM storage_identity')]
        require(rows == [(self.store_id, marker['generation'])], 'VC_OPERATION_STORAGE_REQUIRED')
        return marker

    @contextlib.contextmanager
    def transaction(self):
        marker = None
        try:
            self.db.execute('BEGIN IMMEDIATE')
            marker = self._healthy()
            self._replace_marker(self.root, marker | {'state': 'writing'})
            yield
            self.db.execute('UPDATE storage_identity SET generation=generation+1 WHERE store_id=?', (self.store_id,))
            self.db.execute('COMMIT')
            self._replace_marker(self.root, marker | {'generation': marker['generation'] + 1})
        except sqlite3.Error:
            if self.db.in_transaction:
                self.db.execute('ROLLBACK')
                if marker is not None:
                    self._replace_marker(self.root, marker)
            raise AdapterError('VC_OPERATION_STORAGE_UNAVAILABLE') from None
        except BaseException:
            if self.db.in_transaction:
                self.db.execute('ROLLBACK')
                if marker is not None:
                    self._replace_marker(self.root, marker)
            raise

    def create_plan(self, binding, intent, observation, *, ttl=300):
        owner_text, intent_text = owner(binding), canonical(intent)
        context = {key: binding[key] for key in ('credentialVersion', 'policyVersion', 'packageDigest', 'connectorRelease') + OPTIONAL_BINDINGS if key in binding}
        observed = canonical({'facts': observation, 'context': context}, max_string=32768)
        require(type(ttl) is int and 1 <= ttl <= 300)
        require(isinstance(intent, dict) and set(intent) == {'connectionId', 'instanceId', 'key', 'operation', 'parameters', 'expected', 'scopeRevision'})
        require(intent['connectionId'] == binding['connectionId'] and intent['instanceId'] == binding['instanceId'])
        identity(intent['key'])
        require(isinstance(intent['operation'], str) and 1 <= len(intent['operation']) <= 80 and intent['operation'].replace('.', '').isalnum())
        require(isinstance(intent['parameters'], dict) and isinstance(intent['expected'], dict))
        require(type(intent['scopeRevision']) is int and intent['scopeRevision'] >= 1)
        proof, expires = secrets.token_urlsafe(32), self.now() + ttl
        with self.transaction():
            self.db.execute('DELETE FROM plans WHERE expires < ? AND used_by IS NULL', (self.now(),))
            require(self.db.execute('SELECT COUNT(*) FROM plans').fetchone()[0] < self.max_records, 'VC_OPERATION_CAPACITY_EXHAUSTED')
            self.db.execute('INSERT INTO plans VALUES(?,?,?,?,?,NULL)', (proof, owner_text, intent_text, observed, expires))
        return {'planRef': proof, 'expiresAtMs': int(expires * 1000), 'intent': copy.deepcopy(intent), 'observation': copy.deepcopy(observation)}

    def plan(self, binding, proof, *, for_operation_id=None):
        self._healthy()
        require(isinstance(proof, str) and len(proof) == 43)
        row = self.db.execute('SELECT * FROM plans WHERE proof=? AND owner=?', (proof, owner(binding))).fetchone()
        require(row is not None, 'VC_OPERATION_PLAN_EXPIRED')
        replay = for_operation_id is not None and row['used_by'] == operation_id(for_operation_id)
        require(replay or row['expires'] > self.now(), 'VC_OPERATION_PLAN_EXPIRED')
        require(row['used_by'] is None or replay, 'VC_OPERATION_PLAN_USED')
        observed = json.loads(row['observation'])
        if not replay:
            require(all(binding.get(key) == value for key, value in observed['context'].items()), 'VC_OPERATION_PLAN_CHANGED')
            require(all((key in binding) == (key in observed['context']) for key in OPTIONAL_BINDINGS), 'VC_OPERATION_PLAN_CHANGED')
        return {'intent': json.loads(row['intent']), 'observation': observed['facts']}

    def accept(self, binding, identifier, proof, *, expected_intent):
        identifier = operation_id(identifier)
        if 'operationContext' in binding:
            require(binding['operationContext']['operationId'] == identifier, 'VC_OPERATION_INTENT_MISMATCH')
        owner_text, intent_text = owner(binding), canonical(expected_intent)
        # Persist only non-secret identity/lease metadata, never the call context wholesale.
        metadata = {key: binding[key] for key in ('packageDigest', 'policyVersion', 'connectorRelease', 'credentialVersion', 'credentialLeaseId') + OPTIONAL_BINDINGS if key in binding}
        require(binding.get('credentialLeaseActive') is True and isinstance(metadata.get('credentialLeaseId'), str), 'VC_OPERATION_CREDENTIAL_REQUIRED')
        now = self.now()
        with self.transaction():
            existing = self.db.execute('SELECT * FROM operations WHERE operation_id=?', (identifier,)).fetchone()
            if existing:
                require(existing['owner'] == owner_text, 'VC_OPERATION_PERMISSION_DENIED')
                require(existing['intent'] == intent_text, 'VC_OPERATION_INTENT_MISMATCH')
                return {'claimed': False, 'operation': self._record(existing)}
            row = self.db.execute('SELECT * FROM plans WHERE proof=? AND owner=?', (proof, owner_text)).fetchone()
            require(row is not None and row['expires'] > now, 'VC_OPERATION_PLAN_EXPIRED')
            require(row['used_by'] is None and row['intent'] == intent_text, 'VC_OPERATION_INTENT_MISMATCH')
            observed = json.loads(row['observation'])
            require(all(binding.get(key) == value for key, value in observed['context'].items()), 'VC_OPERATION_PLAN_CHANGED')
            require(all((key in binding) == (key in observed['context']) for key in OPTIONAL_BINDINGS), 'VC_OPERATION_PLAN_CHANGED')
            require(self.db.execute('SELECT COUNT(*) FROM operations').fetchone()[0] < self.max_records, 'VC_OPERATION_CAPACITY_EXHAUSTED')
            target = canonical({key: binding[key] for key in ('providerId', 'origin', 'instanceId')} | {'key': expected_intent['key']})
            require(self.db.execute("SELECT 1 FROM operations WHERE target=? AND state IN ('accepted','unknown','queued','running','verifying')", (target,)).fetchone() is None, 'VC_OPERATION_TARGET_BUSY')
            self.db.execute('INSERT INTO operations VALUES(?,?,?,?,?,?,?,NULL,NULL,NULL,?,?)',
                            (identifier, owner_text, intent_text, hashlib.sha256(intent_text.encode()).hexdigest(), canonical(metadata, max_string=32768), target, 'accepted', now, now))
            self.db.execute('UPDATE plans SET used_by=? WHERE proof=?', (identifier, proof))
        return {'claimed': True, 'operation': self.read(binding, identifier)}

    def _record(self, row):
        return {'operationId': row['operation_id'], **json.loads(row['intent']), 'state': row['state'],
                'task': json.loads(row['task']) if row['task'] else None, 'result': json.loads(row['result']) if row['result'] else None,
                'errorCode': row['error_code'], 'createdAtMs': int(row['created'] * 1000), 'updatedAtMs': int(row['updated'] * 1000)}

    def read(self, binding, identifier):
        self._healthy()
        row = self.db.execute('SELECT * FROM operations WHERE operation_id=? AND owner=?', (operation_id(identifier), owner(binding))).fetchone()
        return self._record(row) if row is not None else None

    def credential_binding(self, binding, identifier, *, require_active=True):
        self._healthy()
        row = self.db.execute('SELECT binding FROM operations WHERE operation_id=? AND owner=?', (operation_id(identifier), owner(binding))).fetchone()
        require(row is not None, 'VC_OPERATION_NOT_FOUND')
        stored = json.loads(row['binding'])
        require(all(binding.get(key) == stored.get(key) and (key in binding) == (key in stored) for key in OPTIONAL_BINDINGS), 'VC_OPERATION_CREDENTIAL_REQUIRED')
        require(binding.get('credentialLeaseId') == stored.get('credentialLeaseId') and binding.get('credentialVersion') == stored.get('credentialVersion'), 'VC_OPERATION_CREDENTIAL_REQUIRED')
        require(type(binding.get('credentialLeaseActive')) is bool and (not require_active or binding['credentialLeaseActive']), 'VC_OPERATION_CREDENTIAL_REQUIRED')
        return stored

    def update(self, binding, identifier, state, *, task=None, result=None, error_code=None):
        require(state in ACTIVE | TERMINAL)
        if task is not None:
            identity(task, 'Task')
        if error_code is not None:
            require(isinstance(error_code, str) and error_code.startswith('VC_') and len(error_code) <= 100 and error_code.replace('_', '').isalnum())
        with self.transaction():
            row = self.db.execute('SELECT * FROM operations WHERE operation_id=? AND owner=?', (operation_id(identifier), owner(binding))).fetchone()
            require(row is not None, 'VC_OPERATION_NOT_FOUND')
            require(row['state'] not in TERMINAL or row['state'] == state, 'VC_OPERATION_STATE_CONFLICT')
            require(state != 'accepted' or row['state'] == 'accepted', 'VC_OPERATION_STATE_CONFLICT')
            require(not (row['state'] == 'running' and state == 'queued'), 'VC_OPERATION_STATE_CONFLICT')
            stored_task = json.loads(row['task']) if row['task'] else None
            require(task is None or stored_task is None or stored_task == task, 'VC_OPERATION_TASK_MISMATCH')
            if row['state'] in TERMINAL:
                require(task is None or task == stored_task, 'VC_OPERATION_TASK_MISMATCH')
                require(result is None or row['result'] == canonical(result), 'VC_OPERATION_STATE_CONFLICT')
                require(error_code is None or error_code == row['error_code'], 'VC_OPERATION_STATE_CONFLICT')
            require(state not in ('queued', 'running') or task is not None or stored_task is not None)
            next_error = None if state == 'success' and row['state'] not in TERMINAL else error_code or row['error_code']
            self.db.execute('UPDATE operations SET state=?,task=?,result=?,error_code=?,updated=? WHERE operation_id=?',
                            (state, canonical(task or stored_task) if task or stored_task else None, canonical(result) if result is not None else row['result'], next_error, self.now(), identifier))
        return self.read(binding, identifier)

    def recover(self, binding, *, limit=50):
        self._healthy()
        require(type(limit) is int and 1 <= limit <= 50)
        rows = self.db.execute("SELECT * FROM operations WHERE owner=? AND state IN ('accepted','unknown','queued','running','verifying') ORDER BY created,operation_id LIMIT ?", (owner(binding), limit + 1)).fetchall()
        require(len(rows) <= limit, 'VC_OPERATION_RECOVERY_INCOMPLETE')
        return [self._record(row) for row in rows]

    def history(self, binding, scope_revision, selected, parent_roots, before_id=None):
        self._healthy()
        principal = owner(binding)
        filters = ["owner=?", "json_extract(intent,'$.scopeRevision')=?"]
        args = [principal, scope_revision]
        kind = "json_extract(intent,'$.key.objectType')"
        object_id = "json_extract(intent,'$.key.objectId')"
        operation = "json_extract(intent,'$.operation')"
        # Old schema-1 rows contain the scope revision but no historical scope
        # membership proof. A changed revision cannot authorize bulk disclosure.
        purposes = {'vmware.cluster.create': 'cluster.create', 'vmware.alarm.acknowledge': 'alarm.acknowledge',
                    'vmware.alarm.reset': 'alarm.resetGreen'}
        grants = [{'kind': row['objectType'], 'id': row['objectId'], 'operation': purposes[purpose]}
                  for row in parent_roots for purpose in row['purposes'] if purpose in purposes]
        filters.append(f"""(
            ({kind}='ClusterComputeResource' AND {object_id} IN (SELECT value FROM json_each(?)))
            OR (? AND {kind} NOT IN ('ClusterComputeResource','Datacenter','Folder'))
            OR EXISTS (SELECT 1 FROM json_each(?) AS grants
                       WHERE json_extract(grants.value,'$.kind')={kind}
                       AND json_extract(grants.value,'$.id')={object_id}
                       AND json_extract(grants.value,'$.operation')={operation})
        )""")
        args.extend((json.dumps([key['objectId'] for key in selected]), bool(selected), json.dumps(grants)))
        if before_id is not None:
            filters.append("""(created,operation_id) < (SELECT created,operation_id FROM operations
                            WHERE owner=? AND json_extract(intent,'$.scopeRevision')=? AND operation_id=?)""")
            args.extend((principal, scope_revision, operation_id(before_id)))
        rows = self.db.execute('SELECT * FROM operations WHERE ' + ' AND '.join(filters) +
                               ' ORDER BY created DESC,operation_id DESC LIMIT 51', args).fetchall()
        fields = ('operationId', 'connectionId', 'instanceId', 'scopeRevision', 'key', 'operation', 'state',
                  'task', 'errorCode', 'createdAtMs', 'updatedAtMs')
        items = [{key: record[key] for key in fields} for record in map(self._record, rows[:50])]
        return {'items': items, 'nextBeforeId': items[-1]['operationId'] if len(rows) > 50 else None}

    def close(self):
        self.db.close()
