import { isIP } from 'node:net';
import { createVmwarePodProvider } from './pod_provider.mjs';
import { createProviderTransportPolicy } from '../runtime-support/server/provider-transport-policy.js';
import { createInventoryCache, withInventoryCache } from './inventory_cache.mjs';

const criticalMethods = new Set(['probe', 'discover', 'revalidate', 'prepareOperation', 'submitOperation', 'readOperation', 'refreshOperation', 'recoverOperations']);
const operationStates = new Set(['accepted', 'queued', 'running', 'verifying', 'success', 'rejected', 'failed', 'unknown', 'error', 'not-accepted', 'not-found', 'cancelled']);
const uuid = /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i;
const pluginId = 'rivetin-vcenter-manager';
// Framework control method: full replacement of the desired vCenter target set.
const controlMethod = 'provider.targets.apply';
const maximumTargets = 4;
const targetKeys = ['origin', 'trustRef', 'policyVersion', 'addresses'];
const targetOptionalKeys = [...targetKeys, 'caPem'];
const unavailable = () => Object.assign(new Error('WORKLOAD_UNAVAILABLE'),
  { code: 'WORKLOAD_UNAVAILABLE', outcome: 'not-accepted' });
const invalidTargets = reason => Object.assign(new Error('VC_TARGET_APPLY_FAILED'),
  { code: 'VC_TARGET_APPLY_FAILED', outcome: 'not-accepted', reason });
const staleGeneration = (generation, appliedGeneration) => Object.assign(new Error('VC_TARGET_GENERATION_STALE'),
  { code: 'VC_TARGET_GENERATION_STALE', outcome: 'not-accepted', generation, appliedGeneration });
const failedApply = cause => {
  const error = Object.assign(new Error('VC_TARGET_APPLY_FAILED'), { code: 'VC_TARGET_APPLY_FAILED', outcome: 'unknown',
    cause: podErrorCode(cause, 'VC_TARGET_APPLY_FAILED') });
  if (typeof cause?.origin === 'string') error.origin = cause.origin;
  if (typeof cause?.reason === 'string') error.reason = cause.reason;
  return error;
};
const maximumCauseCharacters = 200;
// Diagnostic-only cause summary: bounded and stripped of PEM bodies and obvious
// credential assignments so the control-plane log cannot echo trust material.
function failureCause(error) {
  const causeName = typeof error?.name === 'string' && error.name ? error.name.slice(0, 64) : undefined;
  let causeMessage;
  if (typeof error?.message === 'string' && error.message) {
    causeMessage = error.message
      .replace(/-----BEGIN [A-Z0-9 ]+-----[\s\S]*?(?:-----END [A-Z0-9 ]+-----|$)/g, '[redacted-pem]')
      .replace(/\b(password|passwd|secret|token|authorization)\s*[:=]\s*\S+/gi, '$1=[redacted]')
      .replace(/\s+/g, ' ').trim();
    if (causeMessage.length > maximumCauseCharacters) causeMessage = causeMessage.slice(0, maximumCauseCharacters);
  }
  return { ...(causeName === undefined ? {} : { causeName }), ...(causeMessage ? { causeMessage } : {}) };
}

export function podErrorCode(error, fallback) {
  return typeof error?.code === 'string' && /^(?:(?:VC|CONNECTION|WORKLOAD)_[A-Z0-9_]{1,80}|ENOENT|EACCES|EADDRINUSE|ECONNREFUSED|ECONNRESET|ETIMEDOUT)$/.test(error.code)
    ? error.code : fallback;
}

function targetPolicy(target) {
  return { origin: target.origin, trustRef: target.trustRef, policyVersion: target.policyVersion, addresses: [...target.addresses] };
}
function targetIdentity(target) {
  return JSON.stringify([target.origin, target.trustRef, target.policyVersion, [...target.addresses].sort()]);
}
function targetDefinition(value) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw invalidTargets('target');
  const keys = Object.keys(value);
  if (targetKeys.some(key => !keys.includes(key)) || keys.some(key => !targetOptionalKeys.includes(key))) throw invalidTargets('target');
  let url;
  try { url = new URL(value.origin); } catch { throw invalidTargets('origin'); }
  const hostname = url.hostname.replace(/^\[|\]$/g, '');
  if (url.protocol !== 'https:' || url.origin !== value.origin || url.username || url.password ||
      url.search || url.hash || url.pathname !== '/' || !isIP(hostname)) throw invalidTargets('origin');
  if (!Array.isArray(value.addresses) || !value.addresses.length || value.addresses.length > 8) throw invalidTargets('addresses');
  if (value.caPem !== undefined && (typeof value.caPem !== 'string' || Buffer.byteLength(value.caPem) > 65536)) throw invalidTargets('caPem');
  return { origin: value.origin, trustRef: value.trustRef, policyVersion: value.policyVersion,
    addresses: [...value.addresses], ...(value.caPem === undefined ? {} : { caPem: value.caPem }) };
}
function targetList(values) {
  if (!Array.isArray(values) || values.length > maximumTargets) throw invalidTargets('targets');
  const targets = values.map(targetDefinition);
  if (new Set(targets.map(row => row.origin)).size !== targets.length) throw invalidTargets('targets');
  if (targets.length) {
    try { createProviderTransportPolicy({ targets: targets.map(targetPolicy) }); }
    catch (error) { throw invalidTargets(podErrorCode(error, 'CONNECTION_NETWORK_POLICY_DENIED')); }
  }
  return targets;
}
function targetApplyPayload(input) {
  if (input === null || typeof input !== 'object' || Array.isArray(input) ||
      input.payload === null || typeof input.payload !== 'object' || Array.isArray(input.payload) ||
      Object.keys(input).some(key => !['payload', 'binding', 'deadlineMs'].includes(key))) throw invalidTargets('input');
  const payload = input.payload;
  const keys = Object.keys(payload);
  if (!keys.includes('generation') || !keys.includes('targets') ||
      keys.some(key => !['generation', 'targets'].includes(key))) throw invalidTargets('payload');
  if (!Number.isSafeInteger(payload.generation) || payload.generation < 1) throw invalidTargets('generation');
  return { generation: payload.generation, targets: payload.targets };
}
function diffTargets(applied, desired) {
  const add = [], remove = [];
  for (const [origin, target] of desired) {
    const current = applied.get(origin);
    if (!current) add.push(target);
    else if (targetIdentity(current) !== targetIdentity(target)) { remove.push(origin); add.push(target); }
  }
  for (const origin of applied.keys()) if (!desired.has(origin)) remove.push(origin);
  return { add, remove };
}

export function createVmwarePodBackend({ tls, frameworkPin, identity, framework, connector, businessMethods,  createBackendServer, createPermitMonitor, pollIntervalMs, onStartupFailure, log = () => {}, summaryIntervalMs = 45_000, connectorRequired = true, initialTargets = [], inventoryCache }) {
  const inventory = inventoryCache ?? createInventoryCache();
  const provider = createVmwarePodProvider({ businessMethods, connector: withInventoryCache(connector, inventory) });
  const methods = Object.freeze({ ...provider.methods, [controlMethod]: 'submit' });
  const active = new Set();
  let admission = new AbortController();
  let stopping = false;
  let timer, summaryTimer, pending;
  let connectorStarted = false;
  let previousState;
  let completed = 0, failed = 0, suppressed = 0;
  const recentFailures = new Set();
  const recentOperations = new Set();
  let startupApplied;
  try { startupApplied = targetList(initialTargets); }
  catch { throw Object.assign(new Error('CONNECTION_SCHEMA_INVALID'), { code: 'CONNECTION_SCHEMA_INVALID' }); }
  const targets = { generation: 0, applied: new Map(startupApplied.map(target => [target.origin, target])) };
  let applyQueue = Promise.resolve();
  function serializeApply(task) {
    const run = applyQueue.then(task, task);
    applyQueue = run.then(() => undefined, () => undefined);
    return run;
  }
  function operation(event, fields) {
    const key = JSON.stringify([event, fields.method, fields.originalOperationId ?? fields.operationId, fields.state]);
    if (recentOperations.has(key) || recentOperations.size >= 64) { suppressed++; return; }
    recentOperations.add(key);
    log('INFO', event, fields);
  }
  function failure(event, fields) {
    const key = event + ':' + fields.errorCode;
    if (recentFailures.has(key) || recentFailures.size >= 16) { suppressed++; return; }
    recentFailures.add(key);
    log('WARN', event, fields);
  }
  const permits = createPermitMonitor({ async renew() {
    try { return await framework.permit(identity); }
    catch (error) {
      failure('permit-failed', { errorCode: podErrorCode(error, 'WORKLOAD_PERMIT_REQUEST_FAILED') });
      throw error;
    }
  }, async onPause() {
    admission.abort();
    observeState();
    await Promise.allSettled(active);
  } });
  // The Pod is ready to serve the framework control plane (including target
  // delivery) as soon as the permit is active. Connector processes for the
  // desired targets are then established one by one; a target that is down must
  // never take the control plane offline, or the framework could not deliver a
  // replacement target set.
  const connectorNeeded = () => connectorRequired || targets.applied.size > 0;
  const ready = () => !stopping && Boolean(permits.current());
  function state() {
    if (stopping) return 'stopping';
    if (!permits.current()) return 'waiting-for-permit';
    if (!connectorNeeded()) return 'ready';
    return connector.ready() ? 'ready' : 'starting-connector';
  }
  function observeState() {
    const current = state();
    if (current !== previousState) {
      log('INFO', 'state-changed', { state: current, previousState: previousState ?? null });
      previousState = current;
    }
  }
  function controlsTargets(call) {
    return call?.method === controlMethod && call.capability === 'vmware.provider' &&
      call.interfaceVersion === 1 && (call.kind === 'submit' || call.kind === 'read') &&
      (call.caller?.pluginId === null || call.caller?.pluginId === pluginId);
  }
  async function repairTargets() {
    // Nothing to repair when every desired instance is already live, and a Pod
    // without any applied target never needs its connector or storage proven.
    if (connector.ready() || targets.applied.size === 0) return;
    try { await connector.applyTargets({ add: [...targets.applied.values()], remove: [] }); }
    catch (error) {
      const applyFailure = failedApply(error);
      failure('targets-apply-failed', { replay: true, errorCode: applyFailure.code, causeErrorCode: applyFailure.cause,
        ...failureCause(error),
        ...(applyFailure.reason === undefined ? {} : { reason: applyFailure.reason }),
        ...(applyFailure.origin === undefined ? {} : { origin: applyFailure.origin }) });
      throw applyFailure;
    }
  }
  function applyTargetsInput(input) {
    return serializeApply(async () => {
      if (stopping || !permits.current()) throw unavailable();
      const { generation, targets: requested } = targetApplyPayload(input);
      if (generation < targets.generation) {
        log('WARN', 'targets-apply-stale', { generation, appliedGeneration: targets.generation });
        throw staleGeneration(generation, targets.generation);
      }
      if (generation === targets.generation) {
        // An identical generation is an idempotent replay. Repairing a lost
        // connector child is still safe: the desired set is unchanged.
        await repairTargets();
        log('INFO', 'targets-apply-replay', { generation });
        return { payload: { generation, applied: true } };
      }
      const desired = new Map(targetList(requested).map(target => [target.origin, target]));
      const { add, remove } = diffTargets(targets.applied, desired);
      // A generation that does not change the applied target set is a pure
      // bookkeeping update. It must not require a connector process or a
      // storage proof: a freshly deployed Pod has none, and replacing zero
      // targets with zero targets is still a successful, idempotent apply.
      const changed = add.length > 0 || remove.length > 0;
      if (changed) {
        try { await connector.applyTargets({ add, remove }); }
        catch (error) {
          const applyFailure = failedApply(error);
          const fields = { generation, errorCode: applyFailure.code, causeErrorCode: applyFailure.cause, ...failureCause(error),
            ...(applyFailure.reason === undefined ? {} : { reason: applyFailure.reason }),
            ...(applyFailure.origin === undefined ? {} : { origin: applyFailure.origin }),
            ...(applyFailure.reason === 'TARGET_CA_REQUIRED' && applyFailure.origin !== undefined ? { missingCa: [applyFailure.origin] } : {}) };
          failure('targets-apply-failed', fields);
          throw applyFailure;
        }
        // Target removal/replacement deletes or rewrites the connections those
        // targets served, so no cached inventory may survive it.
        inventory.clear();
      }
      targets.generation = generation;
      targets.applied = desired;
      observeState();
      log('INFO', 'targets-applied', { generation, added: add.map(target => target.origin), removed: remove });
      return { payload: { generation, applied: true } };
    });
  }
  function executeTargets(call) {
    const invocation = applyTargetsInput(call.input);
    active.add(invocation);
    invocation.then(() => active.delete(invocation), () => active.delete(invocation));
    return invocation;
  }

  const server = createBackendServer({ tls, frameworkPin, identity, framework, permits,
    authorize: call => provider.supports(call) || controlsTargets(call),
    // Control-plane readiness: the framework must be able to deliver targets
    // while connector processes are still being established or are unavailable.
    ready: () => !stopping,
    async execute(call, { claimCredential }) {
      if (call.method === controlMethod) {
        if (stopping || !permits.current()) throw unavailable();
        return executeTargets(call);
      }
      const method = Object.hasOwn(methods, call.method) ? call.method : 'unsupported';
      const fields = { method, ...(typeof call.operationId === 'string' && uuid.test(call.operationId) ? { operationId: call.operationId } : {}) };
      const original = method === 'refreshOperation' ? call.input?.payload?.operationId : undefined;
      if (typeof original === 'string' && uuid.test(original)) fields.originalOperationId = original;
      if (method === 'prepareOperation' || method === 'submitOperation') operation('operation-started', fields);
      let invocation;
      try {
        if (call.kind === 'observe') invocation = provider.invoke(call);
        else {
          if (stopping || !permits.current()) throw unavailable();
          if (admission.signal.aborted) admission = new AbortController();
          invocation = provider.invoke(call, { signal: admission.signal, claimCredential });
          active.add(invocation);
        }
        const result = await invocation;
        const candidateState = result?.data?.state ?? result?.data?.operation?.state ?? result?.data?.kind;
        const resultState = operationStates.has(candidateState) ? candidateState : undefined;
        if (['rejected', 'failed', 'unknown', 'error', 'not-accepted'].includes(resultState)) {
          failed++;
          failure('operation-failed', { ...fields, state: resultState, errorCode: podErrorCode({ code: result.data.errorCode }, 'VC_OPERATION_FAILED') });
        } else {
          completed++;
          if (criticalMethods.has(method)) operation('operation-returned', { ...fields, ...(resultState ? { state: resultState } : {}) });
          // A successful mutating call invalidates the cached inventory of the
          // affected connection (or all entries when the scope is unknown).
          if (call.kind === 'submit') {
            const connectionId = call.input?.binding?.connectionId, instanceId = call.input?.binding?.instanceId;
            if (typeof connectionId === 'string' && connectionId) {
              inventory.invalidate({ connectionId, ...(typeof instanceId === 'string' && instanceId ? { instanceId } : {}) });
            } else inventory.clear();
          }
        }
        return result;
      } catch (error) {
        failed++;
        failure('operation-failed', { ...fields, errorCode: podErrorCode(error, 'VC_OPERATION_FAILED') });
        throw error;
      } finally { active.delete(invocation); }
    },
  });

  function tick() {
    if (stopping || pending) return;
    pending = (async () => {
      await permits.poll();
      observeState();
      if (stopping || connectorStarted || !permits.current()) return;
      if (!connectorRequired && targets.applied.size === 0) return;
      connectorStarted = true;
      await connector.start();
      observeState();
    })().catch(error => {
      if (!stopping) onStartupFailure(error);
    }).finally(() => { pending = undefined; });
  }

  return Object.freeze({ server, methods,
    ready,
    start() {
      if (timer || stopping) return;
      timer = setInterval(tick, pollIntervalMs);
      timer.unref();
      summaryTimer = setInterval(() => {
        observeState();
        log('INFO', 'activity-summary', { state: state(), active: active.size, completed, failed, suppressed });
        completed = failed = suppressed = 0;
        recentFailures.clear();
        recentOperations.clear();
      }, summaryIntervalMs);
      summaryTimer.unref();
      observeState();
      tick();
    },
    async stop() {
      stopping = true;
      clearInterval(timer);
      clearInterval(summaryTimer);
      observeState();
      try { await permits.stop(); }
      finally { await connector.stop(); }
    },
  });
}
