const pluginId = 'rivetin-vcenter-manager';
// The provider transport policy admits at most four targets; the Pod keeps one
// connector process per target so a target can be added or removed alone.
const maximumTargets = 4;

function fail(code) {
  throw Object.assign(new Error(code), { code });
}

function definitionOf(target) {
  return { origin: target.origin, trustRef: target.trustRef, policyVersion: target.policyVersion,
    addresses: target.addresses.map(String) };
}

function targetIdentity(target) {
  const definition = definitionOf(target);
  return JSON.stringify([definition.origin, definition.trustRef, definition.policyVersion,
    [...definition.addresses].sort()]);
}

function validateTarget(target) {
  if (target === null || typeof target !== 'object' || Array.isArray(target) ||
      typeof target.origin !== 'string' || !target.origin ||
      typeof target.trustRef !== 'string' || !target.trustRef ||
      typeof target.policyVersion !== 'string' || !target.policyVersion ||
      !Array.isArray(target.addresses) || !target.addresses.length || target.addresses.length > 8 ||
      target.addresses.some(address => typeof address !== 'string' || !address)) fail('CONNECTION_SCHEMA_INVALID');
  return definitionOf(target);
}

// Each configured target owns one pinned Python connector process. A target add
// or remove never touches another target's process, and provider calls route by
// the binding origin to the client of exactly that target.
export function createVmwarePodConnector({ identity, tls, contract, createTargetProcess, initialTargets = [],
  verifyStore, createConnectorProcess, createProviderRpc, createProviderTransportPolicy,
  verifyWindowsPermissions, diagnosticSink, log = () => {}, diagnoseConnector }) {
  if (identity?.pluginId !== pluginId || typeof verifyStore !== 'function' || typeof createTargetProcess !== 'function' ||
      !Array.isArray(initialTargets) || initialTargets.length > maximumTargets) fail('CONNECTION_SCHEMA_INVALID');
  const instances = new Map();
  const requested = new Map();
  // Runtime-added targets carry their CA material in the apply request. It is
  // kept next to (never inside) the identity/policy entry so a later restart of
  // that instance can regenerate its single-target configuration. The startup
  // targets keep using the CA materialized by the Pod entrypoint.
  const trust = new Map();
  let verified = false, closing = false;
  let queue = Promise.resolve();
  function requestMaterial(target) {
    return typeof target.caPem === 'string' && target.caPem ? { caPem: target.caPem } : {};
  }
  function materialFor(origin) {
    const material = trust.get(origin);
    return material ? { ...material } : {};
  }
  function rememberMaterial(origin, material) {
    if (material.caPem) trust.set(origin, material); else trust.delete(origin);
  }
  function serialize(task) {
    const run = queue.then(task, task);
    queue = run.then(() => undefined, () => undefined);
    return run;
  }
  for (const target of initialTargets) {
    const definition = validateTarget(target);
    requested.set(definition.origin, definition);
  }

  function policy() {
    const targets = [...requested.values()];
    if (!targets.length) fail('CONNECTION_NETWORK_POLICY_DENIED');
    return createProviderTransportPolicy({ targets });
  }
  if (requested.size) policy();
  async function authorizeBinding(binding) {
    return policy().authorize(binding);
  }
  function instanceReady(origin) {
    const instance = instances.get(origin);
    return Boolean(instance) && instance.manager.state().state === 'ready' && Boolean(instance.client);
  }
  async function ensureStore() {
    if (verified) return;
    if (await verifyStore() !== true) fail('VC_OPERATION_STORAGE_REQUIRED');
    verified = true;
  }
  // Diagnostics only: redact PEM bodies/credential assignments, collapse
  // whitespace and bound every field so logs can never carry trust material.
  function diagnosticText(value, limit) {
    if (typeof value !== 'string' || !value) return undefined;
    const text = value
      .replace(/-----BEGIN [A-Z0-9 ]+-----[\s\S]*?(?:-----END [A-Z0-9 ]+-----|$)/g, '[redacted-pem]')
      .replace(/\b(password|passwd|secret|token|authorization)\s*[:=]\s*\S+/gi, '$1=[redacted]')
      .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ')
      .replace(/\s+/g, ' ').trim();
    return text ? text.slice(0, limit) : undefined;
  }
  function diagnosticFields(error) {
    return { ...(typeof error?.name === 'string' && error.name ? { causeName: error.name.slice(0, 64) } : {}),
      ...(diagnosticText(error?.message, 200) === undefined ? {} : { causeMessage: diagnosticText(error?.message, 200) }) };
  }
  function logTargetFailure(origin, stage, errorCode, error, extra = {}) {
    log('ERROR', 'target-start-failed', { origin, stage, errorCode, ...diagnosticFields(error), ...extra });
  }
  async function launch(prepared) {
    const instance = { manager: null, client: null, definition: validateTarget(prepared.target) };
    let failure = null;
    let manager;
    try {
      manager = createConnectorProcess({ ...prepared.processConfig, release: identity.connectorRelease,
        maxRestarts: 0, verifyWindowsPermissions, diagnosticSink,
        async verifyReady(ready) {
          try {
            if (prepared.port && ready.port !== prepared.port) {
              failure = { stage: 'port', code: 'CONNECTION_PROOF_MISMATCH' };
              fail('CONNECTION_PROOF_MISMATCH');
            }
            let next;
            try { next = createProviderRpc({ ...tls, port: ready.port, identity,
              businessMethods: contract.businessMethods, credentialInputs: contract.credentialInputs,
              authorizationRoots: contract.authorizationRoots, diagnosticSink, authorizeBinding }); }
            catch (error) {
              failure = { stage: 'rpc', code: typeof error?.code === 'string' ? error.code : 'CONNECTION_PROVIDER_UNAVAILABLE', error };
              throw error;
            }
            let peer;
            try { peer = await next.verifyPeer(); }
            catch (error) {
              failure = { stage: 'peer', code: typeof error?.code === 'string' ? error.code : 'CONNECTION_TLS_TRUST_REQUIRED', error };
              throw error;
            }
            if (peer !== true) {
              failure = { stage: 'peer', code: 'CONNECTION_TLS_TRUST_REQUIRED' };
              return false;
            }
            instance.client = next;
            return true;
          } catch (error) {
            failure ??= { stage: 'verify', code: typeof error?.code === 'string' ? error.code : 'CONNECTION_PROVIDER_UNAVAILABLE', error };
            throw error;
          }
        },
      });
    } catch (error) {
      failure = { stage: 'configuration', code: typeof error?.code === 'string' ? error.code : 'CONNECTION_PROVIDER_UNAVAILABLE', error };
    }
    instance.manager = manager;
    if (!manager) {
      logTargetFailure(prepared.target.origin, failure.stage, failure.code, failure.error);
      throw Object.assign(new Error(failure.code), { code: failure.code, ...(failure.error ? { cause: failure.error } : {}) });
    }
    try { await manager.start(); }
    catch (error) {
      await manager.stop().catch(() => {});
      const detail = failure ?? { stage: 'ready', code: typeof error?.code === 'string' ? error.code : 'CONNECTION_PROVIDER_UNAVAILABLE', error };
      let diagnostic;
      try { if (typeof diagnoseConnector === 'function') diagnostic = await diagnoseConnector(prepared.processConfig); }
      catch { /* Diagnostics never replace the primary failure. */ }
      const stderr = diagnosticText(diagnostic?.stderr, 2048);
      logTargetFailure(prepared.target.origin, detail.stage, detail.code, detail.error ?? error, {
        ...(typeof error?.code === 'string' && error.code !== detail.code ? { startErrorCode: error.code } : {}),
        ...(diagnostic?.child ? { child: diagnostic.child } : {}),
        ...(stderr === undefined ? {} : { stderr }),
      });
      throw Object.assign(new Error(detail.code), { code: detail.code,
        ...(detail.error ? { cause: detail.error } : { cause: error }) });
    }
    return instance;
  }
  function withOrigin(error, origin) {
    if (error !== null && typeof error === 'object' && error.origin === undefined) error.origin = origin;
    return error;
  }

  return Object.freeze({
    async start() {
      return serialize(async () => {
        if (closing) fail('CONNECTION_PROVIDER_UNAVAILABLE');
        await ensureStore();
        for (const definition of [...requested.values()]) {
          if (instanceReady(definition.origin)) continue;
          const previous = instances.get(definition.origin);
          if (previous) {
            instances.delete(definition.origin);
            await previous.manager.stop().catch(() => {});
          }
          let prepared;
          try { prepared = await createTargetProcess({ ...definition, ...materialFor(definition.origin) }); }
          catch (error) {
            logTargetFailure(definition.origin, 'configuration', typeof error?.code === 'string' ? error.code : 'CONNECTION_PROVIDER_UNAVAILABLE', error);
            throw withOrigin(error, definition.origin);
          }
          try { instances.set(definition.origin, await launch({ target: definition, ...prepared })); }
          catch (error) { throw withOrigin(error, definition.origin); }
        }
      });
    },
    ready() {
      if (closing) return false;
      return [...requested.keys()].every(instanceReady);
    },
    // Full replacement is computed by the caller: add/remove name the exact
    // target origins that must change. Every addition is prepared (single-target
    // configuration generated and its trust material materialized) before any
    // live connection is mutated.
    async applyTargets({ add = [], remove = [] } = {}) {
      return serialize(async () => {
        if (closing) fail('CONNECTION_PROVIDER_UNAVAILABLE');
        if (!Array.isArray(add) || !Array.isArray(remove) ||
            remove.some(origin => typeof origin !== 'string' || !origin)) fail('CONNECTION_SCHEMA_INVALID');
        const additions = add.map(target => ({ definition: validateTarget(target), material: requestMaterial(target) }));
        const definitions = additions.map(row => row.definition);
        if (new Set(definitions.map(row => row.origin)).size !== definitions.length) fail('CONNECTION_SCHEMA_INVALID');
        const next = new Set(requested.keys());
        for (const origin of remove) next.delete(origin);
        for (const definition of definitions) next.add(definition.origin);
        if (next.size > maximumTargets) fail('CONNECTION_LIMIT_EXCEEDED');
        await ensureStore();
        const prepared = [];
        for (const row of additions) {
          const definition = row.definition;
          const live = instances.get(definition.origin);
          if (live && instanceReady(definition.origin) && targetIdentity(live.definition) === targetIdentity(definition)) continue;
          try {
            prepared.push({ target: definition, material: row.material,
              ...await createTargetProcess({ ...definition, ...row.material }) });
          } catch (error) {
            logTargetFailure(definition.origin, 'configuration', typeof error?.code === 'string' ? error.code : 'CONNECTION_PROVIDER_UNAVAILABLE', error);
            throw withOrigin(error, definition.origin);
          }
        }
        for (const origin of remove) {
          // A replacement origin is stopped by the addition below, with the new
          // configuration already prepared.
          if (definitions.some(row => row.origin === origin)) continue;
          requested.delete(origin);
          trust.delete(origin);
          const instance = instances.get(origin);
          if (!instance) continue;
          instances.delete(origin);
          try { await instance.manager.stop(); } catch (error) { throw withOrigin(error, origin); }
        }
        for (const row of prepared) {
          const origin = row.target.origin;
          const previous = instances.get(origin);
          if (previous) {
            instances.delete(origin);
            await previous.manager.stop().catch(() => {});
          }
          try { instances.set(origin, await launch(row)); }
          catch (error) { throw withOrigin(error, origin); }
          requested.set(origin, row.target);
          rememberMaterial(origin, row.material);
        }
        for (const row of additions) {
          if (!instanceReady(row.definition.origin)) continue;
          requested.set(row.definition.origin, row.definition);
          rememberMaterial(row.definition.origin, row.material);
        }
        return { added: definitions.map(row => row.origin), removed: [...remove] };
      });
    },
    async call(request) {
      const origin = request?.binding?.origin;
      const instance = typeof origin === 'string' ? instances.get(origin) : undefined;
      if (!instance || !instanceReady(origin)) fail('CONNECTION_PROVIDER_UNAVAILABLE');
      return instance.client.call(request);
    },
    stop() {
      return serialize(async () => {
        closing = true;
        trust.clear();
        let failure;
        for (const [origin, instance] of [...instances]) {
          instances.delete(origin);
          requested.delete(origin);
          try { await instance.manager.stop(); } catch (error) { failure ??= withOrigin(error, origin); }
        }
        if (failure) throw failure;
      });
    },
  });
}
