import { createHash } from 'node:crypto';

const capability = 'vmware.provider';
const connectionMethods = new Set(['probe', 'discover', 'revalidate']);
const kinds = { prepareOperation: 'submit', submitOperation: 'submit', refreshOperation: 'submit', readOperation: 'observe' };

const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function fail(code, outcome = 'not-accepted') {
  throw Object.assign(new Error(code), { code, outcome });
}

export function createVmwarePodProvider({ businessMethods, connector, clock = Date.now }) {
  const definitions = { ...Object.fromEntries([...connectionMethods].map(method => [method, { credential: 'current' }])),
    ...structuredClone(businessMethods) };
  const methods = Object.freeze(Object.fromEntries(Object.keys(definitions).map(method => [method,
    Object.hasOwn(kinds, method) ? kinds[method] : 'read'])));

  function supports(call) {
    return call.capability === capability && call.interfaceVersion === 1 &&
      Object.hasOwn(methods, call.method) && methods[call.method] === call.kind &&
      (call.caller?.pluginId === null || call.caller?.pluginId === 'rivetin-vcenter-manager');
  }

  async function invoke(call, { signal, claimCredential } = {}) {
    const { method, kind, caller, input, operationId, credentialLeaseId } = call;
    if (!supports(call)) fail('CONNECTION_MODE_UNSUPPORTED');
    if (!isObject(input) || Object.keys(input).sort().join() !== 'binding,deadlineMs,payload' ||
        !isObject(input.payload) || !isObject(input.binding)) fail('CONNECTION_SCHEMA_INVALID');
    const { deadlineMs, payload, binding } = input;
    if (typeof caller?.id !== 'string' || !caller.id || typeof caller.source !== 'string' || !caller.source ||
        binding.pluginId !== 'rivetin-vcenter-manager')
      fail('CONNECTION_PERMISSION_DENIED');
    // Existing connection and operation rows are owned by this provider-host digest.
    const actorId = createHash('sha256').update(caller.source + ':' + caller.id).digest('hex');
    if (binding.actorId !== actorId)
      fail('CONNECTION_PERMISSION_DENIED');
    if (((method === 'submitOperation' || method === 'readOperation') && payload.operationId !== operationId) ||
        (method === 'refreshOperation' && (!payload.operationId || payload.operationId === operationId))) fail('CONNECTION_PROOF_MISMATCH');
    // Legacy refresh can return a terminal row after its retained lease was released.
    // The connector refuses a nonterminal refresh with an inactive lease before SOAP.
    const releasedRefresh = method === 'refreshOperation' && binding.credentialLeaseActive === false;
    const needsCredential = definitions[method].credential !== 'none' && !releasedRefresh;
    if (needsCredential ? typeof credentialLeaseId !== 'string' || !credentialLeaseId : credentialLeaseId !== null)
      fail('CONNECTION_PERMISSION_DENIED');
    const budget = deadlineMs - clock();
    if (!Number.isSafeInteger(deadlineMs) || budget <= 0 || budget > 15_000 || signal?.aborted) fail('CONNECTION_TIMEOUT');
    const deadlineSignal = AbortSignal.timeout(budget);
    const invocationSignal = signal ? AbortSignal.any([signal, deadlineSignal]) : deadlineSignal;
    if (needsCredential && typeof claimCredential !== 'function') fail('CONNECTION_PERMISSION_DENIED');
    const material = needsCredential ? await claimCredential() : { secret: {} };
    if (invocationSignal.aborted || deadlineMs <= clock()) fail('CONNECTION_TIMEOUT');
    if (!isObject(material?.secret) || (material.credentialInputs != null && !isObject(material.credentialInputs)))
      fail('CONNECTION_PERMISSION_DENIED');

    try {
      return await connector.call({ method, binding, payload, secret: material.secret,
        ...(material.credentialInputs == null ? {} : { credentialInputs: material.credentialInputs }),
        signal: invocationSignal, deadlineMs, includeMetadata: true });
    } catch (error) {
      const code = typeof error?.code === 'string' && /^(CONNECTION|VC)_[A-Z0-9_]{1,88}$/.test(error.code)
        ? error.code : 'CONNECTION_PROVIDER_UNAVAILABLE';
      fail(code, kind === 'submit' ? 'unknown' : 'not-accepted');
    }
  }

  return Object.freeze({ capability, interfaceVersion: 1, methods, supports, invoke });
}

