"""Stage a fenced VMware business ledger on the destination volume."""
from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
import time

from .operation_ledger import ACTIVE, TERMINAL, OperationLedger, canonical, operation_id, require
from .profiles import AdapterError
from .resource_scope import identity
from .storage_snapshot import binding_storage_snapshot


STORAGE_ERROR = 'VC_OPERATION_STORAGE_REQUIRED'
DATABASE = 'vc-operations.sqlite3'
MARKER = 'vc-operations-identity.json'


def stage_pod_storage(source_config, destination, expected):
    """Copy a verified ledger after the controller has fenced the old writer.

    The caller owns writer fencing, target ownership, activation and rollback.
    A copied store is eligible for activation only after this function returns.
    """
    try:
        source = OperationLedger._directory(source_config['dataDirectory']).resolve(strict=True)
        target = Path(destination)
        require(target.is_absolute() and target == target.resolve(), STORAGE_ERROR)
        require(target != source and target not in source.parents and source not in target.parents, STORAGE_ERROR)
        OperationLedger._directory(target.parent)
        require(binding_storage_snapshot(source_config) == expected, STORAGE_ERROR)
        target_config = source_config | {'dataDirectory': str(target)}

        try:
            target.mkdir(mode=0o700)
        except FileExistsError:
            require(not target.samefile(source), STORAGE_ERROR)
            return _verified_copy(source_config, target_config, expected)

        original = json.loads((source / MARKER).read_text(encoding='utf-8'))
        database = target / DATABASE
        descriptor = os.open(database, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.close(descriptor)
        limit = time.monotonic() + 15

        def check_budget(_status, _remaining, _total):
            require(time.monotonic() < limit, STORAGE_ERROR)

        # The SQLite backup API also copies committed rows still present only in WAL.
        with closing(sqlite3.connect((source / DATABASE).as_uri() + '?mode=ro', uri=True, timeout=1)) as old:
            with closing(sqlite3.connect(database.as_uri() + '?mode=rw', uri=True, timeout=1)) as new:
                old.execute('PRAGMA query_only=ON')
                new.execute('PRAGMA synchronous=FULL')
                old.backup(new, pages=256, progress=check_budget, sleep=0.05)

        root_info = target.stat()
        file_info = OperationLedger._regular(database, minimum=4096, maximum=64 * 1024 * 1024)
        marker = original | {
            'rootDevice': str(root_info.st_dev), 'rootInode': str(root_info.st_ino),
            'databaseDevice': str(file_info.st_dev), 'databaseInode': str(file_info.st_ino),
        }
        descriptor = os.open(target / MARKER, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, 'wb') as output:
            output.write(canonical(marker).encode('utf-8'))
            output.flush()
            os.fsync(output.fileno())
        OperationLedger._sync_directory(target)
        OperationLedger._sync_directory(target.parent)
        return _verified_copy(source_config, target_config, expected)
    except (KeyError, OSError, TypeError, ValueError, RuntimeError, sqlite3.Error):
        raise AdapterError(STORAGE_ERROR) from None


def _verified_copy(source_config, target_config, expected):
    target = binding_storage_snapshot(target_config)
    require(target['logicalSHA256'] == expected['logicalSHA256'], STORAGE_ERROR)
    require(target['identitySHA256'] != expected['identitySHA256'], STORAGE_ERROR)
    require(binding_storage_snapshot(source_config) == expected, STORAGE_ERROR)
    return target


def active_pod_operations(config):
    """Read the complete pending-operation projection under the offline fence."""
    try:
        proof = binding_storage_snapshot(config)
        database = Path(config['dataDirectory']) / DATABASE
        operations = []
        with closing(sqlite3.connect(database.as_uri() + '?mode=ro', uri=True, timeout=1)) as db:
            db.execute('PRAGMA query_only=ON')
            db.execute('BEGIN')
            rows = db.execute('SELECT operation_id, state, task FROM operations ORDER BY operation_id LIMIT 10001').fetchall()
            require(len(rows) <= 10000, STORAGE_ERROR)
            for identifier, state, raw_task in rows:
                require(state in ACTIVE | TERMINAL, STORAGE_ERROR)
                if state not in ACTIVE:
                    continue
                task = None if raw_task is None else json.loads(raw_task)
                if task is not None:
                    identity(task, 'Task')
                require(task is not None or state not in ('queued', 'running'), STORAGE_ERROR)
                operations.append({'operationId': operation_id(identifier), 'state': state, 'task': task})
        require(binding_storage_snapshot(config) == proof, STORAGE_ERROR)
        return {'version': 1, 'coverage': 'all-active-operations', 'dataStoreId': proof['dataStoreId'],
                'logicalSHA256': proof['logicalSHA256'], 'identitySHA256': proof['identitySHA256'], 'operations': operations}
    except (OSError, ValueError, TypeError, sqlite3.Error, AdapterError):
        raise AdapterError(STORAGE_ERROR) from None
