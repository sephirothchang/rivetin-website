"""Read-only vSphere adapter profiles, independent of FW transport/secret policy."""
import re


class AdapterError(Exception):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


PROFILES = {
    "vc7-legacy": {"restBase": "/rest", "soapBase": "/sdk", "soapVersion": "7.0", "envelope": "value"},
    "vc7-modern": {"restBase": "/api", "soapBase": "/sdk", "soapVersion": "7.0.2", "envelope": "raw"},
    "vc8-modern": {"restBase": "/api", "soapBase": "/sdk", "soapVersion": "8.0", "envelope": "raw"},
}


def choose_profile(about):
    if about.get("apiType") != "VirtualCenter":
        raise AdapterError("VC_TARGET_NOT_VCENTER")
    if not isinstance(about.get("instanceUuid"), str) or not about["instanceUuid"]:
        raise AdapterError("VC_INSTANCE_IDENTITY_REQUIRED")
    version = about.get("version", "")
    if not re.fullmatch(r"\d+\.\d+(?:\.\d+)*", version):
        raise AdapterError("VC_VERSION_UNSUPPORTED")
    parts = [int(part) for part in version.split(".")]
    if parts[:2] == [7, 0]:
        return "vc7-modern" if len(parts) > 2 and parts[2] >= 2 else "vc7-legacy"
    if parts[:2] == [8, 0]:
        return "vc8-modern"
    raise AdapterError("VC_VERSION_UNSUPPORTED")


def adaptation(profile, values=None):
    if profile not in PROFILES:
        raise AdapterError("VC_ADAPTATION_UNSUPPORTED")
    result = {"profile": profile, **PROFILES[profile], "inventory": "soap", "timeoutMs": 10000, "batchLimit": 100}
    if values is not None:
        if not isinstance(values, dict) or set(values) != set(result):
            raise AdapterError("VC_ADAPTATION_INVALID")
        result = dict(values)
    if result["profile"] != profile or result["inventory"] != "soap" or result["envelope"] not in ("raw", "value"):
        raise AdapterError("VC_ADAPTATION_UNSUPPORTED")
    for field in ("restBase", "soapBase"):
        if not isinstance(result[field], str) or len(result[field]) > 120 or not re.fullmatch(r"/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*", result[field]):
            raise AdapterError("VC_ADAPTATION_INVALID")
    if not isinstance(result["soapVersion"], str) or not re.fullmatch(r"[78]\.\d+(?:\.\d+){0,2}", result["soapVersion"]):
        raise AdapterError("VC_ADAPTATION_INVALID")
    if int(result["soapVersion"].split(".")[0]) != (8 if profile == "vc8-modern" else 7):
        raise AdapterError("VC_ADAPTATION_INVALID")
    if type(result["timeoutMs"]) is not int or not 1000 <= result["timeoutMs"] <= 15000:
        raise AdapterError("VC_BUDGET_EXCEEDED")
    if type(result["batchLimit"]) is not int or not 1 <= result["batchLimit"] <= 200:
        raise AdapterError("VC_BUDGET_EXCEEDED")
    return result
