"""Project management reads to the server-owned enrolled cluster selection."""
import copy
from xml.etree import ElementTree as ET

from .profiles import AdapterError
from .vsphere_readonly import ref


def identity(value, expected=None):
    if (not isinstance(value, dict) or set(value) != {"objectType", "objectId"}
            or not isinstance(value.get("objectType"), str) or not isinstance(value.get("objectId"), str)):
        raise AdapterError("VC_REFERENCE_INVALID")
    node = ET.Element("obj", {"type": value.get("objectType", "")})
    node.text = value.get("objectId")
    result = ref(node, expected)
    return result["objectType"], result["objectId"]


def enrolled_objects(snapshot, selected):
    if not isinstance(selected, list) or not selected or len(selected) > 2000:
        raise AdapterError("VC_PERMISSION_DENIED")
    selected_ids = [identity(key, "ClusterComputeResource") for key in selected]
    if len(set(selected_ids)) != len(selected_ids):
        raise AdapterError("VC_PERMISSION_DENIED")
    if not isinstance(snapshot, dict) or snapshot.get("complete") is not True or not isinstance(snapshot.get("objects"), list) or len(snapshot["objects"]) > 2000:
        raise AdapterError("VC_INVENTORY_INCOMPLETE")
    records = {}
    for row in snapshot["objects"]:
        if not isinstance(row, dict) or set(row) != {"key", "properties"} or not isinstance(row["properties"], dict):
            raise AdapterError("VC_RESPONSE_INVALID")
        key = identity(row["key"])
        if key in records:
            raise AdapterError("VC_RESPONSE_INVALID")
        records[key] = row
    selected_ids = set(selected_ids)
    allowed = set(selected_ids)
    for key in selected_ids:
        row, visited = records.get(key), set()
        if row is None:
            raise AdapterError("VC_INVENTORY_INCOMPLETE")
        while row["key"]["objectType"] != "Datacenter":
            parent = row["properties"].get("parent")
            if parent is None:
                raise AdapterError("VC_INVENTORY_INCOMPLETE")
            parent_id = identity(parent)
            if parent_id[0] not in {"Folder", "Datacenter"} or parent_id in visited or parent_id not in records:
                raise AdapterError("VC_INVENTORY_INCOMPLETE")
            visited.add(parent_id); allowed.add(parent_id); row = records[parent_id]
    host_ids = set()
    for key, row in records.items():
        if key[0] == "HostSystem" and row["properties"].get("parent") is not None:
            if identity(row["properties"]["parent"]) in selected_ids:
                host_ids.add(key)
    allowed |= host_ids
    for key, row in records.items():
        if key[0] != "VirtualMachine":
            continue
        host = row["properties"].get("runtime.host")
        if host is None or identity(host, "HostSystem") not in records:
            # No proof that an unplaced VM is in or outside selected clusters.
            raise AdapterError("VC_INVENTORY_INCOMPLETE")
        if records[identity(host, "HostSystem")]["properties"].get("parent") is None:
            raise AdapterError("VC_INVENTORY_INCOMPLETE")
        if identity(host, "HostSystem") in host_ids:
            allowed.add(key)
    for host_id in host_ids:
        for field, kinds in (("network", {"Network", "DistributedVirtualPortgroup"}), ("datastore", {"Datastore"})):
            links = records[host_id]["properties"].get(field)
            if links is None:
                continue  # UI keeps that page explicitly incomplete.
            if not isinstance(links, list) or len(links) > 2000:
                raise AdapterError("VC_RESPONSE_INVALID")
            for link in links:
                target = identity(link)
                if target[0] not in kinds:
                    raise AdapterError("VC_RESPONSE_INVALID")
                if target in records:
                    allowed.add(target)
    result = []
    for key, original in records.items():
        if key not in allowed:
            continue
        row = copy.deepcopy(original)
        if key[0] in {"Datacenter", "VirtualMachine", "Network", "DistributedVirtualPortgroup", "Datastore"}:
            row["properties"].pop("parent", None)
        if key[0] == "ClusterComputeResource" and "host" in row["properties"]:
            if not isinstance(row["properties"]["host"], list):
                raise AdapterError("VC_RESPONSE_INVALID")
            row["properties"]["host"] = [value for value in row["properties"]["host"] if identity(value, "HostSystem") in host_ids]
        result.append(row)
    return result
