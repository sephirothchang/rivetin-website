"""Offline proof that every retained operation can only resume postchecking."""
import hashlib
import json
import math
import re
import sqlite3

from .operation_ledger import ACTIVE, TERMINAL, OPTIONAL_BINDINGS, OWNER_FIELDS, OperationLedger, canonical, operation_id, owner, require
from .profiles import AdapterError
from .resource_scope import identity
from .managed_executor import OPERATIONS
from .managed_host import HOST_OPERATIONS, HISTORICAL_STORAGE_OPERATIONS
from .managed_network import NETWORK_OPERATIONS, vmk_device
from .managed_alarms import ALARM_OPERATIONS

CODE = 'VC_OPERATION_RETAINED_OBSERVATION_REQUIRED'
COLUMNS = ('operation_id', 'owner', 'intent', 'intent_hash', 'binding', 'target', 'state', 'task', 'result', 'error_code', 'created', 'updated')
OBSERVABLE_OPERATIONS = OPERATIONS | HISTORICAL_STORAGE_OPERATIONS
SYNCHRONOUS = set(HOST_OPERATIONS) | set(HISTORICAL_STORAGE_OPERATIONS) | set(NETWORK_OPERATIONS) | set(ALARM_OPERATIONS) | {
    'cluster.create', 'template.mark', 'template.toVM', 'vm.shutdownGuest', 'vm.rebootGuest'}


def _text(value):
    require(type(value) is str and 0 < len(value) <= 512 and not any(ord(c) < 32 or ord(c) == 127 for c in value), CODE)


def _release(value):
    require(type(value) is dict and set(value) == {'pluginPackageDigest', 'connectorReleaseDigest'}, CODE)
    require(all(type(v) is str and re.fullmatch(r'[a-f0-9]{64}', v) for v in value.values()), CODE)


def _json(value):
    require(type(value) is str and len(value.encode('utf-8')) <= 65536, CODE)
    result = json.loads(value)
    require(canonical(result, max_string=32768) == value, CODE)
    return result


def _record(row, expected, config):
    require(row['state'] == 'verifying' and operation_id(row['operation_id']) == expected['operationId'], CODE)
    binding = {name: expected[name] for name in OWNER_FIELDS if name in expected}
    binding.update(providerId=config['providerId'], pluginId=config['pluginId'])
    require(row['owner'] == owner(binding), CODE)
    intent, metadata = _json(row['intent']), _json(row['binding'])
    require(type(intent) is dict and set(intent) == {'connectionId', 'instanceId', 'scopeRevision', 'key', 'operation', 'parameters', 'expected'}, CODE)
    require(hashlib.sha256(row['intent'].encode('utf-8')).hexdigest() == row['intent_hash'], CODE)
    require(intent['connectionId'] == expected['connectionId'] and intent['instanceId'] == expected['instanceId'] and
            type(intent['scopeRevision']) is int and intent['scopeRevision'] >= 1 and intent['operation'] in OBSERVABLE_OPERATIONS and
            type(intent['parameters']) is dict and type(intent['expected']) is dict, CODE)
    identity(intent['key'], OBSERVABLE_OPERATIONS[intent['operation']][0])
    require(row['target'] == canonical({'providerId': config['providerId'], 'origin': expected['origin'],
                                     'instanceId': expected['instanceId'], 'key': intent['key']}), CODE)
    required = {'packageDigest', 'connectorRelease', 'policyVersion', 'credentialVersion', 'credentialLeaseId'}
    require(type(metadata) is dict and required <= set(metadata) <= required | set(OPTIONAL_BINDINGS), CODE)
    require(metadata['packageDigest'] == config['from']['pluginPackageDigest'] and
            metadata['connectorRelease'] == config['from']['connectorReleaseDigest'] and
            metadata['policyVersion'] == expected['policyVersion'] and metadata['credentialVersion'] == expected['credentialVersion'] and
            metadata['credentialLeaseId'] == expected['leaseId'], CODE)
    for name in OPTIONAL_BINDINGS:
        require((name in metadata) == (name in expected) and metadata.get(name) == expected.get(name), CODE)
    result = _json(row['result'])
    require(type(result) is dict, CODE)
    if row['task'] is None:
        require(intent['operation'] in SYNCHRONOUS and set(result) == {'nativeReturned', 'value'} and result['nativeReturned'] is True, CODE)
        if intent['operation'] in {'cluster.create', 'storage.mountNfs'}:
            identity(result['value'], 'ClusterComputeResource' if intent['operation'] == 'cluster.create' else 'Datastore')
        elif intent['operation'] == 'vmk.create':
            require(type(result['value']) is dict and set(result['value']) == {'device'}, CODE)
            vmk_device(result['value']['device'])
        else:
            require(result['value'] is None, CODE)
    else:
        require(intent['operation'] not in SYNCHRONOUS, CODE)
        identity(_json(row['task']), 'Task')
        require({'nativeState'} <= set(result) <= {'nativeState', 'progress', 'result'} and result['nativeState'] == 'success', CODE)
        if 'progress' in result:
            require(type(result['progress']) is int and 0 <= result['progress'] <= 100, CODE)
        if intent['operation'] in {'vm.create', 'vm.provision', 'vm.clone', 'vm.cloneTemplate', 'template.deploy', 'host.add'}:
            identity(result.get('result'), 'HostSystem' if intent['operation'] == 'host.add' else 'VirtualMachine')
        if intent['operation'] == 'vm.snapshot.create': identity(result.get('result'), 'VirtualMachineSnapshot')
    require(all(v is None or type(v) in (str, int, float) for v in row.values()), CODE)
    require(all(type(v) is not float or math.isfinite(v) for v in row.values()), CODE)
    encoded = json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
    require(len(encoded) <= 196608, CODE)
    return {'actorId': expected['actorId'], 'operationId': expected['operationId'], 'leaseId': expected['leaseId'],
            'recordSHA256': hashlib.sha256(encoded).hexdigest()}


def binding_retained_observations(config):
    """No native session, writable ledger constructor, checkpoint or migration."""
    db = None
    try:
        fields = {'version', 'providerId', 'pluginId', 'dataDirectory', 'dataStoreId', 'ledgerStoreId', 'from', 'to', 'retained'}
        require(type(config) is dict and set(config) == fields and type(config['version']) is int and config['version'] == 1, CODE)
        canonical(config, max_string=32768)
        require(config['pluginId'] == 'rivetin-vcenter-manager', CODE)
        _text(config['providerId']); operation_id(config['ledgerStoreId'])
        store_id = operation_id(config['dataStoreId'])
        _release(config['from']); _release(config['to'])
        require(config['from'] != config['to'], CODE)
        retained = config['retained']
        require(type(retained) is list and 1 <= len(retained) <= 32, CODE)
        required = {'actorId', 'operationId', 'leaseId', 'connectionId', 'instanceId', 'credentialVersion', 'origin', 'trustRef', 'policyVersion'}
        for item in retained:
            require(type(item) is dict and required <= set(item) <= required | set(OPTIONAL_BINDINGS), CODE)
            for name in required: _text(item[name])
            operation_id(item['operationId'])
        leases = [item['leaseId'] for item in retained]
        ids = [item['operationId'] for item in retained]
        require(leases == sorted(set(leases)) and len(set(ids)) == len(ids), CODE)
        root = OperationLedger._directory(config['dataDirectory'])
        probe = object.__new__(OperationLedger)
        probe.root, probe.store_id, probe.path = root, store_id, root / 'vc-operations.sqlite3'
        marker = probe._marker()
        db = sqlite3.connect(probe.path.as_uri() + '?mode=ro', uri=True, isolation_level=None, timeout=1)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA query_only=ON'); db.execute('BEGIN')
        require([tuple(r) for r in db.execute('PRAGMA integrity_check')] == [('ok',)] and
                db.execute('PRAGMA user_version').fetchone()[0] == 1 and
                [tuple(r) for r in db.execute('SELECT store_id,generation FROM storage_identity')] == [(store_id, marker['generation'])] and
                [tuple(r) for r in db.execute('SELECT version FROM schema_version')] == [(1,)], CODE)
        require(tuple(r['name'] for r in db.execute('PRAGMA table_info(operations)')) == COLUMNS, CODE)
        known = tuple(sorted(ACTIVE | TERMINAL))
        require(db.execute('SELECT COUNT(*) FROM operations').fetchone()[0] <= 10000 and
                db.execute('SELECT 1 FROM operations WHERE state NOT IN (' + ','.join('?' for _ in known) + ') LIMIT 1', known).fetchone() is None, CODE)
        placeholders = ','.join('?' for _ in ACTIVE)
        rows = [dict(r) for r in db.execute('SELECT * FROM operations WHERE state IN (' + placeholders + ') LIMIT 33', tuple(sorted(ACTIVE)))]
        require(len(rows) == len(retained) and {r['operation_id'] for r in rows} == set(ids), CODE)
        by_id = {r['operation_id']: r for r in rows}
        proofs = [_record(by_id[item['operationId']], item, config) for item in retained]
        require(probe._marker() == marker, CODE)
        db.execute('ROLLBACK')
        return {'version': 1, 'kind': 'retained-observation-repair', 'providerId': config['providerId'], 'pluginId': config['pluginId'],
                'dataStoreId': store_id, 'ledgerStoreId': config['ledgerStoreId'], 'from': dict(config['from']), 'to': dict(config['to']),
                'coverage': 'all-active-operations', 'observationOnly': True, 'retained': proofs}
    except (OSError, ValueError, TypeError, KeyError, sqlite3.Error, AdapterError, OverflowError):
        raise AdapterError(CODE) from None
    finally:
        if db is not None: db.close()
