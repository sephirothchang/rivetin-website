"""Offline, read-only fingerprint of the complete original business store."""
import hashlib
import json
import math
import sqlite3

from .operation_ledger import OperationLedger, operation_id, require
from .profiles import AdapterError

TABLES = ('operations', 'plans', 'schema_version', 'storage_identity')


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def _digest(value):
    return hashlib.sha256(_encoded(value)).hexdigest()


def _typed(value):
    # Preserve SQLite storage classes, including exact binary64 and BLOB values.
    if value is None:
        return ['null', None]
    if isinstance(value, bytes):
        return ['blob', value.hex()]
    if type(value) is int:
        return ['integer', str(value)]
    if type(value) is float:
        require(math.isfinite(value), 'VC_OPERATION_STORAGE_REQUIRED')
        return ['real', value.hex()]
    require(type(value) is str, 'VC_OPERATION_STORAGE_REQUIRED')
    return ['text', value]


def binding_storage_snapshot(config):
    """Never provisions, repairs, checkpoints, migrates or opens a native session.

    Read the WAL-aware database in one query-only transaction. Reuse only the
    ledger's original-file identity validation, without its writable constructor.
    """
    db = None
    try:
        require(type(config) is dict and set(config) == {'dataDirectory', 'dataStoreId'}, 'VC_OPERATION_STORAGE_REQUIRED')
        store_id = operation_id(config['dataStoreId'])
        root = OperationLedger._directory(config['dataDirectory'])
        probe = object.__new__(OperationLedger)
        probe.root, probe.store_id = root, store_id
        probe.path = root / 'vc-operations.sqlite3'
        marker = probe._marker()
        db = sqlite3.connect(probe.path.as_uri() + '?mode=ro', uri=True, isolation_level=None, timeout=1)
        db.execute('PRAGMA query_only=ON')
        db.execute('BEGIN')
        require(db.execute('PRAGMA integrity_check').fetchall() == [('ok',)], 'VC_OPERATION_STORAGE_REQUIRED')
        require(db.execute('PRAGMA foreign_key_check').fetchall() == [], 'VC_OPERATION_STORAGE_REQUIRED')
        schema = [list(row) for row in db.execute('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name,tbl_name')]
        require(sorted(row[1] for row in schema if row[0] == 'table') == list(TABLES), 'VC_OPERATION_STORAGE_REQUIRED')
        tables = {}
        for name in TABLES:
            columns = [list(row) for row in db.execute('PRAGMA table_xinfo("' + name + '")')]
            count = db.execute('SELECT COUNT(*) FROM "' + name + '"').fetchone()[0]
            require(count <= 10000, 'VC_OPERATION_STORAGE_REQUIRED')
            rows = sorted(_encoded([_typed(value) for value in row]).decode('utf-8')
                          for row in db.execute('SELECT * FROM "' + name + '"'))
            tables[name] = {'columns': columns, 'rowCount': count, 'rowsSHA256': _digest(rows)}
        require(db.execute('SELECT store_id,generation FROM storage_identity').fetchall() == [(store_id, marker['generation'])], 'VC_OPERATION_STORAGE_REQUIRED')
        require(db.execute('SELECT version FROM schema_version').fetchall() == [(1,)], 'VC_OPERATION_STORAGE_REQUIRED')
        logical = _digest({'schema': schema, 'userVersion': db.execute('PRAGMA user_version').fetchone()[0], 'tables': tables})
        require(probe._marker() == marker, 'VC_OPERATION_STORAGE_REQUIRED')
        db.execute('ROLLBACK')
        return {'version': 1, 'dataStoreId': store_id, 'coverage': 'complete-store',
                'logicalSHA256': logical, 'identitySHA256': _digest(marker),
                'physicalFiles': [{'path': 'vc-operations.sqlite3', 'role': 'primary'},
                                  {'path': 'vc-operations.sqlite3-wal', 'role': 'ephemeral'},
                                  {'path': 'vc-operations.sqlite3-shm', 'role': 'ephemeral'}]}
    except (OSError, ValueError, TypeError, KeyError, sqlite3.Error, AdapterError):
        raise AdapterError('VC_OPERATION_STORAGE_REQUIRED') from None
    finally:
        if db is not None:
            db.close()
