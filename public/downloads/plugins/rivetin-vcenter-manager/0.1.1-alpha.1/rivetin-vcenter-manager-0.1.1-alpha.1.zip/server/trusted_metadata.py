"""FW011 metadata validation. Ordinary business input never grants authority."""
import copy
import hashlib
import base64
import re
from datetime import datetime
from urllib.parse import urlsplit

from .operation_ledger import canonical, operation_id, require
from .resource_scope import identity

ROOT_PURPOSES = {
    'vmware.cluster.create': frozenset({'Datacenter'}),
    'vmware.alarm.read': frozenset({'Datacenter', 'Folder'}),
    'vmware.alarm.acknowledge': frozenset({'Datacenter', 'Folder'}),
    'vmware.alarm.reset': frozenset({'Datacenter', 'Folder'}),
}


def exact(value, required):
    require(isinstance(value, dict) and set(value) == set(required), 'VC_OPERATION_BINDING_INVALID')


def label(value, maximum=128):
    require(isinstance(value, str) and 0 < len(value) <= maximum and not any(ord(c) < 32 or ord(c) == 127 for c in value), 'VC_OPERATION_BINDING_INVALID')
    return value


def roots_request(roots):
    require(isinstance(roots, list) and len(roots) <= 32, 'VC_PERMISSION_DENIED')
    normalized, seen = [], set()
    for row in roots:
        exact(row, ('objectType', 'objectId', 'purposes'))
        key = {name: row[name] for name in ('objectType', 'objectId')}
        marker = identity(key)
        require(marker not in seen, 'VC_PERMISSION_DENIED'); seen.add(marker)
        purposes = row['purposes']
        require(isinstance(purposes, list) and 0 < len(purposes) <= 8 and all(isinstance(p, str) for p in purposes), 'VC_PERMISSION_DENIED')
        require(len(set(purposes)) == len(purposes) and all(p in ROOT_PURPOSES and marker[0] in ROOT_PURPOSES[p] for p in purposes), 'VC_PERMISSION_DENIED')
        normalized.append(key | {'purposes': sorted(purposes)})
    normalized.sort(key=lambda row: (row['objectType'], row['objectId']))
    require(len(canonical(normalized).encode()) <= 16384, 'VC_PERMISSION_DENIED')
    return normalized


def validate_context(context, method, payload=None, credential_inputs=None):
    """Validate authenticated runtime additions before creating a target session."""
    operation = context.get('operationContext')
    if operation is not None:
        require(method in {'prepareOperation', 'submitOperation', 'readOperation', 'refreshOperation', 'recoverOperations'}, 'VC_OPERATION_BINDING_INVALID')
        exact(operation, ('version', 'operationId', 'credentialInputBindings'))
        require(type(operation['version']) is int and operation['version'] == 1, 'VC_OPERATION_BINDING_INVALID')
        operation_id(operation['operationId'])
        if payload is not None and 'operationId' in payload:
            require(payload['operationId'] == operation['operationId'], 'VC_OPERATION_BINDING_INVALID')
        bindings = operation['credentialInputBindings']
        require(isinstance(bindings, list) and len(bindings) <= 1, 'VC_OPERATION_BINDING_INVALID')
        for binding in bindings:
            exact(binding, ('name', 'purpose', 'credentialInputVersion', 'target', 'endpoint', 'targetEvidenceSHA256', 'targetEvidence'))
            require(binding['name'] == 'hostEnrollment' and binding['purpose'] == 'vmware.host.add', 'VC_OPERATION_BINDING_INVALID')
            label(binding['credentialInputVersion']); identity(binding['target'], 'ClusterComputeResource')
            exact(binding['endpoint'], ('origin', 'trustRef')); label(binding['endpoint']['trustRef'])
            parsed = urlsplit(label(binding['endpoint']['origin'], 512))
            require(parsed.scheme == 'https' and parsed.hostname and not parsed.username and not parsed.password and not parsed.path and not parsed.query and not parsed.fragment and parsed.port in (None, 443), 'VC_OPERATION_BINDING_INVALID')
            digest = binding['targetEvidenceSHA256']
            require(isinstance(digest, str) and len(digest) == 64 and all(c in '0123456789abcdef' for c in digest), 'VC_OPERATION_BINDING_INVALID')
            evidence = target_evidence(binding['targetEvidence'])
            require(evidence['origin'] == binding['endpoint']['origin'] and evidence['trustRef'] == binding['endpoint']['trustRef'], 'VC_OPERATION_BINDING_INVALID')
            require(hashlib.sha256(canonical(evidence, max_string=32768).encode()).hexdigest() == digest, 'VC_OPERATION_BINDING_INVALID')
    roots = context.get('authorizationRoots')
    if roots is not None:
        require(method not in {'probe', 'discover', 'revalidate'}, 'VC_OPERATION_BINDING_INVALID')
        exact(roots, ('version', 'connectionId', 'instanceId', 'scopeRevision', 'roots'))
        require(type(roots['version']) is int and roots['version'] == 1 and roots['connectionId'] == context['connectionId'] and roots['instanceId'] == context['instanceId'], 'VC_OPERATION_BINDING_INVALID')
        require(type(roots['scopeRevision']) is int and roots['scopeRevision'] >= 1, 'VC_OPERATION_BINDING_INVALID')
        if payload is not None:
            require(roots['scopeRevision'] == payload.get('scopeRevision'), 'VC_OPERATION_SCOPE_CHANGED')
        require(isinstance(roots['roots'], list) and len(roots['roots']) <= 32, 'VC_PERMISSION_DENIED')
        stripped = []
        for row in roots['roots']:
            exact(row, ('objectType', 'objectId', 'grantId', 'grantVersion', 'purposes'))
            operation_id(row['grantId']); label(row['grantVersion'])
            stripped.append({name: row[name] for name in ('objectType', 'objectId', 'purposes')})
        roots_request(stripped)
    if credential_inputs is not None:
        require(method == 'submitOperation' and operation is not None and len(operation['credentialInputBindings']) == 1, 'VC_OPERATION_BINDING_INVALID')
        exact(credential_inputs, ('hostEnrollment',))
        exact(credential_inputs['hostEnrollment'], ('username', 'password'))
        label(credential_inputs['hostEnrollment']['username'], 256); label(credential_inputs['hostEnrollment']['password'], 4096)
    return roots_request([{name: row[name] for name in ('objectType', 'objectId', 'purposes')} for row in roots['roots']]) if roots else []


def target_evidence(evidence):
    exact(evidence, ('version','kind','origin','trustRef','policyVersion','serverName','leafDERBase64','leafSHA256','notBefore','notAfter','observedAt','expiresAt','verification'))
    require(type(evidence['version']) is int and evidence['version'] == 1 and evidence['kind'] == 'tls-peer-leaf', 'VC_OPERATION_BINDING_INVALID')
    exact(evidence['verification'], ('mode',))
    mode = evidence['verification']['mode']
    require(mode in ('ca-hostname-and-exact-leaf', 'observed'), 'VC_OPERATION_BINDING_INVALID')
    for field in ('origin','trustRef','policyVersion','serverName'): label(evidence[field],512)
    parsed = urlsplit(evidence['origin'])
    require(parsed.hostname == evidence['serverName'], 'VC_OPERATION_BINDING_INVALID')
    dates = {}
    for field in ('notBefore','notAfter','observedAt','expiresAt'):
        value = evidence[field]
        if mode == 'observed' and field in ('notBefore', 'notAfter') and value is None:
            continue
        require(isinstance(value,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z', value), 'VC_OPERATION_BINDING_INVALID')
        try: dates[field] = datetime.strptime(value, '%Y-%m-%dT%H:%M:%S.%fZ')
        except ValueError: require(False, 'VC_OPERATION_BINDING_INVALID')
    require(dates['observedAt'] < dates['expiresAt'], 'VC_OPERATION_BINDING_INVALID')
    if mode == 'ca-hostname-and-exact-leaf':
        require(dates['notBefore'] <= dates['observedAt'] and dates['expiresAt'] <= dates['notAfter'], 'VC_OPERATION_BINDING_INVALID')
    if evidence['leafDERBase64'] is None:
        require(mode == 'observed' and all(evidence[field] is None for field in ('leafSHA256', 'notBefore', 'notAfter')), 'VC_OPERATION_BINDING_INVALID')
        return copy.deepcopy(evidence)
    encoded = label(evidence['leafDERBase64'], 22000)
    try: der = base64.b64decode(encoded, validate=True)
    except (ValueError, TypeError): require(False, 'VC_OPERATION_BINDING_INVALID')
    require(64 <= len(der) <= 16384 and base64.b64encode(der).decode('ascii') == encoded, 'VC_OPERATION_BINDING_INVALID')
    # The authenticated FW verifier parses X.509. Check the exact single DER
    # envelope here too, so no suffix/chain is accepted as the leaf representation.
    require(der[0] == 0x30, 'VC_OPERATION_BINDING_INVALID')
    count = der[1] & 0x7f if der[1] & 0x80 else 0
    require(count <= 2 and (not count or der[2] != 0), 'VC_OPERATION_BINDING_INVALID')
    length = int.from_bytes(der[2:2+count], 'big') if count else der[1]
    require((not (der[1] & 0x80) or count > 0 and length >= 128) and 2+count+length == len(der), 'VC_OPERATION_BINDING_INVALID')
    require(hashlib.sha256(der).hexdigest() == evidence['leafSHA256'], 'VC_OPERATION_BINDING_INVALID')
    require(len(canonical(evidence,max_string=32768).encode()) <= 32768, 'VC_OPERATION_BINDING_INVALID')
    return copy.deepcopy(evidence)


def host_credential_definitions():
    return {'version':1,'definitions':[{'name':'hostEnrollment','purpose':'vmware.host.add','targetTypes':['ClusterComputeResource'],
        'secretSchema':{'type':'object','properties':{'username':{'type':'string','maxLength':256},'password':{'type':'string','maxLength':4096}},'required':['username','password']}}]}


def root_definitions():
    return {'version': 1, 'method': 'authorizeRoots', 'definitions': [
        {'purpose': purpose, 'rootTypes': sorted(types)} for purpose, types in ROOT_PURPOSES.items()]}


class AuthorizationRoots:
    def authorize_roots(self, roots):
        from .managed_executor import native_key
        normalized = roots_request(roots)
        for row in normalized:
            key = {name: row[name] for name in ('objectType', 'objectId')}
            self.read(key, ['name']); self.privilege(key, ['System.Read'])
            if key['objectType'] == 'Folder':
                require(native_key(self.service.rootFolder) == key, 'VC_PERMISSION_DENIED')
            else:
                current, seen = key, set()
                for _ in range(16):
                    marker = identity(current)
                    require(marker not in seen, 'VC_PERMISSION_DENIED'); seen.add(marker)
                    current = native_key(self.read(current, ['parent'])['parent'])
                    require(current['objectType'] == 'Folder', 'VC_PERMISSION_DENIED')
                    if current == native_key(self.service.rootFolder):
                        break
                else:
                    require(False, 'VC_PERMISSION_DENIED')
            if 'vmware.cluster.create' in row['purposes']:
                folder = native_key(self.read(key, ['hostFolder'])['hostFolder']); identity(folder, 'Folder')
                values = self.read(folder, ['parent', 'childType'])
                require(native_key(values['parent']) == key and any(value in values['childType'] for value in ('ComputeResource', 'vim.ComputeResource')), 'VC_PERMISSION_DENIED')
                self.privilege(folder, ['Host.Inventory.CreateCluster'])
        return {'version': 1, 'roots': copy.deepcopy(normalized),
                'requestedRootsDigest': hashlib.sha256(canonical({'version': 1, 'roots': normalized}).encode()).hexdigest()}
