"""Pinned SDK types/codec over the existing bounded TLS transport, without retries."""
import hashlib
import importlib
from pathlib import Path
import sys
import time

from .profiles import AdapterError
from .vsphere_readonly import parse_response

VENDOR = {
    'pyvmomi-8.0.3.0.1-runtime.zip': (315097, 'f3f25a89c137496386ae1889b8719357871b1ab9575c7b839e86352993c0b96b'),
    'six-1.17.0-py2.py3-none-any.whl': (11050, '4721f391ed90541fddacab5acf947aa0d3dc7d27b2e1e8eda2be8970586c3274')
}
SDK_READ = frozenset({'QueryConfigOption', 'RetrieveServiceContent', 'RetrievePropertiesEx', 'ContinueRetrievePropertiesEx', 'CancelRetrievePropertiesEx', 'HasUserPrivilegeOnEntities', 'QueryEvents', 'QueryPerf', 'QueryPerfProviderSummary', 'QueryAvailablePerfMetric', 'SearchDatastore_Task', 'CreateCollectorForEvents', 'DestroyCollector'})
SDK_WRITE = frozenset({'MountToolsInstaller', 'CreateSnapshot_Task', 'RevertToSnapshot_Task', 'RemoveSnapshot_Task', 'CreateClusterEx','PowerOnVM_Task', 'PowerOffVM_Task', 'SuspendVM_Task', 'ResetVM_Task', 'ShutdownGuest', 'RebootGuest',
                       'ReconfigVM_Task', 'RelocateVM_Task', 'CloneVM_Task', 'CreateVM_Task', 'Destroy_Task', 'MarkAsTemplate', 'MarkAsVirtualMachine',
                       'ReconfigureComputeResource_Task', 'AddPortGroup', 'UpdatePortGroup', 'RemovePortGroup',
                       'EnterMaintenanceMode_Task', 'ExitMaintenanceMode_Task', 'Rename_Task',
                       'AddVirtualSwitch', 'UpdateVirtualSwitch', 'RemoveVirtualSwitch', 'AddVirtualNic', 'UpdateVirtualNic', 'RemoveVirtualNic', 'AcknowledgeAlarm', 'SetAlarmStatus', 'AddHost_Task'})


def load_sdk(code_directory):
    root = Path(code_directory)
    if not root.is_absolute() or not root.is_dir() or root.is_symlink():
        raise AdapterError('VC_SDK_INTEGRITY_FAILED')
    if not (root / 'vendor').is_dir() or (root / 'vendor').is_symlink():
        raise AdapterError('VC_SDK_INTEGRITY_FAILED')
    archives = []
    for name, (length, digest) in VENDOR.items():
        path = root / 'vendor' / name
        if path.is_symlink() or not path.is_file() or path.stat().st_nlink != 1 or path.stat().st_size != length or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise AdapterError('VC_SDK_INTEGRITY_FAILED')
        archives.append(str(path))
    # Never borrow an SDK/six already loaded from global site-packages or another release.
    for name, archive in (('pyVmomi', archives[0]), ('six', archives[1])):
        loaded = sys.modules.get(name)
        if loaded is not None and not str(getattr(loaded, '__file__', '')).startswith(archive + '/') and not str(getattr(loaded, '__file__', '')).startswith(archive + '\\'):
            raise AdapterError('VC_SDK_INTEGRITY_FAILED')
    previous = list(sys.path)
    try:
        sys.path[:0] = archives
        package = importlib.import_module('pyVmomi')
        support = importlib.import_module('pyVmomi.VmomiSupport')
        soap = importlib.import_module('pyVmomi.SoapAdapter')
    finally:
        sys.path[:] = previous
    return package, support, soap


def create_stub(code_directory, transport, api_version, deadline, *, monotonic=time.monotonic):
    package, support, soap = load_sdk(code_directory)
    normalized = api_version + '.0' * (4 - len(api_version.split('.')))
    version = support.versionMap.get('vim25/' + api_version) or support.versionMap.get('vim25/' + normalized)
    if version is None:
        raise AdapterError('VC_VERSION_UNSUPPORTED')

    class TypedStub(soap.SoapStubAdapterBase):
        def __init__(self):
            super().__init__(version)
            self.requestContext = {}

        def _versions(self, value, depth=0):
            if depth > 12:
                raise AdapterError('VC_RESPONSE_INVALID')
            if isinstance(value, package.VmomiSupport.ManagedObject):
                if value._stub is not self:
                    raise AdapterError('VC_REFERENCE_INVALID')
            elif isinstance(value, package.VmomiSupport.DataObject):
                for prop in value._GetPropertyList():
                    item = getattr(value, prop.name)
                    if item is None or isinstance(item, list) and not item:
                        continue
                    if not support.IsChildVersion(self.version, prop.version):
                        raise AdapterError('VC_VERSION_UNSUPPORTED')
                    self._versions(item, depth + 1)
            elif isinstance(value, list):
                if len(value) > 2000:
                    raise AdapterError('VC_INVENTORY_LIMIT')
                for item in value:
                    self._versions(item, depth + 1)

        def InvokeAccessor(self, mo, info):
            # All reads must use explicit, bounded PropertyCollector specifications.
            raise AdapterError('VC_OPERATION_UNSUPPORTED')

        def InvokeMethod(self, mo, info, args):
            if info.wsdlName not in SDK_READ | SDK_WRITE:
                raise AdapterError('VC_OPERATION_UNSUPPORTED')
            cleanup = info.wsdlName == 'DestroyCollector'
            if cleanup and (type(mo) is not package.vim.event.EventHistoryCollector or mo._stub is not self):
                raise AdapterError('VC_REFERENCE_INVALID')
            for value in args:
                self._versions(value)
            remaining = deadline - monotonic()
            if remaining <= 0 and not cleanup:
                raise AdapterError('VC_TIMEOUT')
            body = self.SerializeRequest(mo, info, args)
            if len(body) > 4 * 1024 * 1024:
                raise AdapterError('VC_RESPONSE_INVALID')
            # Exactly one transport invocation. No SmartConnect or session retry layer.
            data = transport.sdk_soap(info.wsdlName, transport.path, api_version, body, 3 if cleanup else min(remaining, 15))
            if not cleanup and monotonic() >= deadline:
                raise AdapterError('VC_TIMEOUT')
            try:
                parse_response(data, info.wsdlName)
            except AdapterError as error:
                if error.code not in {'VC_SOAP_FAULT', 'VC_AUTHENTICATION_FAILED', 'VC_PERMISSION_DENIED'}:
                    raise
                # A well-formed, bounded native fault still needs its SDK type.
            result = soap.SoapResponseDeserializer(self).Deserialize(data, info.result)
            if not cleanup and monotonic() >= deadline:
                raise AdapterError('VC_TIMEOUT')
            if isinstance(result, package.vmodl.MethodFault):
                raise result
            return result

    return package, TypedStub()
