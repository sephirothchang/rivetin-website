"""Bounded SOAP inventory business core.

The caller supplies an already authorized, origin-bound transport. This module
does not acquire secrets, establish trust, open sockets or implement FW RPC.
"""
import re
import time
from datetime import datetime, timezone
from xml.etree import ElementTree as ET

from .profiles import AdapterError, adaptation, choose_profile
from .inventory_diagnostics import annotate

VIM = "urn:vim25"
SOAP = "http://schemas.xmlsoap.org/soap/envelope/"
NS = {"v": VIM, "s": SOAP}
METHODS = frozenset({"RetrieveServiceContent", "CreateContainerView", "RetrievePropertiesEx", "ContinueRetrievePropertiesEx", "CancelRetrievePropertiesEx", "DestroyView",
                     "CreatePropertyCollector", "WaitForUpdatesEx", "DestroyPropertyCollector"})
KINDS = frozenset({"Folder", "Datacenter", "ComputeResource", "ClusterComputeResource", "HostSystem", "VirtualMachine", "Datastore"})
PATHS = {
    "Folder": ("name", "parent"), "Datacenter": ("name", "parent"),
    "ComputeResource": ("name", "parent", "host"),
    "HostSystem": ("name", "parent", "runtime.connectionState", "hardware.systemInfo.uuid"),
    "VirtualMachine": ("name", "parent", "runtime.host"),
    "Datastore": ("name", "parent", "summary.capacity", "summary.freeSpace"),
}


def text(value, limit=512):
    if not isinstance(value, str) or not value or len(value) > limit or any(ord(char) < 32 for char in value):
        raise AdapterError("VC_RESPONSE_INVALID")
    return value


def ref(value, expected=None):
    if value is None or not re.fullmatch(r"[A-Za-z][A-Za-z0-9]{0,79}", value.get("type", "")):
        raise AdapterError("VC_REFERENCE_INVALID")
    identifier = value.text or ""
    ordinary = re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", identifier)
    session_view = value.get("type") == "ContainerView" and re.fullmatch(r"session\[[0-9a-fA-F-]{36}\][0-9a-fA-F-]{36}", identifier)
    if not ordinary and not session_view:
        raise AdapterError("VC_REFERENCE_INVALID")
    if expected and value.get("type") != expected:
        raise AdapterError("VC_REFERENCE_INVALID")
    return {"objectType": value.get("type"), "objectId": value.text}


def sub(parent, tag, value=None, **attrs):
    element = ET.SubElement(parent, tag, attrs)
    if value is not None:
        element.text = str(value)
    return element


def envelope(method, target, fields=None):
    if method not in METHODS:
        raise AdapterError("VC_OPERATION_UNSUPPORTED")
    root = ET.Element("{%s}Envelope" % SOAP)
    body = ET.SubElement(root, "{%s}Body" % SOAP)
    action = ET.SubElement(body, method, {"xmlns": VIM})
    sub(action, "_this", target["objectId"], type=target["objectType"])
    if fields:
        fields(action)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


class _SoapTreeBuilder(ET.TreeBuilder):
    def doctype(self, name, pubid, system):
        # Reject DTDs after XML encoding detection, including their entity declarations.
        raise AdapterError("VC_XML_REFUSED")


def _parse_response(data, method, diagnostic_stage):
    if not isinstance(data, bytes) or len(data) > 4 * 1024 * 1024:
        raise AdapterError("VC_XML_REFUSED")
    try:
        root = ET.fromstring(data, parser=ET.XMLParser(target=_SoapTreeBuilder()))
    except (ET.ParseError, ValueError, LookupError):
        raise AdapterError("VC_RESPONSE_INVALID") from None
    if root.tag != "{%s}Envelope" % SOAP or len(list(root.iter())) > 100000:
        raise AdapterError("VC_RESPONSE_INVALID")
    children = list(root)
    if [node.tag for node in children] not in (["{%s}Body" % SOAP], ["{%s}Header" % SOAP, "{%s}Body" % SOAP]):
        raise AdapterError('VC_RESPONSE_INVALID')
    body = children[-1]
    if len(list(body)) != 1:
        raise AdapterError('VC_RESPONSE_INVALID')
    payload = list(body)[0]
    data_response_fields = set()
    if method == 'RetrievePropertiesEx' and payload.tag == '{%s}RetrievePropertiesExResponse' % VIM:
        # The SDK delegates payload decoding to SoapDeserializer. This scalar
        # HA field is data within a typed cluster configuration, not another
        # response envelope. Keep the exception restricted to its exact paths.
        for prop in payload.findall('v:returnval/v:objects/v:propSet', NS):
            value = prop.find('v:val', NS)
            if prop.findtext('v:name', namespaces=NS) != 'configurationEx' or value is None:
                continue
            kind = value.get('{http://www.w3.org/2001/XMLSchema-instance}type', '').split(':')[-1]
            if kind != 'ClusterConfigInfoEx':
                continue
            for path in ('v:dasConfig/v:defaultVmSettings/v:isolationResponse', 'v:dasVmConfig/v:dasSettings/v:isolationResponse'):
                for node in value.findall(path, NS):
                    if len(node) == 0 and node.text in ('none', 'powerOff', 'shutdown', 'clusterIsolationResponse'):
                        data_response_fields.add(node)
    # The pinned SDK starts a new decoder on *any* tag ending in Response.
    # Guard the complete tree it receives, including Header/Envelope siblings.
    structural = {"{%s}%s" % (SOAP, name) for name in ('Envelope', 'Body', 'Fault')}
    for node in root.iter():
        if node is not payload and node.tag.endswith('Response') and node not in data_response_fields:
            raise AdapterError('VC_RESPONSE_INVALID')
        if node not in (root, body, payload) and node.tag in structural:
            raise AdapterError('VC_RESPONSE_INVALID')
    fault = payload if payload.tag == '{%s}Fault' % SOAP else None
    if fault is not None:
        detail = fault.find("detail")
        types = {node.tag.rsplit("}", 1)[-1] for node in detail} if detail is not None else set()
        fault_kind = None
        if detail is not None and len(detail) == 1 and detail[0].tag.startswith('{%s}' % VIM):
            fault_kind = detail[0].tag[len(VIM) + 2:]
            if fault_kind.endswith('Fault') and fault_kind != 'RuntimeFault':
                fault_kind = fault_kind[:-5]
        if any("NotAuthenticated" in name or "InvalidLogin" in name for name in types):
            raise annotate(AdapterError("VC_AUTHENTICATION_FAILED"), diagnostic_stage, fault=fault_kind)
        if any("NoPermission" in name for name in types):
            raise annotate(AdapterError("VC_PERMISSION_DENIED"), diagnostic_stage, fault=fault_kind)
        raise annotate(AdapterError("VC_SOAP_FAULT"), diagnostic_stage, fault=fault_kind)
    result = payload if payload.tag == '{%s}%sResponse' % (VIM, method) else None
    if result is None:
        raise AdapterError("VC_RESPONSE_INVALID")
    return result


def parse_response(data, method, *, diagnostic_stage=1):
    try:
        return _parse_response(data, method, diagnostic_stage)
    except AdapterError as error:
        annotate(error, diagnostic_stage)
        raise


class ReadOnlyConnector:
    property_paths = PATHS
    resource_kinds = KINDS
    optional_properties = frozenset()

    def __init__(self, transport, max_objects=2000, max_pages=20, max_calls=40, seconds=60):
        if not (1 <= max_objects <= 2000 and 1 <= max_pages <= 20 and 1 <= max_calls <= 40 and 0 < seconds <= 60):
            raise AdapterError("VC_BUDGET_EXCEEDED")
        self.transport = transport
        self.max_objects, self.max_pages, self.max_calls = max_objects, max_pages, max_calls
        self.deadline = time.monotonic() + seconds
        self.calls = 0
        self.service = None
        self.native_pages = 0
        self.cleanup_errors = []
        self.config = adaptation("vc8-modern")
        self.config["soapVersion"] = "2.0"  # anonymous baseline before version negotiation

    def call(self, method, target, fields=None, cleanup=False):
        remaining = self.deadline - time.monotonic()
        if not cleanup and (remaining <= 0 or self.calls >= self.max_calls):
            raise AdapterError("VC_BUDGET_EXCEEDED")
        self.calls += 1
        timeout = min(self.config["timeoutMs"] / 1000, remaining) if not cleanup else 3
        try:
            data = self.transport.soap(method, self.config["soapBase"], self.config["soapVersion"], envelope(method, target, fields), timeout)
            return parse_response(data, method, diagnostic_stage=4 if cleanup else 1)
        except AdapterError as error:
            annotate(error, 4 if cleanup else 1)
            raise

    def service_content(self):
        result = self.call("RetrieveServiceContent", {"objectType": "ServiceInstance", "objectId": "ServiceInstance"})
        value = result.find("v:returnval", NS)
        if value is None:
            raise AdapterError("VC_RESPONSE_INVALID")
        about = value.find("v:about", NS)
        if about is None:
            raise AdapterError("VC_RESPONSE_INVALID")
        keys = {"apiType", "version", "build", "apiVersion", "instanceUuid", "fullName"}
        facts = {node.tag.rsplit("}", 1)[-1]: text(node.text) for node in about if node.tag.rsplit("}", 1)[-1] in keys}
        if any(key not in facts for key in ("apiType", "version", "build", "apiVersion")):
            raise AdapterError("VC_RESPONSE_INVALID")
        self.service = {"about": facts}
        for key, kind in (("rootFolder", "Folder"), ("viewManager", "ViewManager"), ("propertyCollector", "PropertyCollector"), ("sessionManager", "SessionManager")):
            self.service[key] = ref(value.find("v:" + key, NS), kind)
        version = facts["apiVersion"]
        if not re.fullmatch(r"[78]\.\d+(?:\.\d+){0,2}", version):
            raise AdapterError("VC_VERSION_UNSUPPORTED")
        self.config["soapVersion"] = version
        return self.service

    def probe(self, manual=None):
        if manual is not None:
            self.config = adaptation(manual.get("profile"), manual)
        facts = self.service_content()["about"]
        profile = choose_profile(facts)
        self.config = adaptation(profile, manual)
        # REST is unknown until an authenticated, read-only endpoint is observed.
        return {"server": dict(facts), "profile": profile, "selectedAdaptation": dict(self.config),
                "observedApis": ["soap"], "authentication": "unknown", "authorization": "unknown",
                "capabilities": {"inventory": "unknown", "vm.write": "unsupported", "network.write": "unsupported", "storage.write": "unsupported"},
                "observedAt": datetime.now(timezone.utc).isoformat()}

    def inventory_version(self):
        """Read the current inventory version with one WaitForUpdatesEx round trip.

        The version is a PropertyCollector update counter, so it changes for any
        inventory mutation. This never traverses inventory objects or creates a
        view; the throw-away collector is destroyed on every path.
        """
        service = self.service or self.service_content()
        created = self.call("CreatePropertyCollector", service["propertyCollector"])
        node = created.find("v:returnval", NS)
        if node is None or node.get("type") != "PropertyCollector":
            raise AdapterError("VC_RESPONSE_INVALID")
        identifier = node.text or ""
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_\-\[\]]{0,255}", identifier):
            raise AdapterError("VC_RESPONSE_INVALID")
        collector = {"objectType": "PropertyCollector", "objectId": identifier}
        primary = None
        try:
            result = self.call("WaitForUpdatesEx", collector, lambda action: sub(action, "maxWaitSeconds", "0"))
            value = result.find("v:returnval", NS)
            if value is None:
                raise AdapterError("VC_RESPONSE_INVALID")
            return text(value.findtext("v:version", namespaces=NS), 128)
        except Exception as error:
            primary = error
            raise
        finally:
            try:
                self.call("DestroyPropertyCollector", collector, cleanup=True)
            except Exception as error:
                self.cleanup_errors.append(error.code if isinstance(error, AdapterError) else "VC_CLEANUP_FAILED")
                if primary is None:
                    raise

    def parse_property(self, name, value):
        if name in ("parent", "runtime.host"):
            return None if value.get("{http://www.w3.org/2001/XMLSchema-instance}nil") == "true" else ref(value)
        if name == "host":
            return [ref(node, "HostSystem") for node in value]
        if name in ("summary.capacity", "summary.freeSpace"):
            number = value.text or ""
            if not re.fullmatch(r"\d{1,20}", number):
                raise AdapterError("VC_RESPONSE_INVALID")
            return int(number)
        if name in ("name", "runtime.connectionState", "hardware.systemInfo.uuid"):
            return text(value.text)
        raise AdapterError("VC_RESPONSE_INVALID")

    def collect(self, first_fields, records=None):
        service = self.service or self.service_content()
        token, primary_error = None, None
        records = {} if records is None else records
        seen_tokens = set()
        try:
            for page in range(self.max_pages - self.native_pages):
                if page == 0:
                    response = self.call("RetrievePropertiesEx", service["propertyCollector"], first_fields)
                else:
                    response = self.call("ContinueRetrievePropertiesEx", service["propertyCollector"], lambda action: sub(action, "token", token))
                self.native_pages += 1
                value = response.find("v:returnval", NS)
                if value is None:
                    raise AdapterError("VC_INVENTORY_INCOMPLETE")
                # Retain this page's continuation before object validation can fail.
                next_token = value.findtext("v:token", namespaces=NS)
                token = text(next_token, 4096) if next_token else None
                if token is not None:
                    if token in seen_tokens:
                        raise AdapterError("VC_INVENTORY_INCOMPLETE")
                    seen_tokens.add(token)
                for item in value.findall("v:objects", NS):
                    identity = ref(item.find("v:obj", NS))
                    key = (identity["objectType"], identity["objectId"])
                    if identity["objectType"] not in self.resource_kinds or key in records or item.find("v:missingSet", NS) is not None:
                        raise AdapterError("VC_INVENTORY_INCOMPLETE")
                    props, seen_props = {}, set()
                    for entry in item.findall("v:propSet", NS):
                        name = entry.findtext("v:name", namespaces=NS)
                        val = entry.find("v:val", NS)
                        try:
                            if name in seen_props or val is None:
                                raise AdapterError("VC_RESPONSE_INVALID")
                            seen_props.add(name)
                            if (name in self.optional_properties or (identity["objectType"], name) in self.optional_properties) and val.get("{http://www.w3.org/2001/XMLSchema-instance}nil") == "true":
                                continue
                            props[name] = self.parse_property(name, val)
                        except AdapterError as error:
                            annotate(error, 2, field=name, kind=identity['objectType'], value=val)
                            raise
                    records[key] = {"key": identity, "properties": props}
                    if len(records) > self.max_objects:
                        raise AdapterError("VC_INVENTORY_LIMIT")
                if token is None:
                    break
            else:
                raise AdapterError("VC_INVENTORY_LIMIT")
        except Exception as error:
            primary_error = error
            raise
        finally:
            try:
                if token:
                    self.call("CancelRetrievePropertiesEx", service["propertyCollector"], lambda action: sub(action, "token", token), cleanup=True)
            except Exception as error:
                self.cleanup_errors.append(error.code if isinstance(error, AdapterError) else "VC_CLEANUP_FAILED")
                if primary_error is None:
                    raise
        return records

    def property_spec(self, action):
        spec = sub(action, "specSet")
        for kind, paths in self.property_paths.items():
            prop = sub(spec, "propSet"); sub(prop, "type", kind)
            for path in paths:
                sub(prop, "pathSet", path)
        sub(sub(action, "options"), "maxObjects", self.config["batchLimit"])
        return spec

    def snapshot(self, records):
        return {"source": "vsphere-soap", "complete": True, "visibleScope": "current authenticated account",
                "observedAt": datetime.now(timezone.utc).isoformat(), "about": dict(self.service["about"]), "objects": list(records.values())}

    def inventory(self):
        service = self.service or self.service_content()
        def view_fields(action):
            sub(action, "container", service["rootFolder"]["objectId"], type="Folder")
            for kind in self.property_paths:
                sub(action, "type", kind)
            sub(action, "recursive", "true")
        view = ref(self.call("CreateContainerView", service["viewManager"], view_fields).find("v:returnval", NS), "ContainerView")
        primary_error = None
        try:
            def first_fields(action):
                spec = self.property_spec(action)
                obj = sub(spec, "objectSet"); sub(obj, "obj", view["objectId"], type="ContainerView"); sub(obj, "skip", "true")
                traversal = sub(obj, "selectSet", **{"xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance", "xsi:type": "TraversalSpec"})
                sub(traversal, "name", "viewTraversal"); sub(traversal, "type", "ContainerView"); sub(traversal, "path", "view"); sub(traversal, "skip", "false")
            records = self.collect(first_fields)
        except Exception as error:
            primary_error = error
            raise
        finally:
            try:
                self.call("DestroyView", view, cleanup=True)
            except Exception as error:
                self.cleanup_errors.append(error.code if isinstance(error, AdapterError) else "VC_CLEANUP_FAILED")
                if primary_error is None:
                    raise
        return self.snapshot(records)

    @staticmethod
    def clusters(snapshot):
        records = {(row["key"]["objectType"], row["key"]["objectId"]): row for row in snapshot["objects"]}
        result = []
        for identity, row in records.items():
            if identity[0] != "ClusterComputeResource":
                continue
            parent = row["properties"].get("parent")
            visited = set()
            while parent and parent["objectType"] != "Datacenter":
                key = (parent["objectType"], parent["objectId"])
                if key in visited or key not in records:
                    raise AdapterError("VC_INVENTORY_INCOMPLETE")
                visited.add(key); parent = records[key]["properties"].get("parent")
            if not parent or (parent["objectType"], parent["objectId"]) not in records:
                raise AdapterError("VC_INVENTORY_INCOMPLETE")
            dc = records[(parent["objectType"], parent["objectId"])]
            result.append({"key": row["key"], "name": text(row["properties"].get("name")), "parent": {"key": parent, "name": text(dc["properties"].get("name"))}})
        return result
