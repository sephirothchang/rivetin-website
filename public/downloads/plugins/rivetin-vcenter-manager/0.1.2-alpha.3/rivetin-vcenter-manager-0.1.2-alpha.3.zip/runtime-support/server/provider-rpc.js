import { validateBusinessMethod, validateProviderExtensions, validateBusinessBindings } from './provider-extensions.js';
import tls from 'node:tls';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { bounded, canonical, fields, integer, digest, identifier, schemaDefinition, validateSchema, ConnectionError, safeErrorCode, fail, parseConnectionJson } from '../shared/provider-connections.js';
import { validateRpcBinding } from './provider-transport-policy.js';
import { emitRpcDiagnostic } from './provider-rpc-diagnostics.js';
import { observeTlsSocket } from './connection-observation.js';

const hash = value => createHash('sha256').update(canonical(value)).digest('hex');
const methods = ['probe', 'discover', 'revalidate'];
export function createProviderRpc({ host = '127.0.0.1', port, serverName, cert, key, serverLeafSHA256,
  identity, authorizeBinding, businessMethods = {}, credentialInputs, authorizationRoots, clock = Date.now, timeoutMs = 15000, diagnosticSink } = {}) {
  if (host !== '127.0.0.1' || !cert || !key || typeof authorizeBinding !== 'function') fail('CONNECTION_SCHEMA_INVALID');
  integer(port, 1, 65535); integer(timeoutMs, 1, 15000);
  fields(identity, ['providerId', 'pluginId', 'packageDigest', 'connectorRelease']);
  const catalog = bounded(businessMethods, 32768);
  if (Object.keys(catalog).length > 12) fail('CONNECTION_LIMIT_EXCEEDED');
  for (const [name, definition] of Object.entries(catalog)) {
    identifier(name); if (methods.includes(name)) fail('CONNECTION_SCHEMA_INVALID');
    validateBusinessMethod(definition);
    if (definition.responseBytes !== undefined) integer(definition.responseBytes, 1024, 4 * 1024 ** 2);
  }
  const descriptor = { businessMethods: catalog, ...(credentialInputs === undefined ? {} : { credentialInputs }), ...(authorizationRoots === undefined ? {} : { authorizationRoots }) };
  validateProviderExtensions(descriptor);
  let inflight = 0;
  function connect(deadline, signal) {
    return new Promise((resolve, reject) => {
      if (signal?.aborted || deadline <= clock()) { reject(new ConnectionError('CONNECTION_TIMEOUT')); return; }
      const socket = tls.connect({ host, port, servername: serverName, cert, key, rejectUnauthorized: false, minVersion: 'TLSv1.2' });
      const timer = setTimeout(() => done(new ConnectionError('CONNECTION_TIMEOUT')), Math.max(1, deadline - clock()));
      const abort = () => done(new ConnectionError('CONNECTION_TIMEOUT'));
      const error = () => done(new ConnectionError('CONNECTION_PROVIDER_UNAVAILABLE'));
      function done(failure) {
        clearTimeout(timer); signal?.removeEventListener('abort', abort); socket.removeListener('error', error);
        if (failure) { socket.destroy(); reject(failure); } else resolve(socket);
      }
      signal?.addEventListener('abort', abort, { once: true }); socket.once('error', error);
      socket.once('secureConnect', () => {
        observeTlsSocket(socket,`${host}:${port}`,serverLeafSHA256);
        done();
      });
    });
  }
  return Object.freeze({
    async verifyPeer() { const socket = await connect(clock() + timeoutMs); socket.on('error', () => {}); socket.end(); return true; },
    async call({ method, binding, payload, secret, credentialInputs: inputSecrets, signal, deadlineMs, includeMetadata = false }) {
      const business = Object.hasOwn(catalog, method) ? catalog[method] : null;
      const responseLimit = business?.responseBytes || 256 * 1024;
      if (!methods.includes(method) && !business) fail('CONNECTION_MODE_UNSUPPORTED'); validateRpcBinding(binding);
      for (const field of Object.keys(identity)) if (binding[field] !== identity[field]) fail('CONNECTION_PERMISSION_DENIED');
      if (method !== 'probe' && !binding.instanceId) fail('CONNECTION_INSTANCE_CHANGED');
      if (binding.capability !== (business?.capability || 'connection.read')) fail('CONNECTION_PERMISSION_DENIED');
      if (business) { if (!binding.connectionId) fail('CONNECTION_PROOF_MISMATCH'); validateSchema(payload, business.schema); }
      else fields(payload, method === 'probe' ? ['candidate'] : method === 'discover' ? ['instanceId', 'adaptation', 'filter', 'cursor', 'limit'] : ['instanceId', 'selected', 'candidate', 'adaptation']);
      if (payload.connectionId !== undefined && payload.connectionId !== binding.connectionId || payload.instanceId !== undefined && payload.instanceId !== binding.instanceId) fail('CONNECTION_PROOF_MISMATCH');
      if (business) validateBusinessBindings({ definition: business, descriptor, binding, payload, credentialInputs: inputSecrets });
      else if (binding.operationContext !== undefined || binding.authorizationRoots !== undefined || inputSecrets !== undefined) fail('CONNECTION_MODE_UNSUPPORTED');
      bounded(secret, 16384); bounded(payload, 65536);
      const began = clock(), deadline = deadlineMs === undefined ? began + timeoutMs : Math.min(integer(deadlineMs, 1), began + timeoutMs);
      if (deadline <= began) fail('CONNECTION_TIMEOUT');
      if (inflight >= 4) fail('CONNECTION_BUSY'); inflight++;
      let diagnosticCode = 'RPC_AUTHORIZATION', requestId;
      const measurements = { responseLimitBytes: responseLimit };
      try {
        if (await authorizeBinding(structuredClone(binding), method, binding.capability, { deadline, signal }) !== true) fail('CONNECTION_PERMISSION_DENIED');
        diagnosticCode = 'RPC_CALL_EXPIRED';
        if (signal?.aborted || clock() >= deadline) fail('CONNECTION_TIMEOUT');
        diagnosticCode = 'RPC_REQUEST';
        const request = { version: 1, id: randomUUID(), nonce: randomBytes(32).toString('hex'), method,
          binding: structuredClone(binding), deadline, payloadJson: canonical(bounded(payload)), secret: bounded(secret, 16384), ...(inputSecrets === undefined ? {} : { credentialInputs: bounded(inputSecrets, 16384) }) };
        requestId = request.id;
        const bindingDigest = hash(request.binding), requestDigest = hash({ ...request, secret: null, ...(inputSecrets === undefined ? {} : { credentialInputs: null }) });
        request.requestDigest = requestDigest;
        const body = Buffer.from(canonical(request)); if (body.length > 96 * 1024) fail('CONNECTION_LIMIT_EXCEEDED');
        diagnosticCode = 'RPC_CONNECT';
        const socket = await connect(deadline, signal);
        try {
          const result = await new Promise((resolve, reject) => {
            let buffer = Buffer.alloc(0), expected = null, settled = false;
            const timer = setTimeout(() => finish(new ConnectionError('CONNECTION_TIMEOUT'), undefined, 'RPC_RESPONSE_TIMEOUT'), Math.max(1, deadline - clock()));
            const abort = () => finish(new ConnectionError('CONNECTION_TIMEOUT'), undefined, 'RPC_RESPONSE_TIMEOUT');
            function finish(error, value, reason) {
              if (settled) return; settled = true; clearTimeout(timer); signal?.removeEventListener('abort', abort);
              if (reason) diagnosticCode = reason;
              socket.destroy(); if (error) reject(error); else resolve(value);
            }
            signal?.addEventListener('abort', abort, { once: true });
            socket.on('error', () => finish(new ConnectionError('CONNECTION_PROVIDER_UNAVAILABLE'), undefined, 'RPC_RESPONSE_IO'));
            socket.on('close', () => finish(new ConnectionError('CONNECTION_PROVIDER_UNAVAILABLE'), undefined, 'RPC_RESPONSE_IO'));
            socket.on('data', chunk => {
              if (settled) return;
              try {
                diagnosticCode = 'RPC_FRAME_BUFFER_LIMIT';
                measurements.receivedBytes = buffer.length + chunk.length;
                if (buffer.length + chunk.length > responseLimit + 4) fail('CONNECTION_LIMIT_EXCEEDED');
                buffer = Buffer.concat([buffer, chunk]);
                if (expected === null && buffer.length >= 4) {
                  diagnosticCode = 'RPC_FRAME_HEADER'; expected = buffer.readUInt32BE(0); measurements.expectedBytes = expected; integer(expected, 2, responseLimit);
                }
                if (expected !== null && buffer.length >= expected + 4) {
                  diagnosticCode = 'RPC_FRAME_LENGTH';
                  if (buffer.length !== expected + 4) fail('CONNECTION_RESPONSE_INVALID');
                  diagnosticCode = 'RPC_PARSE';
                  finish(null, parseConnectionJson(buffer.subarray(4).toString('utf8'), responseLimit));
                }
              } catch { finish(new ConnectionError('CONNECTION_RESPONSE_INVALID')); }
            });
            const header = Buffer.alloc(4); header.writeUInt32BE(body.length); socket.write(Buffer.concat([header, body]));
          });
          diagnosticCode = 'RPC_ENVELOPE_FIELDS';
          fields(result, ['version', 'id', 'nonce', 'method', 'bindingDigest', 'requestDigest', 'observedAt', 'status'], ['data', 'errorCode', 'credentialLease']);
          for (const [code, matches] of [['RPC_VERSION', result.version === 1], ['RPC_ID', result.id === request.id],
            ['RPC_NONCE', result.nonce === request.nonce], ['RPC_METHOD', result.method === method],
            ['RPC_BINDING_DIGEST', result.bindingDigest === bindingDigest], ['RPC_REQUEST_DIGEST', result.requestDigest === requestDigest]]) {
            diagnosticCode = code; if (!matches) fail('CONNECTION_RESPONSE_INVALID');
          }
          diagnosticCode = 'RPC_OBSERVED_TYPE';
          if (!Number.isSafeInteger(result.observedAt)) fail('CONNECTION_RESPONSE_INVALID');
          measurements.observedOffsetMs = result.observedAt - began;
          diagnosticCode = 'RPC_OBSERVED_OLD';
          if (result.observedAt < began - 1000) fail('CONNECTION_RESPONSE_INVALID');
          diagnosticCode = 'RPC_OBSERVED_FUTURE';
          if (result.observedAt > deadline) fail('CONNECTION_RESPONSE_INVALID');
          diagnosticCode = 'RPC_DEADLINE';
          const receivedAt = clock(); measurements.elapsedMs = receivedAt - began; measurements.remainingMs = deadline - receivedAt;
          if (receivedAt >= deadline) fail('CONNECTION_RESPONSE_INVALID');
          if (result.status === 'error') {
            diagnosticCode = 'RPC_ERROR_SHAPE';
            if (Object.hasOwn(result, 'data') || typeof result.errorCode !== 'string') fail('CONNECTION_RESPONSE_INVALID');
            diagnosticCode = 'RPC_PROVIDER_ERROR';
            fail(safeErrorCode(new ConnectionError(result.errorCode)));
          }
          diagnosticCode = 'RPC_OK_SHAPE';
          if (result.status !== 'ok' || Object.hasOwn(result, 'errorCode') || !Object.hasOwn(result, 'data')) fail('CONNECTION_RESPONSE_INVALID');
          diagnosticCode = 'RPC_LEASE';
          if (result.credentialLease !== undefined && (!business || !['retain', 'release'].includes(result.credentialLease))) fail('CONNECTION_RESPONSE_INVALID');
          diagnosticCode = 'RPC_DATA';
          const data = bounded(result.data, responseLimit);
          return includeMetadata ? { data, credentialLease: result.credentialLease || null, observedAt: result.observedAt } : data;
        } finally { socket.destroy(); body.fill(0); }
      } catch (error) {
        const failureCode = safeErrorCode(error);
        emitRpcDiagnostic({ diagnosticCode, method, requestId, failureCode, ...measurements }, diagnosticSink);
        throw new ConnectionError(failureCode);
      }
      finally { inflight--; }
    }
  });
}
