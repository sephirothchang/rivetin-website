import http from 'node:http';

export function createLocalProbeServer({ ready, backupFence, observeReady }) {
  let checking;
  const server = http.createServer(async (request, response) => {
    if (backupFence && await backupFence(request, response)) return;
    if (request.method !== 'GET' || !['/live', '/ready'].includes(request.url)) {
      response.writeHead(404).end();
      return;
    }
    let healthy = request.url === '/live';
    if (!healthy) {
      checking ||= Promise.resolve().then(ready).then(result => result === true, () => false).finally(() => { checking = null; });
      let timer;
      try {
        healthy = await Promise.race([checking, new Promise(resolve => { timer = setTimeout(() => resolve(false), 4000); })]);
      } finally {
        clearTimeout(timer);
      }
      observeReady?.(healthy);
    }
    response.writeHead(healthy ? 200 : 503, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' });
    response.end(healthy ? 'ok\n' : 'unavailable\n');
  });
  server.maxConnections = 16;
  server.setTimeout(5000, socket => socket.destroy());
  return server;
}
