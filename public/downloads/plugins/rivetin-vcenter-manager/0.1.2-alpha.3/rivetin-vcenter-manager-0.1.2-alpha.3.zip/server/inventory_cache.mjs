// Pod-side readInventory cache. vCenter inventory reads are the expensive part;
// the Pod first probes a light PropertyCollector version and only re-reads the
// full inventory when that version changed (or when a manual refresh asks for
// it). Version comparison is authoritative; the full-read TTL is only a
// reconciliation fallback so a reset/expired version cannot pin stale data.
export const INVENTORY_CACHE_TTL_MS = 60_000;
export const INVENTORY_CACHE_LIMIT = 4;
const controlKeys = ['fresh', 'refresh'];
const baseKeys = ['connectionId', 'instanceId', 'adaptation', 'selected', 'scopeRevision'];
// readInventory doubles as the entry point for the ISO/hardware/datastore
// helpers; those answers are not the inventory tree and are never cached.
const variantKeys = ['isoLookup', 'hardwareKey', 'datastoreIsoBrowse'];
function object(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}
export function isFreshInventoryRequest(request) {
  const payload = request?.payload;
  return object(payload) && (payload.fresh === true || payload.refresh === true);
}
/** A response may only be cached when it is a complete inventory of the same scope. */
export function inventoryCacheValue(value, scope) {
  return object(value) && value.connectionId === scope.connectionId && value.instanceId === scope.instanceId &&
    value.complete === true && Array.isArray(value.objects) && value.objects.length <= 2000 &&
    typeof value.observedAt === 'string' && Number.isFinite(Date.parse(value.observedAt)) &&
    object(value.capabilities);
}
export function inventoryScope(request) {
  if (request?.method !== 'readInventory') return null;
  const payload = request?.payload;
  if (!object(payload) || typeof payload.connectionId !== 'string' || !payload.connectionId ||
      typeof payload.instanceId !== 'string' || !payload.instanceId) return null;
  const keys = Object.keys(payload);
  if (variantKeys.some(key => keys.includes(key)) || keys.some(key => !baseKeys.includes(key) && !controlKeys.includes(key))) return null;
  return { connectionId: payload.connectionId, instanceId: payload.instanceId };
}
/** Remove the cache-control flags before the payload reaches the Python schema. */
export function stripInventoryControls(request) {
  const payload = request?.payload;
  if (request?.method !== 'readInventory' || !object(payload)) return request;
  if (!controlKeys.some(key => Object.hasOwn(payload, key))) return request;
  const clean = { ...payload };
  for (const key of controlKeys) delete clean[key];
  return { ...request, payload: clean };
}
function iso(ms) {
  return new Date(ms).toISOString();
}
function decorated(data, { checkedAt, changedAt, ageMs, cacheHit }) {
  return { ...data, cacheHit, checkedAt: iso(checkedAt), changedAt: iso(changedAt), ageMs };
}
export function createInventoryCache({ ttlMs = INVENTORY_CACHE_TTL_MS, maxEntries = INVENTORY_CACHE_LIMIT, clock = Date.now } = {}) {
  if (!Number.isSafeInteger(ttlMs) || ttlMs < 1_000) throw new Error('CONNECTION_SCHEMA_INVALID');
  if (!Number.isSafeInteger(maxEntries) || maxEntries < 1 || maxEntries > INVENTORY_CACHE_LIMIT) throw new Error('CONNECTION_SCHEMA_INVALID');
  const entries = new Map();
  const keyOf = scope => JSON.stringify([scope.connectionId, scope.instanceId]);
  function remember(key, entry) {
    entries.delete(key); entries.set(key, entry);
    while (entries.size > maxEntries) entries.delete(entries.keys().next().value);
  }
  return Object.freeze({
    ttlMs,
    now: clock,
    peek(scope) {
      return scope === null ? null : entries.get(keyOf(scope)) ?? null;
    },
    store(scope, data, { version = null, now = clock(), changedAt = now } = {}) {
      if (!inventoryCacheValue(data, scope)) return false;
      remember(keyOf(scope), { data, version, checkedAt: now, changedAt, fullReadAt: now });
      return true;
    },
    touch(scope, now = clock()) {
      const entry = entries.get(keyOf(scope));
      if (entry) { entry.checkedAt = now; remember(keyOf(scope), entry); }
      return entry ?? null;
    },
    seedVersion(scope, version) {
      const entry = entries.get(keyOf(scope));
      if (entry && entry.version === null) entry.version = version;
      return entry ?? null;
    },
    invalidate(scope = {}) {
      for (const key of [...entries.keys()]) {
        const [connectionId, instanceId] = JSON.parse(key);
        if ((scope.connectionId === undefined || scope.connectionId === connectionId) &&
            (scope.instanceId === undefined || scope.instanceId === instanceId)) entries.delete(key);
      }
    },
    clear() { entries.clear(); },
    size() { return entries.size; },
    cachedResponse(entry, now = clock()) {
      return { data: decorated(entry.data, { checkedAt: now, changedAt: entry.changedAt,
        ageMs: Math.max(0, now - entry.fullReadAt), cacheHit: true }), credentialLease: null, observedAt: now };
    },
    freshResponse(entry, now = clock()) {
      return { data: decorated(entry.data, { checkedAt: now, changedAt: entry.changedAt, ageMs: 0, cacheHit: false }),
        credentialLease: null, observedAt: now };
    },
  });
}
/** Ask the connector for the current inventory version (single round trip).
 * The runtime catalog is capped at twelve business methods, so the probe rides
 * on readInventory with an explicit probeVersion flag instead of a 13th method.
 * An empty string is a valid stable token: a fresh PropertyCollector with no
 * inventory changes returns no UpdateSet, and the 60s full-read TTL still
 * reconciles the cache. */
async function probeVersion(connector, request) {
  const clean = stripInventoryControls(request);
  const probe = await connector.call({ ...clean, payload: { ...clean.payload, probeVersion: true } });
  const version = probe?.data?.version;
  if (typeof version !== 'string' || version.length > 128) throw Object.assign(new Error('CONNECTION_RESPONSE_INVALID'), { code: 'CONNECTION_RESPONSE_INVALID' });
  return version;
}
/** Wrap the connector call: cached readInventory answers are version-checked. */
export function withInventoryCache(connector, cache) {
  return Object.freeze({
    async call(request) {
      if (request?.method !== 'readInventory') return connector.call(request);
      const scope = inventoryScope(request);
      const clean = stripInventoryControls(request);
      if (scope === null) return connector.call(clean);
      const now = cache.now();
      const existing = cache.peek(scope);
      // Manual refresh: no version probe at all, one full read, cache updated.
      if (isFreshInventoryRequest(request)) {
        const result = await connector.call(clean);
        if (!inventoryCacheValue(result?.data, scope)) return result;
        if (!cache.store(scope, result.data, { version: existing?.version ?? null, now, changedAt: existing?.changedAt ?? now })) return result;
        return cache.freshResponse(cache.peek(scope), now);
      }
      if (existing !== null && now - existing.fullReadAt < cache.ttlMs) {
        // Version comparison is authoritative while the fallback TTL holds.
        const version = await probeVersion(connector, request);
        if (existing.version === null) { cache.seedVersion(scope, version); cache.touch(scope, now); return cache.cachedResponse(existing, now); }
        if (version === existing.version) { cache.touch(scope, now); return cache.cachedResponse(existing, now); }
        const result = await connector.call(clean);
        if (!inventoryCacheValue(result?.data, scope)) return result;
        if (!cache.store(scope, result.data, { version, now, changedAt: now })) return result;
        return cache.freshResponse(cache.peek(scope), now);
      }
      // No cache entry (or the reconciliation TTL expired): probe the version
      // first so the next automatic round can answer from cache, then read.
      let version = existing?.version ?? null;
      if (version === null) version = await probeVersion(connector, request).catch(() => null);
      const result = await connector.call(clean);
      if (!inventoryCacheValue(result?.data, scope)) return result;
      const changedAt = existing === null ? now : (version !== null && version !== existing.version ? now : existing.changedAt);
      if (!cache.store(scope, result.data, { version, now, changedAt })) return result;
      return cache.freshResponse(cache.peek(scope), now);
    },
  });
}
