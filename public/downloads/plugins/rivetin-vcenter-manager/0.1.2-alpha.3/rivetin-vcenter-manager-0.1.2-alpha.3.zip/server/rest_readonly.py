"""Typed read-only REST inventory projection. Transport/trust remains caller-owned."""
import json
import re
import time
from datetime import datetime, timezone

from .profiles import AdapterError, adaptation

KINDS = {"datacenter": "Datacenter", "cluster": "ClusterComputeResource", "host": "HostSystem",
         "vm": "VirtualMachine", "network": "Network", "datastore": "Datastore"}


def pairs(entries):
    result = {}
    for key, value in entries:
        if key in result:
            raise AdapterError("VC_RESPONSE_INVALID")
        result[key] = value
    return result


def decode_inventory(data, kind, config):
    if kind not in KINDS or not isinstance(data, bytes) or len(data) > 4 * 1024 * 1024:
        raise AdapterError("VC_RESPONSE_INVALID")
    try:
        value = json.loads(data, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(AdapterError("VC_RESPONSE_INVALID")))
    except (ValueError, UnicodeError, RecursionError):
        raise AdapterError("VC_RESPONSE_INVALID") from None
    if config["envelope"] == "value":
        if not isinstance(value, dict) or set(value) != {"value"}:
            raise AdapterError("VC_RESPONSE_INVALID")
        value = value["value"]
    limit = 1000 if kind in {"cluster", "network"} else 2000
    if not isinstance(value, list) or len(value) > limit:
        raise AdapterError("VC_INVENTORY_LIMIT")
    items, seen = [], set()
    for row in value:
        if not isinstance(row, dict):
            raise AdapterError("VC_RESPONSE_INVALID")
        identifier, name = row.get(kind), row.get("name")
        if not isinstance(identifier, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", identifier) or identifier in seen:
            raise AdapterError("VC_REFERENCE_INVALID")
        if not isinstance(name, str) or not name or len(name) > 512 or any(ord(char) < 32 for char in name):
            raise AdapterError("VC_RESPONSE_INVALID")
        seen.add(identifier)
        items.append({"key": {"objectType": KINDS[kind], "objectId": identifier}, "name": name})
    return items


class ReadOnlyRest:
    def __init__(self, transport, profile, manual=None):
        self.transport = transport
        self.config = adaptation(profile, manual)
        self.deadline = time.monotonic() + 60
        self.calls = 0

    def read(self, kind):
        if kind not in KINDS:
            raise AdapterError("VC_OPERATION_UNSUPPORTED")
        remaining = self.deadline - time.monotonic()
        if remaining <= 0 or self.calls >= 6:
            raise AdapterError("VC_BUDGET_EXCEEDED")
        self.calls += 1
        path = self.config["restBase"] + "/vcenter/" + kind
        data = self.transport.rest_get(path, min(remaining, self.config["timeoutMs"] / 1000))
        items = decode_inventory(data, kind, self.config)
        return {"items": items, "complete": True, "visibleScope": "current authenticated account matching native list",
                "observedAt": datetime.now(timezone.utc).isoformat(),
                "observedApi": "rest-legacy" if self.config["envelope"] == "value" else "rest-modern"}
